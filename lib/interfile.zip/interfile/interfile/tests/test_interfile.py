# interfile - Interfile read and write
# Michele Scipioni
# University of Pisa, Italy
# Nov 2018, Pisa, Italy

import unittest
import interfile.Interfile as Interfile
import pickle
import os, os.path

test_dir = os.path.dirname(os.path.abspath(__file__))
ex_dir=os.path.join(test_dir,'../examples')
 
class TestInterfile(unittest.TestCase): 
    """Sequence of tests for module interfile. """ 
    def setUp(self):
        pass

    def test_listmode_parse(self):
        """Parse a simple interfile. """
        with open(os.path.join(ex_dir,'parsed_listmode.pickle'), 'rb') as handle:
            listmode_ref = pickle.load(handle)
        listmode = Interfile.load(os.path.join(ex_dir,'pet_listmode.l.hdr'))
        self.assertEqual(listmode_ref, listmode)

    def test_sinogram_parse(self):
        """Parse a simple interfile. """
        with open(os.path.join(ex_dir,'parsed_sinogram.pickle'), 'rb') as handle:
            sino_ref = pickle.load(handle)
        sino = Interfile.load(os.path.join(ex_dir,'pet_sinogram.s.hdr'))
        self.assertEqual(sino_ref, sino)


if __name__=="__main__": 
    unittest.main() 
