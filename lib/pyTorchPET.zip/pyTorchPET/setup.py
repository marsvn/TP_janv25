#from distutils.core import setup,Extension
from setuptools import setup,Extension
from Cython.Build import cythonize
from torch.utils.cpp_extension import BuildExtension, CUDAExtension

import numpy
import subprocess

gsl_include = subprocess.run("gsl-config --cflags".split(),capture_output=True,text=True).stdout.rstrip()
gsl_libs = subprocess.run("gsl-config --libs".split(),capture_output=True,text=True).stdout.rstrip()
cppflags=(gsl_include+" -O3 -DTIMING").split()
gpuflags=(gsl_include+" -O3 -DTIMING").split()
#cppflags=(gsl_include+" -O3 -DTIMING -DDEBUG_FCS").split()
#gpuflags=(gsl_include+" -O3 -DTIMING -DDEBUG_FCS").split()

all_libs=(gsl_libs+' -lnvToolsExt').split()
print('cppflags=',cppflags)
print('all_libs=',all_libs)
ext_modules=[]

setup(name='torchPETADMM',
      version='1.0.0.dev',
      description='Python interface to torch PET ADMM routines',
      author='F. C. Sureau',
      author_email='florent.sureau@cea.fr',
      ext_modules=ext_modules,
      cmdclass={
        'build_ext': BuildExtension},
      packages=['torchPETADMM','torchPETADMM.database','torchPETADMM.reconstruction',
            'torchPETADMM.models','torchPETADMM.learning','torchPETADMM.utils'],
      license='TBD',
      requires=['numpy', 'sklearn','pytorch','tqdm','PETLibs'],
      zip_safe=False,
)
#      ext_modules = cythonize(cyCASToRSino),
