"""
Created on March 2023

@author: florent.sureau
"""

import os,sys,os.path,copy
from interfile import Interfile as Interfile
import numpy as np
import PETLibs
import PETLibs.ios.CASToRSino as CASToRSino

def CASToR_load_sinograms(subject,real, doserec_object,verbose=True):
    '''
    Load additive/multiplicative correction sinograms from a CASToR data file.
    This includes attenuation, normalization (assuming a projector per LOR and
    not per bin), calibration factor (ECF, decay) for multiplicative, and scatter
    and randoms for additive factor.

    Arguments:
        - subject: subject name (string).
        - real: realization number (int, default: 0).
        - doserec_object: database descriptor (genSubDatabaseDoserecParams).
        - verbose: verbosity (bool, default: True)
    '''

    castor_df_ima,castor_df_hdr=doserec_object.get_fname_sinogram_CASToR_hdr(subject,real)
    castor_df_dir=doserec_object.get_gen_castor_dir(subject,real)

    castor_df_hdr_fpath=os.path.join(castor_df_dir,castor_df_hdr)

    return CASToRSino.CASToRLoadAddMultFactors(castor_df_hdr_fpath,castor_df_dir,verbose=verbose)

def get_pt_v3(patient, dbase_dir, suffix=""):

    '''
    Returns the prompt sinogram of a given patient in original database.

    Arguments:
        - patient: Patient name (string).
        - dbase_dir: Simulated database location (string).

    Returns:
        - fw_sino: Forward model sinogram (numpy array).
        - fw_hdrname: path to sinogram header (string).
    '''

    simu_dir=os.path.join(dbase_dir,"{0}{1}/pet/simus/{0}_simuframes_v3_ucm".format(patient, suffix))
    pt_hdrname=os.path.join(simu_dir,"{0}_simuframes_v3_ucm_fr0_pt_rep1.s.hdr".format(patient))
    hdr=Interfile.load(pt_hdrname)
    pt_sino,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(hdr,simu_dir,verbose=False)
    pt_sino=np.squeeze(pt_sino)

    return pt_sino,pt_hdrname

def get_pt(patient, dbase_dir, suffix=""):

    '''
    Returns the prompt sinogram of a given patient in original database.

    Arguments:
        - patient: Patient name (string).
        - dbase_dir: Simulated database location (string).

    Returns:
        - fw_sino: Forward model sinogram (numpy array).
        - fw_hdrname: path to sinogram header (string).
    '''

    simu_dir=os.path.join(dbase_dir,"{0}{1}/pet/simus/frames_ucm".format(patient, suffix))
    pt_hdrname=os.path.join(simu_dir,"frames_ucm_fr0_pt_rep1.s.hdr")
    hdr=Interfile.load(pt_hdrname)
    pt_sino,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(hdr,simu_dir,verbose=False)
    pt_sino=np.squeeze(pt_sino)

    return pt_sino,pt_hdrname

def get_fw(patient, dbase_dir, suffix = "", version = ""):

    '''
    Returns the forward model sinogram of a given patient in original database.

    Arguments:
        - patient: Patient name (string).
        - dbase_dir: Simulated database location (string).

    Returns:
        - fw_sino: Forward model sinogram (numpy array).
        - fw_hdrname: path to sinogram header (string).
    '''
    proj_dir=os.path.join(dbase_dir,"{0}{1}/pet/proj/{0}_projframes{2}_ucm".format(patient, suffix, version))
    fw_hdrname=os.path.join(proj_dir,"{0}_projframes{1}_ucm_fr0_fw.s.hdr".format(patient, version))
    hdr=Interfile.load(fw_hdrname)
    fw_sino,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(hdr,proj_dir,verbose=False)
    fw_sino=np.squeeze(fw_sino)

    return fw_sino,fw_hdrname

def get_scat(patient, dbase_dir, suffix = "", version = ""):

    '''
    Returns the scatter sinogram of a given patient in original database.

    Arguments:
        - patient: Patient name (string).
        - dbase_dir: Simulated database location (string).

    Returns:
        - scat_sino: Scatter sinogram (numpy array).
        - scat_hdrname: path to sinogram header (string).
    '''
    proj_dir=os.path.join(dbase_dir,"{0}{1}/pet/proj/{0}_projframes{2}_ucm".format(patient, suffix, version))
    scat_hdrname=os.path.join(proj_dir,"{0}_projframes{1}_ucm_fr0_sc.s.hdr".format(patient, version))
    hdr=Interfile.load(scat_hdrname)
    scat_sino,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(hdr,proj_dir)
    scat_sino=np.squeeze(scat_sino)
    return scat_sino,scat_hdrname


def get_scat_norm(patient, dbase_dir, suffix = "", version = ""):
    '''
    Returns the scatter correction with normalization correction factors of a given patient in original database.

    Arguments:
        - patient: Patient name (string).
        - dbase_dir: Simulated database location (string).

    Returns:
        - scat_sino: Scatter sinogram divided by normalization sinogram (numpy array).
        - scat_hdrname: path to sinogram header (string).
    '''
    scat_sino,scat_hdrname=get_scat(patient, dbase_dir, suffix, version)
    norm_sino,_=get_norm(patient, dbase_dir, suffix, version)
    sc_nonorm = np.divide(scat_sino, norm_sino, out=np.zeros_like(scat_sino), where= norm_sino!=0)
    return sc_nonorm,scat_hdrname


def get_rd(patient, dbase_dir, suffix = "", version = ""):

    '''
    Returns the randoms sinogram of a given patient in original database.

    Arguments:
        - patient: Patient name (string).
        - dbase_dir: Simulated database location (string).

    Returns:
        - rd_sino: Randoms sinogram (numpy array).
        - rd_hdrname: path to sinogram header (string).
    '''

    proj_dir=os.path.join(dbase_dir,"{0}{1}/pet/proj/{0}_projframes{2}_ucm".format(patient, suffix, version))
    rd_hdrname=os.path.join(proj_dir,"{0}_projframes{1}_ucm_fr0_rd.s.hdr".format(patient, version))
    hdr=Interfile.load(rd_hdrname)
    rd_sino,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(hdr,proj_dir)
    rd_sino=np.squeeze(rd_sino)

    return rd_sino,rd_hdrname

def get_att(patient, dbase_dir, suffix = "", version = ""):

    '''
    Returns the attentuation sinogram of a given patient in original database.

    Arguments:
        - patient: Patient name (string).
        - dbase_dir: Simulated database location (string).

    Returns:
        - att_sino: Attenuation sinogram (numpy array).
        - att_hdrname: path to sinogram header (string).
    '''

    proj_dir=os.path.join(dbase_dir,"{0}{1}/pet/proj/{0}_projframes{2}_ucm".format(patient, suffix, version))
    att_hdrname=os.path.join(proj_dir,"{0}_projframes{1}_ucm_at.s.hdr".format(patient, version))
    hdr=Interfile.load(att_hdrname)
    att_sino,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(hdr,proj_dir)
    att_sino=np.squeeze(att_sino)

    return att_sino,att_hdrname

def get_norm(patient, dbase_dir, suffix = "", version = ""):

    '''
    Returns the normalization sinogram of a given patient in original database.

    Arguments:
        - patient: Patient name (string).
        - dbase_dir: Simulated database location (string).

    Returns:
        - norm_sino: Normalization sinogram (numpy array).
        - norm_hdrname: path to sinogram header (string).
    '''

    proj_dir=os.path.join(dbase_dir,"{0}{1}/pet/proj/{0}_projframes{2}_ucm".format(patient, suffix, version))
    norm_hdrname=os.path.join(proj_dir,"{0}_projframes{1}_ucm_nm.s.hdr".format(patient, version))
    hdr=Interfile.load(norm_hdrname)
    norm_sino,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(hdr,proj_dir)
    norm_sino=np.squeeze(norm_sino)

    return norm_sino,norm_hdrname


def compute_decay_correction_factor(frame_duration,half_life=6586.2,branching_ratio=0.967,unit=1):
    '''
    Returns decay correction factors.

    Arguments:
        - frame_duration: duration of frame (float, in s)
        - half_life: half life of radionucleide (float, default: 6586.2 for [18]F)
        - branching_ratio: branching ratio of positron emission (float, default: 0.967 for [18]F)
        - unit: factor for final image unit (float, e.g. 1000 for kBq or 1 for Bq, default:1)

    Returns:
        - calibration factor value (float)
    '''
    lambda_iso=np.log(np.float32(2.0))/np.float32(half_life)
    decay_factor2=lambda_iso*np.float64(frame_duration)/(1.0-np.exp(-lambda_iso*np.float64(frame_duration)))
    calfact = decay_factor2/(np.float32(frame_duration)*branching_ratio*unit)

    return calfact


def get_at_db(patient, dbase_dir, suffix = "", version = ""):

    '''
    Returns the attenuation sinogram of a given patient in the generated database.

    Arguments:
        - patient: Patient name (string).
        - dbase_dir: Simulated database location (string).

    Returns:
        - att_sino: attenuation sinogram (numpy array).
        - att_hdrname: path to sinogram header (string).
    '''
    proj_dir=os.path.join(dbase_dir,"{0}{1}".format(patient, suffix))
    att_hdrname=os.path.join(proj_dir,"frames_ucm_at.s.hdr")
    hdr=Interfile.load(att_hdrname)
    att_sino,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(hdr,proj_dir)
    att_sino=np.squeeze(att_sino)

    return att_sino,att_hdrname

def get_scat_db(patient,real, dbase_dir):

    '''
    Returns the scatter sinogram of a given patient for a given dose realization
    in the generated database.

    Arguments:
        - patient: Patient name (string).
        - real: realization (int).
        - dbase_dir: Simulated database location (string).

    Returns:
        - scat_sino: Scatter sinogram (numpy array).
        - scat_hdrname: path to sinogram header (string).
    '''
    proj_dir=os.path.join(dbase_dir,f"{patient}")
    scat_hdrname=os.path.join(proj_dir,f"scatter{patient}-{real}.s.hdr")
    hdr=Interfile.load(scat_hdrname)
    scat_sino,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(hdr,proj_dir)
    scat_sino=np.squeeze(scat_sino)

    return scat_sino,scat_hdrname

def get_rd_db(patient,real, dbase_dir):

    '''
    Returns the randoms sinogram of a given patient in the generated database.

    Arguments:
        - patient: Patient name (string).
        - real: realization (int).
        - dbase_dir: Simulated database location (string).

    Returns:
        - rd_sino: randoms sinogram (numpy array).
        - rd_hdrname: path to randoms sinogram header (string).
    '''

    proj_dir=os.path.join(dbase_dir,"{0}".format(patient))
    rd_hdrname=os.path.join(proj_dir,f"randoms{patient}-{real}.s.hdr")
    hdr=Interfile.load(rd_hdrname)
    rd_sino,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(hdr,proj_dir)
    rd_sino=np.squeeze(rd_sino)
    return rd_sino

def get_norm_db(patient, dbase_dir):

    '''
    Returns the normalization sinogram of a given patient in the generated database.

    Arguments:
        - patient: Patient name (string).
        - dbase_dir: Simulated database location (string).

    Returns:
        - norm_sino: Normalization sinogram (numpy array).
        - norm_hdrname: path to sinogram header (string).
    '''
    proj_dir=os.path.join(dbase_dir,f"{patient}".format(patient))
    norm_hdrname=os.path.join(proj_dir,"frames_ucm_nm.s.hdr")
    hdr=Interfile.load(norm_hdrname)
    norm_sino,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(hdr,proj_dir)
    norm_sino=np.squeeze(norm_sino)

    return norm_sino,norm_hdrname

def get_scat_norm_db(patient,real, dbase_dir):
    '''
    Returns the scatter correction with norm correction factors included of a given patient in the generated database.

    Arguments:
        - patient: Patient name (string).
        - real: realization (int).
        - dbase_dir: Simulated database location (string).

    Returns:
        - scat_sino: Scatter sinogram divided by normalization sinogram (numpy array).
        - scat_hdrname: path to sinogram header (string).
    '''
    scat_sino,scat_hdrname=get_scat_db(patient,real, dbase_dir)
    norm_sino,_=get_norm_db(patient, dbase_dir)
    sc_nonorm = np.divide(scat_sino, norm_sino, out=np.zeros_like(scat_sino), where= norm_sino!=0)
    return sc_nonorm,scat_hdrname
