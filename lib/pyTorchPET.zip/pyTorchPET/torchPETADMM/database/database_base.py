"""
Created on March 2023

@author: florent.sureau
"""

import os,sys,os.path,copy,shutil,time
from interfile import Interfile as Interfile
import numpy as np
import torch
from tqdm.autonotebook import trange,tqdm
from sklearn.model_selection import train_test_split
from torch.utils.data import TensorDataset
import PETLibs
from torchPETADMM.utils import normImage as normImage
from . import database_sino
import matplotlib.pyplot as plt
from itertools import combinations

def get_im_phantom(subject,real):
    '''
    Get the filename of the phantom image with dose reduced, reduced by the dose factor.
    Arguments:
        - subject: name of subject (string).
        - real: realization number (int).
        - random_reduc: if True, apply dose reduction by a random factor in U([1,dose_reduc]) (boolean, default: False). Else apply dose reduction by a factor dose_reduc
        - nit: number of iterations for CASToR reconstruction (int)
        - nsubset: number of subsets for CASToR reconstruction (int)
    Returns:
        - filename of the phantom image (string).
        - filename of the phantom image header (string).
    '''
    return  "original{0}-{1}.s".format(subject,real+1),"original{0}-{1}.s.hdr".format(subject,real+1)

def get_im_recons(subject,real):
    '''
    Get the filename of the reconstructed image.
    Arguments:
        - subject: name of subject (string).
        - real: realization number (int).
        - random_reduc: if True, apply dose reduction by a random factor in U([1,dose_reduc]) (boolean, default: False). Else apply dose reduction by a factor dose_reduc
        - nit: number of iterations for CASToR reconstruction (int)
        - nsubset: number of subsets for CASToR reconstruction (int)
    Returns:
        - filename of the reconstructed image (string).
        - filename of the reconstructed image header (string).
    '''

    return "reconstruction{0}-{1}.img".format(subject,real+1),"reconstruction{0}-{1}.hdr".format(subject,real+1)


def generate_database(dbase_dir, database_name, new_dir, lst_subjects, n_sim, n_subjects, dim, same_dose = False,
        CASToRParams=None,smmaker_exec="/share/Programs/Siman/bin_omp/SMmaker.exe"):

    '''
    Generates a database using noise-free images, the original forward model, attenuation, normalization, scatter, and
    randoms sinograms present in the original database, which are the results of a monte-carlo simulation.
    The forward model sinogram's dose is varied into numerous simulations, Poisson noise is then applied to each of them,
    they are then reconstructed  with default parameters and saved to the new directory, the noise-free images are used as target and saved.

    Arguments:
        - dbase_dir: Simulations database location.
        - database_name: Generated database name.
        - new_dir: Generated database location.
        - lst_subjects: List of patient names.
        - n_sim: Number noisy images for every patient in resulting database.
        - n_subjects: Number of patients in resulting database.
        - dim: Image dimensions.
        - same_dose: Generates realizations with the same dose for every patient (Default value: False).
        - CASToRParams: parameters used for reconstruction (CASToRReconsParams, default:None ie default parameters for Biograph).
        - smmaker_exec: filepath of SMmakerexecutable (string, default: '/share/Programs/Siman/bin_omp/SMmaker.exe')

    Returns:
        - all_dose_factor: Varied dose for every generated sample (numpy array [nsim,n_subjects]).
        - mu: Initial bin sum for every patient (numpy array [nsim,n_subjects]).
        - all_time: Time taken for every generated sample (numpy array [nsim,n_subjects]).
    '''

    if CASToRParams is None:
        CASToRParams=CASToRReconsParams()
    if not isinstance(CASToRParams,PETLibs.recons.CASToRReconsParams):
        raise TypeError("CASToRParams type is not PETLibs.recons.CASToRReconsParams ")

    n1 = dim[0]
    n2 = dim[1]
    n3 = dim[2]

    mu = []
    for subject in lst_subjects:
        fw_sino,_=database_sino.get_fw(subject, dbase_dir)
        mu.append(np.sum(fw_sino))
    mean = sum(mu)/len(mu)

    if n_subjects != 14:
        lst_subjects = lst_subjects[0:n_subjects]

    all_time = np.empty(shape = (n_sim, len(lst_subjects)))
    all_dose_factor = np.empty(shape = (n_sim, len(lst_subjects)))

    for i, subject in enumerate(lst_subjects):
        subject_time = time.time()

        fw_sino3D,_ = database_sino.get_fw(subject, dbase_dir)
        sc_sino,sc_hdrname = database_sino.get_scat(subject, dbase_dir)
        rd_sino,rd_hdrname= database_sino.get_rd(subject, dbase_dir)
        at_sino,att_hdrname=database_sino.get_att(subject, dbase_dir)
        norm_sino,norm_hdrname=database_sino.get_norm(subject, dbase_dir)

        test_recons_dir = new_dir + '{0}/{1}'.format(database_name, subject)
        if not os.path.exists(test_recons_dir):
            os.makedirs(test_recons_dir)

        orig_dir=os.path.join(dbase_dir,"{0}/pet/proj/{0}_projframes_ucm".format(subject))
        simu_dir=os.path.join(dbase_dir,"{0}/pet/simus/frames_ucm".format(subject))
        ecm_dir=os.path.join(dbase_dir,"{0}/pet/simus/crystal_map_biograph3D_uniform".format(subject))
        ecm_file=os.path.join(ecm_dir,"crystal_map_biograph3D_uniform.ecm".format(subject))

        src_files = os.listdir(simu_dir)
        for file_name in src_files:
            if "_pt_rep1.s" not in file_name:
                file_path = os.path.join(simu_dir, file_name)
                if os.path.isfile(file_path):
                    shutil.copy(file_path, test_recons_dir)

        original = '{0}_projframes_ucm_fr0_orig_psf.i'.format(subject)
        original_dir = os.path.join(orig_dir, original)
        original_hdr = original.replace('.i','.i.hdr')
        original_hdr_dir = os.path.join(orig_dir, original_hdr)

        imrec_hdr=Interfile.load(original_hdr_dir)
        original_image,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(imrec_hdr,orig_dir)

        pt_hdrname="frames_ucm_fr0_pt_rep1.s.hdr"

        for real in range(n_sim):
            print('-----------------------------------Patient',subject,' (',i+1,') Realization ',real+1,'-----------------------------------')
            real_time = time.time()

            if same_dose:
                alpha = mean/mu[i]
            else:
                alpha = np.random.uniform(min(mu)/(mu[i]), (max(mu))/mu[i])
            print(f"\n\n alpha={alpha} ntot={alpha*mu[i]}")

            all_dose_factor[real, i] = alpha

            new_fw_sino3D = (fw_sino3D - rd_sino)*alpha + rd_sino*alpha*alpha
            new_pt_real = np.random.poisson(new_fw_sino3D.clip(0))
            new_sc_sino3D = sc_sino * alpha
            new_rd_sino3D = rd_sino * alpha * alpha


            real_fname="realization{0}-{1}.s".format(subject,real+1)
            real_hdr_fname=real_fname.replace(".s",".s.hdr")
            sc_fname="scatter{0}-{1}.s".format(subject,real+1)
            sc_hdr_fname=sc_fname.replace(".s",".s.hdr")
            rd_fname="randoms{0}-{1}.s".format(subject,real+1)
            rd_hdr_fname=rd_fname.replace(".s",".s.hdr")
            cdf_name=os.path.basename(real_fname).rsplit('.')[0]

            PETLibs.ios.writeInterfileImgFromHDR(test_recons_dir,
                        real_fname,simu_dir,pt_hdrname,new_pt_real)
            PETLibs.ios.writeInterfileImgFromHDR(test_recons_dir,
                        sc_fname,simu_dir,sc_hdrname,new_sc_sino3D.astype("float32"))
            PETLibs.ios.writeInterfileImgFromHDR(test_recons_dir,
                        rd_fname,simu_dir,rd_hdrname,new_rd_sino3D.astype("float32"))

            cdf_hdrname,_,_=PETLibs.CASTORCreateDataFile(test_recons_dir,real_hdr_fname,
                             ecm_file,cdf_name,
                             att_hdr=att_hdrname,
                             norm_hdr=norm_hdrname,
                             sc_hdr=sc_hdr_fname,
                             rd_hdr=rd_hdr_fname,nthr=32,
                             scanner="biograph",executable=smmaker_exec,verbose=False)

            rootname_recons=os.path.dirname(cdf_hdrname)+"/reconstruction{0}-{1}".format(subject,real)
            im_rec_fname,_,_=PETLibs.CASTORReconsIm(cdf_hdrname, rootname_recons,cdf_name,test_recons_dir,
                                                    CASToRParams=CASToRParams,verbose=verbose)

            img_recons=os.path.dirname(cdf_hdrname)+"_it4.img"
            img_hdr_recons=img_recons.replace(".img",".hdr")
            real_imrec,real_hdr_imrec=get_im_recons(subject,real)
            os.rename(img_recons, os.path.join(test_recons_dir, real_imrec))
            os.rename(img_hdr_recons, os.path.join(test_recons_dir, real_hdr_imrec))

            datafiles = os.listdir(test_recons_dir)
            for file_name in datafiles:
                h = cdf_hdrname.rsplit('/')[-2]
                if file_name in [h+"_it1.hdr", h+"_it1.img", h+"_img1.log", h+".log", h+".s", h+".s.hdr"]:
                    file_path = os.path.join(test_recons_dir, file_name)
                    os.remove(file_path)
                if file_name in [h]:
                    file_path = os.path.join(test_recons_dir, file_name)
                    #shutil.rmtree(file_path)

            orig_name,_ = get_im_phantom(subject,real)
            PETLibs.ios.writeInterfileImgFromHDR(test_recons_dir, orig_name, orig_dir, original_hdr_dir,
                                                 original_image * alpha)

            if n_sim == 0:
                all_time[real, i] = time.time() - subject_time
            else:
                all_time[real, i] = time.time() - real_time

        datafiles = os.listdir(test_recons_dir)
        for file_name in datafiles:
            if (file_name in src_files):
                file_path = os.path.join(test_recons_dir, file_name)
                os.remove(file_path)

    return all_dose_factor, mu, all_time

def delete_database(database_name, new_dir):

    '''
    Deletes generated database.

    Arguments:
        - database_name: Generated database name (string).
        - new_dir: Generated database location (string).
    '''
    test_recons_dir = new_dir + '{0}'.format(database_name)
    if os.path.exists(test_recons_dir):
        shutil.rmtree(test_recons_dir)

def import_data(new_dbase_dir, lst_subjects, n_sim, n_subjects = 14, dim = [109,128,128], target = "one"):

    '''
    Imports generated data from its original folder and outputs a numpy database.

    Arguments:
        - dbase_dir: Original database location (string).
        - new_dbase_dir: Generated database location (string).
        - lst_subjects: List of patient names (list of string).
        - n_sim: Number noisy images for every patient in resulting database (int)
        - n_subjects: Number of patients in resulting database (int, default: 14).
        - dim: Image dimensions (list of 3 int, default: [109,128,128]).
        - target: whether the imported database has one target image per patient or many - if random dose- (Possible values: "one", "many").

    Returns:
        data_x: Input images (numpy array, [n_sim*n_subjects,dim[0],dim[1],dim[2]]).
        data_y: Target images (numpy array, [n_sim*n_subjects,dim[0],dim[1],dim[2]]).
    '''

    if n_subjects != 14:
        lst_subjects = lst_subjects[0:n_subjects]

    n1 = dim[0]
    n2 = dim[1]
    n3 = dim[2]

    data_x = np.empty([n_sim*len(lst_subjects),n1,n2,n3])
    data_y = np.empty([n_sim*len(lst_subjects),n1,n2,n3])

    for i, subject in enumerate(lst_subjects):
        test_recons_dir = new_dbase_dir + '{0}'.format(subject)

        if target == "one":
            originaldir=test_recons_dir+'/original{0}.i'.format(subject)
            originalhdr=originaldir.replace(".i",".i.hdr")
            old_originaldir=originaldir.replace("original{0}.i".format(subject),'{0}_projframes_ucm_fr0_orig_psf.i'.format(subject))
            old_originalhdr=old_originaldir.replace(".i",".i.hdr")
            os.rename(originaldir, old_originaldir)
            os.rename(originalhdr, old_originalhdr)

            imrec_hdr=Interfile.load(old_originalhdr)
            imrec_rep_original,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(imrec_hdr,test_recons_dir)

            os.rename(old_originaldir, originaldir)
            os.rename(old_originalhdr, originalhdr)

        for real in range(n_sim):

            test_recons_dir = new_dbase_dir + '{0}'.format(subject)
            realdir=test_recons_dir+'/realization{0}-{1}'.format(subject,real+1)
            reconname,_=get_im_recons(subject,real)
            recondir=test_recons_dir+"/"+reconname
            os.rename(recondir+".hdr",realdir+"_it4.hdr")
            os.rename(recondir+".img",realdir+"_it4.img")

            img_recons=realdir+"_it4.hdr"
            imrec_hdr=Interfile.load(img_recons)
            imrec_rep,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(imrec_hdr,test_recons_dir)

            if target == "many":
                originalname,_=get_im_phantom(subject,real)
                originaldir=test_recons_dir+"/"+originalname
                originalhdr=originaldir.replace(".s",".s.hdr")
                #old_originaldir=originaldir.replace("original{0}.i".format(subject),'{0}_projframes_ucm_fr0_orig_psf.i'.format(subject))
                #old_originalhdr=old_originaldir.replace(".i",".i.hdr")
                #os.rename(originaldir, old_originaldir)
                #os.rename(originalhdr, old_originalhdr)

                imrec_hdr=Interfile.load(originalhdr)
                imrec_rep_original,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(imrec_hdr,test_recons_dir)

            os.rename(realdir+"_it4.hdr", recondir+".hdr")
            os.rename(realdir+"_it4.img", recondir+".img")
            print('Subject: ',subject,' (',i,')\nRealization: ',real+1,'\nNumber: ',real + i*n_sim)
            data_x[real + i*n_sim] = np.transpose(np.expand_dims(imrec_rep[:,:,:],axis=3),(3,0,1,2))
            data_y[real + i*n_sim] = np.transpose(np.expand_dims(imrec_rep_original[:,:,:],axis=3),(3,0,1,2))

    return data_x, data_y

def normalize_data(data_x, data_y, alpha=9*1e6):

    '''
    Normalizes numpy database such that the result is equivalent to:
    .. math::
        g_1(v) = \frac{\alpha}{\sum_jv_j} v

    Arguments:
        - data_x: Input images (numpy array).
        - data_y: Target images (numpy array).
        - alpha: value of sum in normalized images (default:9*1e6)

    Returns:
        - normalized_data_x: Normalized input images (numpy array).
        - normalized_data_y: Normalized target images (numpy array).
        - sum_x: List of input image sum values (list of floats).
        - sum_y: List of target image sum values (list of floats)
        - alpha: Normalization constant used (float).
    '''

    sum_x = []
    sum_y = []
    normalized_data_x=np.zeros_like(data_x)
    normalized_data_y=np.zeros_like(data_y)
    o_sum_x = []
    o_sum_y = []

    with tqdm(total=2*data_x.shape[0], desc=f'Normalizing Data', unit='Sample(s)') as pbar:
        for i in range(data_x.shape[0]):
            n_image, sum_image=normImage.normalize_image(data_x[i],alpha=alpha)
            o_sum_x.append((1.0/547248240.0)*sum_image)
            # o_sum_x.append((1.0/547248240.0)*sum_image/np.linalg.norm(data_y[i])*1e6)
            # o_sum_x.append((1.0/547248240.0)*sum_image/np.linalg.norm(data_x[i])*1e6)
            sum1 = sum_image
            sum_x.append(sum_image)
            normalized_data_x[i]=n_image
            pbar.update(1)

            n_image, sum_image=normImage.normalize_image(data_y[i],alpha=alpha)
            sum2 = sum_image
            # sum2 souvent plus petit que sum1
            # print("sum1", sum1, "sum2", sum2, "[n]sum1", sum1/np.linalg.norm(data_y[i]), "[n]sum2", sum2/np.linalg.norm(data_y[i]), "[n2]sum1", sum1/np.linalg.norm(data_x[i]))
            sum_y.append(sum_image)
            o_sum_y.append((1.0/547248240.0)*sum_image) #/np.linalg.norm(data_y[i])*1e6)
            normalized_data_y[i]=n_image
            pbar.update(1)
    print('Min sum_x: ',np.min(sum_x))
    print('Min sum_y: ',np.min(sum_y))
    print('Mean sum_x: ',np.mean(sum_x))
    print('Std sum_x: ',np.std(sum_x))
    print('Mean sum_y: ',np.mean(sum_y))
    print('Std sum_y: ',np.std(sum_y))
    return normalized_data_x, normalized_data_y, sum_x, sum_y, alpha, np.min(sum_x)/sum_x, np.min(sum_y)/sum_y, o_sum_x, o_sum_y 


def get_sum_img(data_x):

    sum_x = []

    for i in range(data_x.shape[0]):
        sum_x.append(np.sum(data_x[i]))


    print('[getsum] Min sum_x: ',np.min(sum_x)/np.max(sum_x))
    print('[getsum] Mean sum_x: ',np.mean(sum_x)/np.max(sum_x))
    print('[getsum] Max sum_x: ',np.max(sum_x)/np.max(sum_x))

    return sum_x/np.max(sum_x)
    
    #(sum_x - np.mean(sum_x))/np.std(sum_x), (sum_y - np.mean(sum_y))/np.std(sum_y)

#sum_x/np.max(sum_x), sum_y/np.max(sum_y)
#np.min(sum_x)/sum_x, np.min(sum_y)/sum_y
#sum_x/np.max(sum_x), sum_y/np.max(sum_y)

def FNE_constants(data_x, data_y, img):


    res = list(combinations(range(data_x.shape[0]), 2))
    list_ratio = []

    for _, (a, b) in enumerate(res):
        if a == img and b != a:
            
            ratio =  np.linalg.norm(data_y[a]-data_y[b])/np.linalg.norm(data_x[a]-data_x[b])
           
            list_ratio.append(ratio)

    return np.sort(list_ratio)

def FNE_constants_ph(data_x, data_y, img):


    res = list(combinations(range(data_x.shape[0]), 2))
    # list_ratio_2D_I = []
    # list_ratio_D_I = []
    # list_ratio_D = []

    list_ratio_2D_I_m = []
    list_ratio_D_I_m = []
    list_ratio_D_m = []

    for _, (a, b) in enumerate(res):
        if a == img and b != a:
            # mask_a = data_ph[a] > 0
            # mask_b = data_ph[b] > 0
           
            # list_ratio_2D_I.append(np.linalg.norm(2*mask_a*data_y[a]-2*mask_b*data_y[b]-(data_x[a]-data_x[b]))/np.linalg.norm(data_x[a]-data_x[b]))
            # list_ratio_D_I.append(np.linalg.norm(mask_a*data_y[a]-mask_b*data_y[b]-(data_x[a]-data_x[b]))/np.linalg.norm(data_x[a]-data_x[b]))
            # list_ratio_D.append(np.linalg.norm(mask_a*data_y[a]-mask_b*data_y[b])/np.linalg.norm(data_x[a]-data_x[b]))

            list_ratio_2D_I_m.append(np.linalg.norm(2*data_y[a]-2*data_y[b]-(data_x[a]-data_x[b]))/np.linalg.norm(data_x[a]-data_x[b]))
            list_ratio_D_I_m.append(np.linalg.norm(data_y[a]-data_y[b]-(data_x[a]-data_x[b]))/np.linalg.norm(data_x[a]-data_x[b]))
            list_ratio_D_m.append(np.linalg.norm(data_y[a]-data_y[b])/np.linalg.norm(data_x[a]-data_x[b]))
    list_ratio_D_m = np.sort(list_ratio_D_m)
    list_ratio_D_I_m = np.sort(list_ratio_D_I_m)
    list_ratio_2D_I_m = np.sort(list_ratio_2D_I_m)
    # list_ratio_D = np.sort(list_ratio_D)
    # list_ratio_D_I = np.sort(list_ratio_D_I)
    # list_ratio_2D_I = np.sort(list_ratio_2D_I)

    # print("list_ratio_D_m", list_ratio_D_m)
    # print("list_ratio_D_I_m", list_ratio_D_I_m)
    # print("list_ratio_2D_I_m", list_ratio_2D_I_m)


    return list_ratio_2D_I_m





def aug_pairs_real(data_x, data_y, nb_real):

    nbx = data_x.shape[0]
    aug_data_x=np.zeros((nbx*(nb_real-1),data_x.shape[1],data_x.shape[2],data_x.shape[3]))
    aug_data_y=np.zeros((nbx*(nb_real-1),data_y.shape[1],data_y.shape[2],data_x.shape[3]))
    

    i_aug = 0 

    for i in range(nbx//nb_real):
        index_same_img = [i*nb_real+j for j in range(nb_real)]
        for i1 in index_same_img :
            for i2 in index_same_img :
                if i1 != i2 :
                    aug_data_x[i_aug] = data_x[i1]
                    aug_data_y[i_aug] = data_y[i2]
                    i_aug += 1
        

    assert(i_aug == aug_data_x.shape[0])
    return aug_data_x, aug_data_y


def min_max_normalize_data(data_x, data_y):

    '''
    Normalizes numpy database such that the result is equivalent to:
    .. math::
        g_1(v) = \frac{v - min(v)}{max(v) - min(v)}

    Arguments:
        - data_x: Input images (numpy array).
        - data_y: Target images (numpy array).

    Returns:
        - normalized_data_x: Normalized input images (numpy array).
        - normalized_data_y: Normalized target images (numpy array).
        - min_x: List of input image min values (list of floats).
        - min_y: List of target image min values (list of floats)
        - max_x: List of input image max values (list of floats).
        - max_y: List of target image max values (list of floats)
        - sum_x/max(sum_x): List of input image normalized sum values (list of floats).
        - sum_y/max(sum_y): List of target image normalized sum values (list of floats)

    '''

    sum_x = []
    min_x = []
    max_x = []
    sum_y = []
    min_y = []
    max_y = []

    normalized_data_x=np.zeros_like(data_x)
    normalized_data_y=np.zeros_like(data_y)


    with tqdm(total=2*data_x.shape[0], desc=f'Normalizing Data', unit='Sample(s)') as pbar:
        for i in range(data_x.shape[0]):
            n_image, min_image, max_image, sum_image=normImage.min_max_normalize_image(data_x[i])
            sum_x.append(sum_image)
            min_x.append(min_image)
            max_x.append(max_image)
            normalized_data_x[i]=n_image
            pbar.update(1)

            n_image, min_image, max_image, sum_image=normImage.min_max_normalize_image(data_y[i])
            sum_y.append(sum_image)
            min_y.append(min_image)
            max_y.append(max_image)
            normalized_data_y[i]=n_image
            pbar.update(1)

    return normalized_data_x, normalized_data_y, min_x, max_x, sum_x/np.max(sum_x), min_y, max_y, sum_y/np.max(sum_y)


def get_loaders_torch(data_x, data_y, test_percent, train_batch_size, test_batch_size, shuffle_train, shuffle_test,
                normalize = False, norm_sj = False, norm_train = False, all_dose_factor = 0, n_patients = 0, n_sim = 0,
                truncate = 109):

    '''
    Generates training and testing torch dataloaders using the numpy data.

    Arguments:
        - data_x: Input images (4D numpy array - [index_im,z,y,x]).
        - data_y: Target images (4D numpy array - [index_im,z,y,x]).
        - test_percent: Percentage of database used for testing (float).
        - train_batch_size: Batch size for training (int).
        - test_batch_size: Batch size for testing (int).
        - shuffle_train: Shuffles the training data set at every epoch (boolean, see torch dataloader).
        - shuffle_test: Shuffles the testing data at every epoch (boolean, see torch dataloader).
        - normalize: Normalizes the datasets in the loader (boolean, default: False).
        - norm_sj: add sum arrays needed for future estimates of the Square Jacobian's Spectral Norm on denormalized data
                   (provided the input images are normalized) (boolean, default: False).
        - norm_train: add arrays for future normalization and denormalizion during training (eg. using g1/g2), images
            used should not be normalized beforehand (boolean, default: False).
        - all_dose_factor: array of variable dose factors for each realization to normalize/denormalize sinograms
        - n_patients: number of patients (int, default: 0).
        - n_sim: number of dose realizations per patient (int, default: 0).
        - truncate: Truncates the images' first dimension (int, so that zrange=data_x.shape[1]-truncate, Default value: 109).

    Returns:
        - dataset: TensorDataset wrapping input and target data. When norm_sj=True, add the list of total sum of data_x
                   and data_y for every 3D image and the normalization constant to be able to denormalize (normalized) data.
                   If norm_sj=False and norm_train=True,add the tensor array of patient number, realization number,dose factor
                   and init value for the scaling constant since we need to know which sinogram should be used for ML
                   and used dose adjusted correction sinograms (torch.utils.data.TensorDataset).
        -  train_loader: Dataloader containing the training data (torch.utils.data.DataLoader)
        - test_loader: Dataloader containing the testing data (torch.utils.data.DataLoader).
        - sum_x: List of input image sum values (list of floats).
        - sum_y: List of target image sum values (list of floats).
        - alpha: Normalization constant used (list of normalization constants).
    '''

    alpha = 9*1e6

    if truncate != 109:
        t = data_x.shape[1] - truncate
        data_x = data_x[:,t:,:,:]
        data_y = data_y[:,t:,:,:]
        print("Data Truncated\n")

    if normalize:
        data_x, data_y, sum_x, sum_y, alpha = normalize_data(data_x, data_y, alpha)
        print("Data Normalized\n")
    else:
        alpha = 0
        sum_x = []
        sum_y = []

    if norm_sj:
        dataset = TensorDataset(torch.tensor(data_x,device=device,dtype=torch.float32),
                                torch.tensor(data_y,device=device,dtype=torch.float32),
                                torch.tensor(sum_x,device=device,dtype=torch.float32),
                                torch.tensor(sum_y,device=device,dtype=torch.float32),
                                alpha*torch.ones(data_x.shape[0]))
    elif norm_train:
        patient = []
        for i in range(n_patients):
            for j in range(n_sim):
                patient.append(i+1)

        realization = []
        for i in range(n_patients):
            for j in range(n_sim):
                realization.append(j+1)

        all_dose_factor = [all_dose_factor[i][:n_patients] for i in range(n_sim)]

        init = []
        for i in range(n_patients):
            for j in range(n_sim):
                init.append(0.1)
        dataset = TensorDataset(torch.tensor(data_x,device=device,dtype=torch.float32),
                                torch.tensor(data_y,device=device,dtype=torch.float32),
                                torch.tensor(patient,device=device,dtype=torch.float32),
                                torch.tensor(realization,device=device,dtype=torch.float32),
                                torch.reshape(torch.tensor(all_dose_factor,device=device,dtype=torch.float32), (-1,)),
                                torch.tensor(initv,device=device,dtype=torch.float32))
    else:
        dataset = TensorDataset(torch.tensor(data_x,device=device,dtype=torch.float32),
                                torch.tensor(data_y,device=device,dtype=torch.float32))
    train_data, test_data = train_test_split(dataset, test_size = test_percent, shuffle = False)

    loader_args = dict(num_workers=2, pin_memory=True)
    train_loader = torch.utils.data.DataLoader(train_data, shuffle = shuffle_train, batch_size = train_batch_size, drop_last = True, **loader_args)
    test_loader = torch.utils.data.DataLoader(test_data, shuffle = shuffle_test, batch_size = test_batch_size, **loader_args)
    print("Data Loaded\n")

    return dataset, train_loader, test_loader, sum_x, sum_y, alpha
