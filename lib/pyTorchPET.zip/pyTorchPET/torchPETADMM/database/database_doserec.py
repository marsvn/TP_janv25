"""
Created on March 2023

@author: florent.sureau
"""

import numbers
import os,sys,os.path,copy,shutil,time,errno
from interfile import Interfile as Interfile
from torchvision import transforms
import random
import numpy as np, math
import torch
from tqdm.autonotebook import trange,tqdm
from sklearn.model_selection import train_test_split
from torch.utils.data import Dataset, TensorDataset, Subset
import PETLibs, PETLibs.recons,PETLibs.ios
from PETLibs.recons.CASToRRecons import CASToRReconsParams as CASToRReconsParams
import PETLibs.recons.GPURecons as GPURecons
from PETLibs import *
# from itertools import combinations
from torchPETADMM.utils import normImage as normImage
from . import database_sino
from . import database_base
import fnmatch
import pickle
from torch import nn
from torch.nn import functional as F
import math
import nibabel as nib
import torchvision.models as models
from skimage.segmentation import *
from skimage import measure
from skimage.morphology import binary_opening,convex_hull_image
from skimage.filters import threshold_multiotsu
from skimage.morphology import erosion, dilation, opening, closing
from skimage.morphology import ball  # noqa

def get_majority_label(roi):
    bw = binary_opening(roi, np.ones((3,3,3)))
    cc=measure.label(bw)
    props=measure.regionprops(cc)
    pixmax=0
    kc=0
    for kp in props:
        if kp.area>pixmax:
            kc=kp.label
            pixmax=kp.area
    mask=np.zeros(roi.shape)
    mask[cc==kc]=1
    return mask
    
def create_masks(image,LogHist=False,vmin=2e-2,vmax=None,nclasses=5):
    if vmax is None:
        vmax=np.max(image)
    lst_pixels=image[image>=vmin] 
    lst_pixels=lst_pixels[lst_pixels<=vmax] 
    if LogHist:
        thrs=np.exp(threshold_multiotsu(np.log(lst_pixels),classes=nclasses,nbins=256))
    else:
        thrs=(threshold_multiotsu(lst_pixels,classes=nclasses,nbins=256))
    masks=[]
    for thr in thrs:
        roi=(image > thr)
        mask=get_majority_label(roi)
        masks.append(mask)
    return masks
    
class VGG(nn.Module):
    """VGG/Perceptual Loss
    
    Parameters
    ----------
    conv_index : str
        Convolutional layer in VGG model to use as perceptual output

    """
    def __init__(self, conv_index: str = '22'):

        super(VGG, self).__init__()
        
        vgg_features = models.vgg16(weights=models.VGG16_Weights.DEFAULT).features
        modules = [m for m in vgg_features]
        print("Modules for perceptual loss", modules[:4])
        
        if conv_index == '22':
            self.vgg = nn.Sequential(*modules[:4])
        elif conv_index == '54':
            self.vgg = nn.Sequential(*modules[:35])
        
       
        for param in self.vgg.parameters():
            param.requires_grad = False
        del vgg_features, modules


    def forward(self, sr: torch.Tensor, hr: torch.Tensor) -> torch.Tensor:
        """Compute VGG/Perceptual loss between Super-Resolved and High-Resolution

        Parameters
        ----------
        sr : torch.Tensor
            Super-Resolved model output tensor
        hr : torch.Tensor
            High-Resolution image tensor

        Returns
        -------
        loss : torch.Tensor
            Perceptual VGG loss between sr and hr

        """
        def _forward(x):
            return self.vgg(x)
            
        vgg_sr = _forward(sr)

        with torch.no_grad():
            vgg_hr = _forward(hr.detach())
        criterion = nn.L1Loss(reduction='none')
        loss = criterion(vgg_hr.view(hr.size()[0], -1), vgg_sr.view(sr.size()[0], -1)).mean(dim=1)
        # loss = F.mse_loss(vgg_sr, vgg_hr, )

#         return loss
# class GaussianSmoothing(nn.Module):
#     """
#     Apply gaussian smoothing on a
#     1d, 2d or 3d tensor. Filtering is performed seperately for each channel
#     in the input using a depthwise convolution.
#     Arguments:
#         channels (int, sequence): Number of channels of the input tensors. Output will
#             have this number of channels as well.
#         kernel_size (int, sequence): Size of the gaussian kernel.
#         sigma (float, sequence): Standard deviation of the gaussian kernel.
#         dim (int, optional): The number of dimensions of the data.
#             Default value is 2 (spatial).
#     """
#     def __init__(self, channels, kernel_size, sigma, dim=2):
#         super(GaussianSmoothing, self).__init__()
#         if isinstance(kernel_size, numbers.Number):
#             kernel_size = [kernel_size] * dim
#         if isinstance(sigma, numbers.Number):
#             sigma = [sigma] * dim
#             #you should smooth with a Gaussian filter approximately three times the size of your voxel.

#         # The gaussian kernel is the product of the
#         # gaussian function of each dimension.
#         kernel = 1
#         meshgrids = torch.meshgrid(
#             [
#                 torch.arange(size, dtype=torch.float32)
#                 for size in kernel_size
#             ]
#         )
#         for size, std, mgrid in zip(kernel_size, sigma, meshgrids):
#             mean = (size - 1) / 2
#             kernel *= 1 / (std * math.sqrt(2 * math.pi)) * \
#                       torch.exp(-((mgrid - mean) / std) ** 2 / 2)

#         # Make sure sum of values in gaussian kernel equals 1.
#         kernel = kernel / torch.sum(kernel)

#         # Reshape to depthwise convolutional weight
#         kernel = kernel.view(1, 1, *kernel.size())
#         kernel = kernel.repeat(channels, *[1] * (kernel.dim() - 1))

#         self.register_buffer('weight', kernel)
#         self.groups = channels

#         if dim == 1:
#             self.conv = F.conv1d
#         elif dim == 2:
#             self.conv = F.conv2d
#         elif dim == 3:
#             self.conv = F.conv3d
#         else:
#             raise RuntimeError(
#                 'Only 1, 2 and 3 dimensions are supported. Received {}.'.format(dim)
#             )

#     def forward(self, input):
#         """
#         Apply gaussian filter to input.
#         Arguments:
#             input (torch.Tensor): Input to apply gaussian filter on.
#         Returns:
#             filtered (torch.Tensor): Filtered output.
#         """
#         return self.conv(input, weight=self.weight, groups=self.groups, padding=2)



def sigma2fwhm(sigma):
     return sigma * np.sqrt(8 * np.log(2))


def fwhm2sigma(fwhm):
    return fwhm / np.sqrt(8 * np.log(2))


class LinearCombinationTransform:
    def __init__(self, alpha=0.5):
        self.alpha = alpha

    def __call__(self, img1, img2):
        if not torch.is_tensor(img1):
            img1 = transforms.ToTensor()(img1)
        if not torch.is_tensor(img2):
            img2 = transforms.ToTensor()(img2)
        
        combined_image = self.alpha * img1 + (1 - self.alpha) * img2
        
        return combined_image

class CustomTensorDataset(Dataset):
    """TensorDataset with support of transforms.
    """
    def __init__(self, tensors, transform=None, bLinear = False):
        assert all(tensors[0].size(0) == tensor.size(0) for tensor in tensors)
        self.tensors = tensors
        self.transform = transform
        self.bLinear = bLinear

    def __getitem__(self, index):
        x = self.tensors[0][index]
        y = self.tensors[1][index]
        phantom = self.tensors[3][index]
        mu = self.tensors[4][index]
        alpha = torch.ones_like(mu)

        if self.transform:
            input_tf = torch.cat((x.unsqueeze(0), y.unsqueeze(0), phantom.unsqueeze(0)), dim=0)
            output_tf = self.transform(input_tf)
            x = output_tf[0, :, :, :]
            y = output_tf[1, :, :, :]
            phantom = output_tf[2, :, :, :]

        if self.bLinear:
            alpha = random.uniform(0.1, 1) #0.01, 0.2
            mu = alpha * mu
            x = LinearCombinationTransform(alpha)(x, self.tensors[1][index])
            alpha = alpha * torch.ones_like(mu)

            # a = random.uniform(1.0, 2.0) 
            # b = random.uniform(-1.0, 1.0)
            # if b > 0:
            #     mu = mu / a
            #     x = LinearCombinationTransform(1.0/a)(x, self.tensors[1][index])
            # else :
            #     mu = mu * a
            #     x = LinearCombinationTransform(a)(x, self.tensors[1][index])

            # alpha = random.uniform(0.1, 1) #0.01
            # mu = alpha * mu
            # x = LinearCombinationTransform(alpha)(x, self.tensors[1][index])
        

        
        # input, target, EM, phantom, mu, _, mri
        return x, y, self.tensors[2][index], phantom, mu, self.tensors[5][index], self.tensors[6][index], alpha 

    def __len__(self):
        return self.tensors[0].size(0)


#-------------------------------------------------------------------------------
# Class for parameters to generate new database with dose redution
#-------------------------------------------------------------------------------
class genSubDatabaseDoserecParams():
    '''
    Parameters used for generating subdatabase with dose reduction and multiple dose realizations.
    '''
    def __init__(self, dbase_dir=None,database_name=None, gen_dir=None, lst_subjects=[], n_sim=0, n_subjects=0,
                 same_dose = False,dose_reduc=None,random_reduc=False,CASToRParams=None,castor_dir=None,
                 clean_dbase=True,smmaker_exec="/share/Programs/Siman/bin_omp/SMmaker.exe",verbose=False):
        '''
        Initialization of the parameters used for Database Generation

        Arguments:
            - dbase_dir: Simulations database location (string, default:None).
            - database_name: Generated database name (string, default:None).
            - gen_dir: Generated database location (string, default:None).
            - lst_subjects: List of patient names (list of string, default:[]).
            - n_sim: Number noisy images for every patient in resulting database (int, default:0).
            - n_subjects: Number of patients in resulting database (int,default: 0).
            - same_dose: Generates realizations with the same dose for every patient,
                taken as the mean over all patient doses (boolean, default: False).
                Otherwise, take random dose inside the original range of doses.
            - dose_reduc:apply dose reduction factor (float, default: None, should be >1 otherwise) .
            - random_reduc: if True, apply dose reduction by a random factor in U([1,dose_reduc])
                (boolean, default: False). Else apply dose reduction by a factor dose_reduc
            - CASToRParams: parameters used for reconstruction (CASToRReconsParams,
                default:None ie default parameters for Biograph).
            - castor_dir: path to copy (large) CASToR files ; if None, keep them in new_dir,
                otherwise copy them to castor_dir and make symlink to them
                in new_dir  (string, default: None).
            - clean_dbase: remove intermediate files at the end (boolean, default: True)
            - smmaker_exec: filepath of SMmakerexecutable (string,
                default: '/share/Programs/Siman/bin_omp/SMmaker.exe')
            - verbose: verbosity (boolean, default:False).
        '''

        if CASToRParams is None:
            CASToRParams=CASToRReconsParams()
        if not isinstance(CASToRParams,PETLibs.recons.CASToRReconsParams):
            raise TypeError("CASToRParams type is not PETLibs.recons.CASToRReconsParams ")

        self._dbase_dir=dbase_dir
        self._database_name=database_name
        self._gen_dir=gen_dir
        self._lst_subjects=lst_subjects
        self._n_sim=n_sim
        self._n_subjects=n_subjects
        self._same_dose=same_dose
        self._dose_reduc=dose_reduc
        self._random_reduc=random_reduc
        self._CASToRParams=CASToRParams
        self._castor_dir=castor_dir
        self._clean_dbase=clean_dbase
        self._smmaker_exec=smmaker_exec
        self._verbose=verbose
        self.all_time = []
        self.all_dose_factor =[]
        self.all_mu=[]
        self.ref_dose_factor = []
        self.dose_reduc_arr = []


    @property
    def dbase_dir(self):
        return self._dbase_dir
    @property
    def database_name(self):
        return self._database_name
    @property
    def gen_dir(self):
        return self._gen_dir
    @property
    def lst_subjects(self):
        return self._lst_subjects
    @property
    def lst_subjects_reduced(self):
        return self.lst_subjects[0:self.n_subjects]
    @property
    def n_sim(self):
        return self._n_sim
    @property
    def n_subjects(self):
        return self._n_subjects
    @property
    def same_dose(self):
        return self._same_dose
    @property
    def dose_reduc(self):
        return self._dose_reduc
    @property
    def random_reduc(self):
        return self._random_reduc
    @property
    def CASToRParams(self):
        return self._CASToRParams
    @property
    def castor_dir(self):
        return self._castor_dir
    @property
    def clean_dbase(self):
        return self._clean_dbase
    @property
    def smmaker_exec(self):
        return self._smmaker_exec
    @property
    def verbose(self):
        return self._verbose

    @dbase_dir.setter
    def dbase_dir(self,_dbase_dir):
        self._dbase_dir=_dbase_dir
    @database_name.setter
    def database_name(self,_database_name):
        self._database_name=_database_name
    @gen_dir.setter
    def gen_dir(self,_gen_dir):
        self._gen_dir=_gen_dir
    @lst_subjects.setter
    def lst_subjects(self,_lst_subjects):
        self._lst_subjects=_lst_subjects
    @n_sim.setter
    def n_sim(self,_n_sim):
        self._n_sim=_n_sim
    @n_subjects.setter
    def n_subjects(self,_n_subjects):
        self._n_subjects=_n_subjects
    @same_dose.setter
    def same_dose(self,_same_dose):
        self._same_dose=_same_dose
    @dose_reduc.setter
    def dose_reduc(self,_dose_reduc):
        self._dose_reduc=_dose_reduc
    @random_reduc.setter
    def random_reduc(self,_random_reduc):
        self._random_reduc=_random_reduc
    @CASToRParams.setter
    def CASToRParams(self,_CASToRParams):
        self._CASToRParams=_CASToRParams
    @castor_dir.setter
    def castor_dir(self,_castor_dir):
        self._castor_dir=_castor_dir
    @clean_dbase.setter
    def clean_dbase(self,_clean_dbase):
        self._clean_dbase=_clean_dbase
    @smmaker_exec.setter
    def smmaker_exec(self,_smmaker_exec):
        self._smmaker_exec=_smmaker_exec
    @verbose.setter
    def verbose(self,_verbose):
        self._verbose=_verbose

    def get_projections_dir(self,subject, suffix = "", version = ""):
        '''
        Get the directory where projections are stored.
        Arguments:
            - subject: name of subject (string).
        Returns:
            - directory where projections are stored (string).
        '''
        return os.path.join(self.dbase_dir,"{0}{1}/pet/proj/{0}_projframes{2}_ucm".format(subject, suffix, version))

    def get_gen_dbase_rootdir(self):
        '''
        Get the root directory where generated database is generated.
        Arguments:
        Returns:
            - directory where generated database is generated (string).
        '''
        return os.path.join(self.gen_dir,f'{self.database_name}')

    def get_simulations_dir(self,subject, suffix = "", version = ""):
        
        '''
        Get the directory where simulations are stored.
        Arguments:
            - subject: name of subject (string).
        Returns:
            - directory where simulations are stored (string).
        '''
        if suffix == "":
            return os.path.join(self.dbase_dir,"{0}/pet/simus/frames_ucm".format(subject))
        else :
            return os.path.join(self.dbase_dir,"{0}{1}/pet/simus/{0}_simuframes{2}_ucm".format(subject, suffix, version))

    def get_gen_dbase_dir(self,subject):
        '''
        Get the directory where subdatabse is generated.
        Arguments:
            - subject: name of subject (string).
        Returns:
            - directory where subdatabse is generated (string).
        '''
        return os.path.join(self.get_gen_dbase_rootdir(),f'{subject}')

    def get_gen_castor_dir(self,subject,real):
        '''
        Get the directory where CASToR files in subdatabse are generated.
        Arguments:
            - subject: name of subject (string).
            - real: realization number (int).
        Returns:
            - directory where CASToR files in subdatabase are generated (string).
        '''
        cdir=os.path.join(self.gen_dir,f'{self.database_name}/{subject}')
        return os.path.join(cdir,f"realization{subject}-{real+1}")
    
    def get_gen_castor_dir_var(self,subject,real, var):
        '''
        Get the directory where CASToR files in subdatabse are generated.
        Arguments:
            - subject: name of subject (string).
            - real: realization number (int).
        Returns:
            - directory where CASToR files in subdatabase are generated (string).
        '''
        cdir=os.path.join(self.gen_dir,f'{self.database_name}/{subject}')
        return os.path.join(cdir,f"realization{subject}-{real+1}-{var}")

    def get_stored_castor_dir(self,subject):
        '''
        Get the directory where CASToR files in subdatabse are stored.
        Arguments:
            - subject: name of subject (string).
        Returns:
            - directory where CASToR files in subdatabase are stored (string).
        '''
        return os.path.join(self.castor_dir,f'{self.database_name}/{subject}')

    def get_fpath_ecm(self,subject, suffix = ""):
        '''
        Get the filepath where ecm are stored.
        Arguments:
            - subject: name of subject (string).
        Returns:
            - filepath where crytal map are stored (string).
        '''
        ecm_dir=os.path.join(self.dbase_dir,"{0}{1}/pet/simus/crystal_map_biograph3D_uniform".format(subject, suffix))
        return os.path.join(ecm_dir,"crystal_map_biograph3D_uniform.ecm")

    def get_fpath_dbase_phantom(self,subject, suffix = "", version = ""):
        '''
        Get the filepath of the phantom in original database (for projections).
        Arguments:
            - subject: name of subject (string).
        Returns:
            - filepath of the phantom in original database (string).
        '''
        return  os.path.join(self.get_projections_dir(subject, suffix, version),f'{subject}_projframes{version}_ucm_fr0_orig_psf.i')

    def get_fpath_dbase_calib(self,subject, suffix = "", version = ""):
        '''
        Get filepath of the calibration in original database.
        Arguments:
            - subject: name of subject (string).
        Returns:
            - filepath of the calibration in original database (string).
        '''
        if suffix == "":
            return os.path.join(self.get_simulations_dir(subject, suffix, version),"frames_ucm_nm.calib.hdr")
        else :
            return os.path.join(self.get_simulations_dir(subject, suffix, version),"{0}_simuframes{1}_ucm_nm.calib.hdr".format(subject, version))

    def get_fpath_gen_calib(self,subject):
        '''
        Get filepath of the calibration in original database.
        Arguments:
            - subject: name of subject (string).
        Returns:
            - filepath of the calibration header in original database (string).
        '''
        return os.path.join(self.get_gen_dbase_dir(subject),"frames_ucm_nm.calib.hdr")

    def get_fname_sino_att(self, subject, version = ""):
        '''
        Get the filename of the attenuation sinogram in generated database.
        Arguments:
            - subject: name of subject (string).
        Returns:
            - filename of the attenuation sinogram in generated database (string).
            - filename of the attenuation sinogram header in generated database (string).
        '''
        if version == "" :
            return "frames_ucm_at.s","frames_ucm_at.s.hdr"
        else :
            return "{0}_simuframes{1}_ucm_at.s".format(subject, version),"{0}_simuframes{1}_ucm_at.s.hdr".format(subject, version)

    def get_fname_sino_norm(self,subject, version = ""):
        '''
        Get the filename of the normalization sinogram in generated database.
        Arguments:
            - subject: name of subject (string).
            - real: realization number (int).
        Returns:
            - filename of the normalization sinogram in generated database (string).
            - filename of the normalization sinogram header in generated database (string).
        '''
        if version == "" :
            return "frames_ucm_nm.s","frames_ucm_nm.s.hdr"
        else :
            return "{0}_simuframes{1}_ucm_nm.s".format(subject, version),"{0}_simuframes{1}_ucm_nm.s.hdr".format(subject, version)

    def get_fname_sino_pt(self, subject, version= ""):
        '''
        Get the filename of the prompt sinogram in generated database.
        Arguments:
            - subject: name of subject (string).
            - real: realization number (int).
        Returns:
            - filename of the prompt sinogram in generated database (string).
            - filename of the prompt sinogram header in generated database (string).
        '''
        if version == "" :
            return "frames_ucm_fr0_pt_rep1.s","frames_ucm_fr0_pt_rep1.s.hdr"
        else :
            return "{0}_simuframes{1}_ucm_fr0_pt_rep1.s".format(subject, version),"{0}_simuframes{1}_ucm_fr0_pt_rep1.s.hdr".format(subject, version)

    def get_fname_im_phantom_red(self,subject,real):
        '''
        Get the filename of the phantom image with dose reduced, reduced by the dose factor.
        Arguments:
            - subject: name of subject (string).
            - real: realization number (int).
        Returns:
            - filename of the phantom image with original dose reduced (string),
            - filename of the phantom image header with original dose reduced (string)
        '''

        return "phantom{0}-red-{1}.ima".format(subject,real+1),\
                "phantom{0}-red-{1}.hdr".format(subject,real+1)

    def get_fname_im_ordose_red(self,subject,real):
        '''
        Get the filename of the reconstructed image with original dose, reduced by the dose factor.
        Arguments:
            - subject: name of subject (string).
            - real: realization number (int).
            - nit: number of iterations for CASToR reconstruction (int)
            - nsubset: number of subsets for CASToR reconstruction (int)
        Returns:
            - filename of the reconstructed image with original dose reduced (string).
            - filename of the reconstructed image header with original dose reduced (string).
        '''
        nit=self.CASToRParams.nit
        nsubset=self.CASToRParams.nsubset
        return "originaldose-red-{0}-{1}-{2}it-{3}sub.ima".format(subject,real+1,nit,nsubset),\
                "originaldose-red-{0}-{1}-{2}it-{3}sub.hdr".format(subject,real+1,nit,nsubset)
    
    def get_fname_im_ordose_red_var(self,subject,real,var):
        '''
        Get the filename of the reconstructed image with original dose, reduced by the dose factor.
        Arguments:
            - subject: name of subject (string).
            - real: realization number (int).
            - nit: number of iterations for CASToR reconstruction (int)
            - nsubset: number of subsets for CASToR reconstruction (int)
        Returns:
            - filename of the reconstructed image with original dose reduced (string).
            - filename of the reconstructed image header with original dose reduced (string).
        '''
        nit=self.CASToRParams.nit
        nsubset=self.CASToRParams.nsubset
        return "originaldose-red-{0}-{1}-{2}it-{3}sub-{4}var.ima".format(subject,real+1,nit,nsubset,var),\
                "originaldose-red-{0}-{1}-{2}it-{3}sub-{4}var.hdr".format(subject,real+1,nit,nsubset,var)

    def get_fname_im_reddose(self,subject,real):
        '''
        Get the filename of the reconstructed image with reduced dose.
        Arguments:
            - subject: name of subject (string).
            - real: realization number (int).
            - nit: number of iterations for CASToR reconstruction (int)
            - nsubset: number of subsets for CASToR reconstruction (int)
        Returns:
            - filename of the reconstructed image with reduced dose (string).
            - filename of the reconstructed image header with reduced dose (string).
        '''
        nit=self.CASToRParams.nit
        nsubset=self.CASToRParams.nsubset
        return "reconstruction{0}-{1}-{2}it-{3}sub.ima".format(subject,real+1,nit,nsubset),\
                "reconstruction{0}-{1}-{2}it-{3}sub.hdr".format(subject,real+1,nit,nsubset)

    def get_fname_im_reddose_var(self,subject,real, var):
        '''
        Get the filename of the reconstructed image with reduced dose.
        Arguments:
            - subject: name of subject (string).
            - real: realization number (int).
            - nit: number of iterations for CASToR reconstruction (int)
            - nsubset: number of subsets for CASToR reconstruction (int)
        Returns:
            - filename of the reconstructed image with reduced dose (string).
            - filename of the reconstructed image header with reduced dose (string).
        '''
        nit=self.CASToRParams.nit
        nsubset=self.CASToRParams.nsubset
        return "reconstruction{0}-{1}-{2}it-{3}sub-{4}var.ima".format(subject,real+1,nit,nsubset, var),\
                "reconstruction{0}-{1}-{2}it-{3}sub-{4}var.hdr".format(subject,real+1,nit,nsubset, var)
    
    def get_fname_sinogram_CASToR_hdr(self,subject,real):
        '''
        Get the filename of the reconstructed image with reduced dose.
        Arguments:
            - subject: name of subject (string).
            - real: realization number (int).
        Returns:
            - filepath of the CASToR datafile (string).
            - filepath of the CASToR datafile header (string).
        '''

        return f"realization{subject}-{real+1}.cdf",f"realization{subject}-{real+1}.cdh"
    
    def get_fname_sinogram_CASToR_hdr_var(self,subject,real,var):
        '''
        Get the filename of the reconstructed image with reduced dose.
        Arguments:
            - subject: name of subject (string).
            - real: realization number (int).
        Returns:
            - filepath of the CASToR datafile (string).
            - filepath of the CASToR datafile header (string).
        '''

        return f"realization{subject}-{real+1}-{var}.cdf",f"realization{subject}-{real+1}-{var}.cdh"

    def save(self,params_fpath):
        '''
        Save the current class parameters using pickle.

        Arguments:
            - params_fpath: filepath to save the parameters (string).
        '''
        dirname=os.path.dirname(params_fpath)
        if not os.path.exists(dirname):
            os.makedirs(dirname)
        with open(params_fpath,"wb") as handle:
            pickle.dump(self.__dict__,handle,protocol=pickle.HIGHEST_PROTOCOL)

    def load(self,params_fpath):
        '''
        Load and update instance using pickle.

        Arguments:
            - params_fpath: filepath where the parameters are saved (string).
        '''
        with open(params_fpath,"rb") as handle:
            tmp=pickle.load(handle)
        self.__dict__.update(tmp)

    def load_im_reddose(self,subject,real,verbose=False):
        '''
        Load the reduced dose reconstructed image.
        Arguments:
            - subject: name of subject (string).
            - real: realization number (int).
            - verbose: verbosity (bool, default: False).
        Returns:
            - reconstructed reduced dose image (np array).
            - interfile header of the image (string).
        '''

        im_reddose_dir=self.get_gen_dbase_dir(subject)
        #Get reference image
        reddose_ref,reddose_hdr_ref=self.get_fname_im_reddose(subject,real)
        path_reddose_hdr=os.path.join(im_reddose_dir,reddose_hdr_ref)
        if os.path.exists(path_reddose_hdr):
            reddose_hdr=Interfile.load(path_reddose_hdr)
            reddose_hdr['name of data file']['value']=reddose_ref
            reddose,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(reddose_hdr,im_reddose_dir,verbose=verbose)
        else:
            raise FileNotFoundError(errno.ENOENT,os.strerror(errno.ENOENT),path_reddose_hdr)
        return reddose,reddose_hdr
    
    def load_im_reddose_var(self,subject,real,var,verbose=False):
        '''
        Load the reduced dose reconstructed image.
        Arguments:
            - subject: name of subject (string).
            - real: realization number (int).
            - verbose: verbosity (bool, default: False).
        Returns:
            - reconstructed reduced dose image (np array).
            - interfile header of the image (string).
        '''

        im_reddose_dir=self.get_gen_dbase_dir(subject)
        #Get reference image
        reddose_ref,reddose_hdr_ref=self.get_fname_im_reddose_var(subject,real,var)
        path_reddose_hdr=os.path.join(im_reddose_dir,reddose_hdr_ref)
        if os.path.exists(path_reddose_hdr):
            reddose_hdr=Interfile.load(path_reddose_hdr)
            reddose_hdr['name of data file']['value']=reddose_ref
            reddose,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(reddose_hdr,im_reddose_dir,verbose=verbose)
        else:
            raise FileNotFoundError(errno.ENOENT,os.strerror(errno.ENOENT),path_reddose_hdr)
        return reddose,reddose_hdr


    def load_im_ordose_red(self,subject,real,verbose=False):
        '''
        Load the reference dose reconstructed image scaled to reduced dose.
        Arguments:
            - subject: name of subject (string).
            - real: realization number (int).
            - verbose: verbosity (bool, default: False).
        Returns:
            - reconstructed image scaled to reduced dose (np array).
            - interfile header of the image (string).
        '''

        im_ordose_dir=self.get_gen_dbase_dir(subject)
        # print("im_ordose_dir", im_ordose_dir)
        #Get reference image
        ordose_ref,ordose_hdr_ref=self.get_fname_im_ordose_red(subject,real)
        path_ordose_hdr=os.path.join(im_ordose_dir,ordose_hdr_ref)
        if os.path.exists(path_ordose_hdr):
            # print("path_ordose_hdr", path_ordose_hdr)
            # print("ordose_ref", ordose_ref)

            ordose_hdr=Interfile.load(path_ordose_hdr)
            ordose_hdr['name of data file']['value']=ordose_ref
            ordose,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(ordose_hdr,im_ordose_dir,verbose=verbose)
        else:
            raise FileNotFoundError(errno.ENOENT,os.strerror(errno.ENOENT),path_ordose_hdr)
        return ordose,ordose_hdr
    
    def load_im_ordose_red_var(self,subject,real,var,verbose=False):
        '''
        Load the reference dose reconstructed image scaled to reduced dose.
        Arguments:
            - subject: name of subject (string).
            - real: realization number (int).
            - verbose: verbosity (bool, default: False).
        Returns:
            - reconstructed image scaled to reduced dose (np array).
            - interfile header of the image (string).
        '''

        im_ordose_dir=self.get_gen_dbase_dir(subject)
        #Get reference image
        ordose_ref,ordose_hdr_ref=self.get_fname_im_ordose_red_var(subject,real, var)
        path_ordose_hdr=os.path.join(im_ordose_dir,ordose_hdr_ref)
        if os.path.exists(path_ordose_hdr):
            ordose_hdr=Interfile.load(path_ordose_hdr)
            ordose_hdr['name of data file']['value']=ordose_ref
            ordose,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(ordose_hdr,im_ordose_dir,verbose=verbose)
        else:
            raise FileNotFoundError(errno.ENOENT,os.strerror(errno.ENOENT),path_ordose_hdr)
        return ordose,ordose_hdr

    def load_im_phantom_red(self,subject,real,verbose=False):
        '''
        Load the phamtom image scaled to reduced dose.
        Arguments:
            - subject: name of subject (string).
            - real: realization number (int).
            - verbose: verbosity (bool, default: False).
        Returns:
            - phamtom image scaled to reduced dose (np array).
            - interfile header of the image (string).
        '''

        im_phantom_dir=self.get_gen_dbase_dir(subject)
        # print("im_phantom_dir", im_phantom_dir)
        
        #Get reference image
        phantom_ref,phantom_hdr_ref=self.get_fname_im_phantom_red(subject,real)
        path_phantom_hdr=os.path.join(im_phantom_dir,phantom_hdr_ref)
        if os.path.exists(path_phantom_hdr):
            # print("path_phantom_hdr", path_phantom_hdr)
            # print("phantom_ref", phantom_ref)
            phantom_hdr=Interfile.load(path_phantom_hdr)
            phantom_hdr['name of data file']['value']=phantom_ref
            phantom,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(phantom_hdr,im_phantom_dir,verbose=verbose)
        else:
            raise FileNotFoundError(errno.ENOENT,os.strerror(errno.ENOENT),path_phantom_hdr)
        return phantom,phantom_hdr


class learningDatabaseDoserecParams():

    def __init__(self, doserecParams=None,import_dir=".",target="highdose"):
        '''
        Initialization of the parameters used for Database Generation

        Arguments:
            - doserecParams: parameters for generated database (genSubDatabaseDoserecParams).
            - import_dir: path where inputs/targets are saved (stringm default:'.').
            - target: whether target is phantom or original dose reduced (string, "highdose" or "phantom").
        '''
        if doserecParams is None:
            doserecParams=genSubDatabaseDoserecParams()
        self._doserecParams=doserecParams
        self._import_dir=import_dir
        self._import_target=target

    @property
    def doserecParams(self):
        return self._doserecParams
    @property
    def import_dir(self):
        return self._import_dir
    @property
    def import_target(self):
        return self._import_target
    @property
    def database_name(self):
        return self.doserecParams.database_name+f"_{self.import_target}"

    @doserecParams.setter
    def doserecParams(self,_doserecParams):
        self._doserecParams=_doserecParams
    @import_dir.setter
    def import_dir(self,_import_dir):
        self._import_dir=_import_dir
    @import_target.setter
    def import_target(self,_import_target):
        self._import_target=_import_target

    def get_gen_dbase_import_rootdir(self):
            '''
            Get the directory where subdatabase is generated for learning.
            Arguments:
            Returns:
                - directory where subdatabase is generated (string).
            '''
            return os.path.join(self.import_dir,f'{self.database_name}')

    def get_gen_dbase_import_dir(self,subject):
        '''
        Get the directory where subdatabase is generated for learning.
        Arguments:
            - subject: name of subject (string).
        Returns:
            - directory where subdatabase is generated (string).
        '''
        return os.path.join(self.get_gen_dbase_import_rootdir(),f'{subject}')

    def get_fname_im_target(self,subject,real,target=None):
        '''
        Get the filename of the target in sub-database.
        Arguments:
            - subject: name of subject (string).
            - real: realization number (int).
            - target: whether the imported database has a highdose
                or phantom image as target (Possible values: "highdose", "phantom").
        Returns:
            - filename of the reconstructed image with reduced dose (string).
            - filename of the reconstructed image header with reduced dose (string).
        '''
        if self.import_target == "highdose":
            target_im,target_hdr=self.doserecParams.get_fname_im_ordose_red(subject,real)
            return target_im.replace("originaldose-red","originaldose-target"),target_hdr.replace("originaldose-red","originaldose-target")
        else:
            target_im,target_hdr=self.doserecParams.get_fname_im_phantom_red(subject,real)
            return target_im.replace("red","target"),target_hdr.replace("red","target")

    def get_fname_im_target_var(self,subject,real, var):
        '''
        Get the filename of the target in sub-database.
        Arguments:
            - subject: name of subject (string).
            - real: realization number (int).
        Returns:
            - filename of the reconstructed image with reduced dose (string).
            - filename of the reconstructed image header with reduced dose (string).
        '''
        if self.import_target == "highdose":
            target_im,target_hdr=self.doserecParams.get_fname_im_ordose_red_var(subject,real, var)
            return target_im.replace("originaldose-red","originaldose-target"),target_hdr.replace("originaldose-red","originaldose-target")
        else:
            target_im,target_hdr=self.doserecParams.get_fname_im_phantom_red(subject,real)
            return target_im.replace("red","target"),target_hdr.replace("red","target")

    def get_fname_im_input_grad(self,subject,real):
        '''
        Get the filename of the input data in sub-database.
        Arguments:
            - subject: name of subject (string).
            - real: realization number (int).
        Returns:
            - filename of the input image in subdatabase (string).
            - filename of the input image header in subdatabase (string).
        '''
        input_im_name,input_hdr_name=self.doserecParams.get_fname_im_reddose(subject,real)
        return input_im_name.replace("reconstruction","grad"),input_hdr_name.replace("reconstruction","grad")
    
    def get_fname_im_input(self,subject,real):
        '''
        Get the filename of the input data in sub-database.
        Arguments:
            - subject: name of subject (string).
            - real: realization number (int).
        Returns:
            - filename of the input image in subdatabase (string).
            - filename of the input image header in subdatabase (string).
        '''
        input_im_name,input_hdr_name=self.doserecParams.get_fname_im_reddose(subject,real)
        return input_im_name.replace("reconstruction","realization"),input_hdr_name.replace("reconstruction","realization")

    def get_fname_im_input_dosevar(self,subject,real, var):
        '''
        Get the filename of the input data in sub-database.
        Arguments:
            - subject: name of subject (string).
            - real: realization number (int).
        Returns:
            - filename of the input image in subdatabase (string).
            - filename of the input image header in subdatabase (string).
        '''
        input_im_name,input_hdr_name=self.doserecParams.get_fname_im_reddose_var(subject,real, var)
        return input_im_name.replace("reconstruction","realization"),input_hdr_name.replace("reconstruction","realization")

    def load_im_input(self,subject,real,target,verbose=False):
        '''
        Load the input image in learning database.
        Arguments:
            - subject: name of subject (string).
            - real: realization number (int).
            - verbose: verbosity (boolean, default:False).
        Returns:
            - input image in learning database (np array).
            - interfile header of the image (string).
        '''

        input_name,input_hdr_name=self.get_fname_im_input(subject,real)
        imdir=self.get_gen_dbase_import_dir(subject)
        path_input_hdr=os.path.join(imdir,input_hdr_name)
        if os.path.exists(path_input_hdr):
            input_hdr=Interfile.load(path_input_hdr)
            input,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(input_hdr,imdir,verbose=verbose)
        else:
            raise FileNotFoundError(errno.ENOENT,os.strerror(errno.ENOENT),path_phantom_hdr)
        return input,input_hdr

    def load_im_target(self,subject,real,target,verbose=False):
        '''
        Load the target image scaled in learning database.
        Arguments:
            - subject: name of subject (string).
            - real: realization number (int).
            - verbose: verbosity (boolean, default:False).
    Returns:
            - target image in learning database (np array).
            - interfile header of the image (string).
        '''
        target_name,target_hdr_name=self.get_fname_im_target(subject,real,self.import_target)
        imdir=self.get_gen_dbase_import_dir(subject)
        path_target_hdr=os.path.join(imdir,target_hdr_name)
        if os.path.exists(path_target_hdr):
            target_hdr=Interfile.load(path_target_hdr)
            target,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(phantom_hdr,imdir,verbose=verbose)
        else:
            raise FileNotFoundError(errno.ENOENT,os.strerror(errno.ENOENT),path_phantom_hdr)
        return target,target_hdr

    def save(self,params_fpath):
        '''
        Save the current class parameters using pickle.

        Arguments:
            - params_fpath: filepath to save the parameters (string).
        '''
        dirname=os.path.dirname(params_fpath)
        if not os.path.exists(dirname):
            os.makedirs(dirname)
        with open(params_fpath,"wb") as handle:
            pickle.dump(self.__dict__,handle,protocol=pickle.HIGHEST_PROTOCOL)

    def load(self,params_fpath):
        '''
        Load and update instance using pickle.

        Arguments:
            - params_fpath: filepath where the parameters are saved (string).
        '''
        with open(params_fpath,"rb") as handle:
            tmp=pickle.load(handle)
        self.__dict__.update(tmp)


#-------------------------------------------------------------------------------
# Class for tensorDatasets with dose redution
#-------------------------------------------------------------------------------
class tensorDataSetDoserecParams():
    '''
    Parameters used for generated tensor datasets with dose reduction.
    '''
    def __init__(self, 
                 dbaseParams=None, 
                 ref_model=None, 
                 test_percent=None, 
                 train_batch_size=None, 
                 test_batch_size=None,
                 shuffle_train=None, 
                 shuffle_test=None, 
                 normalize = False, 
                 min_max_normalize=False,
                 norm_sj = False,
                 norm_train = False, 
                 n_iter_ML = 20, 
                 norm_denoise=False,
                 truncate = 109,
                 n_subjects = -1, 
                 n_sim = -1, 
                 alpha=9*1e6, 
                 augmentation_GT = False, 
                 augmentation_FP = False, 
                 augmentation_FP_w = False,
                 augmentation_FP_NN = False,
                 augmentation_FP_EM = False,
                 augmentation_outputNN = False, 
                 gaussian_denoising = False
                 ):
        '''
        Initialization of the parameters used for Database Generation

        Arguments:
            - dbaseParams: parameters for generated database for learning (learningDatabaseDoserecParams).
            - ref_model: torch NN used for denoising (derived class from torch.nn.Module), if None: no denoising.
            - test_percent: Percentage of database used for testing (float).
            - train_batch_size: Batch size for training (int).
            - test_batch_size: Batch size for testing (int).
            - shuffle_train: Shuffles the training data set at every epoch (boolean, see torch dataloader).
            - shuffle_test: Shuffles the testing data at every epoch (boolean, see torch dataloader).
            - normalize: Normalizes the datasets in the loader (boolean, default: False).
            - min_max_normalize: Normalizes the datasets in the loader using min-max normalization (boolean, default: False).
            - norm_sj: add sum arrays needed for future estimates of the Square Jacobian's Spectral Norm on denormalized data
                       (provided the input images are normalized) (boolean, default: False).
            - norm_train: add arrays for future normalization and denormalizion during training (eg. using g1/g2), images
                used should not be normalized beforehand (boolean, default: False).
            - n_iter_ML: number of iterations for ML scale estimate (intm default: 20).
            - norm_denoise: if normalization of input data is needed prior to using the denoiser NN (boolean, default: False)
            - truncate: Truncates the images' first dimension (int, so that zrange=data_x.shape[1]-truncate, Default value: 109).
            - n_subjects: number of patients (int, default: -1, all patients).
            - n_sim: number of dose realizations per patient (int, default: -1, all dose realizations).
            - alpha: normalization constant for sum activity in the images (float, default: 9*1e6)).
            - import_dir: path where inputs/targets are saved (stringm default:'.').
            - target: whether target is phantom or original dose reduced (string, "highdose" or "phantom").
            - augmentation_GT: whether to perform data augmentation by adding the ground truths as inputs (boolean, default: False).
        '''
        if dbaseParams is None:
            dbaseParams=learningDatabaseDoserecParams()
        self._dbaseParams=dbaseParams
        self._ref_model=ref_model
        self._test_percent=test_percent
        self._train_batch_size=train_batch_size
        self._test_batch_size=test_batch_size
        self._shuffle_train=shuffle_train
        self._shuffle_test=shuffle_test
        self._normalize=normalize
        self._min_max_normalize=min_max_normalize
        self._augmentation_GT=augmentation_GT
        self._augmentation_FP=augmentation_FP
        self._augmentation_FP_w=augmentation_FP_w
        self._augmentation_FP_NN=augmentation_FP_NN
        self._augmentation_FP_EM=augmentation_FP_EM
        self._augmentation_outputNN=augmentation_outputNN
        self._gaussian_denoising=gaussian_denoising
        self._norm_sj=norm_sj
        self._norm_train=norm_train
        self._n_iter_ML=n_iter_ML
        self._norm_denoise=norm_denoise
        self._truncate=truncate
        if n_subjects<0:
            self._n_subjects=dbaseParams.doserecParams.n_subjects
        if n_sim<0:
            self._n_sim=dbaseParams.doserecParams.n_sim
        self._alpha=alpha

    @property
    def dbaseParams(self):
        return self._dbaseParams
    @property
    def doserecParams(self):
        return self._dbaseParams._doserecParams
    @property
    def database_name(self):
        return f"{self.dbaseParams.database_name}"
    @property
    def lst_subjects(self):
        return self.doserecParams.lst_subjects
    @property
    def lst_subjects_reduced(self):
        return self.doserecParams.lst_subjects_reduced[0:self.n_subjects]
    @property
    def ref_model(self):
        return self._ref_model
    @property
    def test_percent(self):
        return self._test_percent
    @property
    def train_batch_size(self):
        return self._train_batch_size
    @property
    def test_batch_size(self):
        return self._test_batch_size
    @property
    def shuffle_train(self):
        return self._shuffle_train
    @property
    def shuffle_test(self):
        return self._shuffle_test
    @property
    def normalize(self):
        return self._normalize
    @property
    def min_max_normalize(self):
        return self._min_max_normalize
    @property
    def augmentation_GT(self):
        return self._augmentation_GT
    
    @property
    def gaussian_denoising(self):
        return self._gaussian_denoising
    @property
    def augmentation_FP(self):
        return self._augmentation_FP
    
    @property
    def augmentation_FP_w(self):
        return self._augmentation_FP_w
    
    @property
    def augmentation_FP_NN(self):
        return self._augmentation_FP_NN
    
    @property
    def augmentation_FP_EM(self):
        return self._augmentation_FP_EM
    @property
    def augmentation_outputNN(self):
        return self._augmentation_outputNN
    @property
    def norm_sj(self):
        return self._norm_sj
    @property
    def norm_train(self):
        return self._norm_train
    @property
    def n_iter_ML(self):
        return self._n_iter_ML
    @property
    def norm_denoise(self):
        return self._norm_denoise
    @property
    def truncate(self):
        return self._truncate
    @property
    def n_subjects(self):
        return self._n_subjects
    @property
    def n_sim(self):
        return self._n_sim
    @property
    def alpha(self):
        return self._alpha

    @dbaseParams.setter
    def dbaseParams(self,_dbaseParams):
        self._dbaseParams=_dbaseParams
    @ref_model.setter
    def ref_model(self,_ref_model):
        self._ref_model=_ref_model
    @test_percent.setter
    def test_percent(self,_test_percent):
        self._test_percent=_test_percent
    @train_batch_size.setter
    def train_batch_size(self,_train_batch_size):
        self._train_batch_size=_train_batch_size
    @test_batch_size.setter
    def test_batch_size(self,_test_batch_size):
        self._test_batch_size=_test_batch_size
    @shuffle_train.setter
    def shuffle_train(self,_shuffle_train):
        self._shuffle_train=_shuffle_train
    @shuffle_test.setter
    def shuffle_test(self,_shuffle_test):
        self._shuffle_test=_shuffle_test
    @normalize.setter
    def normalize(self,_normalize):
        self._normalize=_normalize
    @min_max_normalize.setter
    def min_max_normalize(self,_min_max_normalize):
        self._min_max_normalize=_min_max_normalize
    @augmentation_GT.setter
    def augmentation_GT(self,_augmentation_GT):
        self._augmentation_GT=_augmentation_GT
    @gaussian_denoising.setter
    def gaussian_denoising(self,_gaussian_denoising):
        self._gaussian_denoising=_gaussian_denoising
    @augmentation_FP.setter
    def augmentation_FP(self,_augmentation_FP):
        self._augmentation_FP=_augmentation_FP

    @augmentation_FP_w.setter
    def augmentation_FP_w(self,_augmentation_FP_w):
        self._augmentation_FP_w=_augmentation_FP_w

    @augmentation_FP_NN.setter
    def augmentation_FP_NN(self,_augmentation_FP_NN):
        self._augmentation_FP_NN=_augmentation_FP_NN

    @augmentation_FP_EM.setter
    def augmentation_FP_EM(self,_augmentation_FP_EM):
        self._augmentation_FP_EM=_augmentation_FP_EM

    @augmentation_outputNN.setter
    def augmentation_outputNN(self,_augmentation_outputNN):
        self._augmentation_outputNN=_augmentation_outputNN
    @norm_sj.setter
    def norm_sj(self,_norm_sj):
        self._norm_sj=_norm_sj
    @norm_train.setter
    def norm_train(self,_norm_train):
        self._norm_train=_norm_train
    @n_iter_ML.setter
    def n_iter_ML(self,_n_iter_ML):
        self._n_iter_ML=_n_iter_ML
    @n_subjects.setter
    def n_subjects(self,_n_subjects):
        self._n_subjects=_n_subjects
    @n_sim.setter
    def n_sim(self,_n_sim):
        self._n_sim=_n_sim
    @norm_denoise.setter
    def norm_denoise(self,_norm_denoise):
        self._norm_denoise=_norm_denoise
    @truncate.setter
    def truncate(self,_truncate):
        self._truncate=_truncate
    @alpha.setter
    def alpha(self,_alpha):
        self._alpha=_alpha

    def save(self,params_fpath):
        '''
        Save the current class parameters using pickle.

        Arguments:
            - params_fpath: filepath to save the parameters (string).
        '''
        dirname=os.path.dirname(params_fpath)
        if not os.path.exists(dirname):
            os.makedirs(dirname)
        with open(params_fpath,"wb") as handle:
            pickle.dump(self.__dict__,handle,protocol=pickle.HIGHEST_PROTOCOL)

    def load(self,params_fpath):
        '''
        Load and update instance using pickle.

        Arguments:
            - params_fpath: filepath where the parameters are saved (string).
        '''
        with open(params_fpath,"rb") as handle:
            tmp=pickle.load(handle)
        self.__dict__.update(tmp)

# def generate_database_IncrdoseRec(doserecParams,scanner="biograph",verbose=True):

#     '''
#     Generates a database using noise-free images, the original forward model, attenuation, normalization, scatter, and
#         randoms sinograms present in the original database, which are the results of a monte-carlo simulation.
#         The forward model sinogram's dose is varied into numerous simulations, with potential further dose reduction, Poisson noise is then applied to each of them,
#         they are then reconstructed and saved to the new directory, the noise-free images or original dose images are also saved, as well as (original/reduced)
#         dose values.

#     Arguments:
#         - doserecParams: parameters for generating database (genSubDatabaseDoserecParams).
#         - scanner: name of scanner (string, default: "biograph").
#         - verbose: verbosity (boolean, default:False).

#     Returns:
#         - all_dose_factor: Varied dose for every generated (potentially low-dose) sample (numpy array [nsim,n_subjects]).
#         - mu: Initial bin sum for every patient (numpy array [nsim,n_subjects]).
#         - all_time: Time taken for every generated sample (numpy array [nsim,n_subjects]).
#     '''

#     if not isinstance(doserecParams,genSubDatabaseDoserecParams):
#         raise TypeError("doserecParams type is not genSubDatabaseDoserecParams ")
#     nit=doserecParams.CASToRParams.nit

#     mu = []
#     dbase_dir=doserecParams.dbase_dir

#     for subject in doserecParams.lst_subjects:
#         fw_sino,_=database_sino.get_fw(subject, dbase_dir)
#         mu.append(np.sum(fw_sino))
#     mean = sum(mu)/len(mu)

#     lst_subjects = doserecParams.lst_subjects_reduced

#     all_time = np.empty(shape = (doserecParams.n_sim, len(lst_subjects)))
#     all_dose_factor = np.empty(shape = (doserecParams.n_sim, len(lst_subjects)))
#     ref_dose_factor = np.empty(shape = (doserecParams.n_sim, len(lst_subjects)))
#     dose_reduc_arr = np.empty(shape = (doserecParams.n_sim, len(lst_subjects)))

#     for i, subject in enumerate(lst_subjects):
#         subject_time = time.time()
#         #Get Filepaths needed to have access to sinograms/corrections
#         proj_dir=doserecParams.get_projections_dir(subject)
#         simu_dir=doserecParams.get_simulations_dir(subject)
#         ecm_file=doserecParams.get_fpath_ecm(subject)
#         #Get sinograms
#         fw_sino3D,_ = database_sino.get_fw(subject, dbase_dir)
#         sc_sino,sc_hdrname= database_sino.get_scat(subject, dbase_dir)
#         rd_sino,rd_hdrname = database_sino.get_rd(subject, dbase_dir)
#         _,att_hdrname=database_sino.get_att(subject, dbase_dir)
#         _,norm_hdrname=database_sino.get_norm(subject, dbase_dir)
#         _,pt_hdrname=database_sino.get_pt(subject, dbase_dir)

#         #Locations where resulting realizations will be stored
#         gen_recons_dir = doserecParams.get_gen_dbase_dir(subject)
#         if not os.path.exists(gen_recons_dir):
#             os.makedirs(gen_recons_dir)

#         #Locations where resulting CASToR data files will be stored
#         if doserecParams.castor_dir is not None:#Create directory to get castor files
#             gen_castor_dir=doserecParams.get_stored_castor_dir(subject)
#             if not os.path.exists(gen_castor_dir):
#                 os.makedirs(gen_castor_dir)

#         #Copy attenuationm norm and calib to dest directory
#         att_hdr=Interfile.load(att_hdrname)
#         att,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(att_hdr,proj_dir,verbose=verbose)
#         PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir, doserecParams.get_fname_sino_att(subject)[0], "",
#                                              att_hdrname,att,verbose=verbose)
#         norm_hdr=Interfile.load(norm_hdrname)
#         norm,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(norm_hdr,proj_dir,verbose=verbose)
#         PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir, doserecParams.get_fname_sino_norm(subject)[0], "",
#                                             norm_hdrname,norm,verbose=verbose)
#         shutil.copy2(doserecParams.get_fpath_dbase_calib(subject),gen_recons_dir)
#         shutil.copy2(pt_hdrname,gen_recons_dir)
#         shutil.copy2(ecm_file,gen_recons_dir)

#         src_files = os.listdir(simu_dir)
#         for file_name in src_files:
#             if "_pt_rep1.s" not in file_name:
#                 file_path = os.path.join(simu_dir, file_name)
#                 if os.path.isfile(file_path):
#                     shutil.copy(file_path, gen_recons_dir)

#         #Get phantom
#         original_phantom_fpath = doserecParams.get_fpath_dbase_phantom(subject)
#         original_phantom_hdr = original_phantom_fpath.replace('.i','.i.hdr')
#         imrec_hdr=Interfile.load(original_phantom_hdr)
#         original_phantom_image,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(imrec_hdr,proj_dir,verbose=verbose)

#         _,pt_hdrname=doserecParams.get_fname_sino_pt(subject)
#         if verbose:
#             print(f"\n\npt_hdrname: {pt_hdrname}\n\n")
#         for real in range(doserecParams.n_sim):
#             real_time = time.time()

#             if doserecParams.same_dose:
#                 alpha = mean/mu[i]
#             else:
#                 alpha = np.random.uniform(min(mu)/(mu[i]), (max(mu))/mu[i])

#             orig_name_ima,orig_name_hdr = doserecParams.get_fname_im_phantom_red(subject,real)
#             print("alpha=",alpha)
#             PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir, orig_name_ima, "", original_phantom_hdr,
#                                                      original_phantom_image * alpha,verbose=verbose)
#             global_dose_reduc = int(dose_reduc_arr[real,i])
#             for dose_reduc_factor in range(global_dose_reduc): #dose_reduc_arr[real,i].astype(int) 
#                 if dose_reduc_factor < 2:
#                     continue
#                 print('-----------------------------------Patient',subject,' (',i+1,') Realization ',real+1, 'Factor', dose_reduc_factor,'-----------------------------------')

#                 assert(doserecParams.dose_reduc is not None)
#                 print(f"\n\n REF: alpha={alpha} ntot={alpha*mu[i]}")
                
#                 dose_reduc_arr[real,i]=doserecParams.dose_reduc
#                 alpha_low=alpha/dose_reduc_factor

#                 # writing reference ordose image 1 for each realization and dose reduction factor
#                 PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir, orig_name_ima, "", original_phantom_hdr,
#                                                         original_phantom_image * alpha/dose_reduc_arr[real,i],verbose=verbose)
#                 #Generate reference
#                 new_fw_sino3D = (fw_sino3D - rd_sino)*alpha + rd_sino*alpha*alpha
#                 new_pt_real = np.random.poisson(new_fw_sino3D.clip(0))
#                 print(f"\n\n REF: ntot={np.sum(new_pt_real[:])}")
#                 print(f"\n\n simudir={simu_dir}, pt_hdrname={pt_hdrname}")
#                 new_sc_sino3D = sc_sino * alpha
#                 new_rd_sino3D = rd_sino * alpha * alpha
#                 real_fname="realization-ref-{0}-{1}-{2}.s".format(subject,real+1, dose_reduc_factor)
#                 real_hdr_fname=real_fname.replace(".s",".s.hdr")
#                 sc_fname="scatter-ref-{0}-{1}-{2}.s".format(subject,real+1, dose_reduc_factor)
#                 sc_hdr_fname=sc_fname.replace(".s",".s.hdr")
#                 rd_fname="randoms-ref-{0}-{1}-{2}.s".format(subject,real+1, dose_reduc_factor)
#                 rd_hdr_fname=rd_fname.replace(".s",".s.hdr")
#                 cdf_name=os.path.basename(real_fname).rsplit('.')[0]
#                 PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir,
#                             real_fname,simu_dir,pt_hdrname,new_pt_real,verbose=verbose)
#                 PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir,
#                             sc_fname,simu_dir,sc_hdrname,new_sc_sino3D.astype("float32"),verbose=verbose)
#                 PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir,
#                             rd_fname,simu_dir,rd_hdrname,new_rd_sino3D.astype("float32"),verbose=verbose)

#                 dest_path=os.path.join(gen_recons_dir, f"realization{subject}-{real+1}-{dose_reduc_factor}")
#                 if os.path.exists(dest_path):
#                     os.unlink(dest_path)
#                 gen_att_hdr=os.path.join(gen_recons_dir,doserecParams.get_fname_sino_att(subject)[1])
#                 gen_norm_hdr=os.path.join(gen_recons_dir,doserecParams.get_fname_sino_norm(subject)[1])
#                 cdf_hdrname,_,_=PETLibs.CASTORCreateDataFile(gen_recons_dir,real_hdr_fname,
#                                     ecm_file,cdf_name,
#                                     att_hdr=gen_att_hdr,
#                                     norm_hdr=gen_norm_hdr,
#                                     sc_hdr=sc_hdr_fname,
#                                     rd_hdr=rd_hdr_fname,nthr=doserecParams.CASToRParams.nthr,
#                                     scanner=scanner,executable=doserecParams.smmaker_exec,verbose=True)
#                 rootname_recons=doserecParams.get_gen_castor_dir(subject,real)
#                 print("before recon with rootname_recons",rootname_recons)
#                 im_rec_fname,_,_=PETLibs.CASTORReconsIm(cdf_hdrname, rootname_recons,cdf_name,gen_recons_dir,
#                                                         CASToRParams=doserecParams.CASToRParams,verbose=verbose)
#                 print("after recon")
#                 img_recons=os.path.dirname(cdf_hdrname)+f"_it{nit}.img"
#                 img_hdr_recons=img_recons.replace(".img",".hdr")
#                 imrec_hdr=Interfile.load(f"{img_hdr_recons}")
#                 ref_image,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(imrec_hdr,gen_recons_dir,verbose=verbose)
#                 os.remove(img_recons)
#                 os.remove(img_hdr_recons)
#                 ref_image=copy.deepcopy(ref_image/dose_reduc_arr[real,i])
#                 ref_img_name,ref_img_hdr_name = doserecParams.get_fname_im_ordose_red_var(subject,real, dose_reduc_factor)
#                 print(f"writing ref_img_name={ref_img_name}")
#                 PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir, ref_img_name, "",
#                                                     original_phantom_hdr, ref_image,verbose=verbose)
#                 datafiles = os.listdir(gen_recons_dir)
#                 h = cdf_hdrname.rsplit('/')[-2]
#                 for file_name in datafiles:
#                     #print(f"h={h}")
#                     lst_delete=["*_it*.hdr","*_it*.img"]
#                     for kdelete in lst_delete:
#                         if fnmatch.fnmatch(file_name,kdelete):
#                             file_path = os.path.join(gen_recons_dir, file_name)
#                             os.remove(file_path)
#                             print(f" delete {file_name}")
#                     if file_name in [h]:
#                         file_path = os.path.join(gen_recons_dir, file_name)
#                         print(f"fpath={file_path}",file_path)
#                         shutil.rmtree(file_path)
#                     ref_dose_factor[real,i]=alpha
#                     #update alpha
#                     alpha=alpha_low

            
#                 all_dose_factor[real, i] = alpha
#                 new_fw_sino3D = (fw_sino3D - rd_sino)*alpha + rd_sino*alpha*alpha
#                 new_pt_real = np.random.poisson(new_fw_sino3D.clip(0))
#                 new_sc_sino3D = sc_sino * alpha
#                 new_rd_sino3D = rd_sino * alpha * alpha
#                 print("current dose reduc", dose_reduc_factor)
#                 real_fname="realization{0}-{1}-{2}.s".format(subject,real+1, dose_reduc_factor)
#                 real_hdr_fname=real_fname.replace(".s",".s.hdr")
#                 sc_fname="scatter{0}-{1}-{2}.s".format(subject,real+1, dose_reduc_factor)
#                 sc_hdr_fname=sc_fname.replace(".s",".s.hdr")
#                 rd_fname="randoms{0}-{1}-{2}.s".format(subject,real+1, dose_reduc_factor)
#                 rd_hdr_fname=rd_fname.replace(".s",".s.hdr")
#                 cdf_name=(doserecParams.get_fname_sinogram_CASToR_hdr_var(subject,real, dose_reduc_factor)[0]).rsplit('.')[0]
#                 print("cdf_name get_fname_sinogram_CASToR_hdr",cdf_name)
#                 PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir,
#                             real_fname,simu_dir,pt_hdrname,new_pt_real,verbose=verbose)
#                 PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir,
#                             sc_fname,simu_dir,sc_hdrname,new_sc_sino3D.astype("float32"),verbose=verbose)
#                 PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir,
#                             rd_fname,simu_dir,rd_hdrname,new_rd_sino3D.astype("float32"),verbose=verbose)
#                 gen_att_hdr=os.path.join(gen_recons_dir,doserecParams.get_fname_sino_att(subject)[1])
#                 gen_norm_hdr=os.path.join(gen_recons_dir,doserecParams.get_fname_sino_norm(subject)[1])
#                 print("create data file for img recon")
#                 cdf_hdrname,_,_=PETLibs.CASTORCreateDataFile(gen_recons_dir,real_hdr_fname,
#                                 ecm_file,cdf_name,
#                                 att_hdr=gen_att_hdr,
#                                 norm_hdr=gen_norm_hdr,
#                                 sc_hdr=sc_hdr_fname,
#                                 rd_hdr=rd_hdr_fname,
#                                 nthr=doserecParams.CASToRParams.nthr,
#                                 scanner=scanner,executable=doserecParams.smmaker_exec,verbose=False)

#                 print("generate castor dir")
#                 rootname_recons=doserecParams.get_gen_castor_dir(subject,real)
#                 im_rec_fname,_,_=PETLibs.CASTORReconsIm(cdf_hdrname, rootname_recons,cdf_name,gen_recons_dir,
#                                                             CASToRParams=doserecParams.CASToRParams,verbose=verbose)
#                 img_recons=os.path.dirname(cdf_hdrname)+f"_it{nit}.img"
#                 img_hdr_recons=img_recons.replace(".img",".hdr")
#                 real_imrec,real_hdr_imrec=doserecParams.get_fname_im_reddose_var(subject,real, dose_reduc_factor)
#                 print(f"real_imrec={real_imrec}")
#                 os.rename(img_recons, os.path.join(gen_recons_dir, real_imrec))
#                 os.rename(img_hdr_recons, os.path.join(gen_recons_dir, real_hdr_imrec))

#                 datafiles = os.listdir(gen_recons_dir)
#                 h = cdf_hdrname.rsplit('/')[-2]
#                 for file_name in datafiles:
#                     #print(f"h={h}")
#                     if(doserecParams.clean_dbase):
#                         lst_delete=["*_it*.hdr","*_it*.img",f"*-{real+1}.s",f"*-{real+1}.s.hdr"]
#                     else:
#                         lst_delete=["*_it*.hdr","*_it*.img"]
#                     for kdelete in lst_delete:
#                         if fnmatch.fnmatch(file_name,kdelete):
#                             file_path = os.path.join(gen_recons_dir, file_name)
#                             os.remove(file_path)
#                             print(f" delete {file_name}")
#                     if file_name in [h]:
#                         file_path = os.path.join(gen_recons_dir, file_name)
#                         if doserecParams.castor_dir is not None:#Copy CASToR subdir in dest_path
#                             dest_path=os.path.join(gen_castor_dir, file_name)
#                             print(f"fpath={file_path},{dest_path}")
#                             if os.path.exists(dest_path):
#                                 shutil.rmtree(dest_path)
#                             shutil.move(file_path,dest_path)
#                             os.symlink(dest_path,file_path)
#                         else:
#                             if(doserecParams.clean_dbase):
#                                 shutil.rmtree(file_path)


#                 if doserecParams.n_sim == 0:
#                     all_time[real, i] = time.time() - subject_time
#                 else:
#                     all_time[real, i] = time.time() - real_time

#         if(doserecParams.clean_dbase):
#             datafiles = os.listdir(gen_recons_dir)
#             for file_name in datafiles:
#                 if (file_name in src_files):
#                     file_path = os.path.join(gen_recons_dir, file_name)
#                     os.remove(file_path)
#         if doserecParams.dose_reduc is not None :
#             np.save(os.path.join(doserecParams.get_gen_dbase_rootdir(),"all_alpha_ref.npy"),ref_dose_factor)
#         np.save(os.path.join(doserecParams.get_gen_dbase_rootdir(),"all_alpha.npy"),all_dose_factor)
#         np.save(os.path.join(doserecParams.get_gen_dbase_rootdir(),"all_mu.npy"),mu)
#         np.save(os.path.join(doserecParams.get_gen_dbase_rootdir(),"all_dose_factor_reduc.npy"),dose_reduc_arr)
#         doserecParams.all_time=all_time
#         doserecParams.all_dose_factor=all_dose_factor
#         doserecParams.ref_dose_factor=ref_dose_factor
#         doserecParams.dose_reduc_arr=dose_reduc_arr
#         doserecParams.all_mu=mu

#     return all_dose_factor, mu, all_time

def generate_database_IncrdoseRec2(doserecParams,scanner="biograph",verbose=True):

    '''
    Generates a database using noise-free images, the original forward model, attenuation, normalization, scatter, and
        randoms sinograms present in the original database, which are the results of a monte-carlo simulation.
        The forward model sinogram's dose is varied into numerous simulations, with potential further dose reduction, Poisson noise is then applied to each of them,
        they are then reconstructed and saved to the new directory, the noise-free images or original dose images are also saved, as well as (original/reduced)
        dose values.

    Arguments:
        - doserecParams: parameters for generating database (genSubDatabaseDoserecParams).
        - scanner: name of scanner (string, default: "biograph").
        - verbose: verbosity (boolean, default:False).

    Returns:
        - all_dose_factor: Varied dose for every generated (potentially low-dose) sample (numpy array [nsim,n_subjects]).
        - mu: Initial bin sum for every patient (numpy array [nsim,n_subjects]).
        - all_time: Time taken for every generated sample (numpy array [nsim,n_subjects]).
    '''

    if not isinstance(doserecParams,genSubDatabaseDoserecParams):
        raise TypeError("doserecParams type is not genSubDatabaseDoserecParams ")
    nit=doserecParams.CASToRParams.nit

    mu = []
    dbase_dir=doserecParams.dbase_dir

    for subject in doserecParams.lst_subjects:
        fw_sino,_=database_sino.get_fw(subject, dbase_dir)
        mu.append(np.sum(fw_sino))
    mean = sum(mu)/len(mu)

    lst_subjects = doserecParams.lst_subjects_reduced

    all_time = np.empty(shape = (doserecParams.n_sim, len(lst_subjects)))
    all_dose_factor = np.empty(shape = (doserecParams.n_sim, len(lst_subjects)))
    ref_dose_factor = np.empty(shape = (doserecParams.n_sim, len(lst_subjects)))
    dose_reduc_arr = np.empty(shape = (doserecParams.n_sim, len(lst_subjects)))

    for i, subject in enumerate(lst_subjects):
        subject_time = time.time()
        #Get Filepaths needed to have access to sinograms/corrections
        proj_dir=doserecParams.get_projections_dir(subject)
        simu_dir=doserecParams.get_simulations_dir(subject)
        ecm_file=doserecParams.get_fpath_ecm(subject)
        #Get sinograms
        fw_sino3D,_ = database_sino.get_fw(subject, dbase_dir)
        sc_sino,sc_hdrname= database_sino.get_scat(subject, dbase_dir)
        rd_sino,rd_hdrname = database_sino.get_rd(subject, dbase_dir)
        _,att_hdrname=database_sino.get_att(subject, dbase_dir)
        _,norm_hdrname=database_sino.get_norm(subject, dbase_dir)
        _,pt_hdrname=database_sino.get_pt(subject, dbase_dir)

        #Locations where resulting realizations will be stored
        gen_recons_dir = doserecParams.get_gen_dbase_dir(subject)
        if not os.path.exists(gen_recons_dir):
            os.makedirs(gen_recons_dir)

        #Locations where resulting CASToR data files will be stored
        if doserecParams.castor_dir is not None:#Create directory to get castor files
            gen_castor_dir=doserecParams.get_stored_castor_dir(subject)
            if not os.path.exists(gen_castor_dir):
                os.makedirs(gen_castor_dir)

        #Copy attenuationm norm and calib to dest directory
        att_hdr=Interfile.load(att_hdrname)
        att,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(att_hdr,proj_dir,verbose=verbose)
        PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir, doserecParams.get_fname_sino_att(subject)[0], "",
                                             att_hdrname,att,verbose=verbose)
        norm_hdr=Interfile.load(norm_hdrname)
        norm,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(norm_hdr,proj_dir,verbose=verbose)
        PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir, doserecParams.get_fname_sino_norm(subject)[0], "",
                                            norm_hdrname,norm,verbose=verbose)
        shutil.copy2(doserecParams.get_fpath_dbase_calib(subject),gen_recons_dir)
        shutil.copy2(pt_hdrname,gen_recons_dir)
        shutil.copy2(ecm_file,gen_recons_dir)

        src_files = os.listdir(simu_dir)
        for file_name in src_files:
            if "_pt_rep1.s" not in file_name:
                file_path = os.path.join(simu_dir, file_name)
                if os.path.isfile(file_path):
                    shutil.copy(file_path, gen_recons_dir)

        #Get phantom
        original_phantom_fpath = doserecParams.get_fpath_dbase_phantom(subject)
        original_phantom_hdr = original_phantom_fpath.replace('.i','.i.hdr')
        imrec_hdr=Interfile.load(original_phantom_hdr)
        original_phantom_image,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(imrec_hdr,proj_dir,verbose=verbose)

        _,pt_hdrname=doserecParams.get_fname_sino_pt(subject)
        if verbose:
            print(f"\n\npt_hdrname: {pt_hdrname}\n\n")
        for real in range(doserecParams.n_sim):
            real_time = time.time()

            if doserecParams.same_dose:
                alpha = mean/mu[i]
            else:
                alpha = np.random.uniform(min(mu)/(mu[i]), (max(mu))/mu[i])

            orig_name_ima,orig_name_hdr = doserecParams.get_fname_im_phantom_red(subject,real)
            print("alpha=",alpha)
            PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir, orig_name_ima, "", original_phantom_hdr,
                                                     original_phantom_image * alpha,verbose=verbose)
            print('-----------------------------------Patient',subject,' (',i+1,') Realization ',real+1, '-----------------------------------')
            dose_reduc_arr[real,i]=doserecParams.dose_reduc
            global_dose_reduc = int(dose_reduc_arr[real,i])

            # writing reference ordose image 1 for each realization and dose reduction factor
            PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir, orig_name_ima, "", original_phantom_hdr,
                                                    original_phantom_image * alpha/dose_reduc_arr[real,i],verbose=verbose)
            #Generate reference
            new_fw_sino3D = (fw_sino3D - rd_sino)*alpha + rd_sino*alpha*alpha
            new_pt_real = np.random.poisson(new_fw_sino3D.clip(0))
            print(f"\n\n REF: ntot={np.sum(new_pt_real[:])}")
            print(f"\n\n simudir={simu_dir}, pt_hdrname={pt_hdrname}")
            new_sc_sino3D = sc_sino * alpha
            new_rd_sino3D = rd_sino * alpha * alpha
            real_fname="realization-ref-{0}-{1}.s".format(subject,real+1)
            real_hdr_fname=real_fname.replace(".s",".s.hdr")
            sc_fname="scatter-ref-{0}-{1}.s".format(subject,real+1)
            sc_hdr_fname=sc_fname.replace(".s",".s.hdr")
            rd_fname="randoms-ref-{0}-{1}.s".format(subject,real+1)
            rd_hdr_fname=rd_fname.replace(".s",".s.hdr")
            cdf_name=os.path.basename(real_fname).rsplit('.')[0]
            PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir,
                        real_fname,simu_dir,pt_hdrname,new_pt_real,verbose=verbose)
            PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir,
                        sc_fname,simu_dir,sc_hdrname,new_sc_sino3D.astype("float32"),verbose=verbose)
            PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir,
                        rd_fname,simu_dir,rd_hdrname,new_rd_sino3D.astype("float32"),verbose=verbose)

            
            gen_att_hdr=os.path.join(gen_recons_dir,doserecParams.get_fname_sino_att(subject)[1])
            gen_norm_hdr=os.path.join(gen_recons_dir,doserecParams.get_fname_sino_norm(subject)[1])
            cdf_hdrname,_,_=PETLibs.CASTORCreateDataFile(gen_recons_dir,real_hdr_fname,
                                ecm_file,cdf_name,
                                att_hdr=gen_att_hdr,
                                norm_hdr=gen_norm_hdr,
                                sc_hdr=sc_hdr_fname,
                                rd_hdr=rd_hdr_fname,nthr=doserecParams.CASToRParams.nthr,
                                scanner=scanner,executable=doserecParams.smmaker_exec,verbose=True)
            rootname_recons=doserecParams.get_gen_castor_dir(subject,real)
            im_rec_fname,_,_=PETLibs.CASTORReconsIm(cdf_hdrname, rootname_recons,cdf_name,gen_recons_dir,
                                                    CASToRParams=doserecParams.CASToRParams,verbose=verbose)
            img_recons=os.path.dirname(cdf_hdrname)+f"_it{nit}.img"
            img_hdr_recons=img_recons.replace(".img",".hdr")
            imrec_hdr=Interfile.load(f"{img_hdr_recons}")
            ref_image,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(imrec_hdr,gen_recons_dir,verbose=verbose)
            os.remove(img_recons)
            os.remove(img_hdr_recons)
            ref_image=copy.deepcopy(ref_image/dose_reduc_arr[real,i])
            ref_img_name,ref_img_hdr_name = doserecParams.get_fname_im_ordose_red(subject,real)
            print(f"writing ref_img_name={ref_img_name}")
            PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir, ref_img_name, "",
                                                original_phantom_hdr, ref_image,verbose=verbose)
            datafiles = os.listdir(gen_recons_dir)
            h = cdf_hdrname.rsplit('/')[-2]
            for file_name in datafiles:
                #print(f"h={h}")
                lst_delete=["*_it*.hdr","*_it*.img"]
                for kdelete in lst_delete:
                    if fnmatch.fnmatch(file_name,kdelete):
                        file_path = os.path.join(gen_recons_dir, file_name)
                        os.remove(file_path)
                        print(f" delete {file_name}")
                if file_name in [h]:
                    file_path = os.path.join(gen_recons_dir, file_name)
                    print(f"fpath={file_path}",file_path)
                    shutil.rmtree(file_path)

            ref_dose_factor[real,i] = alpha
            all_dose_factor[real, i] = alpha/dose_reduc_arr[real,i]
            for dose_reduc_factor in range(global_dose_reduc+1): #dose_reduc_arr[real,i].astype(int) 
                if dose_reduc_factor > 1:
                    # factor_div = global_dose_reduc/dose_reduc_factor
                    print('-------------------------------------------Patient',subject,' (',i+1,') Realization ',real+1, 'Factor', dose_reduc_factor,'--------------------------------------------')
                    dest_path=os.path.join(gen_recons_dir, f"realization{subject}-{real+1}-{dose_reduc_factor}")
                    if os.path.exists(dest_path):
                        os.unlink(dest_path)
                    assert(doserecParams.dose_reduc is not None)
                    
                    
                    alpha_low=alpha/dose_reduc_factor    
                    # all_dose_factor[real, i]=alpha_low
                    #update alpha

                
                    
                    new_fw_sino3D = (fw_sino3D - rd_sino)*alpha_low + rd_sino*alpha_low*alpha_low
                    new_pt_real = np.random.poisson(new_fw_sino3D.clip(0))
                    new_sc_sino3D = sc_sino * alpha_low
                    new_rd_sino3D = rd_sino * alpha_low * alpha_low
                    # print("current dose reduc", dose_reduc_factor)
                    # print("alpha_low", alpha_low, "alpha", alpha)
                    real_fname="realization{0}-{1}-{2}.s".format(subject,real+1, dose_reduc_factor)
                    real_hdr_fname=real_fname.replace(".s",".s.hdr")
                    sc_fname="scatter{0}-{1}-{2}.s".format(subject,real+1, dose_reduc_factor)
                    sc_hdr_fname=sc_fname.replace(".s",".s.hdr")
                    rd_fname="randoms{0}-{1}-{2}.s".format(subject,real+1, dose_reduc_factor)
                    rd_hdr_fname=rd_fname.replace(".s",".s.hdr")
                    cdf_name=(doserecParams.get_fname_sinogram_CASToR_hdr_var(subject,real, dose_reduc_factor)[0]).rsplit('.')[0]
                    # print("cdf_name get_fname_sinogram_CASToR_hdr",cdf_name)
                    PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir,
                                real_fname,simu_dir,pt_hdrname,new_pt_real,verbose=verbose)
                    PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir,
                                sc_fname,simu_dir,sc_hdrname,new_sc_sino3D.astype("float32"),verbose=verbose)
                    PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir,
                                rd_fname,simu_dir,rd_hdrname,new_rd_sino3D.astype("float32"),verbose=verbose)
                    gen_att_hdr=os.path.join(gen_recons_dir,doserecParams.get_fname_sino_att(subject)[1])
                    gen_norm_hdr=os.path.join(gen_recons_dir,doserecParams.get_fname_sino_norm(subject)[1])
                    cdf_hdrname,_,_=PETLibs.CASTORCreateDataFile(gen_recons_dir,real_hdr_fname,
                                    ecm_file,cdf_name,
                                    att_hdr=gen_att_hdr,
                                    norm_hdr=gen_norm_hdr,
                                    sc_hdr=sc_hdr_fname,
                                    rd_hdr=rd_hdr_fname,
                                    nthr=doserecParams.CASToRParams.nthr,
                                    scanner=scanner,executable=doserecParams.smmaker_exec,verbose=False)

                    rootname_recons=doserecParams.get_gen_castor_dir_var(subject,real, dose_reduc_factor)
                    im_rec_fname,_,_=PETLibs.CASTORReconsIm(cdf_hdrname, rootname_recons,cdf_name,gen_recons_dir,
                                                                CASToRParams=doserecParams.CASToRParams,verbose=verbose)
                    img_recons=os.path.dirname(cdf_hdrname)+f"_it{nit}.img"
                    img_hdr_recons=img_recons.replace(".img",".hdr")
                    # imrec_hdr=Interfile.load(f"{img_hdr_recons}")
                    # ref_image,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(imrec_hdr,gen_recons_dir,verbose=verbose)
                    # print("+++++++++++++++++++++++++++++++++++++++++++++++")
                    # print("read image",img_hdr_recons)
                    # print("fctor_div",factor_div)
                    # ref_image=copy.deepcopy(ref_image/factor_div)
                    real_imrec,real_hdr_imrec=doserecParams.get_fname_im_reddose_var(subject,real, dose_reduc_factor)
                    # PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir, real_imrec, "",
                    #                                 img_hdr_recons, ref_image,verbose=verbose)
                    # print(f"real_imrec={real_imrec}")
                    os.rename(img_recons, os.path.join(gen_recons_dir, real_imrec))
                    os.rename(img_hdr_recons, os.path.join(gen_recons_dir, real_hdr_imrec))
                    print("+++++++++++++++++++++++++++++++++++++++++++++++")

                    datafiles = os.listdir(gen_recons_dir)
                    h = cdf_hdrname.rsplit('/')[-2]
                    for file_name in datafiles:
                        #print(f"h={h}")
                        if(doserecParams.clean_dbase):
                            lst_delete=["*_it*.hdr","*_it*.img",f"*{subject}-{real+1}-{dose_reduc_factor}.s",f"*{subject}-{real+1}-{dose_reduc_factor}.s.hdr",f"*{subject}-{real+1}.s",f"*{subject}-{real+1}.s.hdr"]
                        else:
                            lst_delete=["*_it*.hdr","*_it*.img"]
                        for kdelete in lst_delete:
                            if fnmatch.fnmatch(file_name,kdelete):
                                file_path = os.path.join(gen_recons_dir, file_name)
                                os.remove(file_path)
                                print(f" delete {file_name}")
                        if file_name in [h]:
                            file_path = os.path.join(gen_recons_dir, file_name)
                            if doserecParams.castor_dir is not None:#Copy CASToR subdir in dest_path
                                dest_path=os.path.join(gen_castor_dir, file_name)
                                print(f"fpath={file_path},{dest_path}")
                                if os.path.exists(dest_path):
                                    shutil.rmtree(dest_path)
                                shutil.move(file_path,dest_path)
                                os.symlink(dest_path,file_path)
                            else:
                                if(doserecParams.clean_dbase):
                                    shutil.rmtree(file_path)


            if doserecParams.n_sim == 0:
                all_time[real, i] = time.time() - subject_time
            else:
                all_time[real, i] = time.time() - real_time

        if(doserecParams.clean_dbase):
            datafiles = os.listdir(gen_recons_dir)
            for file_name in datafiles:
                if (file_name in src_files):
                    file_path = os.path.join(gen_recons_dir, file_name)
                    os.remove(file_path)
        if doserecParams.dose_reduc is not None :
            np.save(os.path.join(doserecParams.get_gen_dbase_rootdir(),"all_alpha_ref.npy"),ref_dose_factor)
        np.save(os.path.join(doserecParams.get_gen_dbase_rootdir(),"all_alpha.npy"),all_dose_factor)
        np.save(os.path.join(doserecParams.get_gen_dbase_rootdir(),"all_mu.npy"),mu)
        np.save(os.path.join(doserecParams.get_gen_dbase_rootdir(),"all_dose_factor_reduc.npy"),dose_reduc_arr)
        doserecParams.all_time=all_time
        doserecParams.all_dose_factor=all_dose_factor
        doserecParams.ref_dose_factor=ref_dose_factor
        doserecParams.dose_reduc_arr=dose_reduc_arr
        doserecParams.all_mu=mu

    return all_dose_factor, mu, all_time


# def generate_database_IncrdoseRec3(doserecParams,scanner="biograph",verbose=True):

#     '''
#     Generates a database using noise-free images, the original forward model, attenuation, normalization, scatter, and
#         randoms sinograms present in the original database, which are the results of a monte-carlo simulation.
#         The forward model sinogram's dose is varied into numerous simulations, with potential further dose reduction, Poisson noise is then applied to each of them,
#         they are then reconstructed and saved to the new directory, the noise-free images or original dose images are also saved, as well as (original/reduced)
#         dose values.

#     Arguments:
#         - doserecParams: parameters for generating database (genSubDatabaseDoserecParams).
#         - scanner: name of scanner (string, default: "biograph").
#         - verbose: verbosity (boolean, default:False).

#     Returns:
#         - all_dose_factor: Varied dose for every generated (potentially low-dose) sample (numpy array [nsim,n_subjects]).
#         - mu: Initial bin sum for every patient (numpy array [nsim,n_subjects]).
#         - all_time: Time taken for every generated sample (numpy array [nsim,n_subjects]).
#     '''

#     if not isinstance(doserecParams,genSubDatabaseDoserecParams):
#         raise TypeError("doserecParams type is not genSubDatabaseDoserecParams ")
#     nit=doserecParams.CASToRParams.nit

#     mu = []
#     dbase_dir=doserecParams.dbase_dir

#     for subject in doserecParams.lst_subjects:
#         fw_sino,_=database_sino.get_fw(subject, dbase_dir)
#         mu.append(np.sum(fw_sino))
#     mean = sum(mu)/len(mu)

#     lst_subjects = doserecParams.lst_subjects_reduced

#     all_time = np.empty(shape = (doserecParams.n_sim, len(lst_subjects)))
#     all_dose_factor = np.empty(shape = (doserecParams.n_sim, len(lst_subjects)))
#     ref_dose_factor = np.empty(shape = (doserecParams.n_sim, len(lst_subjects)))
#     dose_reduc_arr = np.empty(shape = (doserecParams.n_sim, len(lst_subjects)))

#     for i, subject in enumerate(lst_subjects):
#         subject_time = time.time()
#         #Get Filepaths needed to have access to sinograms/corrections
#         proj_dir=doserecParams.get_projections_dir(subject)
#         simu_dir=doserecParams.get_simulations_dir(subject)
#         ecm_file=doserecParams.get_fpath_ecm(subject)
#         #Get sinograms
#         fw_sino3D,_ = database_sino.get_fw(subject, dbase_dir)
#         sc_sino,sc_hdrname= database_sino.get_scat(subject, dbase_dir)
#         rd_sino,rd_hdrname = database_sino.get_rd(subject, dbase_dir)
#         _,att_hdrname=database_sino.get_att(subject, dbase_dir)
#         _,norm_hdrname=database_sino.get_norm(subject, dbase_dir)
#         _,pt_hdrname=database_sino.get_pt(subject, dbase_dir)

#         #Locations where resulting realizations will be stored
#         gen_recons_dir = doserecParams.get_gen_dbase_dir(subject)
#         if not os.path.exists(gen_recons_dir):
#             os.makedirs(gen_recons_dir)

#         #Locations where resulting CASToR data files will be stored
#         if doserecParams.castor_dir is not None:#Create directory to get castor files
#             gen_castor_dir=doserecParams.get_stored_castor_dir(subject)
#             if not os.path.exists(gen_castor_dir):
#                 os.makedirs(gen_castor_dir)

#         #Copy attenuationm norm and calib to dest directory
#         att_hdr=Interfile.load(att_hdrname)
#         att,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(att_hdr,proj_dir,verbose=verbose)
#         PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir, doserecParams.get_fname_sino_att(subject)[0], "",
#                                              att_hdrname,att,verbose=verbose)
#         norm_hdr=Interfile.load(norm_hdrname)
#         norm,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(norm_hdr,proj_dir,verbose=verbose)
#         PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir, doserecParams.get_fname_sino_norm(subject)[0], "",
#                                             norm_hdrname,norm,verbose=verbose)
#         shutil.copy2(doserecParams.get_fpath_dbase_calib(subject),gen_recons_dir)
#         shutil.copy2(pt_hdrname,gen_recons_dir)
#         shutil.copy2(ecm_file,gen_recons_dir)

#         src_files = os.listdir(simu_dir)
#         for file_name in src_files:
#             if "_pt_rep1.s" not in file_name:
#                 file_path = os.path.join(simu_dir, file_name)
#                 if os.path.isfile(file_path):
#                     shutil.copy(file_path, gen_recons_dir)

#         #Get phantom
#         original_phantom_fpath = doserecParams.get_fpath_dbase_phantom(subject)
#         original_phantom_hdr = original_phantom_fpath.replace('.i','.i.hdr')
#         imrec_hdr=Interfile.load(original_phantom_hdr)
#         original_phantom_image,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(imrec_hdr,proj_dir,verbose=verbose)

#         _,pt_hdrname=doserecParams.get_fname_sino_pt(subject)
#         if verbose:
#             print(f"\n\npt_hdrname: {pt_hdrname}\n\n")
#         for real in range(doserecParams.n_sim):
#             real_time = time.time()

#             if doserecParams.same_dose:
#                 alpha = mean/mu[i]
#             else:
#                 alpha = np.random.uniform(min(mu)/(mu[i]), (max(mu))/mu[i])

#             orig_name_ima,orig_name_hdr = doserecParams.get_fname_im_phantom_red(subject,real)
#             print("alpha=",alpha)
#             #Generate reference
#             new_fw_sino3D = (fw_sino3D - rd_sino)*alpha + rd_sino*alpha*alpha
#             new_pt_real = np.random.poisson(new_fw_sino3D.clip(0))
#             print(f"\n\n REF: ntot={np.sum(new_pt_real[:])}")
#             print(f"\n\n simudir={simu_dir}, pt_hdrname={pt_hdrname}")
#             new_sc_sino3D = sc_sino * alpha
#             new_rd_sino3D = rd_sino * alpha * alpha
#             real_fname="realization-ref-{0}-{1}.s".format(subject,real+1)
#             real_hdr_fname=real_fname.replace(".s",".s.hdr")
#             sc_fname="scatter-ref-{0}-{1}.s".format(subject,real+1)
#             sc_hdr_fname=sc_fname.replace(".s",".s.hdr")
#             rd_fname="randoms-ref-{0}-{1}.s".format(subject,real+1)
#             rd_hdr_fname=rd_fname.replace(".s",".s.hdr")
#             cdf_name=os.path.basename(real_fname).rsplit('.')[0]
#             PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir,
#                         real_fname,simu_dir,pt_hdrname,new_pt_real,verbose=verbose)
#             PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir,
#                         sc_fname,simu_dir,sc_hdrname,new_sc_sino3D.astype("float32"),verbose=verbose)
#             PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir,
#                         rd_fname,simu_dir,rd_hdrname,new_rd_sino3D.astype("float32"),verbose=verbose)

            
#             gen_att_hdr=os.path.join(gen_recons_dir,doserecParams.get_fname_sino_att(subject)[1])
#             gen_norm_hdr=os.path.join(gen_recons_dir,doserecParams.get_fname_sino_norm(subject)[1])
#             cdf_hdrname,_,_=PETLibs.CASTORCreateDataFile(gen_recons_dir,real_hdr_fname,
#                                 ecm_file,cdf_name,
#                                 att_hdr=gen_att_hdr,
#                                 norm_hdr=gen_norm_hdr,
#                                 sc_hdr=sc_hdr_fname,
#                                 rd_hdr=rd_hdr_fname,nthr=doserecParams.CASToRParams.nthr,
#                                 scanner=scanner,executable=doserecParams.smmaker_exec,verbose=True)
#             rootname_recons=doserecParams.get_gen_castor_dir(subject,real)
#             print("before recon with rootname_recons",rootname_recons)
#             im_rec_fname,_,_=PETLibs.CASTORReconsIm(cdf_hdrname, rootname_recons,cdf_name,gen_recons_dir,
#                                                     CASToRParams=doserecParams.CASToRParams,verbose=verbose)
#             print("after recon")
#             img_recons=os.path.dirname(cdf_hdrname)+f"_it{nit}.img"
#             img_hdr_recons=img_recons.replace(".img",".hdr")
#             imrec_hdr=Interfile.load(f"{img_hdr_recons}")
#             ref_image,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(imrec_hdr,gen_recons_dir,verbose=verbose)
#             os.remove(img_recons)
#             os.remove(img_hdr_recons)


            

#             ref_dose_factor[real,i]=alpha
#             all_dose_factor[real, i] = alpha
#             for dose_reduc_factor in range(5+1): #dose_reduc_arr[real,i].astype(int) 
#                 if dose_reduc_factor > 1:
#                     print('-------------------------------------------Patient',subject,' (',i+1,') Realization ',real+1, 'Factor', dose_reduc_factor,'--------------------------------------------')
                    
                    
#                     dose_reduc_arr[real,i]=doserecParams.dose_reduc

#                     PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir, orig_name_ima, "", original_phantom_hdr,
#                                         original_phantom_image * alpha/dose_reduc_factor,verbose=verbose)

#                     ref_image=copy.deepcopy(ref_image/dose_reduc_factor)
#                     ref_img_name,ref_img_hdr_name = doserecParams.get_fname_im_ordose_red(subject,real)
#                     print(f"writing ref_img_name={ref_img_name}")
#                     PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir, ref_img_name, "",
#                                                 original_phantom_hdr, ref_image,verbose=verbose)
#                     datafiles = os.listdir(gen_recons_dir)
#                     h = cdf_hdrname.rsplit('/')[-2]
#                     for file_name in datafiles:
#                         #print(f"h={h}")
#                         lst_delete=["*_it*.hdr","*_it*.img"]
#                         for kdelete in lst_delete:
#                             if fnmatch.fnmatch(file_name,kdelete):
#                                 file_path = os.path.join(gen_recons_dir, file_name)
#                                 os.remove(file_path)
#                                 print(f" delete {file_name}")
#                         if file_name in [h]:
#                             file_path = os.path.join(gen_recons_dir, file_name)
#                             print(f"fpath={file_path}",file_path)
#                             shutil.rmtree(file_path)



#                     dest_path=os.path.join(gen_recons_dir, f"realization{subject}-{real+1}-{dose_reduc_factor}")
#                     if os.path.exists(dest_path):
#                         os.unlink(dest_path)
#                     assert(doserecParams.dose_reduc is not None)
                    
                    
#                     alpha_low=alpha/dose_reduc_factor    
#                     #update alpha

#                     PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir, orig_name_ima, "", original_phantom_hdr,
#                                                      original_phantom_image * alpha_low,verbose=verbose)
                    
#                     new_fw_sino3D = (fw_sino3D - rd_sino)*alpha_low + rd_sino*alpha_low*alpha_low
#                     new_pt_real = np.random.poisson(new_fw_sino3D.clip(0))
#                     new_sc_sino3D = sc_sino * alpha_low
#                     new_rd_sino3D = rd_sino * alpha_low * alpha_low
#                     print("current dose reduc", dose_reduc_factor)
#                     print("alpha_low", alpha_low, "alpha", alpha)
#                     real_fname="realization{0}-{1}-{2}.s".format(subject,real+1, dose_reduc_factor)
#                     real_hdr_fname=real_fname.replace(".s",".s.hdr")
#                     sc_fname="scatter{0}-{1}-{2}.s".format(subject,real+1, dose_reduc_factor)
#                     sc_hdr_fname=sc_fname.replace(".s",".s.hdr")
#                     rd_fname="randoms{0}-{1}-{2}.s".format(subject,real+1, dose_reduc_factor)
#                     rd_hdr_fname=rd_fname.replace(".s",".s.hdr")
#                     cdf_name=(doserecParams.get_fname_sinogram_CASToR_hdr_var(subject,real, dose_reduc_factor)[0]).rsplit('.')[0]
#                     print("cdf_name get_fname_sinogram_CASToR_hdr",cdf_name)
#                     PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir,
#                                 real_fname,simu_dir,pt_hdrname,new_pt_real,verbose=verbose)
#                     PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir,
#                                 sc_fname,simu_dir,sc_hdrname,new_sc_sino3D.astype("float32"),verbose=verbose)
#                     PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir,
#                                 rd_fname,simu_dir,rd_hdrname,new_rd_sino3D.astype("float32"),verbose=verbose)
#                     gen_att_hdr=os.path.join(gen_recons_dir,doserecParams.get_fname_sino_att(subject)[1])
#                     gen_norm_hdr=os.path.join(gen_recons_dir,doserecParams.get_fname_sino_norm(subject)[1])
#                     cdf_hdrname,_,_=PETLibs.CASTORCreateDataFile(gen_recons_dir,real_hdr_fname,
#                                     ecm_file,cdf_name,
#                                     att_hdr=gen_att_hdr,
#                                     norm_hdr=gen_norm_hdr,
#                                     sc_hdr=sc_hdr_fname,
#                                     rd_hdr=rd_hdr_fname,
#                                     nthr=doserecParams.CASToRParams.nthr,
#                                     scanner=scanner,executable=doserecParams.smmaker_exec,verbose=False)

#                     print("generate castor dir")
#                     rootname_recons=doserecParams.get_gen_castor_dir_var(subject,real, dose_reduc_factor)
#                     im_rec_fname,_,_=PETLibs.CASTORReconsIm(cdf_hdrname, rootname_recons,cdf_name,gen_recons_dir,
#                                                                 CASToRParams=doserecParams.CASToRParams,verbose=verbose)
#                     img_recons=os.path.dirname(cdf_hdrname)+f"_it{nit}.img"
#                     img_hdr_recons=img_recons.replace(".img",".hdr")
#                     real_imrec,real_hdr_imrec=doserecParams.get_fname_im_reddose_var(subject,real, dose_reduc_factor)
#                     print(f"real_imrec={real_imrec}")
#                     os.rename(img_recons, os.path.join(gen_recons_dir, real_imrec))
#                     os.rename(img_hdr_recons, os.path.join(gen_recons_dir, real_hdr_imrec))

#                     datafiles = os.listdir(gen_recons_dir)
#                     h = cdf_hdrname.rsplit('/')[-2]
#                     for file_name in datafiles:
#                         #print(f"h={h}")
#                         if(doserecParams.clean_dbase):
#                             lst_delete=["*_it*.hdr","*_it*.img",f"*{subject}-{real+1}-{dose_reduc_factor}.s",f"*{subject}-{real+1}-{dose_reduc_factor}.s.hdr",f"*{subject}-{real+1}.s",f"*{subject}-{real+1}.s.hdr"]
#                         else:
#                             lst_delete=["*_it*.hdr","*_it*.img"]
#                         for kdelete in lst_delete:
#                             if fnmatch.fnmatch(file_name,kdelete):
#                                 file_path = os.path.join(gen_recons_dir, file_name)
#                                 os.remove(file_path)
#                                 print(f" delete {file_name}")
#                         if file_name in [h]:
#                             file_path = os.path.join(gen_recons_dir, file_name)
#                             if doserecParams.castor_dir is not None:#Copy CASToR subdir in dest_path
#                                 dest_path=os.path.join(gen_castor_dir, file_name)
#                                 print(f"fpath={file_path},{dest_path}")
#                                 if os.path.exists(dest_path):
#                                     shutil.rmtree(dest_path)
#                                 shutil.move(file_path,dest_path)
#                                 os.symlink(dest_path,file_path)
#                             else:
#                                 if(doserecParams.clean_dbase):
#                                     shutil.rmtree(file_path)


#             if doserecParams.n_sim == 0:
#                 all_time[real, i] = time.time() - subject_time
#             else:
#                 all_time[real, i] = time.time() - real_time

#         if(doserecParams.clean_dbase):
#             datafiles = os.listdir(gen_recons_dir)
#             for file_name in datafiles:
#                 if (file_name in src_files):
#                     file_path = os.path.join(gen_recons_dir, file_name)
#                     os.remove(file_path)
#         if doserecParams.dose_reduc is not None :
#             np.save(os.path.join(doserecParams.get_gen_dbase_rootdir(),"all_alpha_ref.npy"),ref_dose_factor)
#         np.save(os.path.join(doserecParams.get_gen_dbase_rootdir(),"all_alpha.npy"),all_dose_factor)
#         np.save(os.path.join(doserecParams.get_gen_dbase_rootdir(),"all_mu.npy"),mu)
#         np.save(os.path.join(doserecParams.get_gen_dbase_rootdir(),"all_dose_factor_reduc.npy"),dose_reduc_arr)
#         doserecParams.all_time=all_time
#         doserecParams.all_dose_factor=all_dose_factor
#         doserecParams.ref_dose_factor=ref_dose_factor
#         doserecParams.dose_reduc_arr=dose_reduc_arr
#         doserecParams.all_mu=mu

#     return all_dose_factor, mu, all_time


def generate_database_doseRec(doserecParams,scanner="biograph",verbose=True, suffix = "", version="", seed = 0):

    '''
    Generates a database using noise-free images, the original forward model, attenuation, normalization, scatter, and
        randoms sinograms present in the original database, which are the results of a monte-carlo simulation.
        The forward model sinogram's dose is varied into numerous simulations, with potential further dose reduction, Poisson noise is then applied to each of them,
        they are then reconstructed and saved to the new directory, the noise-free images or original dose images are also saved, as well as (original/reduced)
        dose values.

    Arguments:
        - doserecParams: parameters for generating database (genSubDatabaseDoserecParams).
        - scanner: name of scanner (string, default: "biograph").
        - verbose: verbosity (boolean, default:False).

    Returns:
        - all_dose_factor: Varied dose for every generated (potentially low-dose) sample (numpy array [nsim,n_subjects]).
        - mu: Initial bin sum for every patient (numpy array [nsim,n_subjects]).
        - all_time: Time taken for every generated sample (numpy array [nsim,n_subjects]).
    '''

    if not isinstance(doserecParams,genSubDatabaseDoserecParams):
        raise TypeError("doserecParams type is not genSubDatabaseDoserecParams ")
    dim=doserecParams.CASToRParams.im_dim
    nit=doserecParams.CASToRParams.nit

    # np.random.seed(seed)

    mu = []
    dbase_dir=doserecParams.dbase_dir

    for subject in doserecParams.lst_subjects:
        fw_sino,_=database_sino.get_fw(subject, dbase_dir, suffix, version)
        mu.append(np.sum(fw_sino))
    mean = sum(mu)/len(mu)

    lst_subjects = doserecParams.lst_subjects_reduced

    all_time = np.empty(shape = (doserecParams.n_sim, len(lst_subjects)))
    all_dose_factor = np.empty(shape = (doserecParams.n_sim, len(lst_subjects)))
    ref_dose_factor = np.empty(shape = (doserecParams.n_sim, len(lst_subjects)))
    dose_reduc_arr = np.empty(shape = (doserecParams.n_sim, len(lst_subjects)))

    for i, subject in enumerate(lst_subjects):
        subject_time = time.time()
        #Get Filepaths needed to have access to sinograms/corrections
        proj_dir=doserecParams.get_projections_dir(subject,suffix, version)
        simu_dir=doserecParams.get_simulations_dir(subject,suffix, version)
        ecm_file=doserecParams.get_fpath_ecm(subject,suffix)
        #Get sinograms
        fw_sino3D,_ = database_sino.get_fw(subject, dbase_dir, suffix, version)
        sc_sino,sc_hdrname= database_sino.get_scat(subject, dbase_dir, suffix, version)
        rd_sino,rd_hdrname = database_sino.get_rd(subject, dbase_dir, suffix, version)
        _,att_hdrname=database_sino.get_att(subject, dbase_dir, suffix, version)
        _,norm_hdrname=database_sino.get_norm(subject, dbase_dir, suffix, version)
        if suffix == "":
            _,pt_hdrname=database_sino.get_pt(subject, dbase_dir)
        else :
            _,pt_hdrname=database_sino.get_pt_v3(subject, dbase_dir, suffix)
        #Locations where resulting realizations will be stored
        gen_recons_dir = doserecParams.get_gen_dbase_dir(subject)
        if not os.path.exists(gen_recons_dir):
            os.makedirs(gen_recons_dir)

        #Locations where resulting CASToR data files will be stored
        if doserecParams.castor_dir is not None:#Create directory to get castor files
            gen_castor_dir=doserecParams.get_stored_castor_dir(subject)
            if not os.path.exists(gen_castor_dir):
                os.makedirs(gen_castor_dir)

        #Copy attenuationm norm and calib to dest directory
        att_hdr=Interfile.load(att_hdrname)
        att,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(att_hdr,proj_dir,verbose=verbose)
        PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir, doserecParams.get_fname_sino_att(subject, version)[0], "",
                                             att_hdrname,att,verbose=verbose)
        norm_hdr=Interfile.load(norm_hdrname)
        norm,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(norm_hdr,proj_dir,verbose=verbose)
        PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir, doserecParams.get_fname_sino_norm(subject, version)[0], "",
                                            norm_hdrname,norm,verbose=verbose)
        shutil.copy2(doserecParams.get_fpath_dbase_calib(subject, suffix, version),gen_recons_dir)
        shutil.copy2(pt_hdrname,gen_recons_dir)
        shutil.copy2(ecm_file,gen_recons_dir)

        src_files = os.listdir(simu_dir)
        for file_name in src_files:
            if "_pt_rep1.s" not in file_name:
                file_path = os.path.join(simu_dir, file_name)
                if os.path.isfile(file_path):
                    shutil.copy(file_path, gen_recons_dir)

        #Get phantom
        original_phantom_fpath = doserecParams.get_fpath_dbase_phantom(subject, suffix, version)
        original_phantom_hdr = original_phantom_fpath.replace('.i','.i.hdr')
        imrec_hdr=Interfile.load(original_phantom_hdr)
        original_phantom_image,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(imrec_hdr,proj_dir,verbose=verbose)

        _,pt_hdrname=doserecParams.get_fname_sino_pt(subject, version)
        if verbose:
            print(f"\n\npt_hdrname: {pt_hdrname}\n\n")
        for real in range(doserecParams.n_sim):
            print('-----------------------------------Patient',subject,' (',i+1,') Realization ',real+1,'-----------------------------------')
            real_time = time.time()

            if doserecParams.same_dose:
                alpha = mean/mu[i]
            else:
                alpha = np.random.uniform(min(mu)/(mu[i]), (max(mu))/mu[i])

            orig_name_ima,orig_name_hdr = doserecParams.get_fname_im_phantom_red(subject,real)
            print("alpha=",alpha)
            PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir, orig_name_ima, "", original_phantom_hdr,
                                                     original_phantom_image * alpha,verbose=verbose)
            if doserecParams.dose_reduc is not None :
                print(f"\n\n REF: alpha={alpha} ntot={alpha*mu[i]}")
                if doserecParams.random_reduc:
                    dose_reduc_arr[real,i]=np.random.uniform(1.0, doserecParams.dose_reduc)
                    alpha_low=alpha/dose_reduc_arr[real,i]
                else:
                    dose_reduc_arr[real,i]=doserecParams.dose_reduc
                    alpha_low=alpha/dose_reduc_arr[real,i]

                PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir, orig_name_ima, "", original_phantom_hdr,
                                                     original_phantom_image * alpha/dose_reduc_arr[real,i],verbose=verbose)
                #Generate reference
                new_fw_sino3D = (fw_sino3D - rd_sino)*alpha + rd_sino*alpha*alpha
                new_pt_real = np.random.poisson(new_fw_sino3D.clip(0))
                if verbose:
                    print(f"\n\n REF: ntot={np.sum(new_pt_real[:])}")
                    print(f"\n\n simudir={simu_dir}, pt_hdrname={pt_hdrname}")
                new_sc_sino3D = sc_sino * alpha
                new_rd_sino3D = rd_sino * alpha * alpha
                real_fname="realization-ref-{0}-{1}.s".format(subject,real+1)
                real_hdr_fname=real_fname.replace(".s",".s.hdr")
                sc_fname="scatter-ref-{0}-{1}.s".format(subject,real+1)
                sc_hdr_fname=sc_fname.replace(".s",".s.hdr")
                rd_fname="randoms-ref-{0}-{1}.s".format(subject,real+1)
                rd_hdr_fname=rd_fname.replace(".s",".s.hdr")
                cdf_name=os.path.basename(real_fname).rsplit('.')[0]
                PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir,
                            real_fname,simu_dir,pt_hdrname,new_pt_real,verbose=verbose)
                PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir,
                            sc_fname,simu_dir,sc_hdrname,new_sc_sino3D.astype("float32"),verbose=verbose)
                PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir,
                            rd_fname,simu_dir,rd_hdrname,new_rd_sino3D.astype("float32"),verbose=verbose)

                dest_path=os.path.join(gen_recons_dir, f"realization{subject}-{real+1}")
                if os.path.exists(dest_path):
                    os.unlink(dest_path)
                gen_att_hdr=os.path.join(gen_recons_dir,doserecParams.get_fname_sino_att(subject, version)[1])
                gen_norm_hdr=os.path.join(gen_recons_dir,doserecParams.get_fname_sino_norm(subject, version)[1])
                cdf_hdrname,_,_=PETLibs.CASTORCreateDataFile(gen_recons_dir,real_hdr_fname,
                                 ecm_file,cdf_name,
                                 att_hdr=gen_att_hdr,
                                 norm_hdr=gen_norm_hdr,
                                 sc_hdr=sc_hdr_fname,
                                 rd_hdr=rd_hdr_fname,nthr=doserecParams.CASToRParams.nthr,
                                 scanner=scanner,executable=doserecParams.smmaker_exec,verbose=True)
                rootname_recons=doserecParams.get_gen_castor_dir(subject,real)
                im_rec_fname,_,_=PETLibs.CASTORReconsIm(cdf_hdrname, rootname_recons,cdf_name,gen_recons_dir,
                                                        CASToRParams=doserecParams.CASToRParams,verbose=verbose)
                img_recons=os.path.dirname(cdf_hdrname)+f"_it{nit}.img"
                img_hdr_recons=img_recons.replace(".img",".hdr")
                imrec_hdr=Interfile.load(f"{img_hdr_recons}")
                ref_image,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(imrec_hdr,gen_recons_dir,verbose=verbose)
                os.remove(img_recons)
                os.remove(img_hdr_recons)
                ref_image=copy.deepcopy(ref_image/dose_reduc_arr[real,i])
                ref_img_name,ref_img_hdr_name = doserecParams.get_fname_im_ordose_red(subject,real)
                PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir, ref_img_name, "",
                                                    original_phantom_hdr, ref_image,verbose=verbose)
                datafiles = os.listdir(gen_recons_dir)
                h = cdf_hdrname.rsplit('/')[-2]
                for file_name in datafiles:
                    #print(f"h={h}")
                    lst_delete=["*_it*.hdr","*_it*.img"]
                    for kdelete in lst_delete:
                        if fnmatch.fnmatch(file_name,kdelete):
                            file_path = os.path.join(gen_recons_dir, file_name)
                            os.remove(file_path)
                            print(f" delete {file_name}")
                    if file_name in [h]:
                        file_path = os.path.join(gen_recons_dir, file_name)
                        print(f"fpath={file_path}",file_path)
                        shutil.rmtree(file_path)
                ref_dose_factor[real,i]=alpha
                #update alpha
                alpha=alpha_low

            if verbose:
                print(f"\n\n Real: alpha={alpha} ntot={alpha*mu[i]}")
            all_dose_factor[real, i] = alpha
            new_fw_sino3D = (fw_sino3D - rd_sino)*alpha + rd_sino*alpha*alpha
            new_pt_real = np.random.poisson(new_fw_sino3D.clip(0))
            if verbose:
                print(f"\n\n Real: ntot={np.sum(new_pt_real[:])}")
            new_sc_sino3D = sc_sino * alpha
            new_rd_sino3D = rd_sino * alpha * alpha

            real_fname="realization{0}-{1}.s".format(subject,real+1)
            real_hdr_fname=real_fname.replace(".s",".s.hdr")
            sc_fname="scatter{0}-{1}.s".format(subject,real+1)
            sc_hdr_fname=sc_fname.replace(".s",".s.hdr")
            rd_fname="randoms{0}-{1}.s".format(subject,real+1)
            rd_hdr_fname=rd_fname.replace(".s",".s.hdr")
            cdf_name=(doserecParams.get_fname_sinogram_CASToR_hdr(subject,real)[0]).rsplit('.')[0]
            PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir,
                        real_fname,simu_dir,pt_hdrname,new_pt_real,verbose=verbose)
            PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir,
                        sc_fname,simu_dir,sc_hdrname,new_sc_sino3D.astype("float32"),verbose=verbose)
            PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir,
                        rd_fname,simu_dir,rd_hdrname,new_rd_sino3D.astype("float32"),verbose=verbose)
            gen_att_hdr=os.path.join(gen_recons_dir,doserecParams.get_fname_sino_att(subject, version)[1])
            gen_norm_hdr=os.path.join(gen_recons_dir,doserecParams.get_fname_sino_norm(subject, version)[1])
            cdf_hdrname,_,_=PETLibs.CASTORCreateDataFile(gen_recons_dir,real_hdr_fname,
                             ecm_file,cdf_name,
                             att_hdr=gen_att_hdr,
                             norm_hdr=gen_norm_hdr,
                             sc_hdr=sc_hdr_fname,
                             rd_hdr=rd_hdr_fname,
                             nthr=doserecParams.CASToRParams.nthr,
                             scanner=scanner,executable=doserecParams.smmaker_exec,verbose=False)

            rootname_recons=doserecParams.get_gen_castor_dir(subject,real)
            im_rec_fname,_,_=PETLibs.CASTORReconsIm(cdf_hdrname, rootname_recons,cdf_name,gen_recons_dir,
                                                        CASToRParams=doserecParams.CASToRParams,verbose=verbose)
            img_recons=os.path.dirname(cdf_hdrname)+f"_it{nit}.img"
            img_hdr_recons=img_recons.replace(".img",".hdr")
            real_imrec,real_hdr_imrec=doserecParams.get_fname_im_reddose(subject,real)
            os.rename(img_recons, os.path.join(gen_recons_dir, real_imrec))
            os.rename(img_hdr_recons, os.path.join(gen_recons_dir, real_hdr_imrec))

            datafiles = os.listdir(gen_recons_dir)
            h = cdf_hdrname.rsplit('/')[-2]
            for file_name in datafiles:
                #print(f"h={h}")
                if(doserecParams.clean_dbase):
                    lst_delete=["*_it*.hdr","*_it*.img",f"*-{real+1}.s",f"*-{real+1}.s.hdr"]
                else:
                    lst_delete=["*_it*.hdr","*_it*.img"]
                for kdelete in lst_delete:
                    if fnmatch.fnmatch(file_name,kdelete):
                        file_path = os.path.join(gen_recons_dir, file_name)
                        os.remove(file_path)
                        print(f" delete {file_name}")
                if file_name in [h]:
                    file_path = os.path.join(gen_recons_dir, file_name)
                    if doserecParams.castor_dir is not None:#Copy CASToR subdir in dest_path
                        dest_path=os.path.join(gen_castor_dir, file_name)
                        print(f"fpath={file_path},{dest_path}")
                        if os.path.exists(dest_path):
                            shutil.rmtree(dest_path)
                        shutil.move(file_path,dest_path)
                        os.symlink(dest_path,file_path)
                    else:
                        if(doserecParams.clean_dbase):
                            shutil.rmtree(file_path)


            if doserecParams.n_sim == 0:
                all_time[real, i] = time.time() - subject_time
            else:
                all_time[real, i] = time.time() - real_time

        if(doserecParams.clean_dbase):
            datafiles = os.listdir(gen_recons_dir)
            for file_name in datafiles:
                if (file_name in src_files):
                    file_path = os.path.join(gen_recons_dir, file_name)
                    os.remove(file_path)
        if doserecParams.dose_reduc is not None :
            np.save(os.path.join(doserecParams.get_gen_dbase_rootdir(),"all_alpha_ref.npy"),ref_dose_factor)
        np.save(os.path.join(doserecParams.get_gen_dbase_rootdir(),"all_alpha.npy"),all_dose_factor)
        np.save(os.path.join(doserecParams.get_gen_dbase_rootdir(),"all_mu.npy"),mu)
        np.save(os.path.join(doserecParams.get_gen_dbase_rootdir(),"all_dose_factor_reduc.npy"),dose_reduc_arr)
        doserecParams.all_time=all_time
        doserecParams.all_dose_factor=all_dose_factor
        doserecParams.ref_dose_factor=ref_dose_factor
        doserecParams.dose_reduc_arr=dose_reduc_arr
        doserecParams.all_mu=mu

    return all_dose_factor, mu, all_time


def generate_database_doseRec_SIGNA(doserecParams, gate = 0, NGates=10):


    if not isinstance(doserecParams,genSubDatabaseDoserecParams):
        raise TypeError("doserecParams type is not genSubDatabaseDoserecParams ")
    dim=doserecParams.CASToRParams.im_dim
    nit=doserecParams.CASToRParams.nit
    vox_size = doserecParams.CASToRParams.vox_size

    lst_subjects = doserecParams.lst_subjects_reduced
    doserecParams.dose_reduc = NGates

    all_time = np.empty(shape = (doserecParams.n_sim, len(lst_subjects)))
    all_dose_factor = np.empty(shape = (doserecParams.n_sim, len(lst_subjects)))

    mu = []
    folder_data = doserecParams.dbase_dir

    fwhm=[4]*3
    nbsigma=[4]*3
    sigma_gaussian = PETLibs.utils.fwhm2sigma(fwhm,vox_size)
    kernel_size = np.ceil(nbsigma*sigma_gaussian)
    convOp=PETLibs.utils.GaussianSmoothing(kernel_size, sigma_gaussian,device="cuda:0")
    ParamsGPUEM=PETLibs.recons.GPUSignaReconsParams(lut_name="/share/Programs/castor/castor_git/config/scanner/PET_GE_SIGNA_PET-MR.lut",
                                    vox_size=vox_size ,im_dim=dim ,nit=nit, verbose=False,nsubsets=1,
                                                VRing=True,XYZ=True,max_up=-1,min_up=-1,den_thr=0.000001,
                                                convOp=convOp) # False XYZ
    
 
    for i, subject in enumerate(lst_subjects):
        print(f"\n subject={subject}")
        # castor_df_reduc_dir = folder_data + subject+"/transfer/"+subject+"-dose_reduc_"+str(doserecParams.dose_reduc)+"/"
        castor_df_dir = folder_data + subject + "/" #"20240904_e05838/")
        # new_sino_name_df = subject+"-dose_reduc_"+str(doserecParams.dose_reduc)+"-VPHD-SINO0000.cdf"
        target_name = subject+"-dose_reduc_"+str(doserecParams.dose_reduc)+".ima"
        hdr_filepath=folder_data + subject+"/"+subject+"-VPHD-LIST0000.cdh"
        hdr_filepath_norm =folder_data + subject+"/"+subject+"-VPHD-NORM0000.cdh"
        data_pickle =folder_data + subject+"/"+subject+"-gate" + str(gate) + "o"+ str(NGates)+"-data.pickle"
        
        
        thinned_hdr_filename=os.path.join(castor_df_dir,f"lm_thinning_vc_buffer_gate{gate}o{NGates}_all.cdh")        
        sinos_corr_sino=PETLibs.recons.GPUCASToRSinos(hdr_filepath, castor_df_dir,reconsParams=ParamsGPUEM,verbose=False,scanner="Signa",
                                                      norm_dir=castor_df_dir,norm_filepath=hdr_filepath_norm)
        original_phantom_image,_=PETLibs.recons.GPURecons.GPUEMRecons(None,None,reconsParams=ParamsGPUEM,verbose=False,
                    scanner="Signa",dict_sino=sinos_corr_sino,cost_report=True,time_report=True,tensor_output=False)


        sinos_corr_thin=PETLibs.recons.GPUCASToRSinos(thinned_hdr_filename, castor_df_dir,reconsParams=ParamsGPUEM,verbose=False,scanner="Signa",
                            norm_dir=castor_df_dir,norm_filepath=hdr_filepath_norm)

        with open(data_pickle, 'wb') as handle:
            pickle.dump(sinos_corr_thin, handle, protocol=pickle.HIGHEST_PROTOCOL)

        LD_image,_=PETLibs.recons.GPURecons.GPUEMRecons(None,None,reconsParams=ParamsGPUEM,verbose=False,xstart=None,
                        dict_sino=sinos_corr_thin,cost_report=True,time_report=True,scanner="Signa",tensor_output=False)
        # _=PETLibs.display3D_1cbar(np.flip(PETLibs.switchVolFromCudaToNP(signa_rec_em_thin),0),vmin=0,vmax=6700)

        
        current_device = ParamsGPUEM.deviceGPU
        reconsOps=GPURecons.GPUReconsOps(ParamsGPUEM, scanner="Signa")
        # dict_sino_reduc=PETLibs.recons.GPURecons.GPUCASToRSinos(hdr_filepath,castor_df_dir, reconsParams=ParamsGPUEM, scanner="Signa", verbose=False, subsample_fraction= 1.0/doserecParams.dose_reduc, seed = None)
        
        y_data =  ParamsGPUEM.createSubsetData(sinos_corr_thin["val"])
        mult_array =  ParamsGPUEM.createSubsetData(sinos_corr_thin["mult"])
        add_array =  ParamsGPUEM.createSubsetData(sinos_corr_thin["add"])
        sinomask =  ParamsGPUEM.createSubsetData(sinos_corr_thin["mask"])
        sen=reconsOps.computeSensitivityImages(sinomask,mult_factor=mult_array) 
        sen_sub0 = sen[0].cuda()


        # # summap=nib.load(folder_data+subject+"/MR/test_pet_Duetto.nii") #test_pet
        # original_phantom_hdr = folder_data+subject+"/"+subject+"-scastor-VPHD/"+subject+"-scastor-VPHD_it8.hdr"

        # # original_phantom_hdr = original_phantom_fpath.replace('.i','.i.hdr')
        # imrec_hdr=Interfile.load(original_phantom_hdr)
        # original_phantom_image,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(imrec_hdr,folder_data+subject+"/"+subject+"-scastor-VPHD/",verbose=False)
        # original_phantom_image=np.swapaxes(original_phantom_image,2,0)
        # original_phantom_image = np.flip(np.flip(original_phantom_image, axis=1), axis=2)

        # original_phantom_image=summap.get_fdata()
        # original_phantom_image=np.swapaxes(original_phantom_image,2,0)
         
        np_mask = np.zeros_like(original_phantom_image)
        np_mask[original_phantom_image>50.0]=1
        np_mask1=get_majority_label(np_mask)
        # torch_np_mask1 = torch.tensor(np_mask1, dtype=torch.float32, device = current_device)
        cv_hull = convex_hull_image(np_mask1)*original_phantom_image
        cv_hull_th = cv_hull > 50.0
        dil = ball(6)
        ero = ball(6)
        dil_cv_hull_th = dilation(cv_hull_th, dil)
        ero_cv_hull_th = erosion(dil_cv_hull_th, ero)
        torch_np_mask_ero = torch.tensor(ero_cv_hull_th, dtype=torch.float32, device = current_device)
 
        xt= torch.reshape(torch.tensor(original_phantom_image.copy()/doserecParams.dose_reduc ,dtype=torch.float32, device = current_device),ParamsGPUEM.tb_im_dim).contiguous()
        mask_target = torch_np_mask_ero #torch_np_mask2 > 50.0
        fwd=reconsOps.forwardProj(xt,mult_factor=mult_array[0],add_factor=add_array[0], subset=0)
        ratio = torch.where(fwd>0,torch.divide(y_data[0],fwd),torch.tensor(1.0, dtype = torch.float32, device = current_device)) #*sinomask
        del fwd
        bwd=reconsOps.backwardProj(ratio,mult_factor=mult_array[0],add_factor=0, subset=0)
        grad_img = (sen_sub0-bwd)*mask_target
        grad_img_part1 = sen_sub0
        grad_img_part2 = bwd
        np_grad_img = grad_img.squeeze().cpu().numpy() 
        # np_grad_img_part1 = grad_img_part1.squeeze().cpu().numpy()
        # np_grad_img_part2 = grad_img_part2.squeeze().cpu().numpy()
        # np_x_grad = xt.squeeze().cpu().numpy()+600000*np_grad_img
        
        del bwd


        # LD_image=PETLibs.recons.GPURecons.GPUEMRecons(hdr_filepath,castor_df_dir,
        #             reconsParams=ParamsGPUEM,verbose=False,xstart=None,
        #             dict_sino=dict_sino_reduc,eval_mode=True,show_step=False, scanner="Signa", tensor_output=False)

        PETLibs.ios.writeInterfileImg(LD_image, folder_data+subject+"/transfer/"+target_name, pixsize=vox_size, scanner="PET_GE_SIGNA_PET-MR")
        # get MRI image
        img_MRI=nib.load( folder_data+ subject+"/MR/mri_2pet.nii").get_fdata() # test2_mri_2pet
        # img_MRI=np.swapaxes(img_MRI,2,0)
        img_MRI = np.flip(img_MRI, axis=1)
        file_name = target_name.replace(".ima","_mri.ima")
        PETLibs.ios.writeInterfileImg(img_MRI,folder_data+subject+"/transfer/"+file_name, pixsize=vox_size, scanner="PET_GE_SIGNA_PET-MR" )

        file_name = target_name.replace(".ima","_grad.ima")
        PETLibs.ios.writeInterfileImg(np_grad_img ,folder_data+subject+"/transfer/"+file_name, pixsize=vox_size, scanner="PET_GE_SIGNA_PET-MR")

        # file_name = target_name.replace(".ima","_input.ima")
        # PETLibs.ios.writeInterfileImg(np_x_grad ,folder_data+subject+"/transfer/"+file_name, pixsize=vox_size, scanner="PET_GE_SIGNA_PET-MR")

        # file_name = target_name.replace(".ima","_grad_part2.ima")
        # PETLibs.ios.writeInterfileImg(np_grad_img_part2 ,folder_data+subject+"/transfer/"+file_name, pixsize=vox_size, scanner="PET_GE_SIGNA_PET-MR")

    
        file_name = target_name.replace(".ima","_mask.ima")
        PETLibs.ios.writeInterfileImg(mask_target.squeeze().cpu().numpy() ,folder_data+subject+"/transfer/"+file_name, pixsize=vox_size, scanner="PET_GE_SIGNA_PET-MR")


        file_name = target_name.replace(".ima","_target.ima")
        PETLibs.ios.writeInterfileImg(xt.squeeze().cpu().numpy(),folder_data+subject+"/transfer/"+file_name, pixsize=vox_size, scanner="PET_GE_SIGNA_PET-MR" )

        

    return all_dose_factor, mu, all_time



def generate_castor_lowdose_SIGNA(doserecParams, NGates=10,bufferSize=10000000,nb_gate=1):

    if not isinstance(doserecParams,genSubDatabaseDoserecParams):
        raise TypeError("doserecParams type is not genSubDatabaseDoserecParams ")

    lst_subjects = doserecParams.lst_subjects_reduced
    folder_data = doserecParams.dbase_dir
    gates = range(nb_gate)
    for _, subject in enumerate(lst_subjects):
        print(f"\n subject={subject}")
        castor_df_dir = folder_data + subject + "/" #"20240904_e05838/")
        hdr_filepath=folder_data + subject+"/"+subject+"-VPHD-LIST0000.cdh"

        for gate in gates:
            _=PETLibs.ios.cyThinCASToRFile(hdr_filepath,"lm_thinning_vc_buffer.cdh",
                in_dir=castor_df_dir,out_dir=castor_df_dir,
                ZeroFill=True,Endian="=",count=-1,bufferSize=bufferSize,verbose=False,
                scanner="Signa",gate=gate,NGates=NGates,overwrite=True)

    return 1

def get_dose_range_SIGNA(doserecParams):

    if not isinstance(doserecParams,genSubDatabaseDoserecParams):
        raise TypeError("doserecParams type is not genSubDatabaseDoserecParams ")

    lst_subjects = doserecParams.lst_subjects_reduced
    folder_data = doserecParams.dbase_dir
    dim=doserecParams.CASToRParams.im_dim
    nit=doserecParams.CASToRParams.nit
    vox_size = doserecParams.CASToRParams.vox_size
    fwhm=[4]*3
    nbsigma=[4]*3
    sigma_gaussian = PETLibs.utils.fwhm2sigma(fwhm,vox_size)
    kernel_size = np.ceil(nbsigma*sigma_gaussian)
    convOp=PETLibs.utils.GaussianSmoothing(kernel_size, sigma_gaussian,device="cuda:0")
    ParamsGPUEM=PETLibs.recons.GPUSignaReconsParams(lut_name="/share/Programs/castor/castor_git/config/scanner/PET_GE_SIGNA_PET-MR.lut",
                                    vox_size=vox_size ,im_dim=dim ,nit=nit, verbose=False,nsubsets=1,
                                                VRing=True,XYZ=True,max_up=-1,min_up=-1,den_thr=0.000001,
                                                convOp=convOp) # False XYZ
    
    for i, subject in enumerate(lst_subjects):
        print(f"\n subject={subject}")
        castor_df_dir = folder_data + subject + "/" #"20240904_e05838/")
        hdr_filepath=folder_data + subject+"/"+subject+"-VPHD-LIST0000.cdh"
        hdr_filepath_norm =folder_data + subject+"/"+subject+"-VPHD-NORM0000.cdh"
        
        # print(castor_df_dir, hdr_filepath)

        # castor_df_dir = folder_data + subject + "/" #"20240904_e05838/")
        # # new_sino_name_df = subject+"-dose_reduc_"+str(doserecParams.dose_reduc)+"-VPHD-SINO0000.cdf"
        # target_name = subject+"-dose_reduc_"+str(doserecParams.dose_reduc)+".ima"
        # hdr_filepath=folder_data + subject+"/"+subject+"-VPHD-LIST0000.cdh"
        # hdr_filepath_norm =folder_data + subject+"/"+subject+"-VPHD-NORM0000.cdh"
        # data_pickle =folder_data + subject+"/"+subject+"-gate" + str(gate) + "o"+ str(NGates)+"-data.pickle"
        
        
        sinos_corr_sino=PETLibs.recons.GPUCASToRSinos(hdr_filepath, castor_df_dir,reconsParams=ParamsGPUEM,verbose=False,scanner="Signa",
                                                      norm_dir=castor_df_dir,norm_filepath=hdr_filepath_norm)
        
        y_data =  ParamsGPUEM.createSubsetData(sinos_corr_sino["val"])
        if i == 0:
            min_dose = y_data[0].sum().item()
            max_dose = y_data[0].sum().item()
        else :
            min_dose = min(min_dose, y_data[0].sum().item())
            max_dose = max(max_dose, y_data[0].sum().item())
        del sinos_corr_sino
        del y_data
        

    

    return min_dose, max_dose

# def add_to_database_vardoseRec(dset_object):

#     '''
#     Generates a database using noise-free images, the original forward model, attenuation, normalization, scatter, and
#         randoms sinograms present in the original database, which are the results of a monte-carlo simulation.
#         The forward model sinogram's dose is varied into numerous simulations, with potential further dose reduction, Poisson noise is then applied to each of them,
#         they are then reconstructed and saved to the new directory, the noise-free images or original dose images are also saved, as well as (original/reduced)
#         dose values.

#     Arguments:
#         - doserecParams: parameters for generating database (genSubDatabaseDoserecParams).
#         - scanner: name of scanner (string, default: "biograph").
#         - verbose: verbosity (boolean, default:False).

#     Returns:
#         - all_dose_factor: Varied dose for every generated (potentially low-dose) sample (numpy array [nsim,n_subjects]).
#         - mu: Initial bin sum for every patient (numpy array [nsim,n_subjects]).
#         - all_time: Time taken for every generated sample (numpy array [nsim,n_subjects]).
#     '''

#     # if not isinstance(doserecParams,genSubDatabaseDoserecParams):
#     #     raise TypeError("doserecParams type is not genSubDatabaseDoserecParams ")
#     # dim=doserecParams.CASToRParams.im_dim
#     # nit=doserecParams.CASToRParams.nit
#     # nsubset=doserecParams.CASToRParams.nsubset

#     # mu = []
#     # dbase_dir=doserecParams.dbase_dir

#     # for subject in doserecParams.lst_subjects:
#     #     fw_sino,_=database_sino.get_fw(subject, dbase_dir)
#     #     mu.append(np.sum(fw_sino))
#     # mean = sum(mu)/len(mu)

#     # lst_subjects = doserecParams.lst_subjects_reduced

#     # all_time = np.empty(shape = (doserecParams.n_sim, len(lst_subjects)))
#     # all_dose_factor = np.empty(shape = (doserecParams.n_sim, len(lst_subjects)))
#     # ref_dose_factor = np.empty(shape = (doserecParams.n_sim, len(lst_subjects)))
#     # dose_reduc_arr = np.empty(shape = (doserecParams.n_sim, len(lst_subjects)))

#     # for i, subject in enumerate(lst_subjects):
#     #     subject_time = time.time()
#     #     #Get Filepaths needed to have access to sinograms/corrections
#     #     proj_dir=doserecParams.get_projections_dir(subject)
#     #     simu_dir=doserecParams.get_simulations_dir(subject)
#     #     ecm_file=doserecParams.get_fpath_ecm(subject)
#     #     #Get sinograms
#     #     fw_sino3D,_ = database_sino.get_fw(subject, dbase_dir)
#     #     sc_sino,sc_hdrname= database_sino.get_scat(subject, dbase_dir)
#     #     rd_sino,rd_hdrname = database_sino.get_rd(subject, dbase_dir)
#     #     _,att_hdrname=database_sino.get_att(subject, dbase_dir)
#     #     _,norm_hdrname=database_sino.get_norm(subject, dbase_dir)
#     #     _,pt_hdrname=database_sino.get_pt(subject, dbase_dir)

#     #     #Locations where resulting realizations will be stored
#     #     gen_recons_dir = doserecParams.get_gen_dbase_dir(subject)
#     #     if not os.path.exists(gen_recons_dir):
#     #         os.makedirs(gen_recons_dir)

#     #     #Locations where resulting CASToR data files will be stored
#     #     if doserecParams.castor_dir is not None:#Create directory to get castor files
#     #         gen_castor_dir=doserecParams.get_stored_castor_dir(subject)
#     #         if not os.path.exists(gen_castor_dir):
#     #             os.makedirs(gen_castor_dir)

#     #     #Copy attenuationm norm and calib to dest directory
#     #     att_hdr=Interfile.load(att_hdrname)
#     #     att,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(att_hdr,proj_dir,verbose=verbose)
#     #     PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir, doserecParams.get_fname_sino_att(subject)[0], "",
#     #                                          att_hdrname,att,verbose=verbose)
#     #     norm_hdr=Interfile.load(norm_hdrname)
#     #     norm,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(norm_hdr,proj_dir,verbose=verbose)
#     #     PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir, doserecParams.get_fname_sino_norm(subject)[0], "",
#     #                                         norm_hdrname,norm,verbose=verbose)
#     #     shutil.copy2(doserecParams.get_fpath_dbase_calib(subject),gen_recons_dir)
#     #     shutil.copy2(pt_hdrname,gen_recons_dir)
#     #     shutil.copy2(ecm_file,gen_recons_dir)

#     #     src_files = os.listdir(simu_dir)
#     #     for file_name in src_files:
#     #         if "_pt_rep1.s" not in file_name:
#     #             file_path = os.path.join(simu_dir, file_name)
#     #             if os.path.isfile(file_path):
#     #                 shutil.copy(file_path, gen_recons_dir)

#     #     #Get phantom
#     #     original_phantom_fpath = doserecParams.get_fpath_dbase_phantom(subject)
#     #     original_phantom_hdr = original_phantom_fpath.replace('.i','.i.hdr')
#     #     imrec_hdr=Interfile.load(original_phantom_hdr)
#     #     original_phantom_image,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(imrec_hdr,proj_dir,verbose=verbose)

#     #     _,pt_hdrname=doserecParams.get_fname_sino_pt(subject)
#     #     if verbose:
#     #         print(f"\n\npt_hdrname: {pt_hdrname}\n\n")
#     if not isinstance(dset_object,tensorDataSetDoserecParams):
#         raise TypeError("dset_object type is not tensorDataSetDoserecParams ")
#     doserec_object = dset_object.doserecParams
#     castor_object = dset_object.doserecParams.CASToRParams
#     list_sub = doserec_object.lst_subjects
#     BiographParams = PETLibs.recons.GPUBiographReconsParams(lut_name="/share/Programs/castor/castor_git/config/scanner/PET_SIEMENS_BIOGRAPH6_TRUEPOINT_TRUEV.lut",
#                                                 vox_size=castor_object.vox_size,im_dim=castor_object.im_dim,VRing=True,XYZ=True)
#     # print(doserec_object.get_gen_dbase_rootdir())

#     # contains mean/mu[i] or __np.random.uniform(min(mu)/(mu[i]), (max(mu))/mu[i])__
#     alpha_ref = doserec_object.ref_dose_factor

#     # alpha/dose_reduc_arr[real,i]
#     all_alpha = doserec_object.all_dose_factor

#     all_mu = doserec_object.all_mu
#     mean = sum(all_mu)/len(all_mu)

#     # contains __doserecParams.dose_reduc__ or np.random.uniform(1.0, doserecParams.dose_reduc)
#     all_dose_factor_reduc = doserec_object.dose_reduc_arr

#     dim=castor_object.im_dim
#     n1 = dim[0]
#     n2 = dim[1]
#     n3 = dim[2]
#     n_sim=doserec_object.n_sim
#     i = 0
#     BiographReconsOps=GPURecons.GPUBiographReconsOps(BiographParams)
#     for subject in list_sub:
#         print('-----------------------------------Patient',subject,' (',i+1,') Realization ',real+1,'-----------------------------------')
#         for real in range(n_sim):
#             castor_df_ima,castor_df_hdr=doserec_object.get_fname_sinogram_CASToR_hdr(subject,real)
#             castor_df_dir=doserec_object.get_gen_castor_dir(subject,real)
#             castor_df_hdr_fpath=os.path.join(castor_df_dir,castor_df_hdr)
#             imrec_rep,_=doserec_object.load_im_reddose(subject,real)
#             imrec_target,_=doserec_object.load_im_ordose_red(subject,real)
#             alpha = alpha_ref[i, real]
#             for dose_reduc in range(stqrt=1,stop=all_dose_factor_reduc[i, real], step = 1)
#                 alpha_low=alpha/dose_reduc

#                 #Generate reference
#                 new_fw_sino3D = (fw_sino3D - rd_sino)*alpha + rd_sino*alpha*alpha
#                 new_pt_real = np.random.poisson(new_fw_sino3D.clip(0))

#                 new_sc_sino3D = sc_sino * alpha
#                 new_rd_sino3D = rd_sino * alpha * alpha
#                 real_fname="realization-ref-{0}-{1}.s".format(subject,real+1)
#                 real_hdr_fname=real_fname.replace(".s",".s.hdr")
#                 sc_fname="scatter-ref-{0}-{1}.s".format(subject,real+1)
#                 sc_hdr_fname=sc_fname.replace(".s",".s.hdr")
#                 rd_fname="randoms-ref-{0}-{1}.s".format(subject,real+1)
#                 rd_hdr_fname=rd_fname.replace(".s",".s.hdr")
#                 cdf_name=os.path.basename(real_fname).rsplit('.')[0]
#                 PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir,
#                             real_fname,simu_dir,pt_hdrname,new_pt_real,verbose=verbose)
#                 PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir,
#                             sc_fname,simu_dir,sc_hdrname,new_sc_sino3D.astype("float32"),verbose=verbose)
#                 PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir,
#                             rd_fname,simu_dir,rd_hdrname,new_rd_sino3D.astype("float32"),verbose=verbose)

#                 dest_path=os.path.join(gen_recons_dir, f"realization{subject}-{real+1}")
#                 if os.path.exists(dest_path):
#                     os.unlink(dest_path)
#                 gen_att_hdr=os.path.join(gen_recons_dir,doserecParams.get_fname_sino_att(subject)[1])
#                 gen_norm_hdr=os.path.join(gen_recons_dir,doserecParams.get_fname_sino_norm(subject)[1])
#                 cdf_hdrname,_,_=PETLibs.CASTORCreateDataFile(gen_recons_dir,real_hdr_fname,
#                                  ecm_file,cdf_name,
#                                  att_hdr=gen_att_hdr,
#                                  norm_hdr=gen_norm_hdr,
#                                  sc_hdr=sc_hdr_fname,
#                                  rd_hdr=rd_hdr_fname,nthr=doserecParams.CASToRParams.nthr,
#                                  scanner=scanner,executable=doserecParams.smmaker_exec,verbose=True)
#                 rootname_recons=doserecParams.get_gen_castor_dir(subject,real)
#                 im_rec_fname,_,_=PETLibs.CASTORReconsIm(cdf_hdrname, rootname_recons,cdf_name,gen_recons_dir,
#                                                         CASToRParams=doserecParams.CASToRParams,verbose=verbose)
#                 img_recons=os.path.dirname(cdf_hdrname)+f"_it{nit}.img"
#                 img_hdr_recons=img_recons.replace(".img",".hdr")
#                 imrec_hdr=Interfile.load(f"{img_hdr_recons}")
#                 ref_image,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(imrec_hdr,gen_recons_dir,verbose=verbose)
#                 os.remove(img_recons)
#                 os.remove(img_hdr_recons)
#                 ref_image=copy.deepcopy(ref_image/dose_reduc_arr[real,i])
#                 ref_img_name,ref_img_hdr_name = doserecParams.get_fname_im_ordose_red(subject,real)
#                 PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir, ref_img_name, "",
#                                                     original_phantom_hdr, ref_image,verbose=verbose)
#                 datafiles = os.listdir(gen_recons_dir)
#                 h = cdf_hdrname.rsplit('/')[-2]
#                 for file_name in datafiles:
#                     #print(f"h={h}")
#                     lst_delete=["*_it*.hdr","*_it*.img"]
#                     for kdelete in lst_delete:
#                         if fnmatch.fnmatch(file_name,kdelete):
#                             file_path = os.path.join(gen_recons_dir, file_name)
#                             os.remove(file_path)
#                             print(f" delete {file_name}")
#                     if file_name in [h]:
#                         file_path = os.path.join(gen_recons_dir, file_name)
#                         print(f"fpath={file_path}",file_path)
#                         shutil.rmtree(file_path)
#                 ref_dose_factor[real,i]=alpha
#                 #update alpha
#                 alpha=alpha_low

#             if verbose:
#                 print(f"\n\n Real: alpha={alpha} ntot={alpha*mu[i]}")
#             all_dose_factor[real, i] = alpha
#             new_fw_sino3D = (fw_sino3D - rd_sino)*alpha + rd_sino*alpha*alpha
#             new_pt_real = np.random.poisson(new_fw_sino3D.clip(0))
#             if verbose:
#                 print(f"\n\n Real: ntot={np.sum(new_pt_real[:])}")
#             new_sc_sino3D = sc_sino * alpha
#             new_rd_sino3D = rd_sino * alpha * alpha

#             real_fname="realization{0}-{1}.s".format(subject,real+1)
#             real_hdr_fname=real_fname.replace(".s",".s.hdr")
#             sc_fname="scatter{0}-{1}.s".format(subject,real+1)
#             sc_hdr_fname=sc_fname.replace(".s",".s.hdr")
#             rd_fname="randoms{0}-{1}.s".format(subject,real+1)
#             rd_hdr_fname=rd_fname.replace(".s",".s.hdr")
#             cdf_name=(doserecParams.get_fname_sinogram_CASToR_hdr(subject,real)[0]).rsplit('.')[0]
#             PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir,
#                         real_fname,simu_dir,pt_hdrname,new_pt_real,verbose=verbose)
#             PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir,
#                         sc_fname,simu_dir,sc_hdrname,new_sc_sino3D.astype("float32"),verbose=verbose)
#             PETLibs.ios.writeInterfileImgFromHDR(gen_recons_dir,
#                         rd_fname,simu_dir,rd_hdrname,new_rd_sino3D.astype("float32"),verbose=verbose)
#             gen_att_hdr=os.path.join(gen_recons_dir,doserecParams.get_fname_sino_att(subject)[1])
#             gen_norm_hdr=os.path.join(gen_recons_dir,doserecParams.get_fname_sino_norm(subject)[1])
#             cdf_hdrname,_,_=PETLibs.CASTORCreateDataFile(gen_recons_dir,real_hdr_fname,
#                              ecm_file,cdf_name,
#                              att_hdr=gen_att_hdr,
#                              norm_hdr=gen_norm_hdr,
#                              sc_hdr=sc_hdr_fname,
#                              rd_hdr=rd_hdr_fname,
#                              nthr=doserecParams.CASToRParams.nthr,
#                              scanner=scanner,executable=doserecParams.smmaker_exec,verbose=False)

#             rootname_recons=doserecParams.get_gen_castor_dir(subject,real)
#             im_rec_fname,_,_=PETLibs.CASTORReconsIm(cdf_hdrname, rootname_recons,cdf_name,gen_recons_dir,
#                                                         CASToRParams=doserecParams.CASToRParams,verbose=verbose)
#             img_recons=os.path.dirname(cdf_hdrname)+f"_it{nit}.img"
#             img_hdr_recons=img_recons.replace(".img",".hdr")
#             real_imrec,real_hdr_imrec=doserecParams.get_fname_im_reddose(subject,real)
#             os.rename(img_recons, os.path.join(gen_recons_dir, real_imrec))
#             os.rename(img_hdr_recons, os.path.join(gen_recons_dir, real_hdr_imrec))

#             datafiles = os.listdir(gen_recons_dir)
#             h = cdf_hdrname.rsplit('/')[-2]
#             for file_name in datafiles:
#                 #print(f"h={h}")
#                 if(doserecParams.clean_dbase):
#                     lst_delete=["*_it*.hdr","*_it*.img",f"*-{real+1}.s",f"*-{real+1}.s.hdr"]
#                 else:
#                     lst_delete=["*_it*.hdr","*_it*.img"]
#                 for kdelete in lst_delete:
#                     if fnmatch.fnmatch(file_name,kdelete):
#                         file_path = os.path.join(gen_recons_dir, file_name)
#                         os.remove(file_path)
#                         print(f" delete {file_name}")
#                 if file_name in [h]:
#                     file_path = os.path.join(gen_recons_dir, file_name)
#                     if doserecParams.castor_dir is not None:#Copy CASToR subdir in dest_path
#                         dest_path=os.path.join(gen_castor_dir, file_name)
#                         print(f"fpath={file_path},{dest_path}")
#                         if os.path.exists(dest_path):
#                             shutil.rmtree(dest_path)
#                         shutil.move(file_path,dest_path)
#                         os.symlink(dest_path,file_path)
#                     else:
#                         if(doserecParams.clean_dbase):
#                             shutil.rmtree(file_path)


#             if doserecParams.n_sim == 0:
#                 all_time[real, i] = time.time() - subject_time
#             else:
#                 all_time[real, i] = time.time() - real_time

#         if(doserecParams.clean_dbase):
#             datafiles = os.listdir(gen_recons_dir)
#             for file_name in datafiles:
#                 if (file_name in src_files):
#                     file_path = os.path.join(gen_recons_dir, file_name)
#                     os.remove(file_path)
#         if doserecParams.dose_reduc is not None :
#             np.save(os.path.join(doserecParams.get_gen_dbase_rootdir(),"all_alpha_ref.npy"),ref_dose_factor)
#         np.save(os.path.join(doserecParams.get_gen_dbase_rootdir(),"all_alpha.npy"),all_dose_factor)
#         np.save(os.path.join(doserecParams.get_gen_dbase_rootdir(),"all_mu.npy"),mu)
#         np.save(os.path.join(doserecParams.get_gen_dbase_rootdir(),"all_dose_factor_reduc.npy"),dose_reduc_arr)
#         doserecParams.all_time=all_time
#         doserecParams.all_dose_factor=all_dose_factor
#         doserecParams.ref_dose_factor=ref_dose_factor
#         doserecParams.dose_reduc_arr=dose_reduc_arr
#         doserecParams.all_mu=mu

#     return all_dose_factor, mu, all_time

def import_database_dose_rec(learningDataSet,bUse_MRI = False, verbose=True, write = False):

#dbase_dir, new_dbase_dir, lst_subjects, n_sim, n_subjects = 14, dim = [109,128,128],
#                         target="highdose",nit=8,nsubset=14):

    '''
    Imports generated data from its original folder and outputs a numpy database to be use in DataLoaders.

    Arguments:
        - paramsDataSet: parameters for tensor dataset (tensorDataSetDoserec).

    Returns:
        - data_x: Input images (numpy array, [n_sim*n_subjects,dim[2],dim[1],dim[0]]).
        - data_y: Target images (numpy array, [n_sim*n_subjects,dim[2],dim[1],dim[0]]).
    '''


    
    dim=learningDataSet.doserecParams.CASToRParams.im_dim
    n1 = dim[0]
    n2 = dim[1]
    n3 = dim[2]
    # alpha/dose_reduc_arr[real,i]
    # all_alpha = learningDataSet.doserecParams.all_dose_factor
    #  # contains mean/mu[i] or __np.random.uniform(min(mu)/(mu[i]), (max(mu))/mu[i])__
    # alpha_ref = learningDataSet.doserecParams.ref_dose_factor
    # print(all_alpha)
    # print(alpha_ref)
    dbase_dir=learningDataSet.doserecParams.get_gen_dbase_rootdir()
    print("dbase_dir",dbase_dir)
    lst_subjects = learningDataSet.doserecParams.lst_subjects_reduced
    # n_subjects=len(lst_subjects)
    n_sim=learningDataSet.doserecParams.n_sim

    data_x = np.empty([n_sim*len(lst_subjects),n1,n2,n3])
    data_y = np.empty([n_sim*len(lst_subjects),n1,n2,n3])
    if bUse_MRI:
        data_mri = np.empty([n_sim*len(lst_subjects),n1,n2,n3])
    else :
        data_mri = None
    new_dbase_dir=learningDataSet.get_gen_dbase_import_rootdir()
    target=learningDataSet.import_target

    # nit=learningDataSet.doserecParams.CASToRParams.nit
    # nsubset=learningDataSet.doserecParams.CASToRParams.nsubset
    for i, subject in enumerate(lst_subjects):
        sub_dbase_dir = learningDataSet.doserecParams.get_gen_dbase_dir(subject)
        sub_new_dir = os.path.join(new_dbase_dir, f'{subject}')
        if write :
            if not os.path.exists(sub_new_dir):
                os.makedirs(sub_new_dir)
        for real in range(n_sim):
            input_im_name,input_hdr_name=learningDataSet.get_fname_im_input(subject,real)
            _,recon_hdr_name=learningDataSet.doserecParams.get_fname_im_reddose(subject,real)
            imrec_rep,_=learningDataSet.doserecParams.load_im_reddose(subject,real,verbose=verbose)
            if write :
                PETLibs.ios.writeInterfileImgFromHDR(sub_new_dir,input_im_name,
                                        sub_dbase_dir,recon_hdr_name,imrec_rep,verbose=verbose)

            target_name,_=learningDataSet.get_fname_im_target(subject,real,target)
            if target=="highdose":
                _,target_hdr_name=learningDataSet.doserecParams.get_fname_im_ordose_red(subject,real)
                imrec_target,_=learningDataSet.doserecParams.load_im_ordose_red(subject,real,verbose=verbose)
            else:
                _,target_hdr_name=learningDataSet.doserecParams.get_fname_im_phantom_red(subject,real)
                imrec_target,_=learningDataSet.doserecParams.load_im_phantom_red(subject,real,verbose=verbose)
            if write :
                PETLibs.ios.writeInterfileImgFromHDR(sub_new_dir,target_name,
                                         sub_dbase_dir,target_hdr_name,imrec_target,verbose=verbose)
            
            if bUse_MRI:
                reddose_ref,reddose_hdr_ref=learningDataSet.get_fname_im_input(subject,real)
                reddose_ref,reddose_hdr_ref=learningDataSet.doserecParams.get_fname_im_ordose_red(subject,real)
                reddose_ref=reddose_ref.replace("originaldose-red","originaldose-target")
                reddose_hdr_ref=reddose_hdr_ref.replace("originaldose-red","originaldose-target")

                reddose_ref_mri = reddose_ref.replace(".ima","_mri.ima")
                reddose_hdr_ref_mri = reddose_hdr_ref.replace(".hdr","_mri.hdr")

                if os.path.exists(os.path.join(sub_new_dir,reddose_hdr_ref_mri)):
                    reddose_hdr=Interfile.load(os.path.join(sub_new_dir,reddose_hdr_ref_mri))
                    reddose_hdr['name of data file']['value']=reddose_ref_mri
                    img_mri,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(reddose_hdr,sub_new_dir,verbose=verbose)


            if verbose:
                print('Subject: ',subject,' (',i,')\nRealization: ',real+1,'\nNumber: ',real + i*n_sim,imrec_rep.shape,dim)
            data_x[real + i*n_sim] = np.transpose(np.expand_dims(imrec_rep[:,:,:],axis=3),(3,0,1,2))
            data_y[real + i*n_sim] = np.transpose(np.expand_dims(imrec_target[:,:,:],axis=3),(3,0,1,2))
            if bUse_MRI :
                data_mri[real + i*n_sim] = np.transpose(np.expand_dims(img_mri[:,:,:],axis=3),(3,0,1,2))


    return data_x, data_y, data_mri

def import_database_IncrDose_rec(learningDataSet,dosereduc, verbose=True):

#dbase_dir, new_dbase_dir, lst_subjects, n_sim, n_subjects = 14, dim = [109,128,128],
#                         target="highdose",nit=8,nsubset=14):

    '''
    Imports generated data from its original folder and outputs a numpy database to be use in DataLoaders.

    Arguments:
        - paramsDataSet: parameters for tensor dataset (tensorDataSetDoserec).

    Returns:
        - data_x: Input images (numpy array, [n_sim*n_subjects,dim[2],dim[1],dim[0]]).
        - data_y: Target images (numpy array, [n_sim*n_subjects,dim[2],dim[1],dim[0]]).
    '''

    #if not isinstance(learningDataSet,learningDatabaseDoserecParams):
    #    raise TypeError("learningDataSet type is not learningDatabaseDoserecParams ")

    dim=learningDataSet.doserecParams.CASToRParams.im_dim
    n1 = dim[0]
    n2 = dim[1]
    n3 = dim[2]
    dosereduc = int(dosereduc)

    lst_subjects = learningDataSet.doserecParams.lst_subjects_reduced
    n_sim=learningDataSet.doserecParams.n_sim

    data_x = np.empty([n_sim*len(lst_subjects)*(dosereduc-2),n1,n2,n3])
    data_y = np.empty([n_sim*len(lst_subjects)*(dosereduc-2),n1,n2,n3])
    new_dbase_dir=learningDataSet.get_gen_dbase_import_rootdir()

    for i, subject in enumerate(lst_subjects):
        sub_dbase_dir = learningDataSet.doserecParams.get_gen_dbase_dir(subject)
        sub_new_dir = os.path.join(new_dbase_dir, f'{subject}')
        if not os.path.exists(sub_new_dir):
             os.makedirs(sub_new_dir)
        for real in range(n_sim):
            for factor in range(dosereduc):
                if factor < 2:
                    continue
                input_im_name,_=learningDataSet.get_fname_im_input_dosevar(subject,real, factor)
                _,recon_hdr_name=learningDataSet.doserecParams.get_fname_im_reddose_var(subject,real, factor)
                imrec_rep,_=learningDataSet.doserecParams.load_im_reddose_var(subject,real,factor,verbose=verbose)
                PETLibs.ios.writeInterfileImgFromHDR(sub_new_dir,input_im_name,
                                     sub_dbase_dir,recon_hdr_name,imrec_rep,verbose=verbose)

                target_name,_=learningDataSet.get_fname_im_target_var(subject,real,factor)
                _,target_hdr_name=learningDataSet.doserecParams.get_fname_im_ordose_red_var(subject,real, factor)
                imrec_target,_=learningDataSet.doserecParams.load_im_ordose_red_var(subject,real,factor, verbose=verbose)
           
                PETLibs.ios.writeInterfileImgFromHDR(sub_new_dir,target_name,
                                         sub_dbase_dir,target_hdr_name,imrec_target,verbose=verbose)
                if verbose:
                    print("----------------------------------------------")
                    print('Subject: ',subject,' (',i,')\nRealization: ',real+1,'\nDose reduc factor: ',factor,'\nNumber: ',(factor-2) +(dosereduc-2)*real + i*n_sim,imrec_rep.shape,dim)
                    print("----------------------------------------------")
                data_x[(factor-2) +(dosereduc-2)*real + i*n_sim] = np.transpose(np.expand_dims(imrec_rep[:,:,:],axis=3),(3,0,1,2))
                data_y[(factor-2) +(dosereduc-2)*real + i*n_sim] = np.transpose(np.expand_dims(imrec_target[:,:,:],axis=3),(3,0,1,2))
    

    
    return data_x, data_y

def import_database_IncrDose_rec2(learningDataSet,dosereduc, verbose=True):

    # writer=SummaryWriter(log_dir="logs_pretrain/vardose_full")

    dim=learningDataSet.doserecParams.CASToRParams.im_dim
    n1 = dim[0]
    n2 = dim[1]
    n3 = dim[2]
    dosereduc = int(dosereduc)

    lst_subjects = learningDataSet.doserecParams.lst_subjects_reduced
    n_sim=learningDataSet.doserecParams.n_sim

    data_x = np.empty([n_sim*len(lst_subjects)*(dosereduc-1),n1,n2,n3])
    data_y = np.empty([n_sim*len(lst_subjects)*(dosereduc-1),n1,n2,n3])
    new_dbase_dir=learningDataSet.get_gen_dbase_import_rootdir()

    # alpha/dose_reduc_arr[real,i] = alpha_ref/5
    all_alpha = learningDataSet.doserecParams.all_dose_factor
     # contains mean/mu[i] or __np.random.uniform(min(mu)/(mu[i]), (max(mu))/mu[i])__
    alpha_ref = learningDataSet.doserecParams.ref_dose_factor

    

    for i, subject in enumerate(lst_subjects):
        # if i > 0:
        #     continue
        sub_dbase_dir = learningDataSet.doserecParams.get_gen_dbase_dir(subject)
        sub_new_dir = os.path.join(new_dbase_dir, f'{subject}')
        if not os.path.exists(sub_new_dir):
             os.makedirs(sub_new_dir)
        for real in range(n_sim):
            target_name,_=learningDataSet.get_fname_im_target(subject,real)
            _,target_hdr_name=learningDataSet.doserecParams.get_fname_im_ordose_red(subject,real)
            imrec_target,_=learningDataSet.doserecParams.load_im_ordose_red(subject,real, verbose=verbose)
        
            PETLibs.ios.writeInterfileImgFromHDR(sub_new_dir,target_name,
                                        sub_dbase_dir,target_hdr_name,imrec_target,verbose=verbose)
            for factor in reversed(range(dosereduc+1)):
                if factor >1:
                    input_im_name,_=learningDataSet.get_fname_im_input_dosevar(subject,real, factor)
                    _,recon_hdr_name=learningDataSet.doserecParams.get_fname_im_reddose_var(subject,real, factor)
                    imrec_rep,_=learningDataSet.doserecParams.load_im_reddose_var(subject,real,factor,verbose=verbose)
                    
                    PETLibs.ios.writeInterfileImgFromHDR(sub_new_dir,input_im_name,
                                        sub_dbase_dir,recon_hdr_name,imrec_rep,verbose=verbose)

                    imrec_rep = imrec_rep*factor/dosereduc
                    if verbose:
                        print("----------------------------------------------")
                        print('Subject: ',subject,' (',i,')\nRealization: ',real+1,'\nDose reduc factor: ',factor,'\nNumber: ',(factor-2) +(dosereduc-1)*real + i*n_sim*(dosereduc-1),imrec_rep.shape,dim)
                        print("----------------------------------------------")
                    if factor == dosereduc:
                        max_dose_reduc_img = imrec_rep
                        data_x[(factor-2) +(dosereduc-1)*real + i*n_sim*(dosereduc-1)] = np.transpose(np.expand_dims(imrec_rep[:,:,:],axis=3),(3,0,1,2))
                        data_y[(factor-2) +(dosereduc-1)*real + i*n_sim*(dosereduc-1)] = np.transpose(np.expand_dims(imrec_target[:,:,:],axis=3),(3,0,1,2))
                    else :
                        data_x[(factor-2) +(dosereduc-1)*real + i*n_sim*(dosereduc-1)] = np.transpose(np.expand_dims(max_dose_reduc_img[:,:,:],axis=3),(3,0,1,2))
                        data_y[(factor-2) +(dosereduc-1)*real + i*n_sim*(dosereduc-1)] = np.transpose(np.expand_dims(imrec_rep[:,:,:],axis=3),(3,0,1,2))

            
 

    # my_index = 0
    # colors = cm.gist_rainbow(np.linspace(0, 1, len(lst_subjects)))
    # fig=plt.figure(figsize=[12,8]) 
    # for i, subject in enumerate(lst_subjects):
    #     for real in range(n_sim):
    #         if real == 0 :
    #             plt.scatter(my_index, alpha_ref[real, i], color=colors[i], label = subject)
    #         else :
    #             plt.scatter(my_index, alpha_ref[real, i], color=colors[i])
    #         my_index += 1

           
            
    # plt.ylabel('alpha_ref')
    # plt.legend()
    # plt.tight_layout()
    # writer.add_figure("alpha_ref",fig,0,close=True)
    # plt.close(fig)


    # my_index = 0

    # fig=plt.figure(figsize=[12,8]) 
    # for i, subject in enumerate(lst_subjects):
    #     for real in range(n_sim):
    #         if real == 0 :
    #             plt.scatter(my_index, all_alpha[real, i], color=colors[i], label = subject)
    #         else :
    #             plt.scatter(my_index, all_alpha[real, i], color=colors[i])

    #         my_index += 1

           
            
    # plt.ylabel('all_alpha')
    # plt.legend()
    # plt.tight_layout()
    # writer.add_figure("all_alpha",fig,0,close=True)
    # plt.close(fig)

    
    return data_x, data_y

def preprocess_data(image,paramsDataSet, device="cuda"):
    '''
    Preprocess data for DNN.

    Arguments:
        - image: Input images (3D numpy array - [z,y,x]).
        - paramsDataSet: parameters for tensor dataset (tensorDataSetDoserec).
        - device: device used for Tensors ("cuda" or "cpu")

    Returns:
        - preprocessed_data (3D tensor array - [nb,z,y,x,nc]).
        - sum_image: original sum prior to normalization (float).
    '''

    if not isinstance(paramsDataSet,tensorDataSetDoserecParams):
        raise TypeError("paramsDataSet type is not tensorDataSetDoserecParams ")

    alpha = paramsDataSet.alpha
    if paramsDataSet.truncate < image.shape[0]:
        t = image.shape[0] - paramsDataSet.truncate
        image_sel = image[t:,:,:]
    else:
        image_sel=image

    if paramsDataSet.normalize:
        image_sel, sum_image=normImage.normalize_image(image_sel,alpha=alpha)
    else:
        alpha = 0
        sum_image = 0

    image_sel=torch.unsqueeze(torch.unsqueeze(torch.tensor(image_sel,device=device, dtype=torch.float32), 0),0)
    return image_sel, sum_image


def postprocess_data(image,sum_image,paramsDataSet, tensorFlag=False, device="cpu"):
    '''
    Postprocessing data after DNN.

    Arguments:
        - image: Input images (tensor array- [nb,nc,z,y,x]).
        - sum_image: original sum prior to normalization (float).
        - paramsDataSet: parameters for tensor dataset (tensorDataSetDoserec).
        - tensorFlag: output is tensor (bool, default:false)
        - device: device used for Tensors ("cuda" or "cpu", default: "cpu")

    Returns:
        - post processed data (3D numpy array  or tensor- [z,y,x]).
    '''

    if not isinstance(paramsDataSet,tensorDataSetDoserecParams):
        raise TypeError("paramsDataSet type is not tensorDataSetDoserecParams ")

    alpha = paramsDataSet.alpha
    if paramsDataSet.normalize:
        image_sel=normImage.denormalize_image(image,sum_image,alpha=alpha)
        print("Data denormalized\n")
    else :
        image_sel=image
    if tensorFlag:
        image_sel=torch.squeeze(image_sel)
        if paramsDataSet.truncate:
            t = paramsDataSet.doserecParams.CASToRParams.im_dim[0] - paramsDataSet.truncate
            image_rec=torch.zeros(paramsDataSet.doserecParams.CASToRParams.im_dim)
            image_rec[t:,:,:] = image_sel
            return image_rec
        else:
            return image_sel
    else:
        # check if image sel is a numpy array
        if not isinstance(image_sel, np.ndarray):

            image_sel=np.squeeze(image_sel.detach().cpu().numpy())
        else :
            image_sel=np.squeeze(image_sel)
        if paramsDataSet.truncate:
            t = paramsDataSet.doserecParams.CASToRParams.im_dim[0] - paramsDataSet.truncate
            image_rec=np.zeros(paramsDataSet.doserecParams.CASToRParams.im_dim)
            image_rec[t:,:,:] = image_sel
            return image_rec
        else:
            return image_sel

def get_imgSubDiffKL(dset_object, ref_model_to, write_file=False): 
    if not isinstance(dset_object,tensorDataSetDoserecParams):
        raise TypeError("dset_object type is not tensorDataSetDoserecParams ")

    doserec_object = dset_object.doserecParams
    castor_object = dset_object.doserecParams.CASToRParams
    list_sub = doserec_object.lst_subjects
    reconsParams = PETLibs.recons.GPUReconsParams(lut_name="/share/Programs/castor/castor_git/config/scanner/PET_SIEMENS_BIOGRAPH6_TRUEPOINT_TRUEV.lut",
                                                vox_size=castor_object.vox_size,im_dim=castor_object.im_dim,VRing=True,XYZ=True)
    # print(doserec_object.get_gen_dbase_rootdir())

    # contains mean/mu[i] or __np.random.uniform(min(mu)/(mu[i]), (max(mu))/mu[i])__
    alpha_ref = doserec_object.ref_dose_factor

    # alpha/dose_reduc_arr[real,i]
    all_alpha = doserec_object.all_dose_factor

    all_mu = doserec_object.all_mu
    mean = sum(all_mu)/len(all_mu)

    # contains __doserecParams.dose_reduc__ or np.random.uniform(1.0, doserecParams.dose_reduc)
    all_dose_factor_reduc = doserec_object.dose_reduc_arr

    dim=castor_object.im_dim
    n1 = dim[0]
    n2 = dim[1]
    n3 = dim[2]
    n_sim=doserec_object.n_sim
    data_x = np.empty([n_sim*len(list_sub),n1,n2,n3])
    data_y = np.empty([n_sim*len(list_sub),n1,n2,n3])

    reconsOps=GPURecons.GPUReconsOps(reconsParams)
    i = 0
    for subject in list_sub:
        print("Subject: ",subject)
        for real in range(n_sim):
            castor_df_ima,castor_df_hdr=doserec_object.get_fname_sinogram_CASToR_hdr(subject,real)
            castor_df_dir=doserec_object.get_gen_castor_dir(subject,real)
            castor_df_hdr_fpath=os.path.join(castor_df_dir,castor_df_hdr)
            # imrec_rep,_=doserec_object.load_im_reddose(subject,real)
            imrec_target,_=doserec_object.load_im_ordose_red(subject,real)
            # data_x[real + i*n_sim] = np.transpose(np.expand_dims(imrec_rep[:,:,:],axis=3),(3,0,1,2))
            # data_y[real + i*n_sim] = np.transpose(np.expand_dims(imrec_target[:,:,:],axis=3),(3,0,1,2))
            # print("Reading: ",castor_df_hdr_fpath, "\n","and reading: ",castor_df_dir)
    
            # print("alpha_ref: ",alpha_ref[real,i], "alpha: ",all_alpha[real,i],"dose_factor_reduc: ",all_dose_factor_reduc[real,i], "\n")
        
            # alpha_ref = np.load(os.path.join(doserec_object.get_gen_dbase_rootdir(),"alpha.npy"))
            # all_alpha = np.load(os.path.join(doserec_object.get_gen_dbase_rootdir(),"all_alpha.npy"))
            # all_mu = np.load(os.path.join(doserec_object.get_gen_dbase_rootdir(),"all_mu.npy"))
            # all_dose_factor_reduc = np.load(os.path.join(doserec_object.get_gen_dbase_rootdir(),"all_dose_factor_reduc.npy"))
#                   Reading:  /data/dsk1/database_ADMM/marionpnp_dose_reduc5p0/j00150/realizationj00150-2/realizationj00150-2.cdh 
# and reading:  /data/dsk1/database_ADMM/marionpnp_dose_reduc5p0/j00150/realizationj00150-2
#  "mu: ", all_mu[real,subject],                 
            dict_sino=GPURecons.GPUCASToRSinos(castor_df_hdr_fpath, castor_df_dir,
                                                    reconsParams=reconsParams)
            y_data = dict_sino["val"]
            mult_array = dict_sino["mult"]
            add_array = dict_sino["add"]
            sinomask = dict_sino["mask"]
            sen=reconsOps.backwardProj(sinomask,mult_factor=mult_array)
            x_em= torch.reshape(torch.tensor(imrec_target,dtype=torch.float32),reconsParams.tb_im_dim)

            fwd=reconsOps.forwardProj(x_em,mult_factor=mult_array,add_factor=add_array)
            ratio=torch.divide(y_data,fwd)*sinomask
            bwd=reconsOps.backwardProj(ratio,mult_factor=mult_array,add_factor=0)
            grad_img = (sen-bwd)
            grad_img = grad_img.squeeze().cpu().numpy()
  
            grad_img = imrec_target-grad_img
            if write_file:
                sub_dbase_dir = doserec_object.get_gen_dbase_dir(subject)
                input_im_name,input_hdr_name=doserec_object.get_fname_im_input_grad(subject,real)
                new_dbase_dir=doserec_object.get_gen_dbase_import_rootdir()
                sub_new_dir = os.path.join(new_dbase_dir, f'{subject}')
                PETLibs.ios.writeInterfileImgFromHDR(sub_new_dir,input_im_name,
                                            sub_dbase_dir,input_hdr_name,grad_img,verbose=True)
            data_x[real + i*n_sim] = np.transpose(np.expand_dims(grad_img[:,:,:],axis=3),(3,0,1,2))
            data_y[real + i*n_sim] = np.transpose(np.expand_dims(imrec_target[:,:,:],axis=3),(3,0,1,2))
        i = i+1



    # n_select=doserec_object.n_sim*doserec_object._n_subjects
    # dim=[n_select,data_x.shape[1],data_x.shape[2],data_x.shape[3]]
    
    if doserec_object.truncate < data_x.shape[1]:
        t = data_x_sel.shape[1] - doserec_object.truncate
        data_x_sel = data_x[:,t:,:,:]
        data_y_sel = data_y[:,t:,:,:]
        print("Data Truncated\n")
    alpha = doserec_object.alpha
    data_x_sel, data_y_den, sum_x, sum_y, alpha, n_sum_x, n_sum_y, _, _, _, _ = database_base.normalize_data(data_x_sel, data_y_sel, alpha)
    datasetDRSTarget = TensorDataset(torch.tensor(data_x_sel, dtype=torch.float32), torch.tensor(data_y_den, dtype=torch.float32), 
                                     torch.tensor(sum_x, dtype=torch.float32), torch.tensor(sum_y, dtype=torch.float32),
                                alpha*torch.ones(data_x.shape[0]), torch.tensor(n_sum_x, dtype=torch.float32)
                            )
    return datasetDRSTarget



def import_imgSubDiffKL(dset_object, rho, write_file=False): 


    doserec_object = dset_object.doserecParams
    castor_object = dset_object.doserecParams.CASToRParams
    list_sub = doserec_object.lst_subjects
    reconsParams = PETLibs.recons.GPUBiographReconsParams(lut_name="/share/Programs/castor/castor_git/config/scanner/PET_SIEMENS_BIOGRAPH6_TRUEPOINT_TRUEV.lut",
                                                vox_size=castor_object.vox_size,im_dim=castor_object.im_dim) #,VRing=True,XYZ=True)

    # contains mean/mu[i] or __np.random.uniform(min(mu)/(mu[i]), (max(mu))/mu[i])__
    # alpha_ref = doserec_object.ref_dose_factor

    # # alpha/dose_reduc_arr[real,i]
    # all_alpha = doserec_object.all_dose_factor

    # all_mu = doserec_object.all_mu
    # mean = sum(all_mu)/len(all_mu)

    # contains __doserecParams.dose_reduc__ or np.random.uniform(1.0, doserecParams.dose_reduc)
    # all_dose_factor_reduc = doserec_object.dose_reduc_arr

    dim=castor_object.im_dim
    n1 = dim[0]
    n2 = dim[1]
    n3 = dim[2]
    print("dim is ", dim)
    n_sim=doserec_object.n_sim
    data_x = np.empty([n_sim*len(list_sub),n1,n2,n3])
    data_y = np.empty([n_sim*len(list_sub),n1,n2,n3])

    reconsOps=GPURecons.GPUReconsOps(reconsParams)
    for i, subject in enumerate(list_sub):
        print("Subject: ",subject)
        for real in range(n_sim):
            print('simulation n', real)
            _,castor_df_hdr=doserec_object.get_fname_sinogram_CASToR_hdr(subject,real)
            castor_df_dir=doserec_object.get_gen_castor_dir(subject,real)
            castor_df_hdr_fpath=os.path.join(castor_df_dir,castor_df_hdr)
            imrec_target,_=doserec_object.load_im_ordose_red(subject,real)
                 
            dict_sino = GPURecons.GPUCASToRSinos(castor_df_hdr_fpath, castor_df_dir,
                                                    reconsParams=reconsParams)
            y_data = dict_sino["val"]
            mult_array = dict_sino["mult"]
            add_array = dict_sino["add"]
            sinomask = dict_sino["mask"]
            sen =reconsOps.backwardProj(sinomask,mult_factor=mult_array)
            x_em = torch.reshape(torch.tensor(imrec_target,dtype=torch.float32),reconsParams.tb_im_dim)
            fwd = reconsOps.forwardProj(x_em,mult_factor=mult_array,add_factor=add_array)
            ratio = torch.divide(y_data,fwd)*sinomask
            bwd=reconsOps.backwardProj(ratio,mult_factor=mult_array,add_factor=0)
            grad_img = sen-bwd
            grad_img = grad_img.squeeze().cpu().numpy() 
            grad_img = imrec_target - (1.0/rho)*grad_img
  
            # grad_img = imrec_target-grad_img
            if write_file:
                sub_dbase_dir = doserec_object.get_gen_dbase_dir(subject)
                input_im_name,input_hdr_name = doserec_object.get_fname_im_input_grad(subject,real)
                new_dbase_dir = doserec_object.get_gen_dbase_import_rootdir()
                sub_new_dir = os.path.join(new_dbase_dir, f'{subject}')
                PETLibs.ios.writeInterfileImgFromHDR(sub_new_dir,input_im_name,
                                            sub_dbase_dir,input_hdr_name,grad_img,verbose=True)
            data_x[real + i*n_sim] = np.transpose(np.expand_dims(grad_img[:,:,:],axis=3),(3,0,1,2))
            data_y[real + i*n_sim] = np.transpose(np.expand_dims(imrec_target[:,:,:],axis=3),(3,0,1,2))
            break
                               
    return data_x, data_y



def get_loaders(data_x, data_y, paramsDataSet, num_workers=2, device="cuda", verbose=True, img_FNE= 0, copy_all = False): 

    '''
    Generates training and testing torch dataloaders using the numpy data. The target
    is potentially obtained as the output of a NN applied on data_y (e.g. for dose reduction).

    Arguments:
        - data_x: Input images (4D numpy array - [index_im,z,y,x]).
        - data_y: Target images (4D numpy array - [index_im,z,y,x]).
        - paramsDataSet: parameters for tensor dataset (tensorDataSetDoserecParams).
        - device: device used for Tensors ("cuda" or "cpu")
        - device_model: device used for models ("cuda" or "cpu")

    Returns:
        - dataset: TensorDataset wrapping input and target data. When norm_sj=True, add the list of total sum of data_x
                   and data_y for every 3D image and the normalization constant. If norm_sj=False and norm_train=True,
                   add the tensor array of patient number, realization number,normalization constant and init value for
                   the scaling constant (torch.utils.data.TensorDataset).
        - train_loader: Dataloader containing the training data (torch.utils.data.DataLoader)
        - test_loader: Dataloader containing the testing data (torch.utils.data.DataLoader).
        - sum_x: List of input image sum values (list of floats).
        - sum_y: List of target image sum values (list of floats).
        - alpha: Normalization constant used (list of normalization constants).

    Note:
        For large databases the loader should be in CPU, and tensor copied to gpu when used if needed.
    '''

    if not isinstance(paramsDataSet,tensorDataSetDoserecParams):
        raise TypeError("paramsDataSet type is not tensorDataSetDoserecParams ")

    alpha = paramsDataSet.alpha
    all_dose_factor=paramsDataSet.doserecParams.all_dose_factor

    max_sum = 0

    if copy_all:
        data_x_sel = data_x
        data_y_sel = data_y
    else :
       
        n_select=paramsDataSet.n_sim*paramsDataSet._n_subjects
        dim=[n_select,data_x.shape[1],data_x.shape[2],data_x.shape[3]]
        data_x_sel=np.zeros(dim)
        data_y_sel=np.zeros(dim)
        data_phantom_sel = np.zeros(dim)
        # offset_im=0
        for ki, subject in enumerate(paramsDataSet.lst_subjects_reduced):
            for kr,real in enumerate(range(paramsDataSet.n_sim)):
                data_x_sel[kr+ki*paramsDataSet.n_sim]=data_x[kr+ki*paramsDataSet.doserecParams.n_sim]
                data_y_sel[kr+ki*paramsDataSet.n_sim]=data_y[kr+ki*paramsDataSet.doserecParams.n_sim]
                phantom_ref,phantom_hdr_ref=paramsDataSet.doserecParams.get_fname_im_phantom_red(subject,real)
                path_phantom_hdr=os.path.join(paramsDataSet.doserecParams.get_gen_dbase_dir(subject),phantom_hdr_ref)
                if os.path.exists(path_phantom_hdr):
                    phantom_hdr=Interfile.load(path_phantom_hdr)
                    phantom_hdr['name of data file']['value']=phantom_ref
                    phantom,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(phantom_hdr,paramsDataSet.doserecParams.get_gen_dbase_dir(subject),verbose=verbose)
                else:
                    raise FileNotFoundError(errno.ENOENT,os.strerror(errno.ENOENT),path_phantom_hdr)
                
                data_phantom_sel[kr+ki*paramsDataSet.n_sim]=phantom
                tmp_sumx = np.sum(data_x_sel[kr+ki*paramsDataSet.n_sim])
                max_sum = max(max_sum, tmp_sumx)
                
               
   
      
    if paramsDataSet.truncate < data_x.shape[1]:
        t = data_x_sel.shape[1] - paramsDataSet.truncate
        
        data_x_sel = data_x_sel[:,t:,:,:]
        data_y_sel = data_y_sel[:,t:,:,:]
        data_phantom_sel = data_phantom_sel[:,t:,:,:]
        if verbose:
            print("Data Truncated\n")

    # data_y_den=np.zeros_like(data_y_sel)
    # if False : #paramsDataSet.ref_model is not None:
    #     if paramsDataSet.norm_denoise:
    #         ref_model_to=paramsDataSet.ref_model.to(device)
    #         _, data_y_den, _, sum_y_den, _, _, _ = database_base.normalize_data(data_x_sel, data_y_sel, alpha)
    #         for k in range(data_y.shape[0]):
    #             data_y_device=torch.unsqueeze(torch.unsqueeze(torch.Tensor(data_y_den[k]),0),0).to(device)
    #             data_y_out=torch.squeeze(ref_model_to(data_y_device)).detach().cpu().numpy()
    #             data_y_den[k]=normImage.denormalize_image(data_y_out, sum_y_den[k], alpha=alpha)
    #     else:
    #         for k in range(data_y.shape[0]):
    #             data_y_device=torch.unsqueeze(torch.unsqueeze(torch.Tensor(data_y_sel[k]),0),0).to(device)
    #             data_y_den[k]=torch.squeeze(ref_model_to(data_y_device)).detach().cpu().numpy()
    # else:
    if verbose:
        print("No denoising of target\n")
    data_y_den=data_y_sel
    # list_FNE_ratio = database_base.FNE_constants(data_x_sel, data_y_den, img_FNE)
    # print('pre normalization, FNE ratio', list_FNE_ratio)


    if paramsDataSet.normalize:
        _, _, sum_x, sum_y, alpha, n_sum_x, n_sum_y, standardized_sum_x, standardized_sum_y = database_base.normalize_data(data_x_sel, data_y_den, alpha)
        f_sum_x = sum_x
        sum_x = np.ones_like(sum_x)
        sum_y = np.ones_like(sum_y)


        if verbose: 
            print("Data Normalized\n")
        assert(not paramsDataSet.min_max_normalize)

    
    elif paramsDataSet.min_max_normalize:
        print('deprecated')
        
        # data_x_sel, data_y_den, min_x, max_x, max_sum_x, min_y, max_y, max_sum_y = database_base.min_max_normalize_data(data_x_sel, data_y_den)
        # if verbose:
        #     print("using a dataset of size", data_x_sel.shape[0])
        # dataset = TensorDataset(torch.Tensor(data_x_sel), torch.Tensor(data_y_den), torch.Tensor(min_x), torch.Tensor(max_x), 
        #                         torch.Tensor(max_sum_x),
        #                         torch.Tensor(min_y), torch.Tensor(max_y), 
        #                         torch.Tensor(max_sum_y)
        #                         ) #*torch.ones(data_y_sel.shape[0])
        # if verbose: 
        #     print("Data Normalized with min max strategy\n")
        
        # alpha = 0
        # sum_x = []
        # sum_y = []
        # n_sum_x = []
    else:
        alpha = 0
        sum_x = []
        sum_y = []
        n_sum_x = []
        n_sum_y = []
    if paramsDataSet.ref_model is not None :
        ref_model_to=paramsDataSet.ref_model.to(device)


        if paramsDataSet.augmentation_outputNN:
            postNN_data_x=np.zeros_like(data_x_sel)
            # postNN_data_y=np.zeros_like(data_y_sel)
            

            for i in range(data_x.shape[0]):

                data_x_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(data_x_sel[i], dtype=torch.float32),0),0).to(device)
                
                sigma = n_sum_x[i]
                data_x_out=torch.squeeze(ref_model_to.base.forward(data_x_device, None)).detach().cpu().numpy()  
                postNN_data_x[i]=data_x_out #normImage.denormalize_image(data_x_out, sum_x[i], alpha=alpha)  
                

                # data_y_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(postNN_data_y[i], dtype=torch.float32),0),0).to(device)
                # data_y_out=torch.squeeze(ref_model_to.base.forward(data_y_device, None)).detach().cpu().numpy()
                # postNN_data_y[i]=normImage.denormalize_image(data_y_out, sum_y[i], alpha=alpha)
            
            # postNN_data_x, _, postNN_sum_x, _, alpha, postNN_n_sum_x, _, postNN_standardized_sumx, _ = database_base.normalize_data(postNN_data_x, data_y_sel, alpha)
            _, _, postNN_sum_x, _, alpha, postNN_n_sum_x, _, postNN_standardized_sumx, _ = database_base.normalize_data(postNN_data_x, data_y_sel, alpha)
            # min_old = np.min(sum_x)
            # min_new = np.min(postNN_sum_x)
            # postNN_n_sum_x *= min_old/min_new


    # list_FNE_ratio = database_base.FNE_constants(data_x_sel, data_y_den, img_FNE)
    # print('post normalization, FNE ratio', list_FNE_ratio)
    if paramsDataSet.normalize and paramsDataSet.norm_sj and not paramsDataSet.min_max_normalize:
        # always here
 
        dataset = TensorDataset(torch.tensor(data_x_sel, dtype=torch.float32), torch.tensor(data_y_den, dtype=torch.float32), 
                                torch.tensor(sum_x,dtype=torch.float32), torch.tensor(data_phantom_sel, dtype=torch.float32),
                                alpha*torch.ones(data_x_sel.shape[0]), torch.tensor(standardized_sum_x, dtype=torch.float32)
                                )
        
        # dataset = TensorDataset(torch.tensor(data_x_sel, dtype=torch.float32), torch.tensor(data_y_den, dtype=torch.float32), 
        #                         torch.tensor(sum_x,dtype=torch.float32), torch.tensor(sum_y, dtype=torch.float32),
        #                         alpha*torch.ones(data_x_sel.shape[0]), torch.tensor(standardized_sum_x, dtype=torch.float32))
        
    elif paramsDataSet.norm_sj and not paramsDataSet.min_max_normalize:
        print('deprecated')
        dataset = TensorDataset(torch.tensor(data_x_sel, dtype=torch.float32), torch.tensor(data_y_den, dtype=torch.float32)) #, torch.Tensor(sum_x), torch.Tensor(sum_y),
                                #alpha*torch.ones(data_x_sel.shape[0]))

    elif paramsDataSet.norm_train:
        patient = []
        for i in range(paramsDataSet.n_subjects):
            for j in range(paramsDataSet.n_sim):
                patient.append(i+1)

        realization = []
        for i in range(paramsDataSet.n_subjects):
            for j in range(paramsDataSet.n_sim):
                realization.append(j+1)

        all_dose_factor = [all_dose_factor[i][:paramsDataSet.n_subjects] for i in range(paramsDataSet.n_sim)]

        init = []
        for i in range(paramsDataSet.n_subjects):
            for j in range(paramsDataSet.n_sim):
                init.append(0.1)
        dataset = TensorDataset(torch.tensor(data_x_sel, dtype=torch.float32), torch.tensor(data_y_den, dtype=torch.float32), 
                                torch.tensor(patient, dtype=torch.float32),
                                torch.tensor(realization, dtype=torch.float32), torch.reshape(torch.tensor(all_dose_factor, dtype=torch.float32), (-1,)),
                                torch.tensor(init, dtype=torch.float32))
        
    # elif not paramsDataSet.min_max_normalize :
    #     dataset = TensorDataset(torch.tensor(data_x_sel, dtype=torch.float32), torch.tensor(data_y_den, dtype=torch.float32))
    
    # check for augmentations
    if paramsDataSet.augmentation_GT:
        datasetGT = TensorDataset(torch.tensor(data_y_den, dtype=torch.float32), torch.tensor(data_y_den, dtype=torch.float32),
                                  torch.tensor(sum_y, dtype=torch.float32), torch.tensor(data_phantom_sel, dtype=torch.float32),
                                alpha*torch.ones(data_y_sel.shape[0]), torch.tensor(standardized_sum_y, dtype=torch.float32)
                            )
        
  
        
    if paramsDataSet.ref_model is not None and paramsDataSet.augmentation_FP:
        # FP_data_x=np.zeros_like(data_x)
        # FP_data_y=np.zeros_like(data_y)
        doserec_object = paramsDataSet.doserecParams
        castor_object = paramsDataSet.doserecParams.CASToRParams
        list_sub = doserec_object.lst_subjects
        reconsParams = PETLibs.recons.GPUBiographReconsParams(lut_name="/share/Programs/castor/castor_git/config/scanner/PET_SIEMENS_BIOGRAPH6_TRUEPOINT_TRUEV.lut",
                                                    vox_size=castor_object.vox_size,im_dim=castor_object.im_dim, XYZ=False)

        dim=castor_object.im_dim
        n1 = dim[0]
        n2 = dim[1]
        n3 = dim[2]
        data_y_out = np.zeros([n1,n2,n3])
        data_ph_out = np.zeros([n1,n2,n3])
        n_sim = 2 #doserec_object.n_sim
        list_rho = [0.000001, 0.01]
        n_rho = len(list_rho)
        FP_data_x = np.empty([n_sim*n_rho*len(list_sub),n1,n2,n3])
        FP_data_y = np.empty([n_sim*n_rho*len(list_sub),n1,n2,n3])
        FP_data_u = np.empty([n_sim*n_rho*len(list_sub),n1,n2,n3])

        # FP_data_x = np.empty([n_sim*n_rho*2,n1,n2,n3])
        # FP_data_y = np.empty([n_sim*n_rho*2,n1,n2,n3])
        # FP_data_u = np.empty([n_sim*n_rho*2,n1,n2,n3])

        reconsOps=GPURecons.GPUReconsOps(reconsParams)
        i = 0
        t = n1 - paramsDataSet.truncate
        for index_sub, subject in enumerate(list_sub):
            if index_sub < 50000 :
                for index_real, real in enumerate(range(n_sim)):
                    print("Subject nb",index_sub, "out of", len(list_sub), "Realization: ",real)
                    castor_df_ima,castor_df_hdr=doserec_object.get_fname_sinogram_CASToR_hdr(subject,real)
                    castor_df_dir=doserec_object.get_gen_castor_dir(subject,real)
                    castor_df_hdr_fpath=os.path.join(castor_df_dir,castor_df_hdr)
                    data_x_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(data_x_sel[index_real+index_sub*doserec_object.n_sim], dtype=torch.float32),0),0).to(device)
                    data_y_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(data_y_den[index_real+index_sub*doserec_object.n_sim], dtype=torch.float32),0),0).to(device)
                    data_ph_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(data_phantom_sel[index_real+index_sub*doserec_object.n_sim], dtype=torch.float32),0),0).to(device)
                    ## should be changed to handle truncation properly
                    data_y_out[t:,:,:]=torch.squeeze(data_y_device).detach().cpu().numpy() 
                    # data_y_out[t:,:,:]=torch.squeeze(data_ph_device).detach().cpu().numpy() 
                    data_ph_out[t:,:,:]=torch.squeeze(data_ph_device).detach().cpu().numpy() 
                    # data_y_out[t:,:,:]=torch.squeeze(ref_model_to.base.forward(data_x_device, None)).detach().cpu().numpy() 
                    data_y_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(data_y_out[t:,:,:], dtype=torch.float32),0),0).to(device)
                    # D_data_x_out = torch.squeeze(ref_model_to.base.forward(data_x_device, None)).detach().cpu().numpy() 

                    imrec_target=data_y_out #normImage.denormalize_image(data_x_out, sum_x[index_real+index_sub*doserec_object.n_sim], alpha=alpha) 
                    dict_sino=GPURecons.GPUCASToRSinos(castor_df_hdr_fpath, castor_df_dir,
                                                        reconsParams=reconsParams)
                    y_data = dict_sino["val"]
                    mult_array = dict_sino["mult"]
                    add_array = dict_sino["add"]
                    sinomask = dict_sino["mask"]
                    sen=reconsOps.backwardProj(sinomask,mult_factor=mult_array)
                    
                    xt= torch.reshape(torch.tensor(imrec_target,dtype=torch.float32, device = "cuda"),reconsParams.tb_im_dim)
                    fwd=reconsOps.forwardProj(xt,mult_factor=mult_array,add_factor=add_array)
                    # print("fwd min max", fwd.smin(), fwd.max())
                    # ratio=torch.divide(y_data,fwd)*sinomask
                    # ratio[torch.isnan(ratio)] = torch.tensor(0.0,dtype=torch.float32, device = "cuda")
                    ratio = torch.where(fwd>0,torch.divide(y_data,fwd),torch.tensor(1.0, dtype = torch.float32, device = "cuda"))*sinomask
 
                    # print("ratio min max", ratio.min(), ratio.max())
                    bwd=reconsOps.backwardProj(ratio,mult_factor=mult_array,add_factor=0)
                    grad_img = (sen-bwd)
                    # toto = bwd
                    grad_img = grad_img.squeeze().cpu().numpy()  
                    # toto = toto.squeeze().cpu().numpy()
                    # grad_img = imrec_target-grad_img

                    # if True:
                    #     sub_dbase_dir = doserec_object.get_gen_dbase_dir(subject)
                    #     input_im_name,input_hdr_name=doserec_object.get_fname_im_input_grad(subject,real)
                    #     new_dbase_dir=doserec_object.get_gen_dbase_import_rootdir()
                    #     sub_new_dir = os.path.join(new_dbase_dir, f'{subject}')
                    #     PETLibs.ios.writeInterfileImgFromHDR(sub_new_dir,input_im_name,
                    #                                 sub_dbase_dir,input_hdr_name,grad_img,verbose=True)

                    for invrho in list_rho:
                
                        grad_img_copy = imrec_target-invrho*grad_img 
                        # FP_data_x[i]=np.transpose(np.expand_dims(grad_img[:,:,:],axis=3),(3,0,1,2))
                        FP_data_x[i]=np.transpose(np.expand_dims(grad_img_copy[:,:,:],axis=3),(3,0,1,2))
                        FP_data_y[i]=np.transpose(np.expand_dims(imrec_target[:,:,:],axis=3),(3,0,1,2))
                        FP_data_u[i]=np.transpose(np.expand_dims(data_ph_out[:,:,:],axis=3),(3,0,1,2))

                        # FP_data_x[i]=np.transpose(np.expand_dims(pow(10,invrho+2)*grad_img[:,:,:],axis=3),(3,0,1,2))
                        # print("imrec_target", imrec_target.shape)
                        # print("D_data_x_out", D_data_x_out.shape)
                        # new_target = D_data_x_out-imrec_target[:,:,:] # issue here
                        
                        # FP_data_y[i]=np.transpose(np.expand_dims(new_target,axis=3),(3,0,1,2))

                        i = i+1

   
        FP_data_x = FP_data_x[:,t:,:,:]
        FP_data_y = FP_data_y[:,t:,:,:]
        FP_data_u = FP_data_u[:,t:,:,:]

        _, _, FP_sum_x, _, alpha, _, _, FP_standardized_sum_x, _ = database_base.normalize_data(FP_data_x, FP_data_y, alpha)
        # datasetAugFP = get_imgSubDiffKL(paramsDataSet)
        datasetAugFP = TensorDataset(torch.tensor(FP_data_x,dtype=torch.float32), torch.tensor(FP_data_y,dtype=torch.float32),
                                     torch.tensor(FP_sum_x,dtype=torch.float32), torch.tensor(FP_data_u,dtype=torch.float32),
                                alpha*torch.ones(FP_data_x.shape[0]), torch.tensor(FP_standardized_sum_x,dtype=torch.float32)
                            )

    if paramsDataSet.augmentation_outputNN :
       datasetNN = TensorDataset(torch.tensor(postNN_data_x, dtype=torch.float32), torch.tensor(data_y_den, dtype=torch.float32),
                                 torch.tensor(postNN_sum_x, dtype=torch.float32), torch.tensor(data_phantom_sel, dtype=torch.float32),
                                alpha*torch.ones(postNN_data_x.shape[0]), torch.tensor(postNN_standardized_sumx, dtype=torch.float32)
                            )

    
    test_size=int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*paramsDataSet.n_sim
    # train is always the first part of the dataset
    train_data, test_data = train_test_split(dataset, test_size = test_size, shuffle = False)
    # indices = np.where(n_sum_x < 0.4)
    # # Removing duplicates from the list
    # list2 = list(set(n_sum_x))
    
    # # Sorting the  list
    # list2.sort()
    
    # # # Printing the second last element
    # # print("Second largest element is:", list2[-1])

    # Ntot = len(n_sum_x)
    # # indices = np.where(np.logical_and(n_sum_x >= list2[0],n_sum_x <list2[11]) ) # correspond à sigma max 
    # # indices = np.where(np.logical_and(n_sum_x > list2[-11],n_sum_x <=list2[-1]) ) # correspond à sigma max 
    # indices = np.where(np.logical_and(n_sum_x >= list2[Ntot//2],n_sum_x <list2[Ntot//2+10]) ) # correspond à sigma max 
    # # # # print(indices[0])
    # dataset = torch.utils.data.Subset(dataset, indices[0])

    if paramsDataSet.augmentation_GT :
        print("augmentation GT")
        test_size_aug_GT=int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*paramsDataSet.n_sim
        train_data_aug_GT, test_data_aug_GT = train_test_split(datasetGT, test_size = test_size_aug_GT, shuffle = False)
        train_data = torch.utils.data.ConcatDataset([train_data, train_data_aug_GT]) 
        test_data = torch.utils.data.ConcatDataset([test_data, test_data_aug_GT])

    if paramsDataSet.augmentation_FP :
        print("augmentation FP")
        test_size_aug_FP=int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*n_sim*n_rho
        # test_size_aug_FP=int(math.ceil(paramsDataSet.test_percent*5))*paramsDataSet.n_sim
        train_data_aug_FP, test_data_aug_FP = train_test_split(datasetAugFP, test_size = test_size_aug_FP, shuffle = False)
        train_data = train_data_aug_FP #torch.utils.data.ConcatDataset([train_data, train_data_aug_FP]) 
        test_data = test_data_aug_FP #torch.utils.data.ConcatDataset([test_data, test_data_aug_FP]) 

    if paramsDataSet.augmentation_outputNN :
        print("augmentation outputNN")
        test_size_aug_outputNN=int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*paramsDataSet.n_sim
        train_data_aug_outputNN, test_data_aug_outputNN = train_test_split(datasetNN, test_size = test_size_aug_outputNN, shuffle = False)
        train_data = torch.utils.data.ConcatDataset([train_data, train_data_aug_outputNN])
        test_data = torch.utils.data.ConcatDataset([test_data, test_data_aug_outputNN])

    # if paramsDataSet.augmentation_dose :
    #     test_size_aug_dose=int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*paramsDataSet.n_sim*(paramsDataSet.n_sim-1)
    #     train_data_aug_dose, _ = train_test_split(datasetAugDose, test_size = test_size_aug_dose, shuffle = False)
    #     train_data = torch.utils.data.ConcatDataset([train_data, train_data_aug_dose])    

    
    loader_args = dict(num_workers=num_workers, pin_memory=True)
    train_loader = torch.utils.data.DataLoader(train_data, shuffle = paramsDataSet.shuffle_train,
            batch_size = paramsDataSet.train_batch_size, drop_last = False, **loader_args)
    test_loader = torch.utils.data.DataLoader(test_data, shuffle = paramsDataSet.shuffle_test,
            batch_size = paramsDataSet.test_batch_size, **loader_args)
    if verbose:
        print("Data Loaded\n")
    print("size of train loader", len(train_loader))
    print("size of test loader", len(test_loader))
    return dataset, train_loader, test_loader, sum_x, sum_y, alpha



def get_data(data_x, 
             data_y, 
             paramsDataSet, 
             device="cuda", 
             verbose=True, 
             img_FNE= 0, 
             copy_all = False, 
             use_only_FP = False, 
             reduced_sim = False, 
             FP_from_FB = False, 
             transform=None
             ): 

    '''
    Generates training and testing torch dataloaders using the numpy data. The target
    is potentially obtained as the output of a NN applied on data_y (e.g. for dose reduction).

    Arguments:
        - data_x: Input images (4D numpy array - [index_im,z,y,x]).
        - data_y: Target images (4D numpy array - [index_im,z,y,x]).
        - paramsDataSet: parameters for tensor dataset (tensorDataSetDoserecParams).
        - device: device used for Tensors ("cuda" or "cpu")
        - device_model: device used for models ("cuda" or "cpu")

    Returns:
        - dataset: TensorDataset wrapping input and target data. When norm_sj=True, add the list of total sum of data_x
                   and data_y for every 3D image and the normalization constant. If norm_sj=False and norm_train=True,
                   add the tensor array of patient number, realization number,normalization constant and init value for
                   the scaling constant (torch.utils.data.TensorDataset).
        - train_loader: Dataloader containing the training data (torch.utils.data.DataLoader)
        - test_loader: Dataloader containing the testing data (torch.utils.data.DataLoader).
        - sum_x: List of input image sum values (list of floats).
        - sum_y: List of target image sum values (list of floats).
        - alpha: Normalization constant used (list of normalization constants).

    Note:
        For large databases the loader should be in CPU, and tensor copied to gpu when used if needed.
    '''

    if not isinstance(paramsDataSet,tensorDataSetDoserecParams):
        raise TypeError("paramsDataSet type is not tensorDataSetDoserecParams ")

    alpha = paramsDataSet.alpha
    all_dose_factor=paramsDataSet.doserecParams.all_dose_factor

    max_sum = 0

    if copy_all:
        data_x_sel = data_x
        data_y_sel = data_y
        

        # n_select=paramsDataSet.n_sim*paramsDataSet._n_subjects*(img_FNE-1)
        # dim=[n_select,data_x.shape[1],data_x.shape[2],data_x.shape[3]]
        # data_phantom_sel = np.zeros(dim)
        # index = 0
        # # offset_im=0
        # for ki, subject in enumerate(paramsDataSet.lst_subjects_reduced):
        #     for kr,real in enumerate(range(paramsDataSet.n_sim)):
        #         phantom_ref,phantom_hdr_ref=paramsDataSet.doserecParams.get_fname_im_phantom_red(subject,real)
        #         path_phantom_hdr=os.path.join(paramsDataSet.doserecParams.get_gen_dbase_dir(subject),phantom_hdr_ref)
        #         if os.path.exists(path_phantom_hdr):
        #             phantom_hdr=Interfile.load(path_phantom_hdr)
        #             phantom_hdr['name of data file']['value']=phantom_ref
        #             phantom,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(phantom_hdr,paramsDataSet.doserecParams.get_gen_dbase_dir(subject),verbose=verbose)
        #         else:
        #             raise FileNotFoundError(errno.ENOENT,os.strerror(errno.ENOENT),path_phantom_hdr)
        #         for _ in range(img_FNE-1):
        #             data_phantom_sel[index]=phantom
        #             index = index +1
        
                #factor-2 + kr*(img_FNE-1)+ki*paramsDataSet.n_sim*(img_FNE-1)
    else :

        n_select=paramsDataSet.n_sim*paramsDataSet._n_subjects
        dim=[n_select,data_x.shape[1],data_x.shape[2],data_x.shape[3]]
        data_x_sel=np.zeros(dim)
        data_y_sel=np.zeros(dim)
        data_phantom_sel = np.zeros(dim)
        # offset_im=0
        for ki, subject in enumerate(paramsDataSet.lst_subjects_reduced):
            for kr,real in enumerate(range(paramsDataSet.n_sim)):
                data_x_sel[kr+ki*paramsDataSet.n_sim]=data_x[kr+ki*paramsDataSet.doserecParams.n_sim]
                data_y_sel[kr+ki*paramsDataSet.n_sim]=data_y[kr+ki*paramsDataSet.doserecParams.n_sim]
                phantom_ref,phantom_hdr_ref=paramsDataSet.doserecParams.get_fname_im_phantom_red(subject,real)
                path_phantom_hdr=os.path.join(paramsDataSet.doserecParams.get_gen_dbase_dir(subject),phantom_hdr_ref)
                if os.path.exists(path_phantom_hdr):
                    phantom_hdr=Interfile.load(path_phantom_hdr)
                    phantom_hdr['name of data file']['value']=phantom_ref
                    phantom,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(phantom_hdr,paramsDataSet.doserecParams.get_gen_dbase_dir(subject),verbose=verbose)
                else:
                    raise FileNotFoundError(errno.ENOENT,os.strerror(errno.ENOENT),path_phantom_hdr)
                
                data_phantom_sel[kr+ki*paramsDataSet.n_sim]=phantom
                tmp_sumx = np.sum(data_x_sel[kr+ki*paramsDataSet.n_sim])
                max_sum = max(max_sum, tmp_sumx)
                


    if paramsDataSet.truncate < data_x.shape[1]:
        t = data_x_sel.shape[1] - paramsDataSet.truncate
        
        data_x_sel = data_x_sel[:,t:,:,:]
        data_y_sel = data_y_sel[:,t:,:,:]
        data_phantom_sel = data_phantom_sel[:,t:,:,:]
        if verbose:
            print("Data Truncated\n")

    # data_y_den=np.zeros_like(data_y_sel)
    # if False : #paramsDataSet.ref_model is not None:
    #     if paramsDataSet.norm_denoise:
    #         ref_model_to=paramsDataSet.ref_model.to(device)
    #         _, data_y_den, _, sum_y_den, _, _, _ = database_base.normalize_data(data_x_sel, data_y_sel, alpha)
    #         for k in range(data_y.shape[0]):
    #             data_y_device=torch.unsqueeze(torch.unsqueeze(torch.Tensor(data_y_den[k]),0),0).to(device)
    #             data_y_out=torch.squeeze(ref_model_to(data_y_device)).detach().cpu().numpy()
    #             data_y_den[k]=normImage.denormalize_image(data_y_out, sum_y_den[k], alpha=alpha)
    #     else:
    #         for k in range(data_y.shape[0]):
    #             data_y_device=torch.unsqueeze(torch.unsqueeze(torch.Tensor(data_y_sel[k]),0),0).to(device)
    #             data_y_den[k]=torch.squeeze(ref_model_to(data_y_device)).detach().cpu().numpy()
    # else:
    if verbose:
        print("No denoising of target\n")
    data_y_den=data_y_sel
    # list_FNE_ratio = database_base.FNE_constants(data_x_sel, data_y_den, img_FNE)
    # print('pre normalization, FNE ratio', list_FNE_ratio)
    # _ = database_base.FNE_constants_ph(data_x_sel, data_y_den, img_FNE+1)
    FNE_cte= []
    for i in range(data_x_sel.shape[0]):
        # print("img nb", i, "rho", FP_data_rho[i])
        list_FNE_ratio = database_base.FNE_constants_ph(data_x_sel, data_y_den, i)
        for cte in list_FNE_ratio:
            FNE_cte.append(cte)
    print("final mean FNE", np.mean(FNE_cte))
    print("final max FNE", np.max(FNE_cte))
    print("final min FNE", np.min(FNE_cte))
    if paramsDataSet.normalize:
        # check here
        _, _, sum_x, sum_y, alpha, n_sum_x, n_sum_y, standardized_sum_x, standardized_sum_y = database_base.normalize_data(data_x_sel, data_y_den, alpha)
        f_sum_x = sum_x
        sum_x = np.ones_like(sum_x)
        sum_y = np.ones_like(sum_y)
    



        if verbose: 
            print("Data Normalized\n")
        assert(not paramsDataSet.min_max_normalize)        

    
    elif paramsDataSet.min_max_normalize:
        print('deprecated')

    else:
        # _, _, sum_x, sum_y, alpha, n_sum_x, n_sum_y, standardized_sum_x, standardized_sum_y = database_base.normalize_data(data_x_sel, data_y_den, alpha)
        # f_sum_x = sum_x
        # sum_x = np.ones_like(sum_x)
        # sum_y = np.ones_like(sum_y)

        alpha = 0
        sum_x = []
        sum_y = []
        n_sum_x = []
        n_sum_y = []
    if paramsDataSet.ref_model is not None :
        ref_model_to=paramsDataSet.ref_model.to(device)


        if paramsDataSet.augmentation_outputNN:
            postNN_data_x=np.zeros_like(data_x_sel)
            # postNN_data_y=np.zeros_like(data_y_sel)
            

            for i in range(data_x.shape[0]):

                data_x_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(data_x_sel[i], dtype=torch.float32),0),0).to(device)
                data_phantom_sel_device = torch.unsqueeze(torch.unsqueeze(torch.tensor(data_phantom_sel[i], dtype=torch.float32),0),0).to(device)
                
                sigma = torch.where(data_phantom_sel_device > 0, torch.tensor(1.0, dtype=torch.float32, device = "cuda"), torch.tensor(0.0, dtype=torch.float32, device = "cuda"))
                data_x_out=torch.squeeze(ref_model_to.base.forward(data_x_device, sigma)).detach().cpu().numpy()  
                postNN_data_x[i]=data_x_out #normImage.denormalize_image(data_x_out, sum_x[i], alpha=alpha)  
                

                # data_y_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(postNN_data_y[i], dtype=torch.float32),0),0).to(device)
                # data_y_out=torch.squeeze(ref_model_to.base.forward(data_y_device, None)).detach().cpu().numpy()
                # postNN_data_y[i]=normImage.denormalize_image(data_y_out, sum_y[i], alpha=alpha)
            
            # postNN_data_x, _, postNN_sum_x, _, alpha, postNN_n_sum_x, _, postNN_standardized_sumx, _ = database_base.normalize_data(postNN_data_x, data_y_sel, alpha)
            _, _, postNN_sum_x, _, alpha, postNN_n_sum_x, _, postNN_standardized_sumx, _ = database_base.normalize_data(postNN_data_x, data_y_sel, alpha)
            # min_old = np.min(sum_x)
            # min_new = np.min(postNN_sum_x)
            # postNN_n_sum_x *= min_old/min_new


    # list_FNE_ratio = database_base.FNE_constants(data_x_sel, data_y_den, img_FNE)
    # print('post normalization, FNE ratio', list_FNE_ratio)
    if paramsDataSet.normalize and paramsDataSet.norm_sj and not paramsDataSet.min_max_normalize:
        # always here
 
        dataset = CustomTensorDataset(tensors =(torch.tensor(data_x_sel, dtype=torch.float32), torch.tensor(data_y_den, dtype=torch.float32), 
                                torch.tensor(data_x_sel,dtype=torch.float32), torch.tensor(data_phantom_sel, dtype=torch.float32),
                                alpha*torch.ones(data_x_sel.shape[0]), torch.tensor(standardized_sum_x, dtype=torch.float32), 
                                torch.tensor(data_phantom_sel, dtype=torch.float32)))   
        dataset_tf = CustomTensorDataset(tensors =(torch.tensor(data_x_sel, dtype=torch.float32), torch.tensor(data_y_den, dtype=torch.float32), 
                                torch.tensor(data_x_sel,dtype=torch.float32), torch.tensor(data_phantom_sel, dtype=torch.float32),
                                alpha*torch.ones(data_x_sel.shape[0]), torch.tensor(standardized_sum_x, dtype=torch.float32), 
                                torch.tensor(data_phantom_sel, dtype=torch.float32)), transform=transform)                                
        
        # dataset = TensorDataset(torch.tensor(data_x_sel, dtype=torch.float32), torch.tensor(data_y_den, dtype=torch.float32), 
        #                         torch.tensor(sum_x,dtype=torch.float32), torch.tensor(sum_y, dtype=torch.float32),
        #                         alpha*torch.ones(data_x_sel.shape[0]), torch.tensor(standardized_sum_x, dtype=torch.float32))
        
    elif paramsDataSet.norm_sj and not paramsDataSet.min_max_normalize:
        print('deprecated')
        dataset = TensorDataset(torch.tensor(data_x_sel, dtype=torch.float32), torch.tensor(data_y_den, dtype=torch.float32)) #, torch.Tensor(sum_x), torch.Tensor(sum_y),
                                #alpha*torch.ones(data_x_sel.shape[0]))

    elif paramsDataSet.norm_train:
        patient = []
        for i in range(paramsDataSet.n_subjects):
            for j in range(paramsDataSet.n_sim):
                patient.append(i+1)

        realization = []
        for i in range(paramsDataSet.n_subjects):
            for j in range(paramsDataSet.n_sim):
                realization.append(j+1)

        all_dose_factor = [all_dose_factor[i][:paramsDataSet.n_subjects] for i in range(paramsDataSet.n_sim)]

        init = []
        for i in range(paramsDataSet.n_subjects):
            for j in range(paramsDataSet.n_sim):
                init.append(0.1)
        # dataset_tf = CustomTensorDataset(tensors = (torch.tensor(data_x_sel, dtype=torch.float32), torch.tensor(data_y_den, dtype=torch.float32), 
        #                         torch.tensor(patient, dtype=torch.float32),
        #                         torch.tensor(realization, dtype=torch.float32), torch.reshape(torch.tensor(all_dose_factor, dtype=torch.float32), (-1,)),
        #                         torch.tensor(init, dtype=torch.float32)), transform = transform)
        
        dataset = CustomTensorDataset(tensors = (torch.tensor(data_x_sel, dtype=torch.float32), torch.tensor(data_y_den, dtype=torch.float32), 
                                torch.tensor(patient, dtype=torch.float32),
                                torch.tensor(realization, dtype=torch.float32), torch.reshape(torch.tensor(all_dose_factor, dtype=torch.float32), (-1,)),
                                torch.tensor(init, dtype=torch.float32)))
        
        
       
    # check for augmentations
    if paramsDataSet.augmentation_GT:
        raise NotImplementedError
        # datasetGT = TensorDataset(torch.tensor(data_y_den, dtype=torch.float32), torch.tensor(data_y_den, dtype=torch.float32),
        #                           torch.tensor(sum_y, dtype=torch.float32), torch.tensor(data_phantom_sel, dtype=torch.float32),
        #                         alpha*torch.ones(data_y_sel.shape[0]), torch.tensor(standardized_sum_y, dtype=torch.float32),
        #                         torch.tensor(data_phantom_sel, dtype=torch.float32)
        #                     )
        
    
    if paramsDataSet.gaussian_denoising:
        doserec_object = paramsDataSet.doserecParams
        castor_object = paramsDataSet.doserecParams.CASToRParams
        list_sub = doserec_object.lst_subjects
        # noise_levels = [10,20,50,75,100,200] 
        dim=castor_object.im_dim
        n1 = dim[0]
        n2 = dim[1]
        n3 = dim[2]
        t = n1 - paramsDataSet.truncate
        nb_noise_levels = 1
        MMSE_input=np.empty([doserec_object.n_sim*nb_noise_levels*len(list_sub),paramsDataSet.truncate,n2,n3]) 
        MMSE_target=np.empty([doserec_object.n_sim*nb_noise_levels*len(list_sub),paramsDataSet.truncate,n2,n3])
        MMSE_phantom=np.empty([doserec_object.n_sim*nb_noise_levels*len(list_sub),paramsDataSet.truncate,n2,n3]) 
        i_MMSE = 0  
        with tqdm(total=data_x.shape[0], desc="Iterations Gaussian noise", unit='Iteration(s)') as pbar:
  
            for i in range(data_x.shape[0]): #0.2*35150 = 7030, 
                noise_level = 3515*random.random() #400
                # for noise_level in noise_levels:
                mask = np.where(data_phantom_sel[i] > 0,1.0,0)
                # print('mask', mask.shape)
                noise = np.random.normal(0, noise_level, data_y_sel[i].shape)
                # print('noise', noise.shape)
                MMSE_input[i_MMSE]=(data_y_sel[i]+noise)*mask 
                MMSE_target[i_MMSE]=data_y_sel[i]*mask
                MMSE_phantom[i_MMSE]=data_phantom_sel[i]
                i_MMSE += 1
                pbar.update(1)


     #paramsDataSet.ref_model is not None and
    if  (paramsDataSet.augmentation_FP or paramsDataSet.augmentation_FP_w):
        # FP_data_x=np.zeros_like(data_x)
        # FP_data_y=np.zeros_like(data_y)
        doserec_object = paramsDataSet.doserecParams
        castor_object = paramsDataSet.doserecParams.CASToRParams
        list_sub = doserec_object.lst_subjects
        reconsParams = PETLibs.recons.GPUBiographReconsParams(lut_name="/share/Programs/castor/castor_git/config/scanner/PET_SIEMENS_BIOGRAPH6_TRUEPOINT_TRUEV.lut",
                                                    vox_size=castor_object.vox_size,im_dim=castor_object.im_dim, 
                                                    XYZ=False, nsubsets=1)

        dim=castor_object.im_dim
        n1 = dim[0]
        n2 = dim[1]
        n3 = dim[2]
        data_y_out = np.zeros([n1,n2,n3])
        if paramsDataSet.augmentation_FP_NN :
            data_yNN = np.zeros([n1,n2,n3])
        #if paramsDataSet.augmentation_FP_EM :
        data_yEM = np.zeros([n1,n2,n3])
        data_ph_out = np.zeros([n1,n2,n3])
        if reduced_sim :
            n_sim = 1 
        else :
            n_sim = doserec_object.n_sim 
        if paramsDataSet.augmentation_FP_w:
            list_rho = [1e0,1e2]
            list_rho = [1e2] 
            list_rho = [1e5] 
            list_rho = [1e6, 1e2] 
            # list_rho = [1e2]
        else :
            print("using normalization for rho")
            list_rho = [1e2,1e6]
            list_rho = [2*1e6, 1e6]
            list_rho = [1e6, 1e5, 1e4, 1e7, 1e3]
            list_rho = [1e3, 1e6] #1e5

        n_rho = len(list_rho)
        
        FP_data_x = np.empty([n_sim*n_rho*len(list_sub),n1,n2,n3])
        FP_data_y = np.empty([n_sim*n_rho*len(list_sub),n1,n2,n3])
        FP_data_u = np.empty([n_sim*n_rho*len(list_sub),n1,n2,n3])
        FP_data_p = np.empty([n_sim*n_rho*len(list_sub),n1,n2,n3])
        FP_data_rho = np.empty([n_sim*n_rho*len(list_sub),1])

        if paramsDataSet.augmentation_FP_NN :
            FP_data_yNN = np.empty([n_sim*len(list_sub),n1,n2,n3])
            FP_data_xNN = np.empty([n_sim*len(list_sub),n1,n2,n3])
            FP_data_uNN = np.empty([n_sim*len(list_sub),n1,n2,n3])

        if paramsDataSet.augmentation_FP_EM :
            
            list_rho_EM = [0] #, 1e6]
            n_rho_EM = len(list_rho_EM)
            FP_data_yEM = np.empty([n_sim*n_rho_EM*len(list_sub),n1,n2,n3])
            FP_data_xEM = np.empty([n_sim*n_rho_EM*len(list_sub),n1,n2,n3])
            FP_data_uEM = np.empty([n_sim*n_rho_EM*len(list_sub),n1,n2,n3])
            FP_data_rhoEM = np.empty([n_sim*n_rho_EM*len(list_sub),1])

        # FP_data_x = np.empty([n_sim*n_rho*2,n1,n2,n3])
        # FP_data_y = np.empty([n_sim*n_rho*2,n1,n2,n3])
        # FP_data_u = np.empty([n_sim*n_rho*2,n1,n2,n3])

        reconsOps=GPURecons.GPUReconsOps(reconsParams)
        i = 0
        i_EM = 0
        i_NN = 0
        t = n1 - paramsDataSet.truncate

        normalization_target_rho = database_base.get_sum_img(data_y_den)

        for index_sub, subject in enumerate(list_sub):
            if index_sub < 50000 :
                for index_real, real in enumerate(range(n_sim)):
                    print("Subject nb",index_sub, "out of", len(list_sub), "Realization: ",real)
                    castor_df_ima,castor_df_hdr=doserec_object.get_fname_sinogram_CASToR_hdr(subject,real)
                    castor_df_dir=doserec_object.get_gen_castor_dir(subject,real)
                    castor_df_hdr_fpath=os.path.join(castor_df_dir,castor_df_hdr)
                    data_x_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(data_x_sel[index_real+index_sub*doserec_object.n_sim], dtype=torch.float32),0),0).to(device)
                    data_y_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(data_y_den[index_real+index_sub*doserec_object.n_sim], dtype=torch.float32),0),0).to(device)
                    normalization_y = normalization_target_rho[index_real+index_sub*doserec_object.n_sim]
                    data_ph_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(data_phantom_sel[index_real+index_sub*doserec_object.n_sim], dtype=torch.float32),0),0).to(device)


                
                    sigma = torch.where(data_ph_device > 0, torch.tensor(1.0, dtype=torch.float32, device = "cuda"), torch.tensor(0.0, dtype=torch.float32, device = "cuda"))


                    data_y_out[t:,:,:]=torch.squeeze(data_y_device).detach().cpu().numpy() 
                    # data_y_out[t:,:,:]=torch.squeeze(data_ph_device).detach().cpu().numpy() 
                    data_ph_out[t:,:,:]=torch.squeeze(data_ph_device).detach().cpu().numpy() 

                    if paramsDataSet.augmentation_FP_NN :
                        data_yNN[t:,:,:]=torch.squeeze(ref_model_to.base.forward(data_x_device, sigma)).detach().cpu().numpy() 

                    

                    #if paramsDataSet.augmentation_FP_EM :
                    data_yEM[t:,:,:]=torch.squeeze(data_x_device).detach().cpu().numpy()

                    data_y_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(data_y_out[t:,:,:], dtype=torch.float32),0),0).to(device)
                    # D_data_x_out = torch.squeeze(ref_model_to.base.forward(data_x_device, None)).detach().cpu().numpy() 
                    mask_ph = data_ph_out > 0.0
                    imrec_target=data_y_out*mask_ph #normImage.denormalize_image(data_x_out, sum_x[index_real+index_sub*doserec_object.n_sim], alpha=alpha) 
                    
                    if paramsDataSet.augmentation_FP_NN :
                        imrec_targetNN = data_yNN*mask_ph
                    #if paramsDataSet.augmentation_FP_EM :
                    imrec_targetEM = data_yEM*mask_ph



                    dict_sino=GPURecons.GPUCASToRSinos(castor_df_hdr_fpath, castor_df_dir,
                                                        reconsParams=reconsParams)
                   
                    y_data =  reconsParams.createSubsetData(dict_sino["val"])
                    mult_array =  reconsParams.createSubsetData(dict_sino["mult"])
                    add_array =  reconsParams.createSubsetData(dict_sino["add"])
                    sinomask =  reconsParams.createSubsetData(dict_sino["mask"])
                    sen=reconsOps.computeSensitivityImages(sinomask,mult_factor=mult_array) #No need for autograd here 
                    
                    xt= torch.reshape(torch.tensor(imrec_target,dtype=torch.float32, device = "cuda"),reconsParams.tb_im_dim)
                    fwd=reconsOps.forwardProj(xt,mult_factor=mult_array[0],add_factor=add_array[0], subset=0)
                    ratio = torch.where(fwd>0,torch.divide(y_data[0],fwd),torch.tensor(1.0, dtype = torch.float32, device = "cuda")) #*sinomask
                    del fwd
                    bwd=reconsOps.backwardProj(ratio,mult_factor=mult_array[0],add_factor=0, subset=0)
                    if paramsDataSet.augmentation_FP_w:
                        # grad_img = (sen-bwd)/torch.add(sen,0.0)
                        # grad_img *= torch.add(xt, 0)

                        grad_img = (sen[0]-bwd)/torch.add(sen[0],1.0) #1
                        grad_img = torch.where(xt>0.0, grad_img, 1e-10)
                        # grad_img *= torch.add(mask_ph, 1e-10)
                    else :
                        grad_img = sen[0]-bwd

                    grad_img = grad_img.squeeze().cpu().numpy() 
                    del bwd

                    if paramsDataSet.augmentation_FP_NN :
                        xt_NN= torch.reshape(torch.tensor(imrec_targetNN,dtype=torch.float32, device = "cuda"),reconsParams.tb_im_dim)
                        fwd=reconsOps.forwardProj(xt_NN,mult_factor=mult_array[0],add_factor=add_array[0], subset=0)
                        ratio = torch.where(fwd>0,torch.divide(y_data[0],fwd),torch.tensor(1.0, dtype = torch.float32, device = "cuda")) #*sinomask
                        del fwd
                        bwd=reconsOps.backwardProj(ratio,mult_factor=mult_array[0],add_factor=0, subset=0)
                        if paramsDataSet.augmentation_FP_w:
                            grad_img_NN = (sen[0]-bwd)/torch.add(sen[0],1.0) #1
                            grad_img_NN = torch.where(xt>0.0, grad_img_NN, 1e-10)
                        else :
                            grad_img_NN = sen[0]-bwd

                        grad_img_NN = grad_img_NN.squeeze().cpu().numpy() 
                        del bwd

                    if paramsDataSet.augmentation_FP_EM :
                        xt_EM= torch.reshape(torch.tensor(imrec_targetEM,dtype=torch.float32, device = "cuda"),reconsParams.tb_im_dim)
                        fwd=reconsOps.forwardProj(xt_EM,mult_factor=mult_array[0],add_factor=add_array[0], subset=0)
                        ratio = torch.where(fwd>0,torch.divide(y_data[0],fwd),torch.tensor(1.0, dtype = torch.float32, device = "cuda")) #*sinomask
                        del fwd
                        bwd=reconsOps.backwardProj(ratio,mult_factor=mult_array[0],add_factor=0, subset=0)
                        if paramsDataSet.augmentation_FP_w:
                            grad_img_EM = (sen[0]-bwd)/torch.add(sen[0],1.0)
                            grad_img_EM = torch.where(xt>0.0, grad_img_EM, 1e-10)
                        else :
                            grad_img_EM = sen[0]-bwd

                        grad_img_EM = grad_img_EM.squeeze().cpu().numpy()
                        del bwd
                    # grad_img *= imrec_target 

                    # grad_img = imrec_target-grad_img

                    # if True:
                    #     sub_dbase_dir = doserec_object.get_gen_dbase_dir(subject)
                    #     input_im_name,input_hdr_name=doserec_object.get_fname_im_input_grad(subject,real)
                    #     new_dbase_dir=doserec_object.get_gen_dbase_import_rootdir()
                    #     sub_new_dir = os.path.join(new_dbase_dir, f'{subject}')
                    #     PETLibs.ios.writeInterfileImgFromHDR(sub_new_dir,input_im_name,
                    #                                 sub_dbase_dir,input_hdr_name,grad_img,verbose=True)

                    for invrho in list_rho:

                        if FP_from_FB :
                            raise NotImplementedError

                            # grad_img_copy = imrec_target+invrho*grad_img 
                            # grad_img_copy *= mask_ph
                            # precond = torch.where(xt>0.0, 1/torch.add(sen[0],1.0), 1e-10)
                            # precond = precond.squeeze().cpu().numpy() 


                            # FP_data_x[i]=np.transpose(np.expand_dims(imrec_target[:,:,:],axis=3),(3,0,1,2))
                            # FP_data_y[i]=np.transpose(np.expand_dims(grad_img_copy[:,:,:],axis=3),(3,0,1,2))
                            # FP_data_u[i]=np.transpose(np.expand_dims(data_ph_out[:,:,:],axis=3),(3,0,1,2))
                            # FP_data_p[i]=np.transpose(np.expand_dims(precond[:,:,:],axis=3),(3,0,1,2))

                            

                        else :
                    
                            grad_img_copy = imrec_target-invrho*normalization_y*grad_img 
                            grad_img_copy *= mask_ph
                            precond = torch.where(xt>0.0, 1/torch.add(sen[0],1.0), 1e-10)
                            precond = precond.squeeze().cpu().numpy() 

                            # test = invrho*grad_img*mask_ph
                            # FP_data_x[i]=np.transpose(np.expand_dims(grad_img[:,:,:],axis=3),(3,0,1,2))
                            FP_data_x[i]=np.transpose(np.expand_dims(grad_img_copy[:,:,:],axis=3),(3,0,1,2))
                            FP_data_y[i]=np.transpose(np.expand_dims(imrec_target[:,:,:],axis=3),(3,0,1,2))
                            FP_data_u[i]=np.transpose(np.expand_dims(data_ph_out[:,:,:],axis=3),(3,0,1,2))
                            FP_data_p[i]=np.transpose(np.expand_dims(imrec_targetEM[:,:,:],axis=3),(3,0,1,2))
                            FP_data_rho[i] = -1.0 + 2*(invrho*normalization_y/1e6)

                        i = i+1   
                    
                    
                    if paramsDataSet.augmentation_FP_EM:
                        for invrho in list_rho_EM:

                        
                
                            # grad_img_copy = imrec_target-invrho*grad_img 
                            # grad_img_copy *= mask_ph
                            # # precond = torch.add(xt, 1e-10)/torch.add(sen,1.0) #(sen-bwd)/sen 
                            # precond = torch.where(xt>0.0, 1/torch.add(sen[0],1.0), 1e-10)
                            # # torch.add(mask_ph, 1e-10)/torch.add(sen,1.0) #(sen-bwd)/sen 
                            # # precond = precond/torch.norm(precond)
                            # precond = precond.squeeze().cpu().numpy() 

                        
                        
                            grad_img_copy = imrec_targetEM-invrho*normalization_y*grad_img_EM
                            grad_img_copy *= mask_ph
                            FP_data_xEM[i_EM]=np.transpose(np.expand_dims(grad_img_copy[:,:,:],axis=3),(3,0,1,2))
                            FP_data_yEM[i_EM]=np.transpose(np.expand_dims(imrec_target[:,:,:],axis=3),(3,0,1,2))
                            FP_data_uEM[i_EM]=np.transpose(np.expand_dims(data_ph_out[:,:,:],axis=3),(3,0,1,2))
                            FP_data_rhoEM[i_EM] =  -1.0 + 2*(invrho*normalization_y/1e6)
                        
                            i_EM = i_EM+1

                    if paramsDataSet.augmentation_FP_NN:
                
                        grad_img_copy = imrec_targetNN*mask_ph 
                        FP_data_xNN[i_NN]=np.transpose(np.expand_dims(grad_img_copy[:,:,:],axis=3),(3,0,1,2))
                        FP_data_yNN[i_NN]=np.transpose(np.expand_dims(imrec_target[:,:,:],axis=3),(3,0,1,2))
                        FP_data_uNN[i_NN]=np.transpose(np.expand_dims(data_ph_out[:,:,:],axis=3),(3,0,1,2))
                                
                    
                        i_NN = i_NN+1

        FP_data_x = FP_data_x[:,t:,:,:]
        FP_data_y = FP_data_y[:,t:,:,:]
        FP_data_u = FP_data_u[:,t:,:,:]
        FP_data_p = FP_data_p[:,t:,:,:]
        print("max rho", np.max(FP_data_rho), " and min rho", np.min(FP_data_rho))

        # _ = database_base.FNE_constants_ph(FP_data_x, FP_data_y, img_FNE+1)
        # print('pre normalization, FNE ratio', list_FNE_ratio)

        _, _, FP_sum_x, _, alpha, _, _, FP_standardized_sum_x, _ = database_base.normalize_data(FP_data_x, FP_data_y, alpha)
        
        datasetAugFP_tf = CustomTensorDataset(tensors= (torch.tensor(FP_data_x,dtype=torch.float32), torch.tensor(FP_data_y,dtype=torch.float32),
                                     torch.tensor(FP_data_x,dtype=torch.float32), torch.tensor(FP_data_u,dtype=torch.float32),
                                 torch.tensor(FP_data_rho,dtype=torch.float32), torch.tensor(FP_standardized_sum_x,dtype=torch.float32),
                                   torch.tensor(FP_data_p,dtype=torch.float32)), transform=transform)
        
        datasetAugFP = CustomTensorDataset(tensors= (torch.tensor(FP_data_x,dtype=torch.float32), torch.tensor(FP_data_y,dtype=torch.float32),
                                        torch.tensor(FP_data_x,dtype=torch.float32), torch.tensor(FP_data_u,dtype=torch.float32),
                                    torch.tensor(FP_data_rho,dtype=torch.float32), torch.tensor(FP_standardized_sum_x,dtype=torch.float32),
                                    torch.tensor(FP_data_p,dtype=torch.float32)))
                            
        if paramsDataSet.augmentation_FP_NN:
            FP_data_xNN = FP_data_xNN[:,t:,:,:]
            FP_data_yNN = FP_data_yNN[:,t:,:,:]
            FP_data_uNN = FP_data_uNN[:,t:,:,:]

            _, _, FP_sum_x_NN, _, alpha, _, _, FP_standardized_sum_x_NN, _ = database_base.normalize_data(FP_data_xNN, FP_data_yNN, alpha)
            datasetAugFP_NN_tf = CustomTensorDataset(tensors=(torch.tensor(FP_data_xNN,dtype=torch.float32), torch.tensor(FP_data_yNN,dtype=torch.float32),
                                     torch.tensor(FP_sum_x_NN,dtype=torch.float32), torch.tensor(FP_data_uNN,dtype=torch.float32),
                                alpha*torch.ones(FP_data_xNN.shape[0]), torch.tensor(FP_standardized_sum_x_NN,dtype=torch.float32), 
                                torch.tensor(FP_data_uNN,dtype=torch.float32)), transform=transform
                            )
            datasetAugFP_NN = CustomTensorDataset(tensors=(torch.tensor(FP_data_xNN,dtype=torch.float32), torch.tensor(FP_data_yNN,dtype=torch.float32),
                                     torch.tensor(FP_sum_x_NN,dtype=torch.float32), torch.tensor(FP_data_uNN,dtype=torch.float32),
                                alpha*torch.ones(FP_data_xNN.shape[0]), torch.tensor(FP_standardized_sum_x_NN,dtype=torch.float32), 
                                torch.tensor(FP_data_uNN,dtype=torch.float32)) 
                            )
            
        if paramsDataSet.augmentation_FP_EM:
            FP_data_xEM = FP_data_xEM[:,t:,:,:]
            FP_data_yEM = FP_data_yEM[:,t:,:,:]
            FP_data_uEM = FP_data_uEM[:,t:,:,:]
            print("augmentation_FP_EM with max rho", np.max(FP_data_rhoEM), " and min rho", np.min(FP_data_rhoEM))

            _, _, FP_sum_x_EM, _, alpha, _, _, FP_standardized_sum_x_EM, _ = database_base.normalize_data(FP_data_xEM, FP_data_yEM, alpha)
            # datasetAugFP_EM_tf = CustomTensorDataset(tensors=(torch.tensor(FP_data_xEM,dtype=torch.float32), torch.tensor(FP_data_yEM,dtype=torch.float32),
            #                          torch.tensor(FP_sum_x_EM,dtype=torch.float32), torch.tensor(FP_data_uEM,dtype=torch.float32),
            #                      torch.tensor(FP_data_rhoEM,dtype=torch.float32), torch.tensor(FP_standardized_sum_x_EM,dtype=torch.float32), 
            #                     torch.tensor(FP_data_uEM,dtype=torch.float32)), transform=transform
            #                 )
            # datasetAugFP_EM = CustomTensorDataset(tensors=(torch.tensor(FP_data_xEM,dtype=torch.float32), torch.tensor(FP_data_yEM,dtype=torch.float32),
            #                          torch.tensor(FP_sum_x_EM,dtype=torch.float32), torch.tensor(FP_data_uEM,dtype=torch.float32),
            #                      torch.tensor(FP_data_rhoEM,dtype=torch.float32), torch.tensor(FP_standardized_sum_x_EM,dtype=torch.float32), 
            #                     torch.tensor(FP_data_uEM,dtype=torch.float32)) 
            #                 )
            
            datasetAugFP_EM = CustomTensorDataset(tensors=(torch.tensor(FP_data_xEM,dtype=torch.float32), torch.tensor(FP_data_yEM,dtype=torch.float32),
                                     torch.tensor(FP_data_xEM,dtype=torch.float32), torch.tensor(FP_data_uEM,dtype=torch.float32),
                                 torch.ones(FP_data_rhoEM.shape,dtype=torch.float32), torch.ones(FP_data_rhoEM.shape,dtype=torch.float32), 
                                torch.tensor(FP_data_xEM,dtype=torch.float32)) 
                            )


    if paramsDataSet.gaussian_denoising:
        # MMSE_phantom = MMSE_phantom[:,t:,:,:]
        # MMSE_target = MMSE_target[:,t:,:,:]
        # MMSE_input = MMSE_input[:,t:,:,:]

        _, _, gaussian_sum_x, _, alpha, _, _, noisy_standardized_sum_x_NN, _ = database_base.normalize_data(MMSE_input, MMSE_target, alpha)
        # datasetGaussian_tf = CustomTensorDataset(tensors=(torch.tensor(MMSE_input,dtype=torch.float32), torch.tensor(MMSE_target,dtype=torch.float32),
        #                             torch.tensor(gaussian_sum_x,dtype=torch.float32), torch.tensor(MMSE_phantom,dtype=torch.float32),
        #                     alpha*torch.ones(MMSE_input.shape[0]), torch.tensor(noisy_standardized_sum_x_NN,dtype=torch.float32), 
        #                     torch.tensor(MMSE_phantom,dtype=torch.float32)), transform=transform
        #                 )
        datasetGaussian = CustomTensorDataset(tensors=(torch.tensor(MMSE_input,dtype=torch.float32), torch.tensor(MMSE_target,dtype=torch.float32),
                                    torch.tensor(MMSE_input,dtype=torch.float32), torch.tensor(MMSE_phantom,dtype=torch.float32),
                            alpha*torch.ones(MMSE_input.shape[0]), torch.tensor(noisy_standardized_sum_x_NN,dtype=torch.float32), 
                            torch.tensor(MMSE_phantom,dtype=torch.float32)) 
                        )

    if paramsDataSet.augmentation_outputNN :
       datasetNN_tf = CustomTensorDataset(tensors=(torch.tensor(postNN_data_x, dtype=torch.float32), torch.tensor(data_y_den, dtype=torch.float32),
                                 torch.tensor(postNN_sum_x, dtype=torch.float32), torch.tensor(data_phantom_sel, dtype=torch.float32),
                                alpha*torch.ones(postNN_data_x.shape[0]), torch.tensor(postNN_standardized_sumx, dtype=torch.float32),
                                torch.tensor(data_phantom_sel, dtype=torch.float32)), transform=transform
                            )
       datasetNN = CustomTensorDataset(tensors=(torch.tensor(postNN_data_x, dtype=torch.float32), torch.tensor(data_y_den, dtype=torch.float32),
                                 torch.tensor(postNN_sum_x, dtype=torch.float32), torch.tensor(data_phantom_sel, dtype=torch.float32),
                                alpha*torch.ones(postNN_data_x.shape[0]), torch.tensor(postNN_standardized_sumx, dtype=torch.float32),
                                torch.tensor(data_phantom_sel, dtype=torch.float32)) 
                            )

    
    test_size=int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*paramsDataSet.n_sim    
    indices = list(range(paramsDataSet.n_subjects*paramsDataSet.n_sim))
    train_indices, val_indices = indices[test_size:], indices[:test_size]
    # Create Subset for training and validation
    train_data = Subset(dataset_tf, train_indices)
    test_data  = Subset(dataset, val_indices)

    # train_data, test_data = train_test_split(dataset, test_size = test_size, shuffle = False)
    # indices = np.where(n_sum_x < 0.4)
    # # Removing duplicates from the list
    # list2 = list(set(n_sum_x))
    
    # # Sorting the  list
    # list2.sort()
    
    # # # Printing the second last element
    # # print("Second largest element is:", list2[-1])

    # Ntot = len(n_sum_x)
    # # indices = np.where(np.logical_and(n_sum_x >= list2[0],n_sum_x <list2[11]) ) # correspond à sigma max 
    # # indices = np.where(np.logical_and(n_sum_x > list2[-11],n_sum_x <=list2[-1]) ) # correspond à sigma max 
    # indices = np.where(np.logical_and(n_sum_x >= list2[Ntot//2],n_sum_x <list2[Ntot//2+10]) ) # correspond à sigma max 
    # # # # print(indices[0])
    # dataset = torch.utils.data.Subset(dataset, indices[0])

    if paramsDataSet.augmentation_GT :

        print("augmentation GT")
        raise NotImplementedError
        # test_size_aug_GT=int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*paramsDataSet.n_sim
        # train_data_aug_GT, test_data_aug_GT = train_test_split(datasetGT, test_size = test_size_aug_GT, shuffle = False)
        # train_data = torch.utils.data.ConcatDataset([train_data, train_data_aug_GT]) 
        # test_data = torch.utils.data.ConcatDataset([test_data, test_data_aug_GT])

    if paramsDataSet.augmentation_FP or paramsDataSet.augmentation_FP_w:
        print("augmentation FP")
        test_size_aug_FP=int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*n_sim*n_rho
        indices = list(range(paramsDataSet.n_subjects*n_sim*n_rho))
        train_indices, val_indices = indices[test_size_aug_FP:], indices[:test_size_aug_FP]
        # Create Subset for training and validation
        train_data_aug_FP = Subset(datasetAugFP_tf, train_indices)
        test_data_aug_FP = Subset(datasetAugFP, val_indices)

        # test_size_aug_FP=int(math.ceil(paramsDataSet.test_percent*5))*paramsDataSet.n_sim
        # train_data_aug_FP, test_data_aug_FP = train_test_split(datasetAugFP, test_size = test_size_aug_FP, shuffle = False)
        print("size test FP", int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*n_sim*n_rho)
        if use_only_FP : 
            print("using only FP")
            train_data = train_data_aug_FP
            test_data = test_data_aug_FP
        else :
            train_data = torch.utils.data.ConcatDataset([train_data, train_data_aug_FP]) 
            test_data = test_data_aug_FP #torch.utils.data.ConcatDataset([test_data, test_data_aug_FP]) 


    if paramsDataSet.augmentation_FP_NN:
        print("augmentation FP NN")
        test_size_aug_FP=int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*n_sim
        indices = list(range(paramsDataSet.n_subjects*n_sim))
        train_indices, val_indices = indices[test_size_aug_FP:], indices[:test_size_aug_FP]
        # Create Subset for training and validation
        train_data_aug_FP = Subset(datasetAugFP_NN_tf, train_indices)
        test_data_aug_FP = Subset(datasetAugFP_NN, val_indices)

        # train_data_aug_FP, test_data_aug_FP = train_test_split(datasetAugFP_NN, test_size = test_size_aug_FP, shuffle = False)
        train_data = torch.utils.data.ConcatDataset([train_data, train_data_aug_FP]) 
        test_data = torch.utils.data.ConcatDataset([test_data, test_data_aug_FP]) 

    if paramsDataSet.augmentation_FP_EM:
        print("augmentation FP EM")
        test_size_aug_FP=int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*n_sim*n_rho_EM
        indices = list(range(paramsDataSet.n_subjects*n_sim*n_rho_EM))
        train_indices, val_indices = indices[test_size_aug_FP:], indices[:test_size_aug_FP]
        # Create Subset for training and validation
        train_data_aug_FP = Subset(datasetAugFP_EM_tf, train_indices)
        test_data_aug_FP = Subset(datasetAugFP_EM, val_indices)        
        # train_data_aug_FP, test_data_aug_FP = train_test_split(datasetAugFP_EM, test_size = test_size_aug_FP, shuffle = False)
        train_data = torch.utils.data.ConcatDataset([train_data, train_data_aug_FP]) 
        test_data = torch.utils.data.ConcatDataset([test_data, test_data_aug_FP])
        # # print("using only FP")
        # train_data = train_data_aug_FP
        # test_data = test_data_aug_FP


    if paramsDataSet.gaussian_denoising:
        print("gaussian denoising")
        test_size_MMSE=int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*paramsDataSet.n_sim*nb_noise_levels
        indices = list(range(paramsDataSet.n_subjects*paramsDataSet.n_sim*nb_noise_levels))
        train_indices, val_indices = indices[test_size_MMSE:], indices[:test_size_MMSE]
        # Create Subset for training and validation
        train_data_MMSE = Subset(datasetGaussian, train_indices)
        test_data_MMSE = Subset(datasetGaussian, val_indices)


        # train_data_MMSE, test_data_MMSE = train_test_split(datasetGaussian, test_size = test_size_MMSE, shuffle = False)
        train_data = train_data_MMSE 
        test_data = test_data_MMSE


    if paramsDataSet.augmentation_outputNN  :
        print("augmentation output NN")
        test_size_aug_NN=int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*paramsDataSet.n_sim
        indices = list(range(paramsDataSet.n_subjects*paramsDataSet.n_sim))
        train_indices, val_indices = indices[test_size_aug_NN:], indices[:test_size_aug_NN]
        # Create Subset for training and validation
        train_data_aug_NN = Subset(datasetNN_tf, train_indices)
        test_data_aug_NN = Subset(datasetNN, val_indices)


        # train_data_aug_NN, test_data_aug_NN = train_test_split(datasetNN, test_size = test_size_aug_NN, shuffle = False)
        train_data = train_data_aug_NN
        test_data = test_data_aug_NN

 
    return train_data, test_data




def get_train_loader(train_data, paramsDataSet, num_workers=2): 

    
    loader_args = dict(num_workers=num_workers, pin_memory=True)
    train_loader = torch.utils.data.DataLoader(train_data, shuffle = paramsDataSet.shuffle_train,
            batch_size = paramsDataSet.train_batch_size, drop_last = False, **loader_args)


    print("size of train loader", len(train_loader))
    return train_loader

def get_test_loader(test_data, paramsDataSet, num_workers=2): 

    
    loader_args = dict(num_workers=num_workers, pin_memory=True)
    test_loader = torch.utils.data.DataLoader(test_data, shuffle = paramsDataSet.shuffle_test,
            batch_size = paramsDataSet.test_batch_size, **loader_args)

    print("size of test loader", len(test_loader))
    return test_loader



def get_data2(data_x, 
             data_y, 
             data_mri, 
             paramsDataSet, 
             device="cuda", 
             verbose=True, 
             img_FNE= 0, 
             copy_all = False, 
             use_only_FP = False, 
             reduced_sim = False, 
             FP_from_FB = False, 
             transform=None, 
             n_rho = 2, 
             bLowRho = False,
             bFixedRho = False,
             i_list_rho = [],
             weighted_KL = False,
             bRandomRho = False,
             bRhoOpt = False,
             bElasticEM = False,
             fElasticFactor = 1.0,
             rho_m = 1e4,
             rho_M = 1e6, 
             bLinear = False,
             precond_EM = False,
             lut_name="/share/Programs/castor/castor_git/config/scanner/PET_SIEMENS_BIOGRAPH6_TRUEPOINT_TRUEV.lut"
             ): 

    '''
    Generates training and testing torch dataloaders using the numpy data. The target
    is potentially obtained as the output of a NN applied on data_y (e.g. for dose reduction).

    Arguments:
        - data_x: Input images (4D numpy array - [index_im,z,y,x]).
        - data_y: Target images (4D numpy array - [index_im,z,y,x]).
        - paramsDataSet: parameters for tensor dataset (tensorDataSetDoserecParams).
        - device: device used for Tensors ("cuda" or "cpu")
        - device_model: device used for models ("cuda" or "cpu")

    Returns:
        - dataset: TensorDataset wrapping input and target data. When norm_sj=True, add the list of total sum of data_x
                   and data_y for every 3D image and the normalization constant. If norm_sj=False and norm_train=True,
                   add the tensor array of patient number, realization number,normalization constant and init value for
                   the scaling constant (torch.utils.data.TensorDataset).
        - train_loader: Dataloader containing the training data (torch.utils.data.DataLoader)
        - test_loader: Dataloader containing the testing data (torch.utils.data.DataLoader).
        - sum_x: List of input image sum values (list of floats).
        - sum_y: List of target image sum values (list of floats).
        - alpha: Normalization constant used (list of normalization constants).

    Note:
        For large databases the loader should be in CPU, and tensor copied to gpu when used if needed.
    '''

    if not isinstance(paramsDataSet,tensorDataSetDoserecParams):
        raise TypeError("paramsDataSet type is not tensorDataSetDoserecParams ")

    alpha = paramsDataSet.alpha

    max_sum = 0
    bUseMRI = (data_mri is not None)

    if copy_all:
        data_x_sel = data_x
        data_y_sel = data_y
        

    else :

        n_select=paramsDataSet.n_sim*paramsDataSet._n_subjects
        dim=[n_select,data_x.shape[1],data_x.shape[2],data_x.shape[3]]
        data_x_sel=np.zeros(dim)
        data_y_sel=np.zeros(dim)
        data_phantom_sel = np.zeros(dim)
        # offset_im=0
        for ki, subject in enumerate(paramsDataSet.lst_subjects_reduced):
            for kr,real in enumerate(range(paramsDataSet.n_sim)):
                data_x_sel[kr+ki*paramsDataSet.n_sim]=data_x[kr+ki*paramsDataSet.doserecParams.n_sim]
                data_y_sel[kr+ki*paramsDataSet.n_sim]=data_y[kr+ki*paramsDataSet.doserecParams.n_sim]
                phantom_ref,phantom_hdr_ref=paramsDataSet.doserecParams.get_fname_im_phantom_red(subject,real)
                path_phantom_hdr=os.path.join(paramsDataSet.doserecParams.get_gen_dbase_dir(subject),phantom_hdr_ref)
                if os.path.exists(path_phantom_hdr):
                    phantom_hdr=Interfile.load(path_phantom_hdr)
                    phantom_hdr['name of data file']['value']=phantom_ref
                    phantom,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(phantom_hdr,paramsDataSet.doserecParams.get_gen_dbase_dir(subject),verbose=verbose)
                else:
                    raise FileNotFoundError(errno.ENOENT,os.strerror(errno.ENOENT),path_phantom_hdr)
                
                data_phantom_sel[kr+ki*paramsDataSet.n_sim]=phantom
                tmp_sumx = np.sum(data_x_sel[kr+ki*paramsDataSet.n_sim])
                max_sum = max(max_sum, tmp_sumx)
                


    if paramsDataSet.truncate < data_x.shape[1]:
        t = data_x_sel.shape[1] - paramsDataSet.truncate
        
        data_x_sel = data_x_sel[:,t:,:,:]
        data_y_sel = data_y_sel[:,t:,:,:]
        data_phantom_sel = data_phantom_sel[:,t:,:,:]
        
    data_y_den=data_y_sel
    print("max target", np.max(data_y_den))

    # compute max l2 distance between two elements of data_y_den
    # l2_distances = []
    # pairs = list(combinations(range(data_y_den.shape[0]), 2))

    # vgg = VGG().cuda()
    # def calculate_lpips(preds, target):
    #     nmax = target.max()
    #     for i in range(preds.shape[0]):
    #         s_preds = preds[i]/nmax  
    #         s_target = target[i]/nmax
    #         tensor_spreds = torch.tensor(2*s_preds-1, dtype=torch.float32, device = "cuda")
    #         tensor_starget = torch.tensor(2*s_target-1, dtype=torch.float32, device = "cuda")
    #         tensor_spreds = tensor_spreds.unsqueeze(0).unsqueeze(0).expand(1, 3, -1, -1)
    #         tensor_starget = tensor_starget.unsqueeze(0).unsqueeze(0).expand(1, 3, -1, -1) 
    #         if i == 0 :
    #             loss = vgg(tensor_spreds,tensor_starget)
    #         else :
    #             loss += vgg(tensor_spreds,tensor_starget)
                     
    #     return loss


    # for i,j in pairs:
    #     # l2_distances.append((np.abs(data_y_den[i] - data_y_den[j])).sum() )
    #     l2_distances.append(calculate_lpips(data_y_den[i],data_y_den[j]).item() )
            
    #         # np.linalg.norm(data_y_den[i] - data_y_den[j]))

    # max_l2 = max(l2_distances)
    # min_l2 = min(l2_distances)
    # median_l2 = np.median(l2_distances)
    # mean_l2 = np.mean(l2_distances)
    # print("Max l2 distance between two elements of data_y_den: ", max_l2)
    # print("Min l2 distance between two elements of data_y_den: ", min_l2)
    # print("Median l2 distance between two elements of data_y_den: ", median_l2)
    # print("Mean l2 distance between two elements of data_y_den: ", mean_l2)


   
    _, _, sum_x, sum_y, alpha, _, _, standardized_sum_x, _ = database_base.normalize_data(data_x_sel, data_y_den, alpha)
    sum_x = np.ones_like(sum_x)
    sum_y = np.ones_like(sum_y)


    if  (paramsDataSet.augmentation_FP):

        doserec_object = paramsDataSet.doserecParams
        castor_object = paramsDataSet.doserecParams.CASToRParams
        list_sub = doserec_object.lst_subjects
        fwhm=[4]*3
        nbsigma=[5]*3
        sigma_gaussian = PETLibs.utils.fwhm2sigma(fwhm,castor_object.vox_size)
        kernel_size = np.ceil(nbsigma*sigma_gaussian)
        convOp=GaussianSmoothing(kernel_size, sigma_gaussian,device="cuda:0")

        reconsParams = PETLibs.recons.GPUBiographReconsParams(lut_name=lut_name,
                                                    vox_size=castor_object.vox_size,im_dim=castor_object.im_dim, 
                                                    XYZ=False, nsubsets=1, convOp=convOp)
        
        dim=castor_object.im_dim
        n1 = dim[0]
        n2 = dim[1]
        n3 = dim[2]
        data_y_out = np.zeros([n1,n2,n3])

        #if paramsDataSet.augmentation_FP_EM :
        data_yEM = np.zeros([n1,n2,n3])

        data_ph_out = np.zeros([n1,n2,n3])

        if reduced_sim :
            n_sim = 1 
        else :
            n_sim = doserec_object.n_sim 
                
        FP_data_x = np.empty([n_sim*n_rho*len(list_sub),n1,n2,n3])
        FP_data_y = np.empty([n_sim*n_rho*len(list_sub),n1,n2,n3])
        FP_data_u = np.empty([n_sim*n_rho*len(list_sub),n1,n2,n3])
        FP_data_p = np.empty([n_sim*n_rho*len(list_sub),n1,n2,n3])
        FP_data_EM = np.empty([n_sim*n_rho*len(list_sub),n1,n2,n3])
        FP_data_rho = np.empty([n_sim*n_rho*len(list_sub),1])
        vec_dose = np.empty([n_sim*n_rho*len(list_sub),1])
        if bUseMRI:
            FP_data_mri = np.empty([n_sim*n_rho*len(list_sub),n1,n2,n3])

        if paramsDataSet.augmentation_FP_EM :
            
            list_rho_EM = [0] #, 1e6]
            n_rho_EM = len(list_rho_EM)
            FP_data_yEM = np.empty([n_sim*n_rho_EM*len(list_sub),n1,n2,n3])
            FP_data_xEM = np.empty([n_sim*n_rho_EM*len(list_sub),n1,n2,n3])
            FP_data_uEM = np.empty([n_sim*n_rho_EM*len(list_sub),n1,n2,n3])
            FP_data_rhoEM = np.empty([n_sim*n_rho_EM*len(list_sub),1])
            vec_doseEM = np.empty([n_sim*n_rho_EM*len(list_sub),1])

  

        reconsOps=GPURecons.GPUReconsOps(reconsParams)
        i = 0
        i_EM = 0
        t = n1 - paramsDataSet.truncate
        list_rho = []

        # normalization_target_rho = database_base.get_sum_img(data_y_den)
        with tqdm(total=len(list_sub)*n_sim, desc="Iterations FP", unit='Iteration(s)') as pbar:
            for index_sub, subject in enumerate(list_sub):
                for index_real, real in enumerate(range(n_sim)):
                    # print("Subject nb",index_sub, "out of", len(list_sub), "Realization: ",real)
                    castor_df_ima,castor_df_hdr=doserec_object.get_fname_sinogram_CASToR_hdr(subject,real)
                    castor_df_dir=doserec_object.get_gen_castor_dir(subject,real)
                    castor_df_hdr_fpath=os.path.join(castor_df_dir,castor_df_hdr)
                    data_x_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(data_x_sel[index_real+index_sub*doserec_object.n_sim], dtype=torch.float32),0),0).to(device)
                    data_y_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(data_y_den[index_real+index_sub*doserec_object.n_sim], dtype=torch.float32),0),0).to(device)
                    # normalization_y = normalization_target_rho[index_real+index_sub*doserec_object.n_sim]
                    data_ph_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(data_phantom_sel[index_real+index_sub*doserec_object.n_sim], dtype=torch.float32),0),0).to(device)



                    # sigma = torch.where(data_ph_device > 0, torch.tensor(1.0, dtype=torch.float32, device = "cuda"), torch.tensor(0.0, dtype=torch.float32, device = "cuda"))


                    data_y_out[t:,:,:]=torch.squeeze(data_y_device).detach().cpu().numpy() 
                    data_ph_out[t:,:,:]=torch.squeeze(data_ph_device).detach().cpu().numpy() 

                    
                    #if paramsDataSet.augmentation_FP_EM :
                    data_yEM[t:,:,:]=torch.squeeze(data_x_device).detach().cpu().numpy()

                    data_y_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(data_y_out[t:,:,:], dtype=torch.float32),0),0).to(device)
                    mask_ph = data_ph_out > 0.0

                    imrec_target=data_y_out*mask_ph 
                    
                    
                    #if paramsDataSet.augmentation_FP_EM :
                    imrec_targetEM = data_yEM*mask_ph

                    dict_sino=GPURecons.GPUCASToRSinos(castor_df_hdr_fpath, castor_df_dir,
                                                        reconsParams=reconsParams)
                    
                    y_data =  reconsParams.createSubsetData(dict_sino["val"])
                    mult_array =  reconsParams.createSubsetData(dict_sino["mult"])
                    add_array =  reconsParams.createSubsetData(dict_sino["add"])
                    sinomask =  reconsParams.createSubsetData(dict_sino["mask"])
                    sen=reconsOps.computeSensitivityImages(sinomask,mult_factor=mult_array) #No need for autograd here 
                    sen0 = sen[0].to("cuda")
                    # print("dose", np.sum(dict_sino_orig["val"].cpu().numpy()))

                    P = 1.0 #P.squeeze().cpu().numpy()#*imrec_target
                    xt= torch.reshape(torch.tensor(P*imrec_target,dtype=torch.float32, device = "cuda"),reconsParams.tb_im_dim)
                    xEM = torch.reshape(torch.tensor(imrec_targetEM,dtype=torch.float32, device = "cuda"),reconsParams.tb_im_dim)
                    fwd=reconsOps.forwardProj(xt,mult_factor=mult_array[0],add_factor=add_array[0], subset=0)
                    dose_target = fwd.sum()

                    ratio = torch.where(fwd>0,torch.divide(y_data[0],fwd),torch.tensor(1.0, dtype = torch.float32, device = "cuda")) #*sinomask
                    xEM = torch.max(xEM, torch.tensor(0.0, dtype = torch.float32, device = "cuda"))                   


                    # del fwd
                    if weighted_KL :
                        fwd_all_ones = reconsOps.forwardProj(torch.zeros_like(xt),mult_factor=mult_array[0],add_factor=(add_array[0]), subset=0)#0.001+
                        fwd_all_ones = torch.where(fwd>0, fwd_all_ones, torch.tensor(0.0, dtype = torch.float32, device = "cuda"))
                        bwd_all_ones = reconsOps.backwardProj(fwd_all_ones,mult_factor=mult_array[0],add_factor=0, subset=0)
              
                        bwd=reconsOps.backwardProj(fwd_all_ones*ratio,mult_factor=mult_array[0],add_factor=0, subset=0)
                        grad_img = (bwd_all_ones-bwd)
                    elif precond_EM :
                        # (EM/sen)*(sen - Bck) = EM - EM*Bck
                        bwd=reconsOps.backwardProj(ratio,mult_factor=mult_array[0],add_factor=0, subset=0)
                        grad_img = (xEM+10.0)*(sen0-bwd)/sen0
                        precond_mat = sen0/(xEM+10.0)
                        precond_mat /= precond_mat.max()
                        precond_mat = precond_mat.squeeze().cpu().numpy() 
                        precond_mat *= mask_ph
                    else :
                        bwd=reconsOps.backwardProj(ratio,mult_factor=mult_array[0],add_factor=0, subset=0)
                        grad_img = (sen0-bwd)

                    
                     
                                 
                    grad_img = grad_img.squeeze().cpu().numpy() 
                    grad_img *= mask_ph
                    
                    del bwd
                    del fwd

                    
                    if paramsDataSet.augmentation_FP_EM :
                        xt_EM= torch.reshape(torch.tensor(imrec_targetEM,dtype=torch.float32, device = "cuda"),reconsParams.tb_im_dim)
                        fwd=reconsOps.forwardProj(xt_EM,mult_factor=mult_array[0],add_factor=add_array[0], subset=0)
                        ratio = torch.where(fwd>0,torch.divide(y_data[0],fwd),torch.tensor(1.0, dtype = torch.float32, device = "cuda")) #*sinomask
                        del fwd
                        bwd=reconsOps.backwardProj(ratio,mult_factor=mult_array[0],add_factor=0, subset=0)
                        grad_img_EM = sen0-bwd
                        grad_img_EM = grad_img_EM.squeeze().cpu().numpy()
                        del bwd


                    
                    


                    #################################################################
                    invrho_opt = ((((imrec_targetEM - imrec_target)**2)*mask_ph).sum()/(((grad_img**2)*mask_ph).sum()))
                    # print("invrho opt", '{:e}'.format((invrho_opt)))
                    list_rho.append(math.sqrt(invrho_opt))
                    #list_rho.append(invrho_opt)

                    grad_img_copy = grad_img 
                    # grad_img_copy *= mask_ph
                    # grad_img_copy *= imrec_targetEM
                             
                    for invrho in range(n_rho):

                        FP_data_x[i]=np.transpose(np.expand_dims(grad_img_copy[:,:,:],axis=3),(3,0,1,2))
                        if precond_EM :
                            FP_data_p[i]=np.transpose(np.expand_dims(precond_mat[:,:,:],axis=3),(3,0,1,2))

                        FP_data_y[i]=np.transpose(np.expand_dims(imrec_target[:,:,:],axis=3),(3,0,1,2))

                        FP_data_u[i]=np.transpose(np.expand_dims(data_ph_out[:,:,:],axis=3),(3,0,1,2))
                        FP_data_EM[i]=np.transpose(np.expand_dims(imrec_targetEM[:,:,:],axis=3),(3,0,1,2)) 
                        FP_data_rho[i] = dose_target.sqrt().item() #math.sqrt(invrho_opt)
                        vec_dose[i] = y_data[0].sum().cpu().numpy()
                        if bUseMRI :
                            FP_data_mri[i] = data_mri[index_real+index_sub*doserec_object.n_sim]


                        i = i+1    
                    
                    
                    if paramsDataSet.augmentation_FP_EM:
                        for invrho in list_rho_EM:           
                        
                            grad_img_copy = imrec_targetEM #-invrho*normalization_y*grad_img_EM
                            grad_img_copy *= mask_ph
                            FP_data_xEM[i_EM]=np.transpose(np.expand_dims(grad_img_copy[:,:,:],axis=3),(3,0,1,2))
                            FP_data_yEM[i_EM]=np.transpose(np.expand_dims(imrec_target[:,:,:],axis=3),(3,0,1,2))
                            FP_data_uEM[i_EM]=np.transpose(np.expand_dims(data_ph_out[:,:,:],axis=3),(3,0,1,2))
                            FP_data_rhoEM[i_EM] = 1.0 # -1.0 + 2*(invrho*normalization_y/1e6)
                            vec_doseEM[i_EM] = y_data[0].sum().cpu().numpy()
                        
                            i_EM = i_EM+1

                    pbar.update(1)
                # break


    ## second round
        # min_rho = np.min(list_rho)
        # max_rho = np.max(list_rho)
        # i=0
        # print("max invrho opt", '{:e}'.format(max_rho))
        # print("min invrho opt", '{:e}'.format(min_rho))
        # print("min ratio", '{:e}'.format(min_rho/max_rho))
        # random.seed(0)
        # for index_sub, subject in enumerate(list_sub):
        #     for index_real, real in enumerate(range(n_sim)):
        #         for _ in range(n_rho//2):
        #             invrho = max_rho*random.random()
        #             FP_data_x[i]=FP_data_y[i] - invrho*FP_data_x[i]
        #             FP_data_rho[i] = invrho/max_rho
        #             # print("invrho/max_rho", invrho/max_rho)
        #             i = i+1  
        #             invrho = max_rho*random.random()
        #             FP_data_x[i]=FP_data_y[i] - 0.01*invrho*FP_data_x[i]
        #             FP_data_rho[i] = 0.01*invrho/max_rho
        #             # print("invrho/max_rho", invrho/max_rho)
        #             i = i+1   
                
        min_rho = np.min(list_rho)
        max_rho = np.max(list_rho)
        i=0
        print("max invrho opt", '{:e}'.format(max_rho))
        print("min invrho opt", '{:e}'.format(min_rho))
        print("min ratio", '{:e}'.format(min_rho/max_rho))
        # random.seed(seed)
        if bLowRho :
            print("Low rho")
            for index_sub, subject in enumerate(list_sub):
                for index_real, real in enumerate(range(n_sim)):
                    for _ in range(n_rho-1):
                        invrho = min_rho + (max_rho-min_rho)*random.random()
                        FP_data_x[i]=FP_data_y[i] - invrho*FP_data_x[i]
                        FP_data_rho[i] = invrho/max_rho
                        i = i+1  
                    invrho = 0.0001*min_rho + (0.001*max_rho-0.0001*min_rho)*random.random()
                    FP_data_x[i]=FP_data_y[i] - invrho*FP_data_x[i]
                    FP_data_rho[i] = min_rho/max_rho
                    i = i+1  

        elif bFixedRho :
            max_rho = i_list_rho[0]*np.max(FP_data_rho)
            print("min rho", i_list_rho[0]*np.min(FP_data_rho), "max rho", max_rho)
            # l2_distances = []
            
            for index_sub, subject in enumerate(list_sub):
                for index_real, real in enumerate(range(n_sim)):
                    for invrho in i_list_rho:
                        if bElasticEM :
                            # print("invrho", invrho*FP_data_rho[i])
                            FP_data_x[i]=FP_data_y[i] - FP_data_rho[i]*invrho*FP_data_x[i] + fElasticFactor*(FP_data_EM[i] -  FP_data_y[i])
                            # l2_distance = calculate_lpips(FP_data_x[i] , FP_data_y[i]).item()
                            # #(np.abs(FP_data_x[i] - FP_data_y[i])).sum() #np.linalg.norm(FP_data_x[i] - FP_data_y[i], ord=1)
                            # l2_distances.append(l2_distance)
                        else :
                            FP_data_x[i]=FP_data_y[i] - invrho*FP_data_x[i]
                        FP_data_rho[i] = FP_data_rho[i]*invrho/max_rho
                        i = i+1
            # print("Max l2 distance between two elements of xin and target: ", np.max(l2_distances))
            # print("Min l2 distance between two elements of xin and target: ", np.min(l2_distances))
            # print("Median l2 distance between two elements of xin and target: ", np.median(l2_distances))
            # print("Mean l2 distance between two elements of xin and target: ", np.mean(l2_distances))

            # l2_distances_noise = []
            # pairs = list(combinations(range(FP_data_x.shape[0]), 2))
            # for i,j in pairs:
            #     #l2_distances_noise.append(np.linalg.norm(FP_data_x[i] - FP_data_x[j], ord=1))
            #     l2_distances_noise.append(calculate_lpips(FP_data_x[i] , FP_data_x[j]).item())
            #     #l2_distances_noise.append((np.abs(FP_data_x[i] - FP_data_x[j])).sum() )

            # print("Max l2 distance between two elements of xin: ", np.max(l2_distances_noise))
            # print("Min l2 distance between two elements of xin: ", np.min(l2_distances_noise))
            # print("Median l2 distance between two elements of xin: ", np.median(l2_distances_noise))
            # print("Mean l2 distance between two elements of xin: ", np.mean(l2_distances_noise))




        elif bRandomRho :
            for index_sub, subject in enumerate(list_sub):
                for index_real, real in enumerate(range(n_sim)):
                    for _ in i_list_rho:
                        
                        #invrho = np.random.normal(1, 0.99/3)*1e6
                        invrho = np.random.uniform(low=rho_m, high= rho_M)

                        FP_data_x[i]=FP_data_y[i] - invrho*FP_data_x[i]
                        FP_data_rho[i] = invrho/1e6
                        i = i+1

        elif bRhoOpt : # use list_rho
            for index_sub, subject in enumerate(list_sub):
                for index_real, real in enumerate(range(n_sim)):
                    FP_data_x[i]=FP_data_y[i] - FP_data_rho[i]*FP_data_x[i]
                    FP_data_rho[i] = FP_data_rho[i]/max_rho
                    i = i+1
                
                    
                    
        else :
            for index_sub, subject in enumerate(list_sub):
                for index_real, real in enumerate(range(n_sim)):
                    for _ in range(n_rho):
                        # invrho = 0.01*min_rho + (max_rho-0.01*min_rho)*random.random()
                        invrho = 0.1*min_rho + (max_rho-0.1*min_rho)*random.random()
                        # invrho = min_rho + (max_rho-min_rho)*random.random()
                        FP_data_x[i]=FP_data_y[i] - invrho*FP_data_x[i]
                       
                        FP_data_rho[i] = invrho/max_rho
                        if paramsDataSet.augmentation_FP_EM:
                            FP_data_rhoEM[i] = 1.0
                        i = i+1  
                 

        FP_data_x = FP_data_x[:,t:,:,:]
        FP_data_y = FP_data_y[:,t:,:,:]
        FP_data_u = FP_data_u[:,t:,:,:]
        FP_data_p = FP_data_p[:,t:,:,:]
        FP_data_EM = FP_data_EM[:,t:,:,:]
        if bUseMRI :
            FP_data_mri = FP_data_mri[:,t:,:,:]

        _, _, FP_sum_x, _, alpha, _, _, FP_standardized_sum_x, _ = database_base.normalize_data(FP_data_x, FP_data_y, alpha)
        # norm_vec_dose = vec_dose/vec_dose.max()

        norm_vec_dose = vec_dose.min()/vec_dose
        # datasetAugFP_tf = CustomTensorDataset(tensors= (torch.tensor(FP_data_x,dtype=torch.float32), torch.tensor(FP_data_y,dtype=torch.float32),
        #                              torch.tensor(FP_data_EM,dtype=torch.float32), torch.tensor(FP_data_u,dtype=torch.float32),
        #                          torch.tensor(FP_data_rho,dtype=torch.float32), torch.tensor(norm_vec_dose,dtype=torch.float32),
        #                            torch.tensor(FP_data_p,dtype=torch.float32)), transform=transform)
        
        
        if bUseMRI :
            datasetAugFP = CustomTensorDataset(tensors= (torch.tensor(FP_data_x,dtype=torch.float32), torch.tensor(FP_data_y,dtype=torch.float32),
                                        torch.tensor(FP_data_EM,dtype=torch.float32), torch.tensor(FP_data_u,dtype=torch.float32),
                                    torch.tensor(FP_data_rho,dtype=torch.float32), torch.tensor(norm_vec_dose,dtype=torch.float32),
                                    torch.tensor(FP_data_mri,dtype=torch.float32)), bLinear=bLinear)
        else :
            datasetAugFP = CustomTensorDataset(tensors= (torch.tensor(FP_data_x,dtype=torch.float32), torch.tensor(FP_data_y,dtype=torch.float32),
                                        torch.tensor(FP_data_EM,dtype=torch.float32), torch.tensor(FP_data_u,dtype=torch.float32),
                                    torch.tensor(FP_data_rho,dtype=torch.float32), torch.tensor(norm_vec_dose,dtype=torch.float32),
                                    torch.tensor(FP_data_p,dtype=torch.float32)), bLinear=bLinear)

                    
        if paramsDataSet.augmentation_FP_EM:
            FP_data_xEM = FP_data_xEM[:,t:,:,:]
            FP_data_yEM = FP_data_yEM[:,t:,:,:]
            FP_data_uEM = FP_data_uEM[:,t:,:,:]
            norm_vec_doseEM = vec_doseEM/vec_doseEM.max()
            print("augmentation_FP_EM with max rho", np.max(FP_data_rhoEM), " and min rho", np.min(FP_data_rhoEM))

            _, _, FP_sum_x_EM, _, alpha, _, _, FP_standardized_sum_x_EM, _ = database_base.normalize_data(FP_data_xEM, FP_data_yEM, alpha)
            # datasetAugFP_EM_tf = CustomTensorDataset(tensors=(torch.tensor(FP_data_xEM,dtype=torch.float32), torch.tensor(FP_data_yEM,dtype=torch.float32),
            #                          torch.tensor(FP_sum_x_EM,dtype=torch.float32), torch.tensor(FP_data_uEM,dtype=torch.float32),
            #                      torch.tensor(FP_data_rhoEM,dtype=torch.float32), torch.tensor(FP_standardized_sum_x_EM,dtype=torch.float32), 
            #                     torch.tensor(FP_data_uEM,dtype=torch.float32)), transform=transform
            #                 )
            if bUseMRI :
                datasetAugFP_EM = CustomTensorDataset(tensors= (torch.tensor(FP_data_EM,dtype=torch.float32), torch.tensor(FP_data_y,dtype=torch.float32),
                                        torch.tensor(FP_data_EM,dtype=torch.float32), torch.tensor(FP_data_u,dtype=torch.float32),
                                    torch.ones(FP_data_rho.shape,dtype=torch.float32), torch.tensor(norm_vec_dose,dtype=torch.float32),
                                    torch.tensor(FP_data_mri,dtype=torch.float32)), bLinear=bLinear)

            else :
                datasetAugFP_EM = CustomTensorDataset(tensors=(torch.tensor(FP_data_xEM,dtype=torch.float32), torch.tensor(FP_data_yEM,dtype=torch.float32),
                                     torch.tensor(FP_data_xEM,dtype=torch.float32), torch.tensor(FP_data_uEM,dtype=torch.float32),
                                 torch.tensor(FP_data_rhoEM,dtype=torch.float32), torch.tensor(norm_vec_doseEM,dtype=torch.float32), 
                                torch.tensor(FP_data_xEM,dtype=torch.float32)), bLinear=bLinear)


   
    
    test_size=int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*paramsDataSet.n_sim    
    indices = list(range(paramsDataSet.n_subjects*paramsDataSet.n_sim))
    train_indices, val_indices = indices[test_size:], indices[:test_size]
    # Create Subset for training and validation
    # train_data = Subset(dataset_tf, train_indices)
    # test_data  = Subset(dataset, val_indices)

      
    if paramsDataSet.augmentation_FP :
        print("augmentation FP")
        test_size_aug_FP=int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*n_sim*n_rho
        indices = list(range(paramsDataSet.n_subjects*n_sim*n_rho))
        train_indices, val_indices = indices[test_size_aug_FP:], indices[:test_size_aug_FP]
        # Create Subset for training and validation
        train_data_aug_FP = Subset(datasetAugFP, train_indices)
        test_data_aug_FP = Subset(datasetAugFP, val_indices)

        print("size test FP", int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*n_sim*n_rho)
        train_data = train_data_aug_FP
        test_data = test_data_aug_FP
        # if use_only_FP : 
        #     print("using only FP")
        #     train_data = train_data_aug_FP
        #     test_data = test_data_aug_FP
        # else :
        #     train_data = torch.utils.data.ConcatDataset([train_data, train_data_aug_FP]) 
        #     test_data = test_data_aug_FP #torch.utils.data.ConcatDataset([test_data, test_data_aug_FP]) 



    if paramsDataSet.augmentation_FP_EM:
        print("augmentation FP EM")
        test_size_aug_FP=int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*n_sim*n_rho_EM
        indices = list(range(paramsDataSet.n_subjects*n_sim*n_rho_EM))
        train_indices, val_indices = indices[test_size_aug_FP:], indices[:test_size_aug_FP]
        # Create Subset for training and validation
        train_data_aug_FP = Subset(datasetAugFP_EM, train_indices)
        test_data_aug_FP = Subset(datasetAugFP_EM, val_indices)        
        train_data = torch.utils.data.ConcatDataset([train_data, train_data_aug_FP]) 
        test_data = torch.utils.data.ConcatDataset([test_data, test_data_aug_FP])
      

 
    return train_data, test_data


def getDoseMin(paramsDataSet, 
             reduced_sim = False
             ): 

    

    if not isinstance(paramsDataSet,tensorDataSetDoserecParams):
        raise TypeError("paramsDataSet type is not tensorDataSetDoserecParams ")


    doserec_object = paramsDataSet.doserecParams
    castor_object = paramsDataSet.doserecParams.CASToRParams
    list_sub = doserec_object.lst_subjects
    reconsParams = PETLibs.recons.GPUBiographReconsParams(lut_name="/share/Programs/castor/castor_git/config/scanner/PET_SIEMENS_BIOGRAPH6_TRUEPOINT_TRUEV.lut",
                                                vox_size=castor_object.vox_size,im_dim=castor_object.im_dim, 
                                                XYZ=False, nsubsets=1, fwhm_mm = 4, nbsigmas = 5)
    
 


    if reduced_sim :
        n_sim = 1 
    else :
        n_sim = doserec_object.n_sim 
            

    
    list_dose = []

    with tqdm(total=len(list_sub)*n_sim, desc="Sinograms", unit='Iteration(s)') as pbar:
        for _, subject in enumerate(list_sub):
            for _, real in enumerate(range(n_sim)):
                _,castor_df_hdr=doserec_object.get_fname_sinogram_CASToR_hdr(subject,real)
                castor_df_dir=doserec_object.get_gen_castor_dir(subject,real)
                castor_df_hdr_fpath=os.path.join(castor_df_dir,castor_df_hdr)

                dict_sino=GPURecons.GPUCASToRSinos(castor_df_hdr_fpath, castor_df_dir,
                                                    reconsParams=reconsParams)
                
                y_data =  reconsParams.createSubsetData(dict_sino["val"])
          
                
                
                list_dose.append(y_data[0].sum().cpu().numpy())
                pbar.update(1)
        
            
    vec_dose = np.array(list_dose)
    # norm_vec_dose = vec_dose.min()/vec_dose
    return vec_dose.min()


def modelGradDose(data_x, 
             data_y, 
             paramsDataSet, 
             device="cuda", 
             verbose=True, 
             reduced_sim = False
             ): 

    

    if not isinstance(paramsDataSet,tensorDataSetDoserecParams):
        raise TypeError("paramsDataSet type is not tensorDataSetDoserecParams ")

    alpha = paramsDataSet.alpha
    n_select=paramsDataSet.n_sim*paramsDataSet._n_subjects
    dim=[n_select,data_x.shape[1],data_x.shape[2],data_x.shape[3]]
    data_x_sel=np.zeros(dim)
    data_y_sel=np.zeros(dim)
    data_phantom_sel = np.zeros(dim)
    # offset_im=0
    for ki, subject in enumerate(paramsDataSet.lst_subjects_reduced):
        for kr,real in enumerate(range(paramsDataSet.n_sim)):
            data_x_sel[kr+ki*paramsDataSet.n_sim]=data_x[kr+ki*paramsDataSet.doserecParams.n_sim]
            data_y_sel[kr+ki*paramsDataSet.n_sim]=data_y[kr+ki*paramsDataSet.doserecParams.n_sim]
            phantom_ref,phantom_hdr_ref=paramsDataSet.doserecParams.get_fname_im_phantom_red(subject,real)
            path_phantom_hdr=os.path.join(paramsDataSet.doserecParams.get_gen_dbase_dir(subject),phantom_hdr_ref)
            if os.path.exists(path_phantom_hdr):
                phantom_hdr=Interfile.load(path_phantom_hdr)
                phantom_hdr['name of data file']['value']=phantom_ref
                phantom,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(phantom_hdr,paramsDataSet.doserecParams.get_gen_dbase_dir(subject),verbose=verbose)
            else:
                raise FileNotFoundError(errno.ENOENT,os.strerror(errno.ENOENT),path_phantom_hdr)
            
            data_phantom_sel[kr+ki*paramsDataSet.n_sim]=phantom
       
                

    if paramsDataSet.truncate < data_x.shape[1]:
        t = data_x_sel.shape[1] - paramsDataSet.truncate
        
        data_x_sel = data_x_sel[:,t:,:,:]
        data_y_sel = data_y_sel[:,t:,:,:]
        data_phantom_sel = data_phantom_sel[:,t:,:,:]
        
    data_y_den=data_y_sel

   
    _, _, sum_x, sum_y, alpha, _, _, standardized_sum_x, _ = database_base.normalize_data(data_x_sel, data_y_den, alpha)
    sum_x = np.ones_like(sum_x)
    sum_y = np.ones_like(sum_y)


    doserec_object = paramsDataSet.doserecParams
    castor_object = paramsDataSet.doserecParams.CASToRParams
    list_sub = doserec_object.lst_subjects
    reconsParams = PETLibs.recons.GPUBiographReconsParams(lut_name="/share/Programs/castor/castor_git/config/scanner/PET_SIEMENS_BIOGRAPH6_TRUEPOINT_TRUEV.lut",
                                                vox_size=castor_object.vox_size,im_dim=castor_object.im_dim, 
                                                XYZ=False, nsubsets=1, fwhm_mm = 4, nbsigmas = 5)
    
    dim=castor_object.im_dim
    n1 = dim[0]
    n2 = dim[1]
    n3 = dim[2]
    data_y_out = np.zeros([n1,n2,n3])

    data_yEM = np.zeros([n1,n2,n3])

    data_ph_out = np.zeros([n1,n2,n3])

    if reduced_sim :
        n_sim = 1 
    else :
        n_sim = doserec_object.n_sim 
            

    reconsOps=GPURecons.GPUReconsOps(reconsParams)
    
    t = n1 - paramsDataSet.truncate
    list_rho = []
    list_dose = []

    with tqdm(total=len(list_sub)*n_sim, desc="Iterations FP", unit='Iteration(s)') as pbar:
        for index_sub, subject in enumerate(list_sub):
            for index_real, real in enumerate(range(n_sim)):
                castor_df_ima,castor_df_hdr=doserec_object.get_fname_sinogram_CASToR_hdr(subject,real)
                castor_df_dir=doserec_object.get_gen_castor_dir(subject,real)
                castor_df_hdr_fpath=os.path.join(castor_df_dir,castor_df_hdr)
                data_x_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(data_x_sel[index_real+index_sub*doserec_object.n_sim], dtype=torch.float32),0),0).to(device)
                data_y_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(data_y_den[index_real+index_sub*doserec_object.n_sim], dtype=torch.float32),0),0).to(device)
                data_ph_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(data_phantom_sel[index_real+index_sub*doserec_object.n_sim], dtype=torch.float32),0),0).to(device)





                data_y_out[t:,:,:]=torch.squeeze(data_y_device).detach().cpu().numpy() 
                data_ph_out[t:,:,:]=torch.squeeze(data_ph_device).detach().cpu().numpy() 

                
                data_yEM[t:,:,:]=torch.squeeze(data_x_device).detach().cpu().numpy()

                data_y_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(data_y_out[t:,:,:], dtype=torch.float32),0),0).to(device)
                mask_ph = data_ph_out > 0.0

                imrec_target=data_y_out*mask_ph 
                
                imrec_targetEM = data_yEM*mask_ph

                dict_sino=GPURecons.GPUCASToRSinos(castor_df_hdr_fpath, castor_df_dir,
                                                    reconsParams=reconsParams)
                
                y_data =  reconsParams.createSubsetData(dict_sino["val"])
                mult_array =  reconsParams.createSubsetData(dict_sino["mult"])
                add_array =  reconsParams.createSubsetData(dict_sino["add"])
                sinomask =  reconsParams.createSubsetData(dict_sino["mask"])
                sen=reconsOps.computeSensitivityImages(sinomask,mult_factor=mult_array) #No need for autograd here 
                
                P = 1.0 #P.squeeze().cpu().numpy()#*imrec_target
                xt= torch.reshape(torch.tensor(P*imrec_target,dtype=torch.float32, device = "cuda"),reconsParams.tb_im_dim)
                fwd=reconsOps.forwardProj(xt,mult_factor=mult_array[0],add_factor=add_array[0], subset=0)

                fwd_all_ones = reconsOps.forwardProj(torch.zeros_like(xt),mult_factor=mult_array[0],add_factor=(add_array[0]), subset=0)#0.001+
                fwd_all_ones = torch.where(fwd>0, fwd_all_ones, torch.tensor(0.0, dtype = torch.float32, device = "cuda"))

                ratio = torch.where(fwd>0,torch.divide(y_data[0],fwd),torch.tensor(1.0, dtype = torch.float32, device = "cuda")) #*sinomask

                bwd=reconsOps.backwardProj(ratio,mult_factor=mult_array[0],add_factor=0, subset=0)   

                grad_img = (sen[0]-bwd)            
                grad_img = grad_img.squeeze().cpu().numpy() 
                grad_img *= mask_ph
                
                del bwd
                del fwd

                
                
                #################################################################
                # invrho_opt = ((((imrec_targetEM - imrec_target)**2)*mask_ph).sum()/(((grad_img**2)*mask_ph).sum()))
                invrho_opt = ((((imrec_targetEM - imrec_target)**2)*mask_ph).sum()/(((grad_img**2)*mask_ph).sum()))
                print("invrho opt", '{:e}'.format(math.sqrt(invrho_opt)))
                list_rho.append(math.sqrt(invrho_opt))
                list_dose.append(y_data[0].sum().cpu().numpy())
                pbar.update(1)
            

 
    return list_rho, list_dose



def get_data2MRI(data_x, 
             data_y, 
             data_mri,
             paramsDataSet, 
             device="cuda", 
             verbose=True, 
             copy_all = False, 
             reduced_sim = False, 
             transform=None, 
             n_rho = 2, 
             bLowRho = False,
             bFixedRho = False,
             i_list_rho = [],
             bRandomRho = False,
             bLinear = False
             ): 

    '''
    Generates training and testing torch dataloaders using the numpy data. The target
    is potentially obtained as the output of a NN applied on data_y (e.g. for dose reduction).

    Arguments:
        - data_x: Input images (4D numpy array - [index_im,z,y,x]).
        - data_y: Target images (4D numpy array - [index_im,z,y,x]).
        - paramsDataSet: parameters for tensor dataset (tensorDataSetDoserecParams).
        - device: device used for Tensors ("cuda" or "cpu")
        - device_model: device used for models ("cuda" or "cpu")

    Returns:
        - dataset: TensorDataset wrapping input and target data. When norm_sj=True, add the list of total sum of data_x
                   and data_y for every 3D image and the normalization constant. If norm_sj=False and norm_train=True,
                   add the tensor array of patient number, realization number,normalization constant and init value for
                   the scaling constant (torch.utils.data.TensorDataset).
        - train_loader: Dataloader containing the training data (torch.utils.data.DataLoader)
        - test_loader: Dataloader containing the testing data (torch.utils.data.DataLoader).
        - sum_x: List of input image sum values (list of floats).
        - sum_y: List of target image sum values (list of floats).
        - alpha: Normalization constant used (list of normalization constants).

    Note:
        For large databases the loader should be in CPU, and tensor copied to gpu when used if needed.
    '''

    if not isinstance(paramsDataSet,tensorDataSetDoserecParams):
        raise TypeError("paramsDataSet type is not tensorDataSetDoserecParams ")

    alpha = paramsDataSet.alpha
    # data_mri_sel = data_mri
    max_sum = 0

    if copy_all:
        data_x_sel = data_x
        data_y_sel = data_y
        

    else :

        n_select=paramsDataSet.n_sim*paramsDataSet._n_subjects
        dim=[n_select,data_x.shape[1],data_x.shape[2],data_x.shape[3]]
        data_x_sel=np.zeros(dim)
        data_y_sel=np.zeros(dim)
        data_phantom_sel = np.zeros(dim)
        # offset_im=0
        for ki, subject in enumerate(paramsDataSet.lst_subjects_reduced):
            for kr,real in enumerate(range(paramsDataSet.n_sim)):
                data_x_sel[kr+ki*paramsDataSet.n_sim]=data_x[kr+ki*paramsDataSet.doserecParams.n_sim]
                data_y_sel[kr+ki*paramsDataSet.n_sim]=data_y[kr+ki*paramsDataSet.doserecParams.n_sim]
                phantom_ref,phantom_hdr_ref=paramsDataSet.doserecParams.get_fname_im_phantom_red(subject,real)
                path_phantom_hdr=os.path.join(paramsDataSet.doserecParams.get_gen_dbase_dir(subject),phantom_hdr_ref)
                if os.path.exists(path_phantom_hdr):
                    phantom_hdr=Interfile.load(path_phantom_hdr)
                    phantom_hdr['name of data file']['value']=phantom_ref
                    phantom,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(phantom_hdr,paramsDataSet.doserecParams.get_gen_dbase_dir(subject),verbose=verbose)
                else:
                    raise FileNotFoundError(errno.ENOENT,os.strerror(errno.ENOENT),path_phantom_hdr)
                
                data_phantom_sel[kr+ki*paramsDataSet.n_sim]=phantom
                tmp_sumx = np.sum(data_x_sel[kr+ki*paramsDataSet.n_sim])
                max_sum = max(max_sum, tmp_sumx)
                


    if paramsDataSet.truncate < data_x.shape[1]:
        t = data_x_sel.shape[1] - paramsDataSet.truncate
        
        data_x_sel = data_x_sel[:,t:,:,:]
        data_y_sel = data_y_sel[:,t:,:,:]
        # data_mri_sel = data_mri_sel[:,t:,:,:]
        data_phantom_sel = data_phantom_sel[:,t:,:,:]
        
    data_y_den=data_y_sel

   
    _, _, sum_x, sum_y, alpha, _, _, standardized_sum_x, _ = database_base.normalize_data(data_x_sel, data_y_den, alpha)
    sum_x = np.ones_like(sum_x)
    sum_y = np.ones_like(sum_y)

    if  (paramsDataSet.augmentation_FP):

        doserec_object = paramsDataSet.doserecParams
        castor_object = paramsDataSet.doserecParams.CASToRParams
        list_sub = doserec_object.lst_subjects
        reconsParams = PETLibs.recons.GPUBiographReconsParams(lut_name="/share/Programs/castor/castor_git/config/scanner/PET_SIEMENS_BIOGRAPH6_TRUEPOINT_TRUEV.lut",
                                                    vox_size=castor_object.vox_size,im_dim=castor_object.im_dim, 
                                                    XYZ=False, nsubsets=1, fwhm_mm = 4, nbsigmas = 5)
        
        dim=castor_object.im_dim
        n1 = dim[0]
        n2 = dim[1]
        n3 = dim[2]
        data_y_out = np.zeros([n1,n2,n3])

        data_yEM = np.zeros([n1,n2,n3])
        data_ph_out = np.zeros([n1,n2,n3])

        if reduced_sim :
            n_sim = 1 
        else :
            n_sim = doserec_object.n_sim 
                
        FP_data_x = np.empty([n_sim*n_rho*len(list_sub),n1,n2,n3])
        FP_data_y = np.empty([n_sim*n_rho*len(list_sub),n1,n2,n3])
        FP_data_u = np.empty([n_sim*n_rho*len(list_sub),n1,n2,n3])
        FP_data_p = np.empty([n_sim*n_rho*len(list_sub),n1,n2,n3])
        FP_data_EM = np.empty([n_sim*n_rho*len(list_sub),n1,n2,n3])
        FP_data_mri = np.empty([n_sim*n_rho*len(list_sub),n1,n2,n3])
        FP_data_rho = np.empty([n_sim*n_rho*len(list_sub),1])
        vec_dose = np.empty([n_sim*n_rho*len(list_sub),1])

  

        reconsOps=GPURecons.GPUReconsOps(reconsParams)
        i = 0
        t = n1 - paramsDataSet.truncate
        list_rho = []

        # normalization_target_rho = database_base.get_sum_img(data_y_den)
        with tqdm(total=len(list_sub)*n_sim, desc="Iterations FP", unit='Iteration(s)') as pbar:
            for index_sub, subject in enumerate(list_sub):
                for index_real, real in enumerate(range(n_sim)):
                    # print("Subject nb",index_sub, "out of", len(list_sub), "Realization: ",real)
                    castor_df_ima,castor_df_hdr=doserec_object.get_fname_sinogram_CASToR_hdr(subject,real)
                    castor_df_dir=doserec_object.get_gen_castor_dir(subject,real)
                    castor_df_hdr_fpath=os.path.join(castor_df_dir,castor_df_hdr)
                    data_x_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(data_x_sel[index_real+index_sub*doserec_object.n_sim], dtype=torch.float32),0),0).to(device)
                    data_y_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(data_y_den[index_real+index_sub*doserec_object.n_sim], dtype=torch.float32),0),0).to(device)
                    # normalization_y = normalization_target_rho[index_real+index_sub*doserec_object.n_sim]
                    data_ph_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(data_phantom_sel[index_real+index_sub*doserec_object.n_sim], dtype=torch.float32),0),0).to(device)


                    data_y_out[t:,:,:]=torch.squeeze(data_y_device).detach().cpu().numpy() 
                    data_ph_out[t:,:,:]=torch.squeeze(data_ph_device).detach().cpu().numpy() 
                    data_yEM[t:,:,:]=torch.squeeze(data_x_device).detach().cpu().numpy()

                    data_y_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(data_y_out[t:,:,:], dtype=torch.float32),0),0).to(device)
                    mask_ph = data_ph_out > 0.0

                    imrec_target=data_y_out*mask_ph 
                    
                    
                    #if paramsDataSet.augmentation_FP_EM :
                    imrec_targetEM = data_yEM*mask_ph

                    dict_sino=GPURecons.GPUCASToRSinos(castor_df_hdr_fpath, castor_df_dir,
                                                        reconsParams=reconsParams)
                    
                    y_data =  reconsParams.createSubsetData(dict_sino["val"])
                    mult_array =  reconsParams.createSubsetData(dict_sino["mult"])
                    add_array =  reconsParams.createSubsetData(dict_sino["add"])
                    sinomask =  reconsParams.createSubsetData(dict_sino["mask"])
                    sen=reconsOps.computeSensitivityImages(sinomask,mult_factor=mult_array) #No need for autograd here 
                    
                    P = 1.0 #P.squeeze().cpu().numpy()#*imrec_target
                    xt= torch.reshape(torch.tensor(P*imrec_target,dtype=torch.float32, device = "cuda"),reconsParams.tb_im_dim)
                    xEM = torch.reshape(torch.tensor(imrec_targetEM,dtype=torch.float32, device = "cuda"),reconsParams.tb_im_dim)
                    fwd=reconsOps.forwardProj(xt,mult_factor=mult_array[0],add_factor=add_array[0], subset=0)

                    fwd_all_ones = reconsOps.forwardProj(torch.zeros_like(xt),mult_factor=mult_array[0],add_factor=(add_array[0]), subset=0)#0.001+
                    fwd_all_ones = torch.where(fwd>0, fwd_all_ones, torch.tensor(0.0, dtype = torch.float32, device = "cuda"))
      
                    ratio = torch.where(fwd>0,torch.divide(y_data[0],fwd),torch.tensor(1.0, dtype = torch.float32, device = "cuda")) #*sinomask
                    bwd=reconsOps.backwardProj(ratio,mult_factor=mult_array[0],add_factor=0, subset=0)
                    xEM = torch.max(xEM, torch.tensor(0.0, dtype = torch.float32, device = "cuda"))

                    grad_img = (sen[0]-bwd)
                    
                                 
                    grad_img = grad_img.squeeze().cpu().numpy() 
                    grad_img *= mask_ph
                    
                    del bwd
                    del fwd

                    


                    #################################################################
                    # 0.3
                    invrho_opt = (((imrec_target**2)*mask_ph).sum()/(((grad_img**2)*mask_ph).sum()))
                    # print("invrho opt", '{:e}'.format(math.sqrt(invrho_opt)))
                    list_rho.append(math.sqrt(invrho_opt))

                    grad_img_copy = grad_img 
                 
                    for invrho in range(n_rho):

                        FP_data_x[i]=np.transpose(np.expand_dims(grad_img_copy[:,:,:],axis=3),(3,0,1,2))
                        FP_data_y[i]=np.transpose(np.expand_dims(imrec_target[:,:,:],axis=3),(3,0,1,2))
                        FP_data_u[i]=np.transpose(np.expand_dims(data_ph_out[:,:,:],axis=3),(3,0,1,2))
                        # FP_data_p[i]=np.transpose(np.expand_dims(precond[:,:,:],axis=3),(3,0,1,2))
                        FP_data_EM[i]=np.transpose(np.expand_dims(imrec_targetEM[:,:,:],axis=3),(3,0,1,2)) 
                        FP_data_rho[i] = -1.0
                        vec_dose[i] = y_data[0].sum().cpu().numpy()
                        FP_data_mri[i] = data_mri[index_real+index_sub*doserec_object.n_sim]

                        i = i+1    
                    
                    
                    

                    pbar.update(1)

                
        min_rho = np.min(list_rho)
        max_rho = np.max(list_rho)
        i=0
        print("max invrho opt", '{:e}'.format(max_rho))
        print("min invrho opt", '{:e}'.format(min_rho))
        print("min ratio", '{:e}'.format(min_rho/max_rho))
        # random.seed(seed)
        if bLowRho :
            print("Low rho")
            for index_sub, subject in enumerate(list_sub):
                for index_real, real in enumerate(range(n_sim)):
                    for _ in range(n_rho-1):
                        invrho = min_rho + (max_rho-min_rho)*random.random()
                        FP_data_x[i]=FP_data_y[i] - invrho*FP_data_x[i]
                        FP_data_rho[i] = invrho/max_rho
                        i = i+1  
                    invrho = 0.0001*min_rho + (0.001*max_rho-0.0001*min_rho)*random.random()
                    FP_data_x[i]=FP_data_y[i] - invrho*FP_data_x[i]
                    FP_data_rho[i] = min_rho/max_rho
                    i = i+1  
        elif bFixedRho :
            max_rho = np.max(i_list_rho)
            for index_sub, subject in enumerate(list_sub):
                for index_real, real in enumerate(range(n_sim)):
                    for invrho in i_list_rho:
                        FP_data_x[i]=FP_data_y[i] - invrho*FP_data_x[i]
                        FP_data_rho[i] = invrho/max_rho
                        i = i+1  


        elif bRandomRho :
            for index_sub, subject in enumerate(list_sub):
                for index_real, real in enumerate(range(n_sim)):
                    for _ in i_list_rho:
                        
                        #invrho = np.random.normal(1, 0.99/3)*1e6
                        invrho = np.random.uniform(low=1e4, high= 1e6)

                        FP_data_x[i]=FP_data_y[i] - invrho*FP_data_x[i]
                        FP_data_rho[i] = invrho/1e6
                        i = i+1
                    
                    
                    
        
                 

        FP_data_x = FP_data_x[:,t:,:,:]
        FP_data_y = FP_data_y[:,t:,:,:]
        FP_data_u = FP_data_u[:,t:,:,:]
        FP_data_p = FP_data_p[:,t:,:,:]
        FP_data_EM = FP_data_EM[:,t:,:,:]
        FP_data_mri = FP_data_mri[:,t:,:,:]

        _, _, FP_sum_x, _, alpha, _, _, FP_standardized_sum_x, _ = database_base.normalize_data(FP_data_x, FP_data_y, alpha)
        norm_vec_dose = vec_dose/vec_dose.max()
        # datasetAugFP_tf = CustomTensorDataset(tensors= (torch.tensor(FP_data_x,dtype=torch.float32), torch.tensor(FP_data_y,dtype=torch.float32),
        #                              torch.tensor(FP_data_EM,dtype=torch.float32), torch.tensor(FP_data_u,dtype=torch.float32),
        #                          torch.tensor(FP_data_rho,dtype=torch.float32), torch.tensor(norm_vec_dose,dtype=torch.float32),
        #                            torch.tensor(FP_data_p,dtype=torch.float32)), transform=transform)
        
        datasetAugFP = CustomTensorDataset(tensors= (torch.tensor(FP_data_x,dtype=torch.float32), torch.tensor(FP_data_y,dtype=torch.float32),
                                        torch.tensor(FP_data_EM,dtype=torch.float32), torch.tensor(FP_data_u,dtype=torch.float32),
                                    torch.tensor(FP_data_rho,dtype=torch.float32), torch.tensor(norm_vec_dose,dtype=torch.float32),
                                    torch.tensor(FP_data_mri,dtype=torch.float32)), bLinear=bLinear)
        if paramsDataSet.augmentation_FP_EM:
            datasetAugFP_EM = CustomTensorDataset(tensors= (torch.tensor(FP_data_EM,dtype=torch.float32), torch.tensor(FP_data_y,dtype=torch.float32),
                                        torch.tensor(FP_data_EM,dtype=torch.float32), torch.tensor(FP_data_u,dtype=torch.float32),
                                    torch.ones(FP_data_rho.shape,dtype=torch.float32), torch.tensor(norm_vec_dose,dtype=torch.float32),
                                    torch.tensor(FP_data_mri,dtype=torch.float32)), bLinear=bLinear)


                            
        
   
    
    test_size=int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*paramsDataSet.n_sim    
    indices = list(range(paramsDataSet.n_subjects*paramsDataSet.n_sim))
    train_indices, val_indices = indices[test_size:], indices[:test_size]
    # Create Subset for training and validation
    # train_data = Subset(dataset_tf, train_indices)
    # test_data  = Subset(dataset, val_indices)

      
    if paramsDataSet.augmentation_FP :
        print("augmentation FP")
        test_size_aug_FP=int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*n_sim*n_rho
        indices = list(range(paramsDataSet.n_subjects*n_sim*n_rho))
        train_indices, val_indices = indices[test_size_aug_FP:], indices[:test_size_aug_FP]
        # Create Subset for training and validation
        train_data_aug_FP = Subset(datasetAugFP, train_indices)
        test_data_aug_FP = Subset(datasetAugFP, val_indices)

        print("size test FP", int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*n_sim*n_rho)
        train_data = train_data_aug_FP
        test_data = test_data_aug_FP


    if paramsDataSet.augmentation_FP_EM:
        print("augmentation FP EM")
        test_size_aug_FP=int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*n_sim
        indices = list(range(paramsDataSet.n_subjects*n_sim))
        train_indices, val_indices = indices[test_size_aug_FP:], indices[:test_size_aug_FP]
        # Create Subset for training and validation
        train_data_aug_FP = Subset(datasetAugFP_EM, train_indices)
        test_data_aug_FP = Subset(datasetAugFP_EM, val_indices)        
        train_data = torch.utils.data.ConcatDataset([train_data, train_data_aug_FP]) 
        test_data = torch.utils.data.ConcatDataset([test_data, test_data_aug_FP])


    
 
    return train_data, test_data

def get_data1mu(data_x, 
             data_y, 
             paramsDataSet, 
             device="cuda", 
             verbose=True, 
             img_FNE= 0, 
             copy_all = False, 
             use_only_FP = False, 
             reduced_sim = False, 
             FP_from_FB = False, 
             transform=None, 
             i_mu = 1e6, 
             bOptim_mu = False, 
             type_precond = "Id",
             weighted_KL = False, 
             b_aug_precond = False
             ): 

    '''
    Generates training and testing torch dataloaders using the numpy data. The target
    is potentially obtained as the output of a NN applied on data_y (e.g. for dose reduction).

    Arguments:
        - data_x: Input images (4D numpy array - [index_im,z,y,x]).
        - data_y: Target images (4D numpy array - [index_im,z,y,x]).
        - paramsDataSet: parameters for tensor dataset (tensorDataSetDoserecParams).
        - device: device used for Tensors ("cuda" or "cpu")
        - device_model: device used for models ("cuda" or "cpu")

    Returns:
        - dataset: TensorDataset wrapping input and target data. When norm_sj=True, add the list of total sum of data_x
                   and data_y for every 3D image and the normalization constant. If norm_sj=False and norm_train=True,
                   add the tensor array of patient number, realization number,normalization constant and init value for
                   the scaling constant (torch.utils.data.TensorDataset).
        - train_loader: Dataloader containing the training data (torch.utils.data.DataLoader)
        - test_loader: Dataloader containing the testing data (torch.utils.data.DataLoader).
        - sum_x: List of input image sum values (list of floats).
        - sum_y: List of target image sum values (list of floats).
        - alpha: Normalization constant used (list of normalization constants).

    Note:
        For large databases the loader should be in CPU, and tensor copied to gpu when used if needed.
    '''

    if not isinstance(paramsDataSet,tensorDataSetDoserecParams):
        raise TypeError("paramsDataSet type is not tensorDataSetDoserecParams ")

    alpha = paramsDataSet.alpha

    max_sum = 0

    if copy_all:
        data_x_sel = data_x
        data_y_sel = data_y
        

    else :

        n_select=paramsDataSet.n_sim*paramsDataSet._n_subjects
        dim=[n_select,data_x.shape[1],data_x.shape[2],data_x.shape[3]]
        data_x_sel=np.zeros(dim)
        data_y_sel=np.zeros(dim)
        data_phantom_sel = np.zeros(dim)
        # offset_im=0
        for ki, subject in enumerate(paramsDataSet.lst_subjects_reduced):
            for kr,real in enumerate(range(paramsDataSet.n_sim)):
                data_x_sel[kr+ki*paramsDataSet.n_sim]=data_x[kr+ki*paramsDataSet.doserecParams.n_sim]
                data_y_sel[kr+ki*paramsDataSet.n_sim]=data_y[kr+ki*paramsDataSet.doserecParams.n_sim]
                phantom_ref,phantom_hdr_ref=paramsDataSet.doserecParams.get_fname_im_phantom_red(subject,real)
                path_phantom_hdr=os.path.join(paramsDataSet.doserecParams.get_gen_dbase_dir(subject),phantom_hdr_ref)
                if os.path.exists(path_phantom_hdr):
                    phantom_hdr=Interfile.load(path_phantom_hdr)
                    phantom_hdr['name of data file']['value']=phantom_ref
                    phantom,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(phantom_hdr,paramsDataSet.doserecParams.get_gen_dbase_dir(subject),verbose=verbose)
                else:
                    raise FileNotFoundError(errno.ENOENT,os.strerror(errno.ENOENT),path_phantom_hdr)
                
                data_phantom_sel[kr+ki*paramsDataSet.n_sim]=phantom
                tmp_sumx = np.sum(data_x_sel[kr+ki*paramsDataSet.n_sim])
                max_sum = max(max_sum, tmp_sumx)
                


    if paramsDataSet.truncate < data_x.shape[1]:
        t = data_x_sel.shape[1] - paramsDataSet.truncate
        
        data_x_sel = data_x_sel[:,t:,:,:]
        data_y_sel = data_y_sel[:,t:,:,:]
        data_phantom_sel = data_phantom_sel[:,t:,:,:]
        
    data_y_den=data_y_sel

   
    _, _, sum_x, sum_y, alpha, _, _, standardized_sum_x, _ = database_base.normalize_data(data_x_sel, data_y_den, alpha)
    sum_x = np.ones_like(sum_x)
    sum_y = np.ones_like(sum_y)

            

    # dataset = CustomTensorDataset(tensors =(torch.tensor(data_x_sel, dtype=torch.float32), torch.tensor(data_y_den, dtype=torch.float32), 
    #                         torch.tensor(sum_x,dtype=torch.float32), torch.tensor(data_phantom_sel, dtype=torch.float32),
    #                         alpha*torch.ones(data_x_sel.shape[0]), torch.tensor(standardized_sum_x, dtype=torch.float32), 
    #                         torch.tensor(data_phantom_sel, dtype=torch.float32)))   
    # dataset_tf = CustomTensorDataset(tensors =(torch.tensor(data_x_sel, dtype=torch.float32), torch.tensor(data_y_den, dtype=torch.float32), 
    #                         torch.tensor(sum_x,dtype=torch.float32), torch.tensor(data_phantom_sel, dtype=torch.float32),
    #                         alpha*torch.ones(data_x_sel.shape[0]), torch.tensor(standardized_sum_x, dtype=torch.float32), 
    #                         torch.tensor(data_phantom_sel, dtype=torch.float32)), transform=transform)                                
    
            

   
    if paramsDataSet.gaussian_denoising:
        doserec_object = paramsDataSet.doserecParams
        castor_object = paramsDataSet.doserecParams.CASToRParams
        list_sub = doserec_object.lst_subjects
        dim=castor_object.im_dim
        n1 = dim[0]
        n2 = dim[1]
        n3 = dim[2]
        t = n1 - paramsDataSet.truncate
        nb_noise_levels = 1
        MMSE_input=np.empty([doserec_object.n_sim*nb_noise_levels*len(list_sub),paramsDataSet.truncate,n2,n3]) 
        MMSE_target=np.empty([doserec_object.n_sim*nb_noise_levels*len(list_sub),paramsDataSet.truncate,n2,n3])
        MMSE_phantom=np.empty([doserec_object.n_sim*nb_noise_levels*len(list_sub),paramsDataSet.truncate,n2,n3]) 
        i_MMSE = 0  
        with tqdm(total=data_x.shape[0], desc="Iterations Gaussian noise", unit='Iteration(s)') as pbar:
  
            for i in range(data_x.shape[0]):
                noise_level = 400*random.random()
                mask = np.where(data_phantom_sel[i] > 0,1.0,0)
                noise = np.random.normal(0, noise_level, data_y_sel[i].shape)
                MMSE_input[i_MMSE]=(data_y_sel[i]+noise)*mask 
                MMSE_target[i_MMSE]=data_y_sel[i]*mask
                MMSE_phantom[i_MMSE]=data_phantom_sel[i]
                i_MMSE += 1
                pbar.update(1)



    if  (paramsDataSet.augmentation_FP):

        doserec_object = paramsDataSet.doserecParams
        castor_object = paramsDataSet.doserecParams.CASToRParams
        list_sub = doserec_object.lst_subjects
        reconsParams = PETLibs.recons.GPUBiographReconsParams(lut_name="/share/Programs/castor/castor_git/config/scanner/PET_SIEMENS_BIOGRAPH6_TRUEPOINT_TRUEV.lut",
                                                    vox_size=castor_object.vox_size,im_dim=castor_object.im_dim, 
                                                    XYZ=False, nsubsets=1, fwhm_mm = 4, nbsigmas = 5)

        dim=castor_object.im_dim
        n1 = dim[0]
        n2 = dim[1]
        n3 = dim[2]
        data_y_out = np.zeros([n1,n2,n3])

        #if paramsDataSet.augmentation_FP_EM :
        data_yEM = np.zeros([n1,n2,n3])

        data_ph_out = np.zeros([n1,n2,n3])

        if reduced_sim :
            n_sim = 1 
        else :
            n_sim = doserec_object.n_sim 
        

#
        if type_precond != "Id" and b_aug_precond :
            n_rho = 2
        else :
            n_rho = 1
        
        FP_data_x = np.empty([n_sim*n_rho*len(list_sub),n1,n2,n3])
        FP_data_y = np.empty([n_sim*n_rho*len(list_sub),n1,n2,n3])
        FP_data_u = np.empty([n_sim*n_rho*len(list_sub),n1,n2,n3])
        FP_data_p = np.empty([n_sim*n_rho*len(list_sub),n1,n2,n3])
        FP_data_EM = np.empty([n_sim*n_rho*len(list_sub),n1,n2,n3])
        FP_data_rho = np.empty([n_sim*n_rho*len(list_sub),1])
        vec_dose = np.empty([n_sim*n_rho*len(list_sub),1])


        if paramsDataSet.augmentation_FP_EM :
            
            list_rho_EM = [0] #, 1e6]
            n_rho_EM = len(list_rho_EM)
            FP_data_yEM = np.empty([n_sim*n_rho_EM*len(list_sub),n1,n2,n3])
            FP_data_xEM = np.empty([n_sim*n_rho_EM*len(list_sub),n1,n2,n3])
            FP_data_uEM = np.empty([n_sim*n_rho_EM*len(list_sub),n1,n2,n3])
            FP_data_rhoEM = np.empty([n_sim*n_rho_EM*len(list_sub),1])

  

        reconsOps=GPURecons.GPUReconsOps(reconsParams)
        i = 0
        i_EM = 0
        t = n1 - paramsDataSet.truncate
        list_rho = []

        # normalization_target_rho = database_base.get_sum_img(data_y_den)
        with tqdm(total=len(list_sub)*n_sim, desc="Iterations FP", unit='Iteration(s)') as pbar:
            for index_sub, subject in enumerate(list_sub):
                for index_real, real in enumerate(range(n_sim)):
                    # print("Subject nb",index_sub, "out of", len(list_sub), "Realization: ",real)
                    castor_df_ima,castor_df_hdr=doserec_object.get_fname_sinogram_CASToR_hdr(subject,real)
                    castor_df_dir=doserec_object.get_gen_castor_dir(subject,real)
                    castor_df_hdr_fpath=os.path.join(castor_df_dir,castor_df_hdr)
                    data_x_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(data_x_sel[index_real+index_sub*doserec_object.n_sim], dtype=torch.float32),0),0).to(device)
                    data_y_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(data_y_den[index_real+index_sub*doserec_object.n_sim], dtype=torch.float32),0),0).to(device)
                    # normalization_y = normalization_target_rho[index_real+index_sub*doserec_object.n_sim]
                    data_ph_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(data_phantom_sel[index_real+index_sub*doserec_object.n_sim], dtype=torch.float32),0),0).to(device)



                    # sigma = torch.where(data_ph_device > 0, torch.tensor(1.0, dtype=torch.float32, device = "cuda"), torch.tensor(0.0, dtype=torch.float32, device = "cuda"))


                    data_y_out[t:,:,:]=torch.squeeze(data_y_device).detach().cpu().numpy() 
                    data_ph_out[t:,:,:]=torch.squeeze(data_ph_device).detach().cpu().numpy() 


                    #if paramsDataSet.augmentation_FP_EM :
                    data_yEM[t:,:,:]=torch.squeeze(data_x_device).detach().cpu().numpy()

                    data_y_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(data_y_out[t:,:,:], dtype=torch.float32),0),0).to(device)
                    mask_ph = data_ph_out > 0.0

                    imrec_target=data_y_out*mask_ph 
                    
                    
                    #if paramsDataSet.augmentation_FP_EM :
                    imrec_targetEM = data_yEM*mask_ph

                    dict_sino=GPURecons.GPUCASToRSinos(castor_df_hdr_fpath, castor_df_dir,
                                                        reconsParams=reconsParams)
                    
                    y_data =  reconsParams.createSubsetData(dict_sino["val"])
                    
                    mult_array =  reconsParams.createSubsetData(dict_sino["mult"])
                    add_array =  reconsParams.createSubsetData(dict_sino["add"])
                    sinomask =  reconsParams.createSubsetData(dict_sino["mask"])
                    sen=reconsOps.computeSensitivityImages(sinomask,mult_factor=mult_array) #No need for autograd here 
                    # P = 1.0/torch.add(sen[0], 0) # imrec_target/imrec_target.mean()
                    # P /= P.max()
                    # P = 0.5 + P

                    # P = 1.0/torch.add(sen[0], 0) # imrec_target/imrec_target.mean()
                    # P /= P.max()
                    # P = 1.0+ P.clamp(max= 0.5)

                    P = 1.0 #P.squeeze().cpu().numpy()#*imrec_target
                    xt= torch.reshape(torch.tensor(P*imrec_target,dtype=torch.float32, device = "cuda"),reconsParams.tb_im_dim)
                    xEM = torch.reshape(torch.tensor(imrec_targetEM,dtype=torch.float32, device = "cuda"),reconsParams.tb_im_dim)
                    fwd=reconsOps.forwardProj(xt,mult_factor=mult_array[0],add_factor=add_array[0], subset=0)



                    # bwd= BiographReconsOps.backwardProj(fwd-y_data[0],mult_factor=mult_array[0],add_factor=0, subset=0)

                    # fwd_all_ones = BiographReconsOps.forwardProj(torch.ones_like(xt),mult_factor=mult_array[0],add_factor=add_array[0], subset=0) torch.ones_like(mult_array[0])
                    fwd_all_ones = reconsOps.forwardProj(torch.zeros_like(xt),mult_factor=mult_array[0],add_factor=(add_array[0]), subset=0)#0.001+
                    fwd_all_ones = torch.where(fwd>0, fwd_all_ones, torch.tensor(0.0, dtype = torch.float32, device = "cuda"))
                    bwd_all_ones = reconsOps.backwardProj(fwd_all_ones,mult_factor=mult_array[0],add_factor=0, subset=0)
                    # P  = bwd_all_ones.squeeze().cpu().numpy()
                    # xt= torch.reshape(torch.tensor(P*imrec_target,dtype=torch.float32, device = "cuda"),BiographParams.tb_im_dim)
                    # fwd=BiographReconsOps.forwardProj(xt,mult_factor=mult_array[0],add_factor=add_array[0], subset=0)

                    ratio = torch.where(fwd>0,torch.divide(y_data[0],fwd),torch.tensor(1.0, dtype = torch.float32, device = "cuda")) #*sinomask

                    # del fwd
                    if weighted_KL :
                        bwd=reconsOps.backwardProj(fwd_all_ones*ratio,mult_factor=mult_array[0],add_factor=0, subset=0)
                    else :
                        bwd=reconsOps.backwardProj(ratio,mult_factor=mult_array[0],add_factor=0, subset=0)

                    
                     
                    xEM = torch.max(xEM, torch.tensor(0.0, dtype = torch.float32, device = "cuda"))

                    if weighted_KL :
                        grad_img = (bwd_all_ones-bwd)
                    else :
                        grad_img = (sen[0]-bwd)
                    
                    if type_precond == "EM" :
                        grad_img *= (1e-6+xEM/torch.add(sen[0], 0))  
                    elif type_precond == "sen" :
                        # grad_img *= (torch.where(xt>0, bwd_all_ones/torch.add(sen[0], 0), 1.0))
                        grad_img *= (torch.where(xt>0, 1.0/(torch.add(sen[0], 0)), 0.0001*1.0))
                    
                    grad_img = grad_img.squeeze().cpu().numpy() 
                    grad_img *= mask_ph
                    
                    del bwd
                    del fwd

                    
                    if paramsDataSet.augmentation_FP_EM :
                        xt_EM= torch.reshape(torch.tensor(imrec_targetEM,dtype=torch.float32, device = "cuda"),reconsParams.tb_im_dim)
                        fwd=reconsOps.forwardProj(xt_EM,mult_factor=mult_array[0],add_factor=add_array[0], subset=0)
                        ratio = torch.where(fwd>0,torch.divide(y_data[0],fwd),torch.tensor(1.0, dtype = torch.float32, device = "cuda")) #*sinomask
                        del fwd
                        bwd=reconsOps.backwardProj(ratio,mult_factor=mult_array[0],add_factor=0, subset=0)
                        grad_img_EM = sen[0]-bwd
                        grad_img_EM = grad_img_EM.squeeze().cpu().numpy()
                        del bwd


                    
                    


                    #################################################################
                    #0.3
                    invrho_opt =(((imrec_target**2)*mask_ph).sum()/(((grad_img**2)*mask_ph).sum()))
                    list_rho.append(math.sqrt(invrho_opt))
                    grad_img_copy = grad_img 
                    # grad_img_copy *= mask_ph
                    # grad_img_copy *= imrec_targetEM
                    if type_precond == "EM" :
                        precond = (1e-6+xEM/torch.add(sen[0], 0))
                        precond /= 0.1*precond.max()
                        precond = precond.sqrt().squeeze().cpu().numpy() 
                    elif type_precond == "sen" :
                        precond = (torch.where(xt>0, 1.0/(torch.add(sen[0], 0)), 0.0001*1.0))
                        precond /= 0.1*precond.max()
                        precond = precond.sqrt().squeeze().cpu().numpy() 
                    else :
                        # precond = torch.ones_like(xEM).squeeze().cpu().numpy()

                        precond = (torch.where(xt>0, 1.0/(torch.add(sen[0], 0)), 0.0001*1.0))
                        precond /= 0.1*precond.max()
                        precond = precond.sqrt().squeeze().cpu().numpy() 
                    
                    for invrho in range(n_rho):

                        FP_data_x[i]=np.transpose(np.expand_dims(grad_img_copy[:,:,:],axis=3),(3,0,1,2))
                        FP_data_y[i]=np.transpose(np.expand_dims(imrec_target[:,:,:],axis=3),(3,0,1,2))
                        FP_data_u[i]=np.transpose(np.expand_dims(data_ph_out[:,:,:],axis=3),(3,0,1,2))
                        FP_data_p[i]=np.transpose(np.expand_dims(precond[:,:,:],axis=3),(3,0,1,2))
                        FP_data_EM[i]=np.transpose(np.expand_dims(imrec_targetEM[:,:,:],axis=3),(3,0,1,2)) 
                        FP_data_rho[i] = -1.0
                        vec_dose[i] = y_data[0].sum().cpu().numpy()

                        i = i+1   
                    
                    
                    if paramsDataSet.augmentation_FP_EM:
                        for invrho in list_rho_EM:           
                        
                            grad_img_copy = imrec_targetEM #-invrho*normalization_y*grad_img_EM
                            grad_img_copy *= mask_ph
                            FP_data_xEM[i_EM]=np.transpose(np.expand_dims(grad_img_copy[:,:,:],axis=3),(3,0,1,2))
                            FP_data_yEM[i_EM]=np.transpose(np.expand_dims(imrec_target[:,:,:],axis=3),(3,0,1,2))
                            FP_data_uEM[i_EM]=np.transpose(np.expand_dims(data_ph_out[:,:,:],axis=3),(3,0,1,2))
                            FP_data_rhoEM[i_EM] = 1.0 # -1.0 + 2*(invrho*normalization_y/1e6)
                        
                            i_EM = i_EM+1

                    pbar.update(1)


    ## second round
        i=0
        i_rho=0
        
        invrho = i_mu
        rho_max = np.max(list_rho)
        rho_min = np.min(list_rho)
        print("min rho", '{:e}'.format(rho_min))
        print("max rho", '{:e}'.format(rho_max))
        for index_sub, subject in enumerate(list_sub):
            for index_real, real in enumerate(range(n_sim)):
                if bOptim_mu : #0.3
                    if weighted_KL :
                        invrho =0.3*list_rho[i_rho] #10 = bcp avant 2
                    else :
                        invrho =list_rho[i_rho] #10 = bcp avant 2
                else :
                    invrho = i_mu

                
                FP_data_x[i] = (FP_data_y[i]-invrho*FP_data_x[i])
                if type_precond != "Id" and b_aug_precond :
                    FP_data_x[i+1] = (FP_data_y[i+1]-invrho*FP_data_x[i+1])/FP_data_p[i+1]
                    # tmp = FP_data_y[i]-FP_data_x[i]   

                    FP_data_y[i+1] = FP_data_y[i+1]/FP_data_p[i+1]
                    FP_data_rho[i+1] = invrho/rho_max

                # FP_data_p[i] = tmp

                FP_data_rho[i] = invrho/rho_max # (invrho - rho_min)/(rho_min - rho_max)
                if paramsDataSet.augmentation_FP_EM:
                    FP_data_rhoEM[i] = 1.0
                i = i+1
                if type_precond != "Id" and b_aug_precond:
                    i = i+1
                i_rho = i_rho+1
                
                  

        FP_data_x = FP_data_x[:,t:,:,:]
        FP_data_y = FP_data_y[:,t:,:,:]
        FP_data_u = FP_data_u[:,t:,:,:]
        FP_data_p = FP_data_p[:,t:,:,:]
        FP_data_EM = FP_data_EM[:,t:,:,:]

        FNE_cte = []

        for i in range(FP_data_rho.shape[0]):
            # print("img nb", i, "rho", FP_data_rho[i])
            list_FNE_ratio = database_base.FNE_constants_ph(FP_data_x, FP_data_y, i)
            for cte in list_FNE_ratio:
                FNE_cte.append(cte)
        print("final mean FNE", np.mean(FNE_cte))
        print("final max FNE", np.max(FNE_cte))
        print("final min FNE", np.min(FNE_cte))
   

        _, _, FP_sum_x, _, alpha, _, _, FP_standardized_sum_x, _ = database_base.normalize_data(FP_data_x, FP_data_y, alpha)
        #FP_standardized_sum_x

        norm_vec_dose = vec_dose/vec_dose.max()
        datasetAugFP_tf = CustomTensorDataset(tensors= (torch.tensor(FP_data_x,dtype=torch.float32), torch.tensor(FP_data_y,dtype=torch.float32),
                                     torch.tensor(FP_data_EM,dtype=torch.float32), torch.tensor(FP_data_u,dtype=torch.float32),
                                 torch.tensor(FP_data_rho,dtype=torch.float32), torch.tensor(norm_vec_dose,dtype=torch.float32),
                                   torch.tensor(FP_data_p,dtype=torch.float32)), transform=transform)
        
        datasetAugFP = CustomTensorDataset(tensors= (torch.tensor(FP_data_x,dtype=torch.float32), torch.tensor(FP_data_y,dtype=torch.float32),
                                        torch.tensor(FP_data_EM,dtype=torch.float32), torch.tensor(FP_data_u,dtype=torch.float32),
                                    torch.tensor(FP_data_rho,dtype=torch.float32), torch.tensor(norm_vec_dose,dtype=torch.float32),
                                    torch.tensor(FP_data_p,dtype=torch.float32)))
                            
                    
        if paramsDataSet.augmentation_FP_EM:
            FP_data_xEM = FP_data_xEM[:,t:,:,:]
            FP_data_yEM = FP_data_yEM[:,t:,:,:]
            FP_data_uEM = FP_data_uEM[:,t:,:,:]
            print("augmentation_FP_EM with max rho", np.max(FP_data_rhoEM), " and min rho", np.min(FP_data_rhoEM))

            _, _, FP_sum_x_EM, _, alpha, _, _, FP_standardized_sum_x_EM, _ = database_base.normalize_data(FP_data_xEM, FP_data_yEM, alpha)
            datasetAugFP_EM_tf = CustomTensorDataset(tensors=(torch.tensor(FP_data_xEM,dtype=torch.float32), torch.tensor(FP_data_yEM,dtype=torch.float32),
                                     torch.tensor(FP_data_xEM,dtype=torch.float32), torch.tensor(FP_data_uEM,dtype=torch.float32),
                                 torch.tensor(FP_data_rhoEM,dtype=torch.float32), torch.tensor(FP_standardized_sum_x_EM,dtype=torch.float32), 
                                torch.tensor(FP_data_uEM,dtype=torch.float32)), transform=transform
                            )
            datasetAugFP_EM = CustomTensorDataset(tensors=(torch.tensor(FP_data_xEM,dtype=torch.float32), torch.tensor(FP_data_yEM,dtype=torch.float32),
                                     torch.tensor(FP_data_xEM,dtype=torch.float32), torch.tensor(FP_data_uEM,dtype=torch.float32),
                                 torch.tensor(FP_data_rhoEM,dtype=torch.float32), torch.tensor(FP_standardized_sum_x_EM,dtype=torch.float32), 
                                torch.tensor(FP_data_uEM,dtype=torch.float32)) 
                            )

            # for i in range(FP_data_xEM.shape[0]):
            #     print("[EM] img nb", i)
            #     list_FNE_ratio = database_base.FNE_constants_ph(FP_data_xEM, FP_data_yEM, i)
    


    if paramsDataSet.gaussian_denoising:

        _, _, gaussian_sum_x, _, alpha, _, _, noisy_standardized_sum_x_NN, _ = database_base.normalize_data(MMSE_input, MMSE_target, alpha)
        datasetGaussian_tf = CustomTensorDataset(tensors=(torch.tensor(MMSE_input,dtype=torch.float32), torch.tensor(MMSE_target,dtype=torch.float32),
                                    torch.tensor(MMSE_input,dtype=torch.float32), torch.tensor(MMSE_phantom,dtype=torch.float32),
                            alpha*torch.ones(MMSE_input.shape[0]), torch.tensor(noisy_standardized_sum_x_NN,dtype=torch.float32), 
                            torch.tensor(MMSE_phantom,dtype=torch.float32)), transform=transform
                        )
        datasetGaussian = CustomTensorDataset(tensors=(torch.tensor(MMSE_input,dtype=torch.float32), torch.tensor(MMSE_target,dtype=torch.float32),
                                    torch.tensor(MMSE_input,dtype=torch.float32), torch.tensor(MMSE_phantom,dtype=torch.float32),
                            alpha*torch.ones(MMSE_input.shape[0]), torch.tensor(noisy_standardized_sum_x_NN,dtype=torch.float32), 
                            torch.tensor(MMSE_phantom,dtype=torch.float32)) 
                        )

        # for i in range(MMSE_input.shape[0]):
        #     print("[denoising] img nb", i)
        #     list_FNE_ratio = database_base.FNE_constants_ph(MMSE_input, MMSE_target, i)
    
    test_size=int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*paramsDataSet.n_sim    
    indices = list(range(paramsDataSet.n_subjects*paramsDataSet.n_sim))
    train_indices, val_indices = indices[test_size:], indices[:test_size]
    # Create Subset for training and validation
    # train_data = Subset(dataset_tf, train_indices)
    # test_data  = Subset(dataset, val_indices)

      
    if paramsDataSet.augmentation_FP :
        print("augmentation FP")
        test_size_aug_FP=int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*n_sim*n_rho
        indices = list(range(paramsDataSet.n_subjects*n_sim*n_rho))
        train_indices, val_indices = indices[test_size_aug_FP:], indices[:test_size_aug_FP]
        # Create Subset for training and validation
        train_data_aug_FP = Subset(datasetAugFP_tf, train_indices)
        test_data_aug_FP = Subset(datasetAugFP, val_indices)

        print("size test FP", int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*n_sim*n_rho)
        train_data = train_data_aug_FP
        test_data = test_data_aug_FP
        # if use_only_FP : 
        #     print("using only FP")
        #     train_data = train_data_aug_FP
        #     test_data = test_data_aug_FP
        # else :
        #     train_data = torch.utils.data.ConcatDataset([train_data, train_data_aug_FP]) 
        #     test_data = test_data_aug_FP #torch.utils.data.ConcatDataset([test_data, test_data_aug_FP]) 



    if paramsDataSet.augmentation_FP_EM:
        print("augmentation FP EM")
        test_size_aug_FP=int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*n_sim*n_rho_EM
        indices = list(range(paramsDataSet.n_subjects*n_sim*n_rho_EM))
        train_indices, val_indices = indices[test_size_aug_FP:], indices[:test_size_aug_FP]
        # Create Subset for training and validation
        train_data_aug_FP = Subset(datasetAugFP_EM_tf, train_indices)
        test_data_aug_FP = Subset(datasetAugFP_EM, val_indices)        
        train_data = torch.utils.data.ConcatDataset([train_data, train_data_aug_FP]) 
        test_data = torch.utils.data.ConcatDataset([test_data, test_data_aug_FP])
      

    if paramsDataSet.gaussian_denoising:
        print("gaussian denoising")
        test_size_MMSE=int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*paramsDataSet.n_sim*nb_noise_levels
        indices = list(range(paramsDataSet.n_subjects*paramsDataSet.n_sim*nb_noise_levels))
        train_indices, val_indices = indices[test_size_MMSE:], indices[:test_size_MMSE]
        # Create Subset for training and validation
        train_data_MMSE = Subset(datasetGaussian_tf, train_indices)
        test_data_MMSE = Subset(datasetGaussian, val_indices)


        train_data = train_data_MMSE 
        test_data = test_data_MMSE
 
    return train_data, test_data





def get_data_BB(data_x, 
             data_y, 
             data_ph,
             data_rho,
             data_EM,
             data_dose,
             paramsDataSet, 
             n_rho,
             use_reduced_sim,
             transform=None
             ): 

    '''
    Generates training and testing torch dataloaders using the numpy data. The target
    is potentially obtained as the output of a NN applied on data_y (e.g. for dose reduction).

    Arguments:
        - data_x: Input images (4D numpy array - [index_im,z,y,x]).
        - data_y: Target images (4D numpy array - [index_im,z,y,x]).
        - paramsDataSet: parameters for tensor dataset (tensorDataSetDoserecParams).
        - device: device used for Tensors ("cuda" or "cpu")
        - device_model: device used for models ("cuda" or "cpu")

    Returns:
        - dataset: TensorDataset wrapping input and target data. When norm_sj=True, add the list of total sum of data_x
                   and data_y for every 3D image and the normalization constant. If norm_sj=False and norm_train=True,
                   add the tensor array of patient number, realization number,normalization constant and init value for
                   the scaling constant (torch.utils.data.TensorDataset).
        - train_loader: Dataloader containing the training data (torch.utils.data.DataLoader)
        - test_loader: Dataloader containing the testing data (torch.utils.data.DataLoader).
        - sum_x: List of input image sum values (list of floats).
        - sum_y: List of target image sum values (list of floats).
        - alpha: Normalization constant used (list of normalization constants).

    Note:
        For large databases the loader should be in CPU, and tensor copied to gpu when used if needed.
    '''

    if not isinstance(paramsDataSet,tensorDataSetDoserecParams):
        raise TypeError("paramsDataSet type is not tensorDataSetDoserecParams ")

    alpha = paramsDataSet.alpha
    data_x_sel=data_x
    data_y_sel=data_y
    data_phantom_sel = data_ph
    data_EM_sel = data_EM
    n_sim = 1 if use_reduced_sim else paramsDataSet.n_sim

    if paramsDataSet.truncate < data_x.shape[1]:
        t = data_x_sel.shape[1] - paramsDataSet.truncate
        
        data_x_sel = data_x_sel[:,t:,:,:]
        data_y_sel = data_y_sel[:,t:,:,:]
        data_phantom_sel = data_phantom_sel[:,t:,:,:]
        data_EM_sel = data_EM_sel[:,t:,:,:]

        
    data_y_den=data_y_sel   
    _, _, sum_x, sum_y, alpha, _, _, standardized_sum_x, _ = database_base.normalize_data(data_x_sel, data_y_den, alpha)
    sum_x = np.ones_like(sum_x)
    sum_y = np.ones_like(sum_y)
 
    FNE_cte = []
    for i in range(data_rho.shape[0]):
        # print("img nb", i, "rho", FP_data_rho[i])
        list_FNE_ratio = database_base.FNE_constants_ph(data_x_sel, data_y_sel, i)
        for cte in list_FNE_ratio:
            FNE_cte.append(cte)
    print("final mean FNE", np.mean(FNE_cte))
    print("final max FNE", np.max(FNE_cte))
    print("final min FNE", np.min(FNE_cte))

    print(data_x_sel.shape)
    print(data_y_den.shape)
    norm_data_rho = data_rho/data_rho.max()


    # datasetAugFP_tf = CustomTensorDataset(tensors= (torch.tensor(data_x_sel,dtype=torch.float32), torch.tensor(data_y_den,dtype=torch.float32),
    #                                 torch.tensor(data_EM_sel,dtype=torch.float32), torch.tensor(data_phantom_sel,dtype=torch.float32),
    #                             torch.tensor(data_rho,dtype=torch.float32), torch.tensor(data_dose/data_dose.max(),dtype=torch.float32),
    #                             torch.tensor(data_phantom_sel,dtype=torch.float32)), transform=transform)
    
    datasetAugFP = CustomTensorDataset(tensors= (torch.tensor(data_x_sel,dtype=torch.float32), torch.tensor(data_y_den,dtype=torch.float32),
                                    torch.tensor(data_EM_sel,dtype=torch.float32), torch.tensor(data_phantom_sel,dtype=torch.float32),
                                torch.tensor(norm_data_rho,dtype=torch.float32), torch.tensor(data_dose/data_dose.max(),dtype=torch.float32),
                                torch.tensor(data_phantom_sel,dtype=torch.float32)))
                        
    print("after creation dataset")
    
    
    test_size=int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*n_sim*n_rho    
    indices = list(range(paramsDataSet.n_subjects*n_sim))
    train_indices, val_indices = indices[test_size:], indices[:test_size]

      
    test_size_aug_FP=int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*n_sim*n_rho
    indices = list(range(paramsDataSet.n_subjects*n_sim*n_rho))
    train_indices, val_indices = indices[test_size_aug_FP:], indices[:test_size_aug_FP]
    # Create Subset for training and validation
    print("splitting")
    train_data_aug_FP = Subset(datasetAugFP, train_indices)
    test_data_aug_FP = Subset(datasetAugFP, val_indices)

    print("size test FP", int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*n_sim*n_rho)
    train_data = train_data_aug_FP
    test_data = test_data_aug_FP
 
    return train_data, test_data




def get_data_BB_MRI(data_x, 
             data_y, 
             data_ph,
             data_rho,
             data_EM,
             data_dose,
             data_mri,
             paramsDataSet, 
             n_rho,
             use_reduced_sim,
             transform=None
             ): 

   

    if not isinstance(paramsDataSet,tensorDataSetDoserecParams):
        raise TypeError("paramsDataSet type is not tensorDataSetDoserecParams ")

    alpha = paramsDataSet.alpha
    data_x_sel=data_x
    data_y_sel=data_y
    data_phantom_sel = data_ph
    data_EM_sel = data_EM
    data_mri_sel = data_mri
    n_sim = 1 if use_reduced_sim else paramsDataSet.n_sim

    if paramsDataSet.truncate < data_x.shape[1]:
        t = data_x_sel.shape[1] - paramsDataSet.truncate
        
        data_x_sel = data_x_sel[:,t:,:,:]
        data_y_sel = data_y_sel[:,t:,:,:]
        data_phantom_sel = data_phantom_sel[:,t:,:,:]
        data_EM_sel = data_EM_sel[:,t:,:,:]
        data_mri_sel = data_mri_sel[:,t:,:,:]

        
    data_y_den=data_y_sel   
    _, _, sum_x, sum_y, alpha, _, _, standardized_sum_x, _ = database_base.normalize_data(data_x_sel, data_y_den, alpha)
    sum_x = np.ones_like(sum_x)
    sum_y = np.ones_like(sum_y)
 
    FNE_cte = []
    for i in range(data_rho.shape[0]):
        # print("img nb", i, "rho", FP_data_rho[i])
        list_FNE_ratio = database_base.FNE_constants_ph(data_x_sel, data_y_sel, i)
        for cte in list_FNE_ratio:
            FNE_cte.append(cte)
    print("final mean FNE", np.mean(FNE_cte))
    print("final max FNE", np.max(FNE_cte))
    print("final min FNE", np.min(FNE_cte))

    print(data_x_sel.shape)
    print(data_y_den.shape)


    # datasetAugFP_tf = CustomTensorDataset(tensors= (torch.tensor(data_x_sel,dtype=torch.float32), torch.tensor(data_y_den,dtype=torch.float32),
    #                                 torch.tensor(data_EM_sel,dtype=torch.float32), torch.tensor(data_phantom_sel,dtype=torch.float32),
    #                             torch.tensor(data_rho,dtype=torch.float32), torch.tensor(data_dose/data_dose.max(),dtype=torch.float32),
    #                             torch.tensor(data_mri,dtype=torch.float32)), transform=transform)
    norm_data_rho = data_rho/data_rho.max()
    datasetAugFP = CustomTensorDataset(tensors= (torch.tensor(data_x_sel,dtype=torch.float32), torch.tensor(data_y_den,dtype=torch.float32),
                                    torch.tensor(data_EM_sel,dtype=torch.float32), torch.tensor(data_phantom_sel,dtype=torch.float32),
                                torch.tensor(norm_data_rho,dtype=torch.float32), torch.tensor(data_dose/data_dose.max(),dtype=torch.float32),
                                torch.tensor(data_mri_sel,dtype=torch.float32)))
                        
                
    print("post creation dataset")
    
    test_size=int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*n_sim*n_rho    
    indices = list(range(paramsDataSet.n_subjects*n_sim))
    train_indices, val_indices = indices[test_size:], indices[:test_size]

      
    test_size_aug_FP=int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*n_sim*n_rho
    indices = list(range(paramsDataSet.n_subjects*n_sim*n_rho))
    train_indices, val_indices = indices[test_size_aug_FP:], indices[:test_size_aug_FP]
    print("pre splitting")
    # Create Subset for training and validation
    train_data_aug_FP = Subset(datasetAugFP, train_indices)
    test_data_aug_FP = Subset(datasetAugFP, val_indices)

    print("size test FP", int(math.ceil(paramsDataSet.test_percent*paramsDataSet.n_subjects))*n_sim*n_rho)
    train_data = train_data_aug_FP
    test_data = test_data_aug_FP
 
    return train_data, test_data


def mri_to_db(paramsDataSet): 


    lst_subjects = paramsDataSet.doserecParams.lst_subjects_reduced
    n_sim=paramsDataSet.doserecParams.n_sim

    new_dbase_dir=paramsDataSet.get_gen_dbase_import_rootdir()
    target=paramsDataSet.import_target
    
    
    for i, subject in enumerate(lst_subjects):
        print("Subject: ",subject," (",i,")")
        img_MRI=nib.load("/biomaps/physics/sureau/database_fdg_pipeline_v3/temoins/"+subject+"_fsl/mri/T1_"+subject+"_auto_biograph_crop.nii").get_fdata()
        img_MRI=np.swapaxes(img_MRI,2,0)
        img_MRI = np.flip(np.flip(np.flip(img_MRI, axis=0), axis=1), axis=2)
        # img_MRI = img_MRI[::2, ::2, ::2]


        if True:
            sub_dbase_dir = paramsDataSet.doserecParams.get_gen_dbase_dir(subject)
            sub_new_dir = os.path.join(new_dbase_dir, f'{subject}')
            if not os.path.exists(sub_new_dir):
                os.makedirs(sub_new_dir)
            for real in range(n_sim):
                input_im_name,input_hdr_name=paramsDataSet.get_fname_im_input(subject,real)
                _,recon_hdr_name=paramsDataSet.doserecParams.get_fname_im_reddose(subject,real)
                imrec_rep,_=paramsDataSet.doserecParams.load_im_reddose(subject,real,verbose=False)
                PETLibs.ios.writeInterfileImgFromHDR(sub_new_dir,input_im_name,
                                        sub_dbase_dir,recon_hdr_name,imrec_rep,verbose=False)

                target_name,_=paramsDataSet.get_fname_im_target(subject,real,target)
                if target=="highdose":
                    _,target_hdr_name=paramsDataSet.doserecParams.get_fname_im_ordose_red(subject,real)
                    imrec_target,_=paramsDataSet.doserecParams.load_im_ordose_red(subject,real,verbose=False)
                else:
                    _,target_hdr_name=paramsDataSet.doserecParams.get_fname_im_phantom_red(subject,real)
                    imrec_target,_=paramsDataSet.doserecParams.load_im_phantom_red(subject,real,verbose=False)
                PETLibs.ios.writeInterfileImgFromHDR(sub_new_dir,target_name,
                                            sub_dbase_dir,target_hdr_name,imrec_target,verbose=False)
         
              
        
                file_name = target_name.replace(".ima","_mri.ima")
                PETLibs.ios.writeInterfileImg(img_MRI,os.path.join(sub_new_dir,file_name))
        
    
    return None


def prox_reconBB(paramsDataSet, list_rho): 



    lst_subjects = paramsDataSet.doserecParams.lst_subjects_reduced
    n_sim=paramsDataSet.doserecParams.n_sim

    new_dbase_dir=paramsDataSet.get_gen_dbase_import_rootdir()
    target=paramsDataSet.import_target
    
   
    reconsParams = PETLibs.recons.GPUBiographReconsParams(lut_name="/share/Programs/castor/castor_git/config/scanner/PET_SIEMENS_BIOGRAPH6_TRUEPOINT_TRUEV.lut",
                                                vox_size=paramsDataSet.doserecParams.CASToRParams.vox_size,im_dim=paramsDataSet.doserecParams.CASToRParams.im_dim,
                                                XYZ=False, nsubsets=1, fwhm_mm = 4, nbsigmas = 5, nit=224)
    
    for i, subject in enumerate(lst_subjects):
        if i > 6 :
            sub_dbase_dir = paramsDataSet.doserecParams.get_gen_dbase_dir(subject)
            sub_new_dir = os.path.join(new_dbase_dir, f'{subject}')
            if not os.path.exists(sub_new_dir):
                os.makedirs(sub_new_dir)
            for real in range(n_sim):
                input_im_name,input_hdr_name=paramsDataSet.get_fname_im_input(subject,real)
                _,recon_hdr_name=paramsDataSet.doserecParams.get_fname_im_reddose(subject,real)
                imrec_rep,_=paramsDataSet.doserecParams.load_im_reddose(subject,real,verbose=False)
                PETLibs.ios.writeInterfileImgFromHDR(sub_new_dir,input_im_name,
                                        sub_dbase_dir,recon_hdr_name,imrec_rep,verbose=False)

                target_name,_=paramsDataSet.get_fname_im_target(subject,real,target)
                if target=="highdose":
                    _,target_hdr_name=paramsDataSet.doserecParams.get_fname_im_ordose_red(subject,real)
                    imrec_target,_=paramsDataSet.doserecParams.load_im_ordose_red(subject,real,verbose=False)
                else:
                    _,target_hdr_name=paramsDataSet.doserecParams.get_fname_im_phantom_red(subject,real)
                    imrec_target,_=paramsDataSet.doserecParams.load_im_phantom_red(subject,real,verbose=False)
                PETLibs.ios.writeInterfileImgFromHDR(sub_new_dir,target_name,
                                            sub_dbase_dir,target_hdr_name,imrec_target,verbose=False)
                
                castor_df_ima,castor_df_hdr=paramsDataSet.doserecParams.get_fname_sinogram_CASToR_hdr(subject,real)
                castor_df_dir=paramsDataSet.doserecParams.get_gen_castor_dir(subject,real)
                castor_df_hdr_fpath=os.path.join(castor_df_dir,castor_df_hdr)


                dict_sino=GPURecons.GPUCASToRSinos(castor_df_hdr_fpath, castor_df_dir,
                                                    reconsParams=reconsParams)
                    

                xt= torch.reshape(torch.tensor(imrec_target,dtype=torch.float32, device = "cuda"),reconsParams.tb_im_dim)

                for rho in list_rho:
                    
                    print('Subject: ',subject,' (',i,')\nRealization: ',real+1,'\nNumber: ',real + i*n_sim,'\nRho: ',rho)

                    x_rot=GPURecons.GPUProxReconsDPEM(castor_df_hdr_fpath, castor_df_ima,
                        reconsParams=reconsParams,xprox=xt,pnlt_beta=rho,
                        dict_sino=dict_sino,eval_mode=True,verbose = False,show_step = False,
                        tensor_output=False, img_mask = None, bUseWeighted = False)
        
                    file_name = target_name.replace(".ima","_prox_rho_"+str(rho)+".ima")
                    PETLibs.ios.writeInterfileImg(x_rot,os.path.join(sub_new_dir,file_name))
        
    
    return None
                



def import_database_BB(learningDataSet,list_rho,use_reduced_sim,verbose=True):


    dim=learningDataSet.doserecParams.CASToRParams.im_dim
    n1 = dim[0]
    n2 = dim[1]
    n3 = dim[2]
    n_rho = len(list_rho)

    lst_subjects = learningDataSet.doserecParams.lst_subjects_reduced
    n_sim= 1 if use_reduced_sim else learningDataSet.doserecParams.n_sim

    data_x = np.empty([n_sim*n_rho*len(lst_subjects),n1,n2,n3])
    data_y = np.empty([n_sim*n_rho*len(lst_subjects),n1,n2,n3])
    data_ph = np.empty([n_sim*n_rho*len(lst_subjects),n1,n2,n3])
    data_EM = np.empty([n_sim*n_rho*len(lst_subjects),n1,n2,n3])
    data_dose = np.empty([n_sim*n_rho*len(lst_subjects)])
    data_rho = np.empty([n_sim*n_rho*len(lst_subjects)])
    new_dbase_dir=learningDataSet.get_gen_dbase_import_rootdir()
    target=learningDataSet.import_target
    reconsParams = PETLibs.recons.GPUBiographReconsParams(lut_name="/share/Programs/castor/castor_git/config/scanner/PET_SIEMENS_BIOGRAPH6_TRUEPOINT_TRUEV.lut",
                                                    vox_size=learningDataSet.doserecParams.CASToRParams.vox_size,im_dim=learningDataSet.doserecParams.CASToRParams.im_dim, 
                                                    XYZ=False, nsubsets=1, fwhm_mm = 4, nbsigmas = 5)

    for i, subject in enumerate(lst_subjects):
        sub_dbase_dir = learningDataSet.doserecParams.get_gen_dbase_dir(subject)
        sub_new_dir = os.path.join(new_dbase_dir, f'{subject}')
        if not os.path.exists(sub_new_dir):
             os.makedirs(sub_new_dir)
        for real in range(n_sim):
            input_im_name,input_hdr_name=learningDataSet.get_fname_im_input(subject,real)
            _,recon_hdr_name=learningDataSet.doserecParams.get_fname_im_reddose(subject,real)
            imrec_rep,_=learningDataSet.doserecParams.load_im_reddose(subject,real,verbose=verbose)
            PETLibs.ios.writeInterfileImgFromHDR(sub_new_dir,input_im_name,
                                     sub_dbase_dir,recon_hdr_name,imrec_rep,verbose=verbose)

            target_name,_=learningDataSet.get_fname_im_target(subject,real,target)

            _,target_hdr_name=learningDataSet.doserecParams.get_fname_im_ordose_red(subject,real)
            imrec_target,_=learningDataSet.doserecParams.load_im_ordose_red(subject,real,verbose=verbose)

            _,ph_hdr_name=learningDataSet.doserecParams.get_fname_im_phantom_red(subject,real)
            imrec_ph,_=learningDataSet.doserecParams.load_im_phantom_red(subject,real,verbose=verbose)

            PETLibs.ios.writeInterfileImgFromHDR(sub_new_dir,target_name,
                                         sub_dbase_dir,target_hdr_name,imrec_target,verbose=verbose)

            castor_df_ima,castor_df_hdr=learningDataSet.doserecParams.get_fname_sinogram_CASToR_hdr(subject,real)
            castor_df_dir=learningDataSet.doserecParams.get_gen_castor_dir(subject,real)
            castor_df_hdr_fpath=os.path.join(castor_df_dir,castor_df_hdr)
            dict_sino=GPURecons.GPUCASToRSinos(castor_df_hdr_fpath, castor_df_dir,
                                                        reconsParams=reconsParams)
            y_data =  reconsParams.createSubsetData(dict_sino["val"])
            dose = y_data[0].sum().cpu().numpy()

            del dict_sino
            del y_data
            # im_reddose_dir=learningDataSet.doserecParams.get_gen_dbase_dir(subject)
            #Get reference image
            reddose_ref,reddose_hdr_ref=learningDataSet.get_fname_im_input(subject,real)
            reddose_ref,reddose_hdr_ref=learningDataSet.doserecParams.get_fname_im_ordose_red(subject,real)
            reddose_ref=reddose_ref.replace("originaldose-red","originaldose-target")
            reddose_hdr_ref=reddose_hdr_ref.replace("originaldose-red","originaldose-target")


            i_rho = 0
            for rho in list_rho:
                reddose_ref_rho = reddose_ref.replace(".ima","_prox_rho_"+str(rho)+".ima")
                reddose_hdr_ref_rho = reddose_hdr_ref.replace(".hdr","_prox_rho_"+str(rho)+".hdr")
                path_reddose_hdr=os.path.join(sub_new_dir,reddose_hdr_ref_rho)
                # print("path_reddose_hdr", path_reddose_hdr)
                if os.path.exists(path_reddose_hdr):
                    reddose_hdr=Interfile.load(path_reddose_hdr)
                    reddose_hdr['name of data file']['value']=reddose_ref_rho
                    img_rho,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(reddose_hdr,sub_new_dir,verbose=verbose)

                # print('Subject: ',subject,' (',i,')\nRealization: ',real+1,'\nNumber: ',i_rho + real*n_rho + i*n_rho*n_sim,'\nRho: ',rho)
                data_x[i_rho + real*n_rho + i*n_rho*n_sim] = np.transpose(np.expand_dims(img_rho[:,:,:],axis=3),(3,0,1,2))
                data_y[i_rho + real*n_rho + i*n_rho*n_sim] = np.transpose(np.expand_dims(imrec_target[:,:,:],axis=3),(3,0,1,2))
                data_ph[i_rho + real*n_rho + i*n_rho*n_sim] = np.transpose(np.expand_dims(imrec_ph[:,:,:],axis=3),(3,0,1,2))
                data_EM[i_rho + real*n_rho + i*n_rho*n_sim] = np.transpose(np.expand_dims(imrec_rep[:,:,:],axis=3),(3,0,1,2))
                data_dose[i_rho + real*n_rho + i*n_rho*n_sim] = dose
                data_rho[i_rho + real*n_rho + i*n_rho*n_sim] = rho
                i_rho = i_rho+1
    


    return data_x, data_y, data_ph, data_EM, data_rho, data_dose


def import_database_BB_MRI(learningDataSet,list_rho,use_reduced_sim,verbose=True):


    dim=learningDataSet.doserecParams.CASToRParams.im_dim
    n1 = dim[0]
    n2 = dim[1]
    n3 = dim[2]
    n_rho = len(list_rho)

    lst_subjects = learningDataSet.doserecParams.lst_subjects_reduced
    n_sim= 1 if use_reduced_sim else learningDataSet.doserecParams.n_sim

    data_x = np.empty([n_sim*n_rho*len(lst_subjects),n1,n2,n3])
    data_y = np.empty([n_sim*n_rho*len(lst_subjects),n1,n2,n3])
    data_ph = np.empty([n_sim*n_rho*len(lst_subjects),n1,n2,n3])
    data_EM = np.empty([n_sim*n_rho*len(lst_subjects),n1,n2,n3])
    data_mri = np.empty([n_sim*n_rho*len(lst_subjects),n1,n2,n3])
    data_dose = np.empty([n_sim*n_rho*len(lst_subjects)])
    data_rho = np.empty([n_sim*n_rho*len(lst_subjects)])
    new_dbase_dir=learningDataSet.get_gen_dbase_import_rootdir()
    target=learningDataSet.import_target
    reconsParams = PETLibs.recons.GPUBiographReconsParams(lut_name="/share/Programs/castor/castor_git/config/scanner/PET_SIEMENS_BIOGRAPH6_TRUEPOINT_TRUEV.lut",
                                                    vox_size=learningDataSet.doserecParams.CASToRParams.vox_size,im_dim=learningDataSet.doserecParams.CASToRParams.im_dim, 
                                                    XYZ=False, nsubsets=1, fwhm_mm = 4, nbsigmas = 5)

    for i, subject in enumerate(lst_subjects):
        sub_dbase_dir = learningDataSet.doserecParams.get_gen_dbase_dir(subject)
        sub_new_dir = os.path.join(new_dbase_dir, f'{subject}')
        if not os.path.exists(sub_new_dir):
             os.makedirs(sub_new_dir)
        for real in range(n_sim):
            input_im_name,input_hdr_name=learningDataSet.get_fname_im_input(subject,real)
            _,recon_hdr_name=learningDataSet.doserecParams.get_fname_im_reddose(subject,real)
            imrec_rep,_=learningDataSet.doserecParams.load_im_reddose(subject,real,verbose=verbose)
            PETLibs.ios.writeInterfileImgFromHDR(sub_new_dir,input_im_name,
                                     sub_dbase_dir,recon_hdr_name,imrec_rep,verbose=verbose)

            target_name,_=learningDataSet.get_fname_im_target(subject,real,target)

            _,target_hdr_name=learningDataSet.doserecParams.get_fname_im_ordose_red(subject,real)
            imrec_target,_=learningDataSet.doserecParams.load_im_ordose_red(subject,real,verbose=verbose)

            _,ph_hdr_name=learningDataSet.doserecParams.get_fname_im_phantom_red(subject,real)
            imrec_ph,_=learningDataSet.doserecParams.load_im_phantom_red(subject,real,verbose=verbose)

            PETLibs.ios.writeInterfileImgFromHDR(sub_new_dir,target_name,
                                         sub_dbase_dir,target_hdr_name,imrec_target,verbose=verbose)

            castor_df_ima,castor_df_hdr=learningDataSet.doserecParams.get_fname_sinogram_CASToR_hdr(subject,real)
            castor_df_dir=learningDataSet.doserecParams.get_gen_castor_dir(subject,real)
            castor_df_hdr_fpath=os.path.join(castor_df_dir,castor_df_hdr)
            dict_sino=GPURecons.GPUCASToRSinos(castor_df_hdr_fpath, castor_df_dir,
                                                        reconsParams=reconsParams)
            y_data =  reconsParams.createSubsetData(dict_sino["val"])
            dose = y_data[0].sum().cpu().numpy()

            del dict_sino
            del y_data
            # im_reddose_dir=learningDataSet.doserecParams.get_gen_dbase_dir(subject)
            #Get reference image
            reddose_ref,reddose_hdr_ref=learningDataSet.get_fname_im_input(subject,real)
            reddose_ref,reddose_hdr_ref=learningDataSet.doserecParams.get_fname_im_ordose_red(subject,real)
            reddose_ref=reddose_ref.replace("originaldose-red","originaldose-target")
            reddose_hdr_ref=reddose_hdr_ref.replace("originaldose-red","originaldose-target")

            reddose_ref_mri = reddose_ref.replace(".ima","_mri.ima")
            reddose_hdr_ref_mri = reddose_hdr_ref.replace(".hdr","_mri.hdr")

            if os.path.exists(os.path.join(sub_new_dir,reddose_hdr_ref_mri)):
                reddose_hdr=Interfile.load(os.path.join(sub_new_dir,reddose_hdr_ref_mri))
                reddose_hdr['name of data file']['value']=reddose_ref_mri
                img_mri,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(reddose_hdr,sub_new_dir,verbose=verbose)

            i_rho = 0
            for rho in list_rho:
                reddose_ref_rho = reddose_ref.replace(".ima","_prox_rho_"+str(rho)+".ima")
                reddose_hdr_ref_rho = reddose_hdr_ref.replace(".hdr","_prox_rho_"+str(rho)+".hdr")
                path_reddose_hdr=os.path.join(sub_new_dir,reddose_hdr_ref_rho)
                # print("path_reddose_hdr", path_reddose_hdr)
                if os.path.exists(path_reddose_hdr):
                    reddose_hdr=Interfile.load(path_reddose_hdr)
                    reddose_hdr['name of data file']['value']=reddose_ref_rho
                    img_rho,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(reddose_hdr,sub_new_dir,verbose=verbose)

                print('Subject: ',subject,' (',i,')\nRealization: ',real+1,'\nNumber: ',i_rho + real*n_rho + i*n_rho*n_sim,'\nRho: ',rho)
                data_x[i_rho + real*n_rho + i*n_rho*n_sim] = np.transpose(np.expand_dims(img_rho[:,:,:],axis=3),(3,0,1,2))
                data_y[i_rho + real*n_rho + i*n_rho*n_sim] = np.transpose(np.expand_dims(imrec_target[:,:,:],axis=3),(3,0,1,2))
                data_ph[i_rho + real*n_rho + i*n_rho*n_sim] = np.transpose(np.expand_dims(imrec_ph[:,:,:],axis=3),(3,0,1,2))
                data_EM[i_rho + real*n_rho + i*n_rho*n_sim] = np.transpose(np.expand_dims(imrec_rep[:,:,:],axis=3),(3,0,1,2))
                data_mri[i_rho + real*n_rho + i*n_rho*n_sim] = np.transpose(np.expand_dims(img_mri[:,:,:],axis=3),(3,0,1,2))
                data_dose[i_rho + real*n_rho + i*n_rho*n_sim] = dose
                data_rho[i_rho + real*n_rho + i*n_rho*n_sim] = rho
                i_rho = i_rho+1
    


    return data_x, data_y, data_ph, data_EM, data_rho, data_dose, data_mri



def load_prox_LL(learningDataSet, rho, subject, real, verbose= False) : #learningDataSet,list_rho,use_reduced_sim,verbose=True):


    new_dbase_dir=learningDataSet.get_gen_dbase_import_rootdir()


    sub_new_dir = os.path.join(new_dbase_dir, f'{subject}')
    if not os.path.exists(sub_new_dir):
        os.makedirs(sub_new_dir)


    # im_reddose_dir=learningDataSet.doserecParams.get_gen_dbase_dir(subject)
    #Get reference image
    reddose_ref,reddose_hdr_ref=learningDataSet.get_fname_im_input(subject,real)
    reddose_ref,reddose_hdr_ref=learningDataSet.doserecParams.get_fname_im_ordose_red(subject,real)
    reddose_ref=reddose_ref.replace("originaldose-red","originaldose-target")
    reddose_hdr_ref=reddose_hdr_ref.replace("originaldose-red","originaldose-target")



    reddose_ref_rho = reddose_ref.replace(".ima","_prox_rho_"+str(rho)+".ima")
    reddose_hdr_ref_rho = reddose_hdr_ref.replace(".hdr","_prox_rho_"+str(rho)+".hdr")
    path_reddose_hdr=os.path.join(sub_new_dir,reddose_hdr_ref_rho)

    if os.path.exists(path_reddose_hdr):
        reddose_hdr=Interfile.load(path_reddose_hdr)
        reddose_hdr['name of data file']['value']=reddose_ref_rho
        img_rho,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(reddose_hdr,sub_new_dir,verbose=verbose)
    else :
        raise ValueError("Prox image not found")


    return img_rho



def load_mri(learningDataSet, subject, real, verbose= False) : 


    new_dbase_dir=learningDataSet.get_gen_dbase_import_rootdir()


    sub_new_dir = os.path.join(new_dbase_dir, f'{subject}')
    if not os.path.exists(sub_new_dir):
        os.makedirs(sub_new_dir)


    # im_reddose_dir=learningDataSet.doserecParams.get_gen_dbase_dir(subject)
    #Get reference image
    reddose_ref,reddose_hdr_ref=learningDataSet.get_fname_im_input(subject,real)
    reddose_ref,reddose_hdr_ref=learningDataSet.doserecParams.get_fname_im_ordose_red(subject,real)
    reddose_ref=reddose_ref.replace("originaldose-red","originaldose-target")
    reddose_hdr_ref=reddose_hdr_ref.replace("originaldose-red","originaldose-target")

    reddose_ref_mri = reddose_ref.replace(".ima","_mri.ima")
    reddose_hdr_ref_mri = reddose_hdr_ref.replace(".hdr","_mri.hdr")

    if os.path.exists(os.path.join(sub_new_dir,reddose_hdr_ref_mri)):
        reddose_hdr=Interfile.load(os.path.join(sub_new_dir,reddose_hdr_ref_mri))
        reddose_hdr['name of data file']['value']=reddose_ref_mri
        img_mri,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(reddose_hdr,sub_new_dir,verbose=verbose)
    else :
        raise ValueError("MRI image not found")


    return img_mri


def getNormData(data_x, 
             data_y, 
             paramsDataSet, 
             device="cuda", 
             verbose=True 
             ): 

    

    if not isinstance(paramsDataSet,tensorDataSetDoserecParams):
        raise TypeError("paramsDataSet type is not tensorDataSetDoserecParams ")

    alpha = paramsDataSet.alpha
    n_select=paramsDataSet.n_sim*paramsDataSet._n_subjects
    dim=[n_select,data_x.shape[1],data_x.shape[2],data_x.shape[3]]
    data_x_sel=np.zeros(dim)
    data_y_sel=np.zeros(dim)
    data_phantom_sel = np.zeros(dim)
    # offset_im=0
    for ki, subject in enumerate(paramsDataSet.lst_subjects_reduced):
        for kr,real in enumerate(range(paramsDataSet.n_sim)):
            print("Subject", subject, "Realization", real)
            data_x_sel[kr+ki*paramsDataSet.n_sim]=data_x[kr+ki*paramsDataSet.doserecParams.n_sim]
            data_y_sel[kr+ki*paramsDataSet.n_sim]=data_y[kr+ki*paramsDataSet.doserecParams.n_sim]
            phantom_ref,phantom_hdr_ref=paramsDataSet.doserecParams.get_fname_im_phantom_red(subject,real)
            path_phantom_hdr=os.path.join(paramsDataSet.doserecParams.get_gen_dbase_dir(subject),phantom_hdr_ref)
            if os.path.exists(path_phantom_hdr):
                phantom_hdr=Interfile.load(path_phantom_hdr)
                phantom_hdr['name of data file']['value']=phantom_ref
                phantom,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(phantom_hdr,paramsDataSet.doserecParams.get_gen_dbase_dir(subject),verbose=verbose)
            else:
                raise FileNotFoundError(errno.ENOENT,os.strerror(errno.ENOENT),path_phantom_hdr)
            
            data_phantom_sel[kr+ki*paramsDataSet.n_sim]=phantom
       
                

    if paramsDataSet.truncate < data_x.shape[1]:
        t = data_x_sel.shape[1] - paramsDataSet.truncate
        
        data_x_sel = data_x_sel[:,t:,:,:]
        data_y_sel = data_y_sel[:,t:,:,:]
        data_phantom_sel = data_phantom_sel[:,t:,:,:]
        
    data_y_den=data_y_sel

   
    _, _, sum_x, sum_y, alpha, _, _, standardized_sum_x, _ = database_base.normalize_data(data_x_sel, data_y_den, alpha)


    doserec_object = paramsDataSet.doserecParams
    castor_object = paramsDataSet.doserecParams.CASToRParams
    list_sub = doserec_object.lst_subjects

    
    dim=castor_object.im_dim
    n1 = dim[0]



    n_sim = doserec_object.n_sim 
    t = n1 - paramsDataSet.truncate



    with tqdm(total=len(list_sub)*n_sim, desc="Iterations FP", unit='Iteration(s)') as pbar:
        for index_sub, subject in enumerate(list_sub):
            for index_real, real in enumerate(range(n_sim)):
         
                data_x_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(data_x_sel[index_real+index_sub*doserec_object.n_sim], dtype=torch.float32),0),0).to(device)
                data_y_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(data_y_den[index_real+index_sub*doserec_object.n_sim], dtype=torch.float32),0),0).to(device)
                data_ph_device=torch.unsqueeze(torch.unsqueeze(torch.tensor(data_phantom_sel[index_real+index_sub*doserec_object.n_sim], dtype=torch.float32),0),0).to(device)
                distance_xy = torch.linalg.vector_norm(data_x_device - data_y_device, dim=(2,3,4))
                if index_sub == 0 and index_real == 0:
                    max_distance_xy = distance_xy.item()
                    min_distance_xy = distance_xy.item()
                    max_x = data_x_device.max().item()
                
                else :
                    min_distance_xy = min(min_distance_xy, distance_xy.item())
                    max_distance_xy = max(max_distance_xy, distance_xy.item())
                    max_x = max(max_x, data_x_device.max().item())
            

 
    return min_distance_xy, max_distance_xy, max_x
