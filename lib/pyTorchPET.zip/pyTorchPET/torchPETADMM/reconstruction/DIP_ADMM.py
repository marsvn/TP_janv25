"""
Created on March 2023

@author: florent.sureau
"""

import os
import numpy as np
import torch
import copy
import PETLibs
import PETLibs.recons
import PETLibs.recons.GPURecons as GPURecons
from torchPETADMM.database import database_doserec
import torchmetrics
import pytorch_lightning as pl
import numpy as np
from pytorch_lightning.utilities.types import STEP_OUTPUT
import torch
from torch import mean, nn
import pytorch_lightning as pl
from torch.optim import Adam, LBFGS
from torch.optim import lr_scheduler
import torchmetrics
from torch.utils.data import Dataset
from pytorch_lightning import loggers as pl_loggers
import torch.nn.functional as F
from pytorch_lightning.callbacks import ModelCheckpoint, LearningRateMonitor, EarlyStopping
from PETLibs.recons.GPUReconsParams import GPUSignaReconsParams, GPUBiographReconsParams
from torch.utils.tensorboard import SummaryWriter
from torch.utils.tensorboard.summary import hparams as hparams_tb

from torchPETADMM.models.DRUnet import NFDownBlockFix, NFUpBlock, get_norm_layer
import torchPETADMM.models.basicblock as B

import torch

import torch.nn.functional as F


def matrix_free_vector_mult_vec(top_k_weights, top_k_neighbors, x, neigh_max=2):
    """
    Performs matrix-free multiplication of a virtual matrix (represented by the k-nearest neighbors' weights and
    neighbors' indices) with a vector (the MRI image), in a vectorized manner.

    Parameters:
    - top_k_weights: Tensor of shape [N, nb_k], weights of the k-nearest neighbors.
    - top_k_neighbors: Tensor of shape [N, nb_k, 3], indices of the k-nearest neighbors.
    - x: 3D tensor of shape [H, W, D], representing the MRI image.
    - neigh_max: Padding offset for the neighborhood.

    Returns:
    - result: Tensor of shape [H, W, D], result of the matrix-free multiplication.
    """
    H, W, D = x.shape
    N, nb_k = top_k_weights.shape

    # Compute linear indices for neighbors in the original 3D tensor
    linear_neighbors = (top_k_neighbors[..., 0] * W * D +
                        top_k_neighbors[..., 1] * D +
                        top_k_neighbors[..., 2])

    # Gather neighbor values from x using linear indices
    x_flat = x.flatten()
    neighbor_values = x_flat[linear_neighbors]  # Shape: [N, nb_k]

    # Compute weighted contributions for each voxel and normalize them
    voxel_contributions = (top_k_weights * neighbor_values).sum(dim=1)/top_k_weights.sum(dim=1)

    # Map the contributions back to their corresponding 3D indices
    id_H = torch.arange(N, device=x.device) // ((W - 2 * neigh_max) * (D - 2 * neigh_max))
    id_W = (torch.arange(N, device=x.device) % ((W - 2 * neigh_max) * (D - 2 * neigh_max))) // (D - 2 * neigh_max)
    id_D = torch.arange(N, device=x.device) % (D - 2 * neigh_max)

    # Initialize the result tensor and accumulate the contributions
    result = torch.zeros_like(x)
    result[id_H + neigh_max, id_W + neigh_max, id_D + neigh_max] = voxel_contributions

    return result





def dynamic_knn_weights_matrix(x_mri, nb_k=3, neigh_max=1, sigma=1.0):
    """
    Efficiently computes the k-nearest neighbors' weights and their indices for each voxel in x_mri.

    Parameters:
    - x_mri: 3D tensor of shape [H, W, D] representing the MRI image.
    - nb_k: Number of nearest neighbors (default: 3).
    - neigh_max: Maximum neighborhood range (default: 1).
    - sigma: Hyperparameter for weighting function (default: 1.0).

    Returns:
    - all_weights: Tensor of shape [N, nb_k], weights of the k-nearest neighbors for all voxels.
    - all_indices: Tensor of shape [N, nb_k, 3], indices of the k-nearest neighbors for all voxels.
    """
    device = x_mri.device
    
    padded_x_mri = torch.nn.functional.pad(x_mri, (neigh_max, neigh_max, neigh_max, neigh_max, neigh_max, neigh_max))
    H, W, D = x_mri.shape
    # Generate offsets for the neighborhood
    offsets = torch.tensor([[di, dj, dk] for di in range(-neigh_max, neigh_max + 1)
                            for dj in range(-neigh_max, neigh_max + 1)
                            for dk in range(-neigh_max, neigh_max + 1) if not (di == 0 and dj == 0 and dk == 0)],
                           dtype=torch.long, device=device)
    num_neighbors = offsets.shape[0] #5*5*5-1 = 124

    # Create a grid of voxel indices
    grid = torch.stack(torch.meshgrid(
        torch.arange(neigh_max, H - neigh_max, device=device),
        torch.arange(neigh_max, W - neigh_max, device=device),
        torch.arange(neigh_max, D - neigh_max, device=device),
        indexing='ij'
    ), dim=-1).reshape(-1, 3)  # Shape: [N, 3], where N is the number of voxels.
    
    # Compute neighborhood indices
    neighbors = (grid.unsqueeze(1) + offsets.unsqueeze(0)).reshape(-1, 3)  # Shape: [N * num_neighbors, 3]

    # Extract values for the central voxels and their neighbors
    central_values = x_mri[grid[:, 0], grid[:, 1], grid[:, 2]].repeat_interleave(num_neighbors)
    neighbor_values = padded_x_mri[neighbors[:, 0], neighbors[:, 1], neighbors[:, 2]]

    # Compute weights using the Gaussian function
    diff = torch.abs(central_values - neighbor_values)
    weights = torch.exp(-torch.square(diff) / (2 * sigma ** 2)).reshape(-1, num_neighbors)

    # Select the top-k neighbors and their indices
    top_k_weights, top_k_indices = torch.topk(weights, nb_k, dim=1, largest=True, sorted=False)

    # Extract the corresponding indices of the top-k neighbors
    top_k_neighbors = neighbors.reshape(-1, num_neighbors, 3)[torch.arange(grid.shape[0], device=device).unsqueeze(-1), top_k_indices]

    return top_k_weights, top_k_neighbors



class CustomTensorDataset(Dataset):
    """TensorDataset with support of transforms.
    """
    def __init__(self, tensors, transform=None):
        assert all(tensors[0].size(0) == tensor.size(0) for tensor in tensors)
        self.tensors = tensors
        self.transform = transform

    def __getitem__(self, index):
        x = self.tensors[0][index]
        y = self.tensors[1][index]
        z = self.tensors[2][index]
       
        return x, y, z

    def __len__(self):
        return self.tensors[0].size(0)

class DataModule(pl.LightningDataModule):

    def __init__(self, 
                 data_x, data_y, data_mask, 
                 truncate
                 ):
        super().__init__()

        if truncate < data_x.shape[0]:
            t = data_x.shape[0] - truncate
            self.data_x = data_x[t:,:,:] 
            self.data_y = data_y[t:,:,:]
            self.data_mask = data_mask[t:,:,:]
        
        # self.data_x = data_x
        # self.data_y = data_y



    def setup(self, stage=None):       
        self.datasetNN = CustomTensorDataset(tensors=(torch.tensor(self.data_x, dtype=torch.float32).unsqueeze(0), torch.tensor(self.data_y, dtype=torch.float32).unsqueeze(0), torch.tensor(self.data_mask, dtype=torch.float32).unsqueeze(0)) 
                            )
        
    def train_dataloader(self):
        loader_args = dict(num_workers=32, pin_memory=True)
        return torch.utils.data.DataLoader(self.datasetNN, shuffle = False,batch_size = 1, **loader_args)

    def val_dataloader(self):
        loader_args = dict(num_workers=32, pin_memory=True)
        return torch.utils.data.DataLoader(self.datasetNN, shuffle = False,batch_size = 1, **loader_args)

    def test_dataloader(self):
        loader_args = dict(num_workers=32, pin_memory=True)
        return torch.utils.data.DataLoader(self.datasetNN, shuffle = False,batch_size = 1, **loader_args)

   
class NFUNetRes2(nn.Module):
    def __init__(self, in_nc=1, 
                out_nc=1, 
                nb=2, 
                depth = 3, 
                wf=16,
                act_mode='R', 
                downsample_mode='strideconv', 
                upsample_mode='upconv', 
                norm = 'instancenorm.v1', 
                type_init= 'xavier', 
                keep_bias = True, 
                alpha = 1.0,
                repeat = True, 
                bUseComposition = False,
                bUseMask = False,
                ) :
        super(NFUNetRes2, self).__init__() #nc=[16, 32, 64, 128],

        self.down_path = nn.ModuleList()
        self.down_path.append(B.conv(in_nc, wf, bias=keep_bias, mode='C'))
        prev_channels = wf
        self.down_scaling = nn.ModuleList()
        self.alpha = alpha
        self.nb = nb
        self.bUseMask = bUseMask


        mode = get_norm_layer(norm, act_mode, repeat)        
        match act_mode:
            case 'R':  
                # with torch.no_grad():
                    # y = F.relu(torch.randn(1024, 256).cuda()) 
                    # gamma = y.var(dim=1, keepdim=True)
                gain = 1.7139588594436646 #1.2716004848480225 
                    #gamma.mean(dim=0, keepdim=True)

            case 'L':
                # with torch.no_grad():
                    # y = F.leaky_relu(torch.randn(1024, 256).cuda()) 
                    # gamma = y.var(dim=1, keepdim=True)
                gain =  1.70590341091156 #gamma.mean(dim=0, keepdim=True)
            case 'E':
                # with torch.no_grad():
                    # y = F.elu(torch.randn(1024, 256).cuda()) 
                    # gamma = y.var(dim=1, keepdim=True)
                gain = 1.2716004848480225 
                    #gamma.mean(dim=0, keepdim=True)

        # expected_std = ((1.0+(2*(depth)+1)*nb*(alpha**2))**0.5)
        expected_std = (((1.0+nb*(alpha**2))**(depth+1))*(1.0+nb*depth*(alpha**2)))**0.5
        self.init_scaling = B.Scaling(expected_std)

        self.down_path.append(NFDownBlockFix(expected_std= expected_std, alpha = self.alpha, prev_channels= wf , wf = wf, downsample=False, 
                                          nb = nb, keep_bias=keep_bias, 
                                          mode=mode, type_init=type_init, block_type = 'NFblock', gain=gain)
                                          )


        list_expected_std_up = []
        list_expected_std_input = []


        for i in range(depth-1):
                        
            self.down_path.append(NFDownBlockFix(downsample_mode=downsample_mode, prev_channels= prev_channels, wf = wf*(2 ** (i+1)), alpha = self.alpha, expected_std = expected_std,
                                               nb = nb, keep_bias=keep_bias, mode=mode, type_init=type_init, block_type = 'NFblock', gain = gain)
                                               )                         
            expected_std = (expected_std **2 +  nb*(alpha**2))**0.5
            list_expected_std_input.append(expected_std)
            # list_expected_std_up.append((expected_std**2+(2*(depth-i)+1)*nb*(alpha**2))**0.5 )
            list_expected_std_up.append((((1.0+nb*(alpha**2))**(i+1))*(1.0+nb*depth*(alpha**2)))**0.5)
            # todo: add rescale
            self.down_scaling.append(B.Scaling(list_expected_std_up[-1])) 
            prev_channels = wf*(2 ** (i+1))
            
        expected_std = (expected_std ** 2 + alpha**2) ** 0.5

        self.up_path = nn.ModuleList()
    
        for i in reversed(range(depth-1)):
            # beta = 1./ expected_std
            self.up_path.append(NFUpBlock(expected_std= expected_std, alpha = self.alpha, upsample_mode=upsample_mode, 
                                            prev_channels= prev_channels, nb=nb,
                                            wf=wf*(2 ** i), keep_bias=keep_bias, mode=mode,type_init=type_init, 
                                            block_type = 'NFblock' , gain=gain, bUseComposition=bUseComposition
                                            ))
        
           


            prev_channels = wf*(2 ** i)
            expected_std = (expected_std **2 +  nb*(alpha**2))**0.5
        self.up_path.append(NFUpBlock(expected_std= expected_std, alpha = self.alpha, upsample = False, 
                                            prev_channels= wf, nb=nb,
                                            wf=wf, keep_bias=keep_bias, mode=mode,type_init=type_init, 
                                            block_type = 'NFblock' , gain=gain, bUseComposition=bUseComposition
                                            ))

        self.final = B.conv(wf, out_nc, bias=keep_bias, mode='C', type_init=type_init)
        # self.last_act = B.conv(mode=act_mode)
                  

    def forward(self, x):
        
        blocks = []
        xinit = x
        x_s = self.init_scaling(xinit)
        for i, down in enumerate(self.down_path):
            x_s = down(x_s)

            if i < len(self.down_path) - 1 and i > 0:
                blocks.append(x_s)

            if i > 0 and i < len(self.down_path) - 1:
                x_s = self.down_scaling[i-1](x_s)
     
                
        for i, up in enumerate(self.up_path):
                             
            
            if i == 0 : 
                x_s = up(x_s)
            else :
                x_s = up(self.alpha*x_s+ blocks[-i ])


        x_s = self.final(x_s)   

        return F.softplus(x_s)



class DIPModel(pl.LightningModule):
    '''
    Standard DRUNet model
    '''
    def __init__(self, 
                 model_name,  
                 pretrained=None, 
                 pretrained_checkpoint=None, 
                 
                 ):
        super().__init__()
        self.model_name = model_name   
        # self.model = UNET3D_simple(InstanceNorm=True, pos_out=True)
        self.model = NFUNetRes2(act_mode='R', nb=1, wf=8, depth=3)
       
               

        if pretrained:
            print('Loading pretrained model')
            checkpoint = torch.load(pretrained_checkpoint, map_location=self.device)
            state_dict = checkpoint['state_dict']
            new_state_dict = {}
            for key, val in state_dict.items():
                new_state_dict[key[6:]] = val
            self.model.load_state_dict(new_state_dict, strict=False)

    def forward(self, x):
        return self.model(x) 
   

def dynamic_knn_weights_multiply(x_mri, x_ref, k=3, neigh_max=1, sigma=1.0, normalize=True):
    """
    Compute the matrix-vector product of the top-k Gaussian weights with x_ref dynamically.

    Parameters:
    - x_mri: 3D PyTorch tensor (e.g., MRI volume).
    - x_ref: 3D PyTorch tensor (same shape as x_mri) to multiply with the weights.
    - k: Number of nearest neighbors to retain (default: 3).
    - neigh_max: Neighborhood range (default: 1, considering a 3x3x3 cube).
    - sigma: Standard deviation of the Gaussian kernel.
    - normalize: Whether to normalize weights so they sum to 1 for each voxel (default: True).

    Returns:
    - result: 3D PyTorch tensor resulting from the top-k sparse_weights @ x_ref.
    """
    device = x_mri.device
    offsets = torch.tensor([[di, dj, dk]
                            for di in range(-neigh_max, neigh_max + 1)
                            for dj in range(-neigh_max, neigh_max + 1)
                            for dk in range(-neigh_max, neigh_max + 1)
                            if not (di == 0 and dj == 0 and dk == 0)],
                           dtype=torch.long, device=device)

    shape = x_mri.shape
    result = torch.zeros_like(x_mri, device=device)
    weight_sums = torch.zeros_like(x_mri, device=device) if normalize else None

    # Track the top-k weights and indices for each voxel
    topk_weights = torch.full((k, *shape), -float('inf'), device=device)
    topk_contributions = torch.zeros((k, *shape), device=device)

    for offset in offsets:
        di, dj, dk = offset
        rolled_x_mri = torch.roll(x_mri, shifts=(di.item(), dj.item(), dk.item()), dims=(0, 1, 2))
        rolled_x_ref = torch.roll(x_ref, shifts=(di.item(), dj.item(), dk.item()), dims=(0, 1, 2))

        # Gaussian weights
        diff = x_mri - rolled_x_mri
        weights = torch.exp(-torch.square(diff) / (2 * sigma**2))

        # Identify top-k weights dynamically
        combined_weights = torch.cat([topk_weights, weights.unsqueeze(0)], dim=0)
        combined_contributions = torch.cat([topk_contributions, (weights * rolled_x_ref).unsqueeze(0)], dim=0)

        # Find the top-k weights and contributions for each voxel
        topk_indices = torch.argsort(combined_weights, dim=0, descending=True)[:k]
        topk_weights = torch.gather(combined_weights, 0, topk_indices)
        topk_contributions = torch.gather(combined_contributions, 0, topk_indices)

    # Aggregate top-k contributions
    result = topk_contributions.sum(dim=0)

    # Normalize if required
    if normalize:
        topk_weight_sums = topk_weights.sum(dim=0)
        result = result / (topk_weight_sums + 1e-10)

    return result

class MetaDIPModel(pl.LightningModule):
    '''
    Gradient Step Denoiser
    '''

    def __init__(self, hparams, bKernelLayer = False, 
                  neigh_max=None, weights_MR = None, indices_MR = None):
        super().__init__()

        self.save_hyperparameters(hparams)
 

        self.base = DIPModel(self.hparams.model_name, 
                                    pretrained = self.hparams.pretrained_student,
                                    pretrained_checkpoint = self.hparams.pretrained_checkpoint)
                
      
        
        self.train_MSE = torchmetrics.MeanSquaredError()
        self.scale_out = self.hparams.scale_out
        self.bKernelLayer = bKernelLayer
        self.neigh_max = neigh_max
        self.weights_MR = weights_MR
        self.indices_MR = indices_MR
        # print("bKernelLayer : ", self.bKernelLayer)





    def forward(self, x):

        x_p = self.base.forward(x)
        if self.bKernelLayer:
            x_kl =  matrix_free_vector_mult_vec(self.weights_MR, self.indices_MR , x_p.squeeze(), neigh_max=self.neigh_max).unsqueeze(0).unsqueeze(0)  
        else :
            x_kl = x_p

        x_hat = self.scale_out*x_kl

        return x_hat
        


    def lossfn(self, x, y): 

    
        criterion = nn.MSELoss(reduction='none')
        val = criterion(x.view(x.size()[0], -1), y.view(y.size()[0], -1)).mean(dim=1)


        return val
   
        
    def training_step(self, batch, batch_idx):
        # print("current global step : ", self.global_step)
        '''
        Training step
        :param batch: torch.tensor
        :param batch_idx: int
        :return: loss value
        '''
      
        #sum_labels = phantom
        x, y, mask = batch


        x = torch.unsqueeze(x, dim=1)
        y = torch.unsqueeze(y, dim=1)

        # y = y*self.hparams.rescale_input

        x_hat= self.forward(x)*mask

        loss = self.lossfn(x_hat,y) 
        loss = loss.mean()
        
        self.train_MSE.update(x_hat, y)
        self.log('train/train_loss', loss.detach(), on_step=True)

        
       
        img_out = x_hat.detach().cpu().numpy().squeeze()
        img_noisy = x.detach().cpu().numpy().squeeze()
        img_target = y.detach().cpu().numpy().squeeze()

        self.logger.experiment.add_figure('img_out', (PETLibs.display3D_1cbar(img_out, perc=0.7, close=False)), self.global_step, close=True)
        self.logger.experiment.add_figure('img_noisy', (PETLibs.display3D_1cbar(img_noisy, perc=0.7, close=False)),1, close=True)
        self.logger.experiment.add_figure('img_target', (PETLibs.display3D_1cbar(img_target, perc=0.7, close=False)), 1, close=True)
      

        return loss 

    def on_train_epoch_end(self):
        self.train_MSE.reset()
        # sch = self.lr_schedulers()
        # sch.step()  

    
    def configure_optimizers(self):
     
        
        optimizer = Adam(self.parameters(), lr=self.hparams.optimizer_lr)    
        #optimizer = LBFGS(self.parameters(), lr=self.hparams.optimizer_lr, max_iter=100)  
        #scheduler = lr_scheduler.MultiStepLR(optimizer,[2000, 4000, 6000, 8000], 0.5,verbose=False)
        
        return  optimizer #, [scheduler]

    
# tricks = pretraining, save opt state, lbfgs

def DIP_ADMM(subject,
             dset_object, 
             x0, 
             n0,
             nit_admm, 
             pnlt_beta, 
             device,
             hparams_NN,
             reconsParams=None, 
             evaluate = False,
             target=None,
             vmax=None, 
             vmin=None,
             verbose = False,
             bSaveModel = False,
             real=0,
             twriter=False,
             tlog_dir=None,
             phantom = None, 
             algo_prox = "em",
             scanner = "Biograph",
             bMRIInit = False,
             bKernelLayer = False,
             i_neigh_MR = 30, # 0-60
             neigh_max_MR = 2, # 1-3 
             sigma_MR = 0.5 # 0.01 - 5
             ):
  
    if scanner == "Biograph":
        if reconsParams is None:
            reconsParams=GPUBiographReconsParams()
        if not isinstance(reconsParams,GPUBiographReconsParams):
            raise TypeError("ReconsParams type is not GPUBiographReconsParams")
    elif scanner == "Signa":
        if reconsParams is None:
            reconsParams=GPUSignaReconsParams()
        if not isinstance(reconsParams,GPUSignaReconsParams):
            raise TypeError("ReconsParams type is not GPUSignaReconsParams")
    else:
        raise TypeError('Scanner type {0} not enforced'.format(scanner))
    if not isinstance(dset_object,database_doserec.tensorDataSetDoserecParams):
        raise TypeError("dset_object type is not torchPETADMM.database.database_doserec.tensorDataSetDoserecParams")

    doserec_object=dset_object.doserecParams
    bUseWeighted = False
    if twriter:
        writer=SummaryWriter(log_dir=tlog_dir)
    # hparams_dict={}
    # hparams_dict["subject"]=subject
    # hparams_dict["real"]=real
    # hparams_dict["nit_admm"]=nit_admm
    # hparams_dict["pnlt_beta"]=pnlt_beta
    # hparams2=copy.deepcopy(reconsParams.__dict__)
    # lst_delete=[]
    # dict_add={}
    # for key in hparams2.keys():
    #     if torch.is_tensor(hparams2[key]):
    #         lst_delete+=[key]
    #     elif isinstance(hparams2[key],list):
    #         lst_delete+=[key]
    #         print(f"list {key}")
    #         for k in range(len(hparams2[key])):
    #             new_k=f"{key}_{str(k)}"
    #             dict_add[new_k]=hparams2[key][k]
    # for key in lst_delete:
    #     del hparams2[key]
    # hparams_dict.update(hparams2)
    # hparams_dict.update(dict_add)
    fac_scale = 50 if bMRIInit else 1000
    hparams_NN["scale_out"] =  fac_scale

    
    i_n0,sum_n0=database_doserec.preprocess_data(n0,dset_object,device=device)
    xt_target= torch.reshape(torch.tensor(np.swapaxes(phantom,2,0),dtype=torch.float32, device = "cuda"),reconsParams.tb_im_dim)
    mask_phantom = np.where(phantom > 0, 1, 0)
    i_mask_phantom, _ = database_doserec.preprocess_data(mask_phantom,dset_object,device=device)


    if bKernelLayer:
        weights_MR, indices_MR =  dynamic_knn_weights_matrix(i_n0.squeeze(), nb_k= i_neigh_MR, neigh_max=neigh_max_MR, sigma=sigma_MR)
        if twriter:
            fig=PETLibs.utils.display3D_1cbar(x0,interpolation='none',perc=0.7)
            writer.add_figure("debug (x0)",fig,global_step=0,close=True)
            x_kl =  matrix_free_vector_mult_vec(weights_MR, indices_MR , database_doserec.preprocess_data(x0,dset_object,device=device)[0].squeeze(), neigh_max=neigh_max_MR)  
            fig=PETLibs.utils.display3D_1cbar(x_kl.cpu().numpy(),interpolation='none',perc=0.7)
            writer.add_figure("debug",fig,global_step=0,close=True)
        model = MetaDIPModel(hparams_NN, bKernelLayer=bKernelLayer, neigh_max=neigh_max_MR, weights_MR=weights_MR, indices_MR=indices_MR ).cuda()

    else:
        model = MetaDIPModel(hparams_NN).cuda()
 


    if twriter:
        fig=PETLibs.utils.display3D_1cbar(target,interpolation='none',vmax=vmax, vmin=vmin)
        writer.add_figure("target",fig,global_step=0,close=True)


    xt_mask_ph = torch.where(xt_target > 0, torch.tensor(1.0, dtype=torch.float32, device = "cuda"), torch.tensor(0.0, dtype=torch.float32, device = "cuda"))
    xt_mask_ph = np.swapaxes(xt_mask_ph.squeeze().cpu().numpy(),2,0)

    # n0=n0*xt_mask_ph


    opt_iter = hparams_NN["nb_epochs_init"]

    tb_logger = pl_loggers.TensorBoardLogger(tlog_dir, version="init", default_hp_metric=False) if twriter else None
    trainer = pl.Trainer(logger=tb_logger, detect_anomaly = False,  num_sanity_val_steps=0,
                            devices=1,  log_every_n_steps=1,
                            accelerator='cuda', 
                            max_epochs = opt_iter, 
                            enable_progress_bar=True, overfit_batches=1) 
    
    dm = DataModule(n0, x0, mask_phantom, dset_object.truncate)
    trainer.fit(model, dm)
    model = model.to(device)
    # save model state
    model_path = os.path.join(tlog_dir, f"model_0.ckpt")
    trainer.save_checkpoint(model_path)
    model.eval()
    v = model.forward(i_n0)*i_mask_phantom

    
    v=database_doserec.postprocess_data(v,sum_n0,dset_object, device=device,tensorFlag=False)

    

    x=x0
    # x is EM

    if twriter:
        fig=PETLibs.utils.display3D_1cbar(v,interpolation='none',perc=0.7)
        writer.add_figure("outNN0",fig,global_step=0,close=True)
        fig=PETLibs.utils.display3D_1cbar(x,interpolation='none',title="x0",vmax=vmax, vmin=vmin)
        writer.add_figure("x0",fig,global_step=0,close=True)

    u=0*x0
    xref=v  
    
    #Load sinograms
    castor_df_ima,castor_df_hdr=doserec_object.get_fname_sinogram_CASToR_hdr(subject,real)
    castor_df_dir=doserec_object.get_gen_castor_dir(subject,real)
    castor_df_hdr_fpath=os.path.join(castor_df_dir,castor_df_hdr)
    dict_sino=GPURecons.GPUCASToRSinos(castor_df_hdr_fpath, castor_df_dir,
                                            reconsParams=reconsParams)
    
   

    if evaluate:
        criterion = torch.nn.MSELoss()
        criterion_MAE = torch.nn.L1Loss()
        

        loss = criterion(torch.tensor(x0, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda")) 
        loss_phantom = criterion(torch.tensor(x0, dtype=torch.float32,device="cuda"), torch.tensor(phantom, dtype=torch.float32,device="cuda")) 
        loss_MAE = criterion_MAE(torch.tensor(x0, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
        
        mse = [loss.item()]
        mae = [loss_MAE.item()]


        if reconsParams.XYZ:

            x_XYZ=np.swapaxes(x,2,0)
            l = PETLibs.GPURecons.GPU_log_likelihood(x_XYZ, eps =0, reconsParams=reconsParams,
                                        dict_sino=dict_sino,eval_mode=True, bUseWeighted= bUseWeighted)
            del x_XYZ
        else:
            l = PETLibs.GPURecons.GPU_log_likelihood(x, eps =0, reconsParams=reconsParams,
                                        dict_sino=dict_sino,eval_mode=True, bUseWeighted= bUseWeighted)

        log_l = [l]
        norm1 = []
        norm2 = []
    else:
        mse = []
        mae = []
        log_l = []
        norm1 = []
        norm2 = []


    if twriter :
        writer.add_scalar("Loss/LogLikelihood",l,global_step=0)
        writer.add_scalar("Loss/MSE",loss.item(),global_step=0)
        writer.add_scalar("Loss/MSE_phantom",loss_phantom.item(),global_step=0)
        writer.add_scalar("Loss/MAE",loss_MAE.item(),global_step=0)

    for i in range(nit_admm):
        
        
        if verbose:
            print('Iteration {}:-------------------------------------------------------------------------------------------------------------'.format(i+1))
            print('Step 1:-------------------------------------------------------------------')

        if i > 0:
            x_old = x_ZYX

        if twriter :
            fig=PETLibs.utils.display3D_1cbar(xref,interpolation='none',title=f"x_in_prox_it{i+1}",perc=0.7)
            writer.add_figure("x_in_prox",fig,global_step=i+1,close=True)

        if reconsParams.XYZ:
            xprox=np.swapaxes(xref,2,0)
        else :
            xprox=xref
        if algo_prox == "em":
            x=GPURecons.GPUProxReconsDPEM(castor_df_hdr_fpath, castor_df_ima,
                    reconsParams=reconsParams,xprox=xprox,pnlt_beta=pnlt_beta,xstart=xstart if i> 0 else xprox,
                    dict_sino=dict_sino,eval_mode=True,verbose = False,show_step = False,
                    tensor_output=False, img_mask = xt_mask_ph, bUseWeighted = bUseWeighted) 
        
        elif algo_prox == "spdhg":
            x, list_init_dual=PETLibs.recons.GPUProxReconsSPDHG(castor_df_hdr_fpath, castor_df_ima,
                reconsParams=reconsParams,xprox=xprox,pnlt_beta=pnlt_beta,
                dict_sino=dict_sino,nb_iter=reconsParams.nit, 
                warm_start = True if i> 0 else False, list_init_dual = list_init_dual if i> 0 else [], xstart=xstart if i> 0 else None, 
                i_img_mask= xt_mask_ph, use_precond = False, bUseWeighted = bUseWeighted)
            
        elif algo_prox == "dbfb":
            x, list_init_dual =PETLibs.recons.GPUProxReconsDBFB(castor_df_hdr_fpath, castor_df_ima,
                reconsParams=reconsParams,xprox=xprox,pnlt_beta=pnlt_beta,
                dict_sino=dict_sino,nb_iter=reconsParams.nit, 
                warm_start = True if i> 0 else False, list_init_dual = list_init_dual if i> 0 else [],  
                i_img_mask= xt_mask_ph, use_precond = False)
        else :
            raise ValueError("algo_prox must be em, spdhg or dbfb")
        
        xstart=x
        if reconsParams.XYZ:
            x_ZYX=np.swapaxes(x,2,0)
        else:
            x_ZYX=x

         
        
        if twriter :
            fig=PETLibs.utils.display3D_1cbar(x_ZYX,interpolation='none',vmax=vmax, vmin=vmin)
            writer.add_figure("x",fig,global_step=i+1,close=True)



        if evaluate:
            if verbose:
                print('Evaluation Metric:-------------------------------------------------------------------')
            loss = criterion(torch.tensor(x_ZYX, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
            loss_phantom = criterion(torch.tensor(x_ZYX, dtype=torch.float32,device="cuda"), torch.tensor(phantom, dtype=torch.float32,device="cuda"))
            
            loss_MAE = criterion_MAE(torch.tensor(x_ZYX, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
            mae.append(loss_MAE.item())
            mse.append(loss.item())
            # 
            if verbose:
                print('Log Likelihood:-------------------------------------------------------------------')
            l = PETLibs.GPURecons.GPU_log_likelihood(x, eps =0,
                                    reconsParams=reconsParams,dict_sino=dict_sino,eval_mode=True, bUseWeighted = bUseWeighted)#Note here x and not X_ZYX
            log_l.append(l)
            if twriter :
                writer.add_scalar("Loss/MSE",loss.item(),i+1)
                writer.add_scalar("Loss/MSE_phantom",loss_phantom.item(),i+1)
                
                writer.add_scalar("Loss/MAE",loss_MAE.item(),i+1)
                writer.add_scalar("Loss/LogLikelihood",l,i+1)

        if verbose:
            print('Updating X:-------------------------------------------------------------------')
            print('Step 2:-------------------------------------------------------------------')

       
           
        model = model.to(device)
        
        tb_logger = pl_loggers.TensorBoardLogger(tlog_dir, version="iter_"+str(i), default_hp_metric=False) if twriter else None
        
        model_path = os.path.join(tlog_dir, f"model_{i}.ckpt") # le old model
        new_model_path = os.path.join(tlog_dir, f"model_{i+1}.ckpt")
        lr_monitor = LearningRateMonitor(logging_interval='step')
        checkpoint_callback = ModelCheckpoint(  
            dirpath=tlog_dir,  
            monitor="train/train_loss",  
            save_last=False, 
            mode = 'min',
            filename=f"model_{i+1}",        
            verbose=False  
            )    
        # early_stop_callback = EarlyStopping(
        #     monitor="train/train_loss",  
        #     patience=80,
        #     verbose=True,
        #     mode='min'
        # )
        

        if twriter :
            fig=PETLibs.utils.display3D_1cbar(x_ZYX-u,interpolation='none',perc=0.7)
            writer.add_figure("target_NN",fig,global_step=i+1,close=True)

            fig=PETLibs.utils.display3D_1cbar(x_ZYX,interpolation='none',perc=0.7)
            writer.add_figure("x_ZYX",fig,global_step=i+1,close=True)

            fig=PETLibs.utils.display3D_1cbar(u,interpolation='none',perc=0.7)
            writer.add_figure("u",fig,global_step=i+1,close=True)

            fig=PETLibs.utils.display3D_1cbar(n0,interpolation='none',perc=0.7)
            writer.add_figure("in_NN",fig,global_step=i+1,close=True)

        dm = DataModule(n0, x_ZYX-u, mask_phantom, dset_object.truncate)
        # check if model_path exists
        # if os.path.exists(model_path):
        #     trainer = pl.Trainer(logger=tb_logger, detect_anomaly = False,  num_sanity_val_steps=0,
        #                     devices=1,  log_every_n_steps=1,
        #                     accelerator='cuda', 
        #                     max_epochs = opt_iter, 
        #                     callbacks=[checkpoint_callback,lr_monitor,early_stop_callback],
        #                     enable_progress_bar=True, overfit_batches=1) 
        #     print("loading from checkpoint ",model_path)
        #     trainer.fit(model, dm, ckpt_path=model_path)
        # else :
        opt_iter += hparams_NN["nb_epochs"]
        if bSaveModel:
            trainer = pl.Trainer(logger=tb_logger, detect_anomaly = False,  num_sanity_val_steps=0,
                            devices=1,  log_every_n_steps=1,
                            accelerator='cuda', 
                            max_epochs = opt_iter, 
                            callbacks=[checkpoint_callback,lr_monitor],
                            enable_progress_bar=True, overfit_batches=1)
        else :
            trainer = pl.Trainer(logger=tb_logger, detect_anomaly = False,  num_sanity_val_steps=0,
                            devices=1,  log_every_n_steps=1,
                            accelerator='cuda', 
                            max_epochs = opt_iter, 
                            callbacks=[lr_monitor],
                            enable_progress_bar=True, overfit_batches=1)  
        trainer.fit(model, dm, ckpt_path=model_path)
        # model = model.to(device)
        # check if new_model_path exists, load from checkpoint and delete old checkpoint
        if os.path.exists(model_path):
            # print("loading from checkpoint ",new_model_path)
            # model = MetaDIPModel(hparams_NN, bKernelLayer=bKernelLayer, neigh_max=neigh_max_MR, weights_MR=weights_MR, indices_MR=indices_MR ).cuda()
            # model = MetaDIPModel.load_from_checkpoint(new_model_path, hparams=hparams_NN, bKernelLayer=bKernelLayer, neigh_max=neigh_max_MR, weights_MR=weights_MR, indices_MR=indices_MR)
            print("deleting checkpoint ",model_path)
            os.remove(model_path)

        # override weights of model with the ones from the best model
        # model = MetaDIPModel.load_from_checkpoint(new_model_path, hparams=hparams)
        # save model state
        
        trainer.save_checkpoint(new_model_path)

        model.eval()
        model = model.to(device)
 
        if evaluate:
            if verbose:
                print('Evaluation: ADMM CONVERGENCE--------------------------------------------------')
            

            if i > 0:
                primalN=np.linalg.norm(x_ZYX-v)
                dualN=np.linalg.norm(x_ZYX-x_old)
                var_v = np.linalg.norm(x_ZYX-x_old)**2/np.linalg.norm(v)**2
                var_x = np.linalg.norm(x_ZYX-v)**2/np.linalg.norm(x_ZYX)**2                


                norm1.append(primalN)
                norm2.append(dualN)
                if twriter :
                    writer.add_scalar("Accuracy/var_xv",var_x,i+1)
                    writer.add_scalar("Accuracy/var_x",var_v,i+1)
                    writer.add_scalar("Accuracy/scaled_NormPrimal",primalN/np.linalg.norm(v),i+1)
                    writer.add_scalar("Accuracy/scaled_NormDual",dualN/np.linalg.norm(v),i+1)
                    writer.add_scalar("Accuracy/NormPrimal",primalN,i+1)
                    writer.add_scalar("Accuracy/NormDual",dualN,i+1)




        if verbose:
            print('Step 3:-------------------------------------------------------------------')
        out = model.forward(i_n0)*i_mask_phantom
        out=database_doserec.postprocess_data(out,sum_n0,dset_object, device=device,tensorFlag=False)
        u = u - x_ZYX +  out
        

        if twriter :
            fig=PETLibs.utils.display3D_1cbar(u,interpolation='none',title=f"u_it{i+1}", perc=0.7) #,vmin=-vmax,vmax=vmax)
            writer.add_figure("u",fig,global_step=i+1,close=True)

            fig=PETLibs.utils.display3D_1cbar(out,interpolation='none',title=f"u_it{i+1}", perc=0.7) #,vmin=-vmax,vmax=vmax)
            writer.add_figure("outNN",fig,global_step=i+1,close=True)


        xref = out - u  

      


    return x_ZYX

