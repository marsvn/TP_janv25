"""
Created on March 2023

@author: florent.sureau
"""

import os,os.path
import numpy as np
import torch
import torchPETADMM.utils.normImage as normImage
import matplotlib.pyplot as plt
import copy,pickle
from interfile import Interfile
import PETLibs
from torchPETADMM.database import database_doserec,database_sino
import PETLibs.recons.GPURecons as GPURecons
import PETLibs.recons.CASToRRecons as CASToRRecons
import uuid
from tqdm.autonotebook import trange,tqdm
deviceGPU = torch.device("cuda")
deviceCPU = torch.device("cpu")
from PETLibs.recons.GPUReconsParams import GPUSignaReconsParams,GPUReconsParams, GPUBiographReconsParams
from PETLibs.recons.GPUReconsOps import GPUReconsOps
from PETLibs.recons.GPUReconsData import GPUCASToRSinos

def CASToR_EM_recons_dbase(subject, dbase_object, test_dir, CASToRParams=None,
                show = True, verbose = False,real=0):

    '''
    Applies OSEM reconstruction to the forward model sinogram.

    Arguments:
        - subject: subject name (string).
        - dbase_object: database descriptor (genSubDatabaseDoserecParams).
        - test_dir: directory used for saving and loading (string).
        - CASToRParams: parameters used for E (CASToRReconsParams, default:None ie default parameters for Biograph).
        - show: Displays the resulting images (boolean, default: True).
        - verbose: verbosity (boolean, default: False).
        - real: realization number (int, default: 0).

    Returns:
        - EM_image: Reconstructed OSEM image (numpy array).
    '''

    if CASToRParams is None:
        CASToRParams=PETLibs.recons.CASToRReconsParams()
    if not isinstance(CASToRParams,PETLibs.recons.CASToRReconsParams):
        raise TypeError("CASToRParams type is not PETLibs.recons.CASToRReconsParams ")
    if not isinstance(dbase_object,database_doserec.genSubDatabaseDoserecParams):
        raise TypeError("dbase_object type is not torchPETADMM.database.database_doserec.genSubDatabaseDoserecParams")

    castor_df_ima,castor_df_hdr=dbase_object.get_fname_sinogram_CASToR_hdr(subject,real)
    castor_df_dir=dbase_object.get_gen_castor_dir(subject,real)

    recons_vox_size=CASToRParams.vox_size_castor
    recons_dim=CASToRParams.im_dim_castor
    nit_EM=CASToRParams.nit

    if not os.path.exists(test_dir):
        os.makedirs(test_dir)
    im_rootname_EM=f"castorRecons_EM_{uuid.uuid4()}"

    hdr_EM_path,sto,ste=PETLibs.recons.CASToRRecons.CASTORReconsIm(castor_df_hdr, castor_df_dir,im_rootname_EM,test_dir,
                            CASToRParams=CASToRParams,verbose=verbose)
    hdr_EM=Interfile.load(os.path.join(test_dir,hdr_EM_path))
    EM_image,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(hdr_EM,test_dir)

    if os.path.exists(test_dir+"/"+im_rootname_EM+f"_it{nit_EM}.hdr"):
        os.remove(test_dir+"/"+im_rootname_EM+f"_it{nit_EM}.hdr")
    if os.path.exists(test_dir+"/"+im_rootname_EM+f"_it{nit_EM}.img"):
        os.remove(test_dir+"/"+im_rootname_EM+f"_it{nit_EM}.img")
    if os.path.exists(test_dir+"/"+im_rootname_EM+f".log"):
        os.remove(test_dir+"/"+im_rootname_EM+f".log")
    if os.path.exists(test_dir+"/"+im_rootname_EM+f"_img1.log"):
        os.remove(test_dir+"/"+im_rootname_EM+f"_img1.log")

    if show:
        _=PETLibs.utils.display3D(EM_image,interpolation='none')

    return EM_image

def CASToR_ProxEM_recons_dbase(subject, dbase_object, test_dir, CASToRParams=None,
                real=0,xprox=None,pnlt_beta=10,pnlt_params="1,0.000001,0,0", verbose = False,show = True):

    '''
    Applies OSEM reconstruction to the forward model sinogram.

    Arguments:
        - subject: subject name (string).
        - dbase_object: database descriptor (genSubDatabaseDoserecParams).
        - test_dir: directory used for saving and loading (string).
    Keyword Parameters:
        - CASToRParams: parameters used for reconstruction (CASToRReconsParams, default:None ie default parameters for Biograph)
        - real: realization number (int, default: 0).
        - xprox: point where prox is computed (np array of same size as output, default:None, ie 0 image).
        - pnlt_beta: hyperparameter weighting prox (float, default: 10)
        - pnlt_params: parameters for algorithm, corresponding to initial image value,
            denominator threshold, minimum image update,maximum image update (string, default: "1,0.000001,0,0")
        - verbose: verbosity (boolean, default:True).
        - show: Displays the resulting images (boolean, default: True).

    Returns:
        - EM_image: Reconstructed OSEM image (numpy array).
    '''

    if CASToRParams is None:
        CASToRParams=PETLibs.recons.CASToRReconsParams()
    if not isinstance(CASToRParams,PETLibs.recons.CASToRReconsParams):
        raise TypeError("CASToRParams type is not PETLibs.recons.CASToRReconsParams ")
    if not isinstance(dbase_object,database_doserec.genSubDatabaseDoserecParams):
        raise TypeError("dbase_object type is not torchPETADMM.database.database_doserec.genSubDatabaseDoserecParams")

    castor_df_ima,castor_df_hdr=dbase_object.get_fname_sinogram_CASToR_hdr(subject,real)
    castor_df_dir=dbase_object.get_gen_castor_dir(subject,real)

    recons_vox_size=CASToRParams.vox_size_castor
    recons_dim=CASToRParams.im_dim_castor
    nit_EM=CASToRParams.nit

    if not os.path.exists(test_dir):
        os.makedirs(test_dir)
    im_rootname_EM=f"castorRecons_ProxEM_{uuid.uuid4()}"

    im_prox_name=im_rootname_EM+"_prox_point.img"
    filepath_prox=os.path.join(test_dir,im_prox_name)
    if xprox is None:
        xprox=np.zeros(CASToRParams.im_dim)
    PETLibs.ios.writeInterfileImg(xprox,filepath_prox,pixsize=CASToRParams.vox_size,
        scanner="PET_SIEMENS_BIOGRAPH6_TRUEPOINT_TRUEV",patient_name="0",
        patient_id="0")
    hdr_EM_path,sto,ste=PETLibs.recons.CASToRRecons.CASTORReconsImProx(castor_df_hdr, castor_df_dir,
                            filepath_prox.replace(".img",".hdr"),im_rootname_EM,test_dir,CASToRParams=CASToRParams,
                            pnlt_beta=pnlt_beta,pnlt_params=pnlt_params,verbose=verbose)
    hdr_EM=Interfile.load(os.path.join(test_dir,hdr_EM_path))
    EM_image,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(hdr_EM,test_dir)

    if os.path.exists(filepath_prox):
        os.remove(filepath_prox)
        os.remove(filepath_prox.replace(".img",".hdr"))
    if os.path.exists(os.path.join(test_dir,f"{im_rootname_EM}_it{nit_EM}.hdr")):
        os.remove(os.path.join(test_dir,f"{im_rootname_EM}_it{nit_EM}.hdr"))
    if os.path.exists(os.path.join(test_dir,f"{im_rootname_EM}_it{nit_EM}.img")):
        os.remove(os.path.join(test_dir,f"{im_rootname_EM}_it{nit_EM}.img"))
    if os.path.exists(os.path.join(test_dir,f"{im_rootname_EM}.log")):
        os.remove(os.path.join(test_dir,f"{im_rootname_EM}.log"))
    if os.path.exists(os.path.join(test_dir,f"{im_rootname_EM}_img1.log")):
        os.remove(os.path.join(test_dir,f"{im_rootname_EM}_img1.log"))

    if show:
        _=PETLibs.utils.display3D(EM_image,interpolation='none')

    return EM_image

def GPU_EM_recons_dbase(subject, 
                        dbase_object, 
                        reconsParams=None,
                        show = True, 
                        verbose = False,
                        real=0, 
                        scanner = "Biograph"
                        ):

    '''
    Applies GPU EM reconstruction to the forward model sinogram.

    Arguments:
        - subject: subject name (string).
        - dbase_object: database descriptor (genSubDatabaseDoserecParams).
        - BiographParams: parameters used for EM (BiographReconsParams, default:None ie default parameters for Biograph).
        - show: Displays the resulting images (boolean, default: True).
        - verbose: verbosity (boolean, default: False).
        - real: realization number (int, default: 0).

    Returns:
        - EM_image: Reconstructed GPU EM image (numpy array, ZYX).
    '''

    if scanner == "Biograph":
        if reconsParams is None:
            reconsParams=GPUBiographReconsParams()
        if not isinstance(reconsParams,GPUBiographReconsParams):
            raise TypeError("ReconsParams type is not GPUBiographReconsParams")
    elif scanner == "Signa":
        if reconsParams is None:
            reconsParams=GPUSignaReconsParams()
        if not isinstance(reconsParams,GPUSignaReconsParams):
            raise TypeError("ReconsParams type is not GPUSignaReconsParams")
    else:
        raise TypeError('Scanner type {0} not enforced'.format(scanner))
    if not isinstance(dbase_object,database_doserec.genSubDatabaseDoserecParams):
        raise TypeError("dbase_object type is not torchPETADMM.database.database_doserec.genSubDatabaseDoserecParams")

    castor_df_ima,castor_df_hdr=dbase_object.get_fname_sinogram_CASToR_hdr(subject,real)
    castor_df_dir=dbase_object.get_gen_castor_dir(subject,real)
    castor_df_fpath=os.path.join(castor_df_dir,castor_df_hdr)
    EM_image=GPURecons.GPUEMRecons(castor_df_fpath,castor_df_dir,
                        reconsParams=reconsParams,verbose=verbose,xstart=None,
                        dict_sino=None,eval_mode=True,show_step=False)

    if show:
        _=PETLibs.utils.display3D(EM_image,interpolation='none')

    return EM_image


def CASToR_log_likelihood(subject,real, doserec_object, test_dir, x, eps = 1e-6,
    vox_size=[2.027,2.03642,2.03642],dict_sino=None,proj="joseph"):

    '''
    Calculates the log-likelihood of an image given the measured data.

    Arguments:
        - subject: subject name (string).
        - real: dose realization (int).
        - doserec_object: database descriptor (genSubDatabaseDoserecParams).
        - test_dir: directory used for saving and loading (string).
        - x: image of estimates (numpy array).
        - eps: Epsilon used to avoid singularities (default: 1e-6).
        - vox_size: voxel size (list of 3 int, default: [2.027,2.03642,2.03642]).
        - dict_sino: dictionary containing sinograms (dictionary of numpy arrays, default:None)
              if None, this will be read by CASToR_load_sinograms using the CASToR data file.
        - proj: name of projector (string, default: "joseph")

    Returns:
        - log_l: Log-likelihood (float).
        - y: Sinogram (numpy array).
    '''
    if dict_sino is None:
        dict_sino=database_sino.CASToR_load_sinograms(subject,real, doserec_object)
    else:
        print("RELOAD SINOS")

    x_path=test_dir+"/x.i"
    x_dir=test_dir
    x_hdr=x_path.replace('.i','.hdr')
    if os.path.exists(x_path):
        os.remove(x_path)
    if os.path.exists(x_hdr):
        os.remove(x_hdr)
    PETLibs.ios.CASToRInterfile.writeInterfileImg(x,x_path,pixsize=vox_size,
                          patient_name="0", patient_id="0",save_type=None,flip=False)


    sino_rootname="castorProj_noadd"

    if not os.path.exists(test_dir):
            os.makedirs(test_dir)
    fwd_proj_mult=PETLibs.proj.CASToRProj.CASTORFwdModel(x_hdr,x_dir,sino_rootname, test_dir,
                   nthr=32,proj=proj)
    if os.path.exists(test_dir+'/'+sino_rootname+'.log'):
        os.remove(test_dir+'/'+sino_rootname+'.log')

    fwd_proj = dict_sino["mult"]*fwd_proj_mult+dict_sino["add"]
    y=dict_sino["val"]
    #clipped_fwd_proj = np.clip(fwd_proj, eps, np.max(fwd_proj))
    #log_l = np.sum(y*np.log(clipped_fwd_proj)-clipped_fwd_proj)
    log_l = np.sum(y[fwd_proj>eps]*np.log(fwd_proj[fwd_proj>eps])-fwd_proj[fwd_proj>eps])
    return log_l, y


def GPU_log_likelihood(subject,
                       real,
                       doserec_object, 
                       x, 
                       eps = 1e-6,
                       reconsParams=None,
                       verbose = False,
                       dict_sino=None,
                       eval_mode=True, 
                       scanner = "Biograph"
                       ):

    '''
    Calculates the log-likelihood of an image given the measured data.

    Arguments:
        - subject: subject name (string), used if dict_sino is None.
        - real: dose realization (int, default 0), used if dict_sino is None..
        - doserec_object: database descriptor (genSubDatabaseDoserecParams).
        - x: image of estimates (torch tensor or np array).
        - eps: Epsilon used to avoid singularities (float, default: 0).
        - reconsParams: parameters used for EM (BiographReconsParams, default:None ie default parameters for Biograph).
        - verbose: verbosity (boolean, default: False).
        - dict_sino: dictionary containing sinograms (dictionary of tensors, default:None)
              if None, this will be read by GPUCASToRBiographSinos using the CASToR data file.
        - eval_mode: if evaluation mode or for training (boolean, default: True).

    Returns:
        - log_l: Log-likelihood (float).
    '''
    if scanner == "Biograph":
        if reconsParams is None:
            reconsParams=GPUBiographReconsParams()
        if not isinstance(reconsParams,GPUBiographReconsParams):
            raise TypeError("ReconsParams type is not GPUBiographReconsParams")
    elif scanner == "Signa":
        if reconsParams is None:
            reconsParams=GPUSignaReconsParams()
        if not isinstance(reconsParams,GPUSignaReconsParams):
            raise TypeError("ReconsParams type is not GPUSignaReconsParams")
    else:
        raise TypeError('Scanner type {0} not enforced'.format(scanner))
    if not isinstance(doserec_object,database_doserec.genSubDatabaseDoserecParams):
        raise TypeError("doserec_object type is not torchPETADMM.database.database_doserec.genSubDatabaseDoserecParams")
    if dict_sino is None:
        castor_df_ima,castor_df_hdr=doserec_object.get_fname_sinogram_CASToR_hdr(subject,real)
        castor_df_dir=doserec_object.get_gen_castor_dir(subject,real)
        cdh_name=os.path.join(castor_df_dir,castor_df_hdr)
        dict_sino=GPURecons.GPUCASToRSinos(cdh_name, castor_df_dir,reconsParams=reconsParams)

    reconsOps=GPURecons.GPUReconsOps(reconsParams)
    if eval_mode:
        fwd_func=reconsOps.forwardProj
    else:
        fwd_func=reconsOps.forwardProj_autograd

    nbsubset=max([1,reconsParams.nsubsets])
    

    y =  reconsParams.createSubsetData(dict_sino["val"])
    mult_array =  reconsParams.createSubsetData(dict_sino["mult"])
    add_array =  reconsParams.createSubsetData(dict_sino["add"])
    # sinomask =  BiographParams.createSubsetData(dict_sino["mask"])

    if not torch.is_tensor(x):
        tx=torch.tensor(np.ascontiguousarray(x),dtype=torch.float32,device=deviceGPU)
    else:
        tx=x.contiguous().cuda()
    tx=torch.reshape(tx,reconsParams.tb_im_dim)
    log_l = 0
    for i in range(nbsubset):
        

        if not torch.is_tensor(y[i]):
            ty=torch.tensor(y[i],dtype=torch.float32,device=deviceGPU)
        else:
            ty=y[i].cuda()
        # ty=torch.reshape(ty,BiographParams.tb_proj_dim)

        fwd=fwd_func(tx,mult_factor=mult_array[i],add_factor=add_array[i], subset=i)


        #clipped_fwd_proj = np.clip(fwd_proj, eps, np.max(fwd_proj))
        #log_l = np.sum(y*np.log(clipped_fwd_proj)-clipped_fwd_proj)
        log_l += torch.sum(ty[fwd>eps]*torch.log(fwd[fwd>eps])-fwd[fwd>eps]).item()
    return log_l

##################################################


def GPU_gradient(subject,
                 real,
                 doserec_object, 
                 x, 
                 eps = 1e-6,
                 reconsParams=None,
                 verbose = False,
                 dict_sino=None,
                 eval_mode=True, 
                 scanner="Biograph"
                 ):

    '''
    Calculates the log-likelihood of an image given the measured data.

    Arguments:
        - subject: subject name (string), used if dict_sino is None.
        - real: dose realization (int, default 0), used if dict_sino is None..
        - doserec_object: database descriptor (genSubDatabaseDoserecParams).
        - x: image of estimates (torch tensor or np array).
        - eps: Epsilon used to avoid singularities (float, default: 0).
        - reconsParams: parameters used for EM (BiographReconsParams, default:None ie default parameters for Biograph).
        - verbose: verbosity (boolean, default: False).
        - dict_sino: dictionary containing sinograms (dictionary of tensors, default:None)
              if None, this will be read by GPUCASToRBiographSinos using the CASToR data file.
        - eval_mode: if evaluation mode or for training (boolean, default: True).

    Returns:
        - log_l: Log-likelihood (float).
    '''
    if scanner == "Biograph":
        if reconsParams is None:
            reconsParams=GPUBiographReconsParams()
        if not isinstance(reconsParams,GPUBiographReconsParams):
            raise TypeError("ReconsParams type is not GPUBiographReconsParams")
    elif scanner == "Signa":
        if reconsParams is None:
            reconsParams=GPUSignaReconsParams()
        if not isinstance(reconsParams,GPUSignaReconsParams):
            raise TypeError("ReconsParams type is not GPUSignaReconsParams")
    else:
        raise TypeError('Scanner type {0} not enforced'.format(scanner))
    if not isinstance(doserec_object,database_doserec.genSubDatabaseDoserecParams):
        raise TypeError("doserec_object type is not torchPETADMM.database.database_doserec.genSubDatabaseDoserecParams")
    if dict_sino is None:
        castor_df_ima,castor_df_hdr=doserec_object.get_fname_sinogram_CASToR_hdr(subject,real)
        castor_df_dir=doserec_object.get_gen_castor_dir(subject,real)
        cdh_name=os.path.join(castor_df_dir,castor_df_hdr)
        dict_sino=GPURecons.GPUCASToRSinos(cdh_name, castor_df_dir,reconsParams=reconsParams)

    reconsOps=GPURecons.GPUReconsOps(reconsParams)
    if eval_mode:
        fwd_func=reconsOps.forwardProj
        bwd_func=reconsOps.backwardProj
    else:
        fwd_func=reconsOps.forwardProj_autograd
        bwd_func=reconsOps.backwardProj_autograd

    nbsubset=max([1,reconsParams.nsubsets])
    

    y =  reconsParams.createSubsetData(dict_sino["val"])
    mult_array =  reconsParams.createSubsetData(dict_sino["mult"])
    add_array =  reconsParams.createSubsetData(dict_sino["add"])
    sinomask =  reconsParams.createSubsetData(dict_sino["mask"])
    sen=reconsParams.computeSensitivityImages(sinomask,mult_factor=mult_array) #No need for autograd here 

    if not torch.is_tensor(x):
        tx=torch.tensor(np.ascontiguousarray(x),dtype=torch.float32,device=deviceGPU)
    else:
        tx=x.contiguous().cuda()
    tx=torch.reshape(tx,reconsParams.tb_im_dim)
    grad_img = torch.zeros_like(tx)
    for i in range(nbsubset):
        

        if not torch.is_tensor(y[i]):
            ty=torch.tensor(y[i],dtype=torch.float32,device=deviceGPU)
        else:
            ty=y[i].cuda()

        fwd=fwd_func(tx,mult_factor=mult_array[i],add_factor=add_array[i], subset=i)
        ratio = torch.where(fwd>0,torch.divide(ty,fwd),torch.tensor(1.0, dtype = torch.float32, device = "cuda")) #*sinomask
        bwd=bwd_func(ratio,mult_factor=mult_array[i],add_factor=0, subset=i)
        grad_img += sen[i]-bwd
    grad_img=np.swapaxes(np.squeeze(grad_img.cpu().numpy()),0,2)
    return grad_img
