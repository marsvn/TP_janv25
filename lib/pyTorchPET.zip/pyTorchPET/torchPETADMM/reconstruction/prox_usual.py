import torch
import numpy as np
import torch.nn.functional as F

forward = ([[[0., 0., 0.],
             [0, -1., 1.],
             [0., 0., 0.]],
            [[0., 0, 0.],
             [0., -1., 0.],
             [0., 1, 0.]]])
D = torch.tensor(forward).type(torch.FloatTensor).view(2,1,3,3).cuda()

backward = ([[[0., 0., 0.],
              [1, -1., 0.],
              [0., 0., 0.]],
             [[0., 1, 0.],
              [0., -1., 0.],
              [0., 0., 0.]]])
D_star = torch.tensor(backward).type(torch.FloatTensor).view(1,2,3,3).cuda()

def Prox_inf_inf(u,sigma):
    return sigma * torch.clamp(u/sigma,-1,1)

def Prox_inf_2(u,sigma):
    return u/torch.clamp(torch.sqrt(torch.sum(torch.mul(u,u),1,True))/sigma,1)

def Prox_1_2(u,sigma):
    Denominator = torch.sqrt(torch.sum(torch.mul(u,u),1,True))/sigma
    Denominator = torch.clamp(Denominator,min=1)
    return u - u/Denominator

def Prox_1_1(u,f,sigma):
    return f+torch.mul(torch.sign(u-f),F.relu(torch.abs(u-f)-sigma))

def Prox_1(u,sigma):
    return torch.mul(torch.sign(u),F.relu(torch.abs(u)-sigma))

def prox_l22(u, f, tau):
    return (u + tau*f)/(1+tau)


def prox_l1(u, f, tau):
    return f + np.maximum(0.0, np.abs(u-f)-tau)*np.sign(u-f)

def proj_inf_l2(p, tau):
    # size must be (K,N), l2 over K, inf over N
    norm_p = np.sqrt(np.sum(p**2, axis=0, keepdims=True))
    p /= np.maximum(1, norm_p/tau)
    return p

def proj_inf(p, tau):
    return np.clip(p, -tau, tau)

# primal dual for TV-l1
def tv_l1_pd(d, lamb=1.0, maxit=1000, norm = 1,check=100, verbose=0):
       
 

    # primal and dual step size
    # tau * sigma * L^2 = 1
    L = np.sqrt(8)
    tau = 1/L
    sigma = 1/tau/L**2
    theta = 1.0
    
   # t0 = time.time()
    E = []
    
    u =torch.zeros([1,1,torch.squeeze(d).size()[0],torch.squeeze(d).size()[1]]).cuda()
        
    p= torch.zeros(1,2,torch.squeeze(d).size()[0],torch.squeeze(d).size()[1]).cuda()


    for it in range(0,maxit):

        # remeber old
        u_ = u.clone()

        # primal update               
        u = u- tau*F.conv2d(p,D_star,padding=1)
             
        # proximal step
        if (norm == 1) :
            u = Prox_1_1(u,d,tau)
        else :
            u = prox_l22(u,d,tau)
    
        # overrelaxation
        u_ = u + theta*(u-u_)
        
        # dual update
        p += sigma*F.conv2d(u_,D,padding=1)
        
        # projection
        p = Prox_inf_2(p, lamb)
        
        TV1 = lamb * torch.sum(torch.abs(F.conv2d(u,D,padding=1)))
        energy = TV1 + (0.5*torch.sum(torch.mul(u-d,u-d)))
        
    
        E.append(energy)
        if verbose > 0:
            if it%check == check-1:
                

                print("iter = ", it,
                      ", tau = ", "{:.3f}".format(tau),
                      ", sigma = ", "{:.3f}".format(sigma),
                      #", time = ", "{:.3f}".format(time.time()-t0),
                      ", E = ", "{:.6f}".format(energy),
                      end="\r")
                
    return u
