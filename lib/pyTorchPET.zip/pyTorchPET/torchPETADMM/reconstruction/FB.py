import os
import numpy as np
import torch
import matplotlib.pyplot as plt
import copy
import PETLibs
import PETLibs.recons
import PETLibs.recons.GPURecons as GPURecons
# import torchPETADMM.utils.normImage as normImage
# import torchPETADMM.learning.jacobian as jacobian
# import torchPETADMM.learning.training as training
import torchPETADMM.reconstruction.EM as reconsEM
from torchPETADMM.database import database_doserec
from torch.utils.tensorboard import SummaryWriter
from torch.utils.tensorboard.summary import hparams as hparams_tb
from numpy import linalg as LA
from PETLibs.recons.GPUReconsParams import GPUSignaReconsParams,GPUReconsParams, GPUBiographReconsParams

def power_iteration(operator, vector_size, steps=10, momentum=0.0,
                        init_vec=None):
    '''
    Power iteration algorithm for spectral norm calculation
    requires a symmetric operator
    '''
    with torch.no_grad():
        if init_vec is None:
            vec = torch.rand(vector_size).cuda()
        else:
            vec = init_vec.cuda()


        vec /= torch.norm(vec.view(vector_size[0], -1), dim=1, p=2).view(vector_size[0], 1, 1, 1, 1)
        # mean = vec.view(vector_size[0], -1).mean(dim=1).view(vector_size[0], 1, 1, 1, 1)
        # norm0 = torch.norm((vec - mean).view(vector_size[0], -1), dim=1, p=2).view(vector_size[0], 1, 1, 1, 1)
        new_vec = vec

        for i in range(steps):
            vec = new_vec
            # mean = vec.view(vector_size[0], -1).mean(dim=1).view(vector_size[0], 1, 1, 1, 1)
            new_vec = operator(vec)
            new_vec = new_vec / torch.norm(new_vec.view(vector_size[0], -1), dim=1, p=2).view(vector_size[0], 1, 1, 1, 1)
            new_vec -= momentum * vec

    new_vec = operator(vec)

    
    div = torch.norm(vec.view(vector_size[0], -1), dim=1, p=2).view(vector_size[0], 1, 1, 1, 1)
    lambda_estimate = torch.abs(
        torch.sum(vec.view(vector_size[0], -1) * new_vec.view(vector_size[0], -1), dim=1)) / div

    return lambda_estimate.sqrt()

def GPU_FB(
        subject,dset_object, 
        z0, 
        nit_fb,
        lbd,
        epsilon, 
        tau, 
        model, 
        device,
        model_name,
        reconsParams=None,
        target=None,
        vmax=None, 
        vmin=None,
        real=0, 
        tlog_dir=None, 
        weight_Ds=1.0, 
        gamma=1e-3, 
        x_NN=None,
        x_EM = None,
        sigma_scale = None,
        max_iter_jacobian = 10, 
        algo_prox = "em", 
        phantom = None,
        prec = 5e-04,
        scanner = "Biograph"
        ):

    if scanner == "Biograph":
        if reconsParams is None:
            reconsParams=GPUBiographReconsParams()
        if not isinstance(reconsParams,GPUBiographReconsParams):
            raise TypeError("ReconsParams type is not GPUBiographReconsParams")
    elif scanner == "Signa":
        if reconsParams is None:
            reconsParams=GPUSignaReconsParams()
        if not isinstance(reconsParams,GPUSignaReconsParams):
            raise TypeError("ReconsParams type is not GPUSignaReconsParams")
    else:
        raise TypeError('Scanner type {0} not enforced'.format(scanner))
    if not isinstance(dset_object,database_doserec.tensorDataSetDoserecParams):
        raise TypeError("dset_object type is not torchPETADMM.database.database_doserec.tensorDataSetDoserecParams")

    doserec_object=dset_object.doserecParams

    eta = 0.9
    metric_dict={}
    criterion = torch.nn.MSELoss()

    #Create log directory   
    writer=SummaryWriter(log_dir=tlog_dir)
    hparams_dict={}
    hparams_dict["subject"]=subject
    hparams_dict["real"]=real
    hparams_dict["nit_fb"]=nit_fb
    hparams_dict["lambda"]=lbd
    hparams_dict["model"]=model_name
    hparams_dict["eps"]=epsilon
    hparams_dict["tau"]=tau
    hparams_dict["weight_Ds"]=weight_Ds
    hparams_dict["gamma"]=gamma
    hparams_dict["eta"]=eta
    hparams_dict["algo"]="fb"
    hparams2=copy.deepcopy(reconsParams.__dict__)
    lst_delete=[]
    dict_add={}
    for key in hparams2.keys():
        if torch.is_tensor(hparams2[key]):
            lst_delete+=[key]
        elif isinstance(hparams2[key],list):
            lst_delete+=[key]
            print(f"list {key}")
            for k in range(len(hparams2[key])):
                new_k=f"{key}_{str(k)}"
                dict_add[new_k]=hparams2[key][k]
    for key in lst_delete:
        del hparams2[key]
    hparams_dict.update(hparams2)
    hparams_dict.update(dict_add)

    #Load sinograms
    castor_df_ima,castor_df_hdr=doserec_object.get_fname_sinogram_CASToR_hdr(subject,real)
    castor_df_dir=doserec_object.get_gen_castor_dir(subject,real)
    castor_df_hdr_fpath=os.path.join(castor_df_dir,castor_df_hdr)
    dict_sino=GPURecons.GPUCASToRSinos(castor_df_hdr_fpath, castor_df_dir,
                                            reconsParams=reconsParams)
    fig=PETLibs.utils.display3D(z0,interpolation='none',title=f"z_init",vmax=vmax, vmin=vmin)
    writer.add_figure("z0",fig,global_step=0,close=True)
    plt.close(fig)

    fig=PETLibs.utils.display3D(x_EM,interpolation='none',title=f"EM",vmax=vmax, vmin=vmin)
    writer.add_figure("EM",fig,global_step=0,close=True)
    plt.close(fig)

    fig=PETLibs.utils.display3D(x_NN,interpolation='none',title=f"NN",vmax=vmax, vmin=vmin)
    writer.add_figure("NN_init",fig,global_step=0,close=True)
    plt.close(fig)

    xt_target= torch.reshape(torch.tensor(np.swapaxes(phantom,2,0),dtype=torch.float32, device = "cuda"),reconsParams.tb_im_dim)
    xt_mask_ph = torch.where(xt_target > 0, torch.tensor(1.0, dtype=torch.float32, device = "cuda"), torch.tensor(0.0, dtype=torch.float32, device = "cuda"))
    xt_mask_ph = np.swapaxes(xt_mask_ph.squeeze().cpu().numpy(),2,0)

    ########################################################

    loss = criterion(torch.tensor(x_NN, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
    if reconsParams.XYZ:
        x_XYZ=np.swapaxes(x_NN,2,0)
        lk = reconsEM.GPU_log_likelihood(subject,real,doserec_object, x_XYZ, eps =0, reconsParams=reconsParams,
                                    dict_sino=dict_sino,eval_mode=True)
        

        del x_XYZ

    else:
        lk = reconsEM.GPU_log_likelihood(subject,real,doserec_object, x_NN, eps =0, reconsParams=reconsParams,
                                    dict_sino=dict_sino,eval_mode=True)
                

   
    metric_dict["Loss/MSE_NN"]=loss.item()
    metric_dict["Loss/LogLikelihood_NN"]=lk
    writer.add_scalar("Loss/MSE_NN",loss.item(),0)
    writer.add_scalar("Loss/LogLikelihood_NN",lk,0)

    ########################################################

    loss = criterion(torch.tensor(x_EM, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
    if reconsParams.XYZ:
        x_XYZ=np.swapaxes(x_EM,2,0)
        lk = reconsEM.GPU_log_likelihood(subject,real,doserec_object, x_XYZ, eps =0, reconsParams=reconsParams,
                                    dict_sino=dict_sino,eval_mode=True)
        

        del x_XYZ

    else:
        lk = reconsEM.GPU_log_likelihood(subject,real,doserec_object, x_EM, eps =0, reconsParams=reconsParams,
                                    dict_sino=dict_sino,eval_mode=True)
                

   
    metric_dict["Loss/MSE_EM"]=loss.item()
    metric_dict["Loss/LogLikelihood_EM"]=lk
    writer.add_scalar("Loss/MSE_EM",loss.item(),0)
    writer.add_scalar("Loss/LogLikelihood_EM",lk,0)

    ########################################################

    # compute x0
    if reconsParams.XYZ:
        xprox=np.swapaxes(z0,2,0)
    else:
        xprox=z0

    if algo_prox == "em":
        x=GPURecons.GPUProxReconsDPEM(castor_df_hdr_fpath, castor_df_ima,
                reconsParams=reconsParams,xprox=xprox,pnlt_beta=1.0/tau,
                dict_sino=dict_sino,eval_mode=True,verbose = False,show_step = False,tensor_output=False, img_mask = xt_mask_ph)# x is np.array
    
    elif algo_prox == "spdhg":
        x, list_init_dual, _=PETLibs.recons.GPUProxReconsSPDHG(castor_df_hdr_fpath, castor_df_ima,
            reconsParams=reconsParams,xprox=xprox,pnlt_beta=1.0/tau,
            dict_sino=dict_sino,nb_iter=reconsParams.nit, 
            warm_start = True if i> 0 else False, list_init_dual = list_init_dual if i> 0 else [], 
            i_img_mask= xt_mask_ph, use_precond = False)
        
    elif algo_prox == "dbfb":
        x, list_init_dual, _ =PETLibs.recons.GPUProxReconsDBFB(castor_df_hdr_fpath, castor_df_ima,
            reconsParams=reconsParams,xprox=xprox,pnlt_beta=1.0/tau,
            dict_sino=dict_sino,nb_iter=reconsParams.nit, 
            warm_start = True if i> 0 else False, list_init_dual = list_init_dual if i> 0 else [],  
            i_img_mask= xt_mask_ph, use_precond = False)
    else :
        raise ValueError("algo_prox must be em, spdhg or dbfb")
    
    if reconsParams.XYZ:
        x_ZYX=np.swapaxes(x,2,0)
    else:
        x_ZYX=x

    # tau = tau/eta
    delta = epsilon + 1e-6

    fig=PETLibs.utils.display3D(target,interpolation='none',vmax=vmax, vmin=vmin)
    writer.add_figure("target",fig,global_step=0,close=True)
   
    i = 0
    s0 =LA.norm(x_ZYX) ** 2
    
    

     # compute likelihood
    if reconsParams.XYZ:
        x_XYZ=np.swapaxes(x_ZYX,2,0)  

        lk = reconsEM.GPU_log_likelihood(subject,real,doserec_object, x_XYZ, eps =0, reconsParams=reconsParams,
                                    dict_sino=dict_sino,eval_mode=True)
        
        del x_XYZ
    else:
        lk = reconsEM.GPU_log_likelihood(subject,real,doserec_object, x, eps =0, reconsParams=reconsParams,
                                    dict_sino=dict_sino,eval_mode=True)
        
    # if BiographParams.XYZ:
    #     x_ZYX=np.swapaxes(x,2,0)
    # else:
    #     x_ZYX=x

    loss = criterion(torch.tensor(x_ZYX, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
    writer.add_scalar("Loss/LogLikelihood",lk,global_step=0)
    writer.add_scalar("Loss/MSE",loss.item(),global_step=0)

    ## compute regularization
    n_image,sum_i=database_doserec.preprocess_data(x_ZYX,dset_object,device=device) 
    # model.eval()
    # torch.set_grad_enabled(True)
    n_image = n_image.to(device=device, dtype=torch.float32) #, requires_grad=True)
    sigma = torch.from_numpy(xt_mask_ph).to(device).unsqueeze(0).unsqueeze(0)
    if dset_object.truncate < sigma.shape[2]:
        t = sigma.shape[2] - dset_object.truncate
        sigma = sigma[:,:,t:,:,:]
    # n_image = n_image.requires_grad_()
    N = model.base.forward(n_image, sigma) #, None)
    # JN = torch.autograd.grad(N, n_image, grad_outputs=n_image - N, create_graph=True, only_inputs=True)[0]
    # torch.set_grad_enabled(False)
    # Dg = n_image - N - JN
    # Dx = n_image - weight_Ds * Dg
    # x0 = database_doserec.postprocess_data(Dx,sum_i,dset_object, device=device)
    Np = database_doserec.postprocess_data(N,sum_i,dset_object, device=device)
    t = x_ZYX - Np
    t = t.flatten()
    t = t ** 2
    t = np.sum(t)
    gx = 0.5 *t

    ## sum loss
    print("loss init", -lk + lbd*gx)
    print("datafit init",-lk)
    print("regularization init",lbd*gx)
    writer.add_scalar("Datafit",-lk,0)
    writer.add_scalar("Weighted Regularization",lbd*gx,0)
    writer.add_scalar("Total loss",-lk+lbd*gx,0)
    writer.add_scalar("tau",tau,0)
    writer.add_scalar("delta",delta,0)
    lk = -lk + lbd*gx
    linit = lk
    

    counter = 0

    # x_ZYX=x0
    fig=PETLibs.utils.display3D(x_ZYX,interpolation='none',title=f"x_init",vmax=vmax, vmin=vmin)
    writer.add_figure("x0",fig,global_step=0,close=True)

    fig=PETLibs.utils.display3D(x_ZYX,interpolation='none',title=f"x_it{0}",vmax=vmax, vmin=vmin)
    writer.add_figure("x",fig,global_step=0,close=True)

    while i <nit_fb and delta > epsilon:
        print("#########################################################")
        print(f"i={i} over {nit_fb}") 
        print("#########################################################")
        
        xprec = x_ZYX
        lprec = lk

        print("computing spectral norm")

        
        backtracking_check = False

        grad= reconsEM.GPU_gradient(subject,real,doserec_object, np.swapaxes(xprec,2,0), eps =0, reconsParams=reconsParams,
                                            dict_sino=dict_sino,eval_mode=True)

        
        ## Update zk = lambda*tau*Dxk + (1-lambda*tau)*xk
        n_image,sum_i=database_doserec.preprocess_data(x_ZYX,dset_object,device=device)  
        sigma = torch.from_numpy(xt_mask_ph).to(device).unsqueeze(0).unsqueeze(0)
        if dset_object.truncate < sigma.shape[2]:
            t = sigma.shape[2] - dset_object.truncate
            sigma = sigma[:,:,t:,:,:]
        fig=PETLibs.utils.display3D(n_image.cpu().squeeze(),interpolation='none',vmax=vmax, vmin=vmin)
        writer.add_figure("preNN",fig,global_step=i+1,close=True)
        torch.set_grad_enabled(True)
        n_image = n_image.to(device=device, dtype=torch.float32) #, requires_grad=True)
        n_image = n_image.requires_grad_()
        Dg, N = model.calculate_grad(n_image, sigma) 
        operator = lambda vec: torch.autograd.grad(Dg, n_image, grad_outputs=vec, create_graph=True, retain_graph=True, only_inputs=True)[0]
        z = power_iteration(operator, n_image.size(), max_iter_jacobian) 
        # JN = torch.autograd.grad(N, n_image, grad_outputs=n_image - N, create_graph=True, only_inputs=True)[0]
        torch.set_grad_enabled(False)
        writer.add_scalar("Spectral norm",z.detach(),i+1)
        # Dg = n_image.detach() - N.detach() - JN.detach()
        Dx = n_image.detach() - weight_Ds * Dg.detach()
        grad = grad*xt_mask_ph


        fig=PETLibs.utils.display3D(Dx.cpu().squeeze(),interpolation='none',vmax=vmax, vmin=vmin)
        writer.add_figure("postNN",fig,global_step=i+1,close=True)

        fig=PETLibs.utils.display3D((Dx-n_image).cpu().squeeze(),interpolation='none',perc=0.7)
        writer.add_figure("difftNN",fig,global_step=i+1,close=True)

        fig=PETLibs.utils.display3D(grad.squeeze()/lbd,interpolation='none',perc=0.7)
        writer.add_figure("gradNN",fig,global_step=i+1,close=True)
        Dx = database_doserec.postprocess_data(Dx,sum_i,dset_object, device=device) 
        
        sub_counter = 0

        while not backtracking_check:


            counter += 1
            
            zk = lbd*tau*Dx + (1-lbd*tau)*x_ZYX
            fig=PETLibs.utils.display3D(zk,interpolation='none',title=f"z_it{i+1}_sub{sub_counter}",vmax=vmax, vmin=vmin)
            writer.add_figure("zi",fig,global_step=counter,close=True)

            ## Update xk+1 = argmin_x 1/2*||x-zk||^2 + lbd*f(x)
            
            if reconsParams.XYZ:
                xprox=np.swapaxes(zk,2,0)
            else:
                xprox=zk
            # x=GPURecons.GPUBiographProxRecons(castor_df_hdr_fpath, castor_df_ima,
            #         BiographReconsParams=BiographParams,xprox=xprox,pnlt_beta=1.0/tau,
            #         dict_sino=dict_sino,eval_mode=True,verbose = False,show_step = False,tensor_output=False)# x is np.array
            
            if algo_prox == "em":
                x=GPURecons.GPUProxReconsDPEM(castor_df_hdr_fpath, castor_df_ima,
                        reconsParams=reconsParams,xprox=xprox,pnlt_beta=1.0/tau,
                        dict_sino=dict_sino,eval_mode=True,verbose = False,show_step = False,tensor_output=False, img_mask = xt_mask_ph)# x is np.array
            
            elif algo_prox == "spdhg":
                x, list_init_dual, _=PETLibs.recons.GPUProxReconsSPDHG(castor_df_hdr_fpath, castor_df_ima,
                    reconsParams=reconsParams,xprox=xprox,pnlt_beta=1.0/tau,
                    dict_sino=dict_sino,nb_iter=reconsParams.nit, 
                    warm_start = True if sub_counter> 0 else False, list_init_dual = list_init_dual if sub_counter> 0 else [], xstart=xstart if sub_counter> 0 else None, 
                    i_img_mask= xt_mask_ph, use_precond = False)
                
            elif algo_prox == "dbfb":
                x, list_init_dual, _ =PETLibs.recons.GPUProxReconsDBFB(castor_df_hdr_fpath, castor_df_ima,
                    reconsParams=reconsParams,xprox=xprox,pnlt_beta=1.0/tau,
                    dict_sino=dict_sino,nb_iter=reconsParams.nit, 
                    warm_start = True if sub_counter> 0 else False, list_init_dual = list_init_dual if sub_counter> 0 else [],  
                    i_img_mask= xt_mask_ph, use_precond = False)
            else :
                raise ValueError("algo_prox must be em, spdhg or dbfb")
            
            if reconsParams.XYZ:
                x_ZYX=np.swapaxes(x,2,0)
            else:
                x_ZYX=x

            print("compute likelihood")
            if reconsParams.XYZ:
                # x_XYZ=np.swapaxes(x,2,0)
                
                lk = reconsEM.GPU_log_likelihood(subject,real,doserec_object, x, eps =0, reconsParams=reconsParams,
                                            dict_sino=dict_sino,eval_mode=True)
                
                # del x_XYZ
                # x_ZYX=np.swapaxes(x,2,0)
    
            else:
                # x_ZYX=x
                # lprec = lk
                lk = reconsEM.GPU_log_likelihood(subject,real,doserec_object, x, eps =0, reconsParams=reconsParams,
                                            dict_sino=dict_sino,eval_mode=True)
                
            ## compute regularization
            n_image,sum_i=database_doserec.preprocess_data(x_ZYX,dset_object,device=device)
            sigma = torch.from_numpy(xt_mask_ph).to(device).unsqueeze(0).unsqueeze(0)
            if dset_object.truncate < sigma.shape[2]:
                t = sigma.shape[2] - dset_object.truncate
                sigma = sigma[:,:,t:,:,:]
            # torch.set_grad_enabled(True)
            n_image = n_image.to(device=device, dtype=torch.float32)
            # n_image = n_image.requires_grad_()
            N = model.base.forward(n_image , sigma) #, None)
            # JN = torch.autograd.grad(N, n_image, grad_outputs=n_image - N, create_graph=True, only_inputs=True)[0]
            # torch.set_grad_enabled(False)
            #Dg = n_image.detach() - N.detach() - JN.detach()
            # Dx = n_image - weight_Ds * Dg
            # Dx = database_doserec.postprocess_data(Dx,sum_i,dset_object, device=device)
            Np = database_doserec.postprocess_data(N.detach(),sum_i,dset_object, device=device)
            t = x_ZYX - Np
            t = t.flatten()
            t = t ** 2
            t = np.sum(t)
            # gprec = gx
            gx = 0.5 *t

            ## sum loss
            writer.add_scalar("Datafit",-lk,counter)
            writer.add_scalar("Weighted Regularization",lbd*gx,counter)
            writer.add_scalar("Total loss",-lk+lbd*gx,counter)

            writer.add_scalar("tau",tau,counter)
            writer.add_scalar("delta",delta,counter)

            # print("regularization",lbd*gx)
            # print("likelihood",-lk)
            KL = lk
            
            lk = -lk + lbd*gx
            
            # print("total loss",lk)
            # lprec = lprec + lbd*gprec

            writer.add_scalar("debug/right_side",(gamma/tau)*LA.norm(xprec-x_ZYX)**2,counter)
            writer.add_scalar("debug/left_side",lprec -lk,counter)
            print("right side",(gamma/tau)*LA.norm(xprec-x_ZYX)**2)
            print("left side",np.abs(lprec -lk))

            ## Update parameters
            if (np.abs(lprec -lk) < (gamma/tau)*LA.norm(xprec-x_ZYX)**2) :
                print("UPDATE tau ",tau)
                print("continue backtracking with xprec")
                tau = eta*tau
                x_ZYX = xprec
                backtracking_check = False
            else:
                print("linit",linit)
                print("lk",lk)
                print("lprec",lprec)
                print("UPDATE delta ",delta, 'by ', (lprec-lk)/linit,' precision ',epsilon)
                delta  = np.abs((lprec-lk)/linit)
                
                
                backtracking_check = True
                
    
            fig=PETLibs.utils.display3D(x_ZYX,interpolation='none',title=f"x_it{i+1}_sub{sub_counter}",vmax=vmax, vmin=vmin)
            writer.add_figure("xi",fig,global_step=counter,close=True)
            sub_counter += 1
            xstart = x
        
        print("delta",delta)
        print("epsilon",epsilon)
        print("precision",prec)
        print(LA.norm(x_ZYX - xprec)/LA.norm(x_ZYX) )
        writer.add_scalar("Loss/Loss",lk, global_step=i+1)
        fig=PETLibs.utils.display3D(x_ZYX,interpolation='none',vmax=vmax, vmin=vmin)
        writer.add_figure("x",fig,global_step=i+1,close=True)
        writer.add_scalar("Loss/residual",LA.norm(x_ZYX - xprec) ** 2/s0,global_step=i+1)
        writer.add_scalar("Loss/scaled_NormPrimal",LA.norm(x_ZYX - xprec)/LA.norm(x_ZYX),global_step=i+1)

        if LA.norm(x_ZYX - xprec)/LA.norm(x_ZYX) < prec:
            print("convergence reached")
            break
        i = i+1
        criterion = torch.nn.MSELoss()
        loss = criterion(torch.tensor(x_ZYX, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
        writer.add_scalar("Loss/LogLikelihood",KL,global_step=i+1)
        writer.add_scalar("Loss/MSE",loss.item(),global_step=i+1)
        plt.close('all')
        # exp,ssi,_=hparams_tb(hparam_dict=hparams_dict) #,metric_dict=metric_dict)
    # writer.file_writer.add_summary(exp)
    # writer.file_writer.add_summary(ssi)
            
            
    ## Update final = lambda*tau*Dxk + (1-lambda*tau)*xk
    n_image,sum_i=database_doserec.preprocess_data(x_ZYX,dset_object,device=device) #n_image is tensor
    sigma = torch.from_numpy(xt_mask_ph).to(device).unsqueeze(0).unsqueeze(0)
    if dset_object.truncate < sigma.shape[2]:
        t = sigma.shape[2] - dset_object.truncate
        sigma = sigma[:,:,t:,:,:]
    torch.set_grad_enabled(True)
    n_image = n_image.to(device=device, dtype=torch.float32) #, requires_grad=True)
    n_image = n_image.requires_grad_()
    Dg, N = model.calculate_grad(n_image, sigma)
    # JN = torch.autograd.grad(N, n_image, grad_outputs=n_image - N, create_graph=True, only_inputs=True)[0]
    torch.set_grad_enabled(False)
    # Dg = n_image.detach() - N.detach() - JN.detach()
    Dx = n_image.detach() - weight_Ds * Dg.detach() 
    Dx = database_doserec.postprocess_data(Dx,sum_i,dset_object, device=device) 
    # Np = database_doserec.postprocess_data(N,sum_i,dset_object, device=device) 
    # t = x_ZYX - Np
    # t = t.flatten()
    # t = t ** 2
    # t = np.sum(t)
    # gprec = 0.5 * t
    
    final = x_ZYX #lbd*tau*Dx + (1-lbd*tau)*x_ZYX 
    #fig=PETLibs.utils.display3D(final,interpolation='none',title=f"x_it{i+1}",vmax=vmax, vmin=vmin)
    #writer.add_figure("x",fig,global_step=nit_fb+1,close=True)
    print("#########################################################")
    print("END OF RECONSTRUCTION") 
    print("#########################################################")
    
    loss = criterion(torch.tensor(final, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
    if reconsParams.XYZ:
        x_XYZ=np.swapaxes(final,2,0)
        lk = reconsEM.GPU_log_likelihood(subject,real,doserec_object, x_XYZ, eps =0, reconsParams=reconsParams,
                                    dict_sino=dict_sino,eval_mode=True)
        

        del x_XYZ

    else:
        lk = reconsEM.GPU_log_likelihood(subject,real,doserec_object, final, eps =0, reconsParams=reconsParams,
                                    dict_sino=dict_sino,eval_mode=True)
                

   
    metric_dict["Loss/MSE"]=loss.item()
    metric_dict["Loss/LogLikelihood"]=lk

    ## compute regularization
    n_image,sum_i=database_doserec.preprocess_data(final,dset_object,device=device) 
    sigma = torch.from_numpy(xt_mask_ph).to(device).unsqueeze(0).unsqueeze(0)
    if dset_object.truncate < sigma.shape[2]:
        t = sigma.shape[2] - dset_object.truncate
        sigma = sigma[:,:,t:,:,:]
    n_image = n_image.to(device=device, dtype=torch.float32)
    N = model.base.forward(n_image, sigma) 
    Np = database_doserec.postprocess_data(N.detach(),sum_i,dset_object, device=device)
    t = final - Np
    t = t.flatten()
    t = t ** 2
    t = np.sum(t)
    gx = 0.5 *t   

    metric_dict["Total loss"]=-lk+lbd*gx
    # exp,ssi,_=hparams_tb(hparam_dict=hparams_dict,metric_dict=metric_dict)
    # writer.file_writer.add_summary(exp)
    # writer.file_writer.add_summary(ssi)
           
    writer.close()

    return metric_dict
