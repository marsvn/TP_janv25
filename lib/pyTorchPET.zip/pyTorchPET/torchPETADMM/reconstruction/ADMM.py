"""
Created on March 2023

@author: florent.sureau
"""

import os
from PETLibs import CASToRReconsParams
import numpy as np
import torch
import matplotlib.pyplot as plt
import copy
import time
import PETLibs
import PETLibs.recons
import PETLibs.recons.GPURecons as GPURecons
import torchPETADMM.learning.jacobian as jacobian
import torchPETADMM.learning.training as training
import torchPETADMM.utils.normImage as normImage
import torchPETADMM.reconstruction.EM as reconsEM
from torchPETADMM.database import database_doserec,database_sino
import torchmetrics
from torchmetrics.image.lpip import LearnedPerceptualImagePatchSimilarity
from torchmetrics import Metric
import torch.nn.functional as F
from PETLibs.recons.GPUReconsParams import GPUSignaReconsParams,GPUBiographReconsParams, GPUReconsParams
from PETLibs.recons.GPUReconsOps import GPUReconsOps
from PETLibs.recons.GPUReconsData import GPUCASToRSinos
# from tqdm.autonotebook import trange,tqdm
from torch.utils.tensorboard import SummaryWriter
from torch.utils.tensorboard.summary import hparams as hparams_tb
from torch import nn
import math
import numbers


class GaussianSmoothing(nn.Module):
    """
    Apply gaussian smoothing on a
    1d, 2d or 3d tensor. Filtering is performed seperately for each channel
    in the input using a depthwise convolution.
    Arguments:
        channels (int, sequence): Number of channels of the input tensors. Output will
            have this number of channels as well.
        kernel_size (int, sequence): Size of the gaussian kernel.
        sigma (float, sequence): Standard deviation of the gaussian kernel.
        dim (int, optional): The number of dimensions of the data.
            Default value is 2 (spatial).
    """
    def __init__(self, channels, kernel_size, sigma, dim=2):
        super(GaussianSmoothing, self).__init__()
        if isinstance(kernel_size, numbers.Number):
            kernel_size = [kernel_size] * dim
        if isinstance(sigma, numbers.Number):
            sigma = [sigma] * dim
            #you should smooth with a Gaussian filter approximately three times the size of your voxel.

        # The gaussian kernel is the product of the
        # gaussian function of each dimension.
        kernel = 1
        meshgrids = torch.meshgrid(
            [
                torch.arange(size, dtype=torch.float32)
                for size in kernel_size
            ]
        )
        for size, std, mgrid in zip(kernel_size, sigma, meshgrids):
            mean = (size - 1) / 2
            kernel *= 1 / (std * math.sqrt(2 * math.pi)) * \
                      torch.exp(-((mgrid - mean) / std) ** 2 / 2)

        # Make sure sum of values in gaussian kernel equals 1.
        kernel = kernel / torch.sum(kernel)

        # Reshape to depthwise convolutional weight
        kernel = kernel.view(1, 1, *kernel.size())
        kernel = kernel.repeat(channels, *[1] * (kernel.dim() - 1))

        self.register_buffer('weight', kernel)
        self.groups = channels

        if dim == 1:
            self.conv = F.conv1d
        elif dim == 2:
            self.conv = F.conv2d
        elif dim == 3:
            self.conv = F.conv3d
        else:
            raise RuntimeError(
                'Only 1, 2 and 3 dimensions are supported. Received {}.'.format(dim)
            )

    def forward(self, input):
        """
        Apply gaussian filter to input.
        Arguments:
            input (torch.Tensor): Input to apply gaussian filter on.
        Returns:
            filtered (torch.Tensor): Filtered output.
        """
        return self.conv(input, weight=self.weight, groups=self.groups, padding=2)



def sigma2fwhm(sigma):
     return sigma * np.sqrt(8 * np.log(2))


def fwhm2sigma(fwhm):
    return fwhm / np.sqrt(8 * np.log(2))



class LearnedPerceptualImagePatchSimilarity3D(Metric):
    def __init__(self):
        super().__init__()
        self.add_state("axial_metric", default=torch.tensor(0))
        self.add_state("sag_metric", default=torch.tensor(0))
        self.add_state("cor_metric", default=torch.tensor(0))

    def update(self, i_preds: torch.Tensor, i_target: torch.Tensor):
    
        # print(i_preds.shape)
        # print(i_target.shape)
        criterion = LearnedPerceptualImagePatchSimilarity(net_type='vgg', normalize=True).to(i_preds.device)
        assert i_preds.shape == i_target.shape
        preds = (i_preds.detach()/i_target.detach().max())
        target = (i_target.detach()/i_target.detach().max())
        preds = preds.clamp(0,1)
        assert(preds.max()<=1 and preds.min()>=0)
        assert(target.max()<=1 and target.min()>=0)
        preds = preds.unsqueeze(0).unsqueeze(0)
        target = target.unsqueeze(0).unsqueeze(0)
        # print(preds.shape)
        # print(target.shape)
        self.axial_metric = torch.tensor([criterion(preds[:,0,i,:,:].squeeze().view(-1, 1, preds.shape[3], preds.shape[4]).expand(preds.shape[0],3,-1,-1), target[:,0,i,:,:].squeeze().view(-1, 1, preds.shape[3], preds.shape[4]).expand(preds.shape[0],3,-1,-1)).mean() for i in range(preds.shape[2])]).mean()
        self.sag_metric = torch.tensor([criterion(preds[:,0,:,i,:].squeeze().view(-1, 1, preds.shape[2], preds.shape[4]).expand(preds.shape[0],3,-1,-1), target[:,0,:,i,:].squeeze().view(-1, 1, preds.shape[2], preds.shape[4]).expand(preds.shape[0],3,-1,-1)).mean() for i in range(preds.shape[3])]).mean()
        self.cor_metric = torch.tensor([criterion(preds[:,0,:,:,i].squeeze().view(-1, 1, preds.shape[2], preds.shape[3]).expand(preds.shape[0],3,-1,-1), target[:,0,:,:,i].squeeze().view(-1, 1, preds.shape[2], preds.shape[3]).expand(preds.shape[0],3,-1,-1)).mean() for i in range(preds.shape[4])]).mean()


    def compute(self):
        return (self.axial_metric.float()+ self.sag_metric.float()+ self.cor_metric.float())/3.0
    



def ADMM(subject,dset_object,test_dir, xref, u0,nit_admm, pnlt_beta, model, device,
         CASToRParams=None, pnlt_params="1,0.000001,0,0", evaluate = False,target=None,
         count = False, show_initial = False, show_x = "all", show_v = False,
         show_u = False, show_target = True, show_metrics = True,
         verbose = False,real=0):
    '''
    Applies the Alternating Direction Method of Multipliers using an input image and a reference image.
    The Reconstruction step is performed using a Proximal Method from CASToR, the denoising step is performed using a trained neural network.
    The algorithm is evaluated using Log-Likelihood, MSE, Square Jacobian Spectral Norm, Primal and Dual Residuals.
    The algorithm is initialized as a Douglas-Rachford algorithm, ie v^{(0)}=NN(xref), u^{(0)}=xref-v^{(0)}
    where v^{(0)-u^{(0)} are used for the reference point used in the first subproblem in ADMM.


    Arguments:
        - subject: subject name (string).
        - dset_object: data set descriptor (tensorDataSetDoserecParams).
        - test_dir: directory used for saving and loading (string).
        - xref: Initial reference image for first step (x0+u0 in DR).
        - u0: Initial u image (Result of the 2nd step).
        - nit_admm: Number of ADMM iterations (int).
        - pnlt_beta: Proximal Method Beta/Rho.
        - model: Neural Network model.
        - device: Device used for prediction (Possible values: "cpu", "gpu").
        - CASToRParams: parameters used for 1st subproblem - prox (CASToRReconsParams, default:None ie default parameters for Biograph).
        - pnlt_params: parameters for algorithm, corresponding to initial image value,
            denominator threshold, minimum image update,maximum image update (string, default: "1,0.000001,0,0")
        - evaluate: compute metrics (Default value: False)
        - target: target image to compute metrics (Default value: None).
        - count: Counts the time taken for every iteration (Default value: False).
        - show_initial: Displays the initial inputs (Default value: False).
        - show_x: Displays the x image every iteration (Default value: "all")
        - show_v: Displays the v image every iteration (Default value: False)
        - show_u: Displays the u image every iteration (Default value: False)
        - show_target: Displays the target image (Default value: True).
        - show_metrics: Plots True,  (Default value: True)
        - truncate: Truncates the images' first dimension for neural network
                    (int, so that zrange=data_x.shape[1]-truncate, defqult: 104).
        - verbose: verbosity (Default value: False)

    Returns: dictionary with following key:values
        x: x image.
        x_all: All x images.
        v: v image.
        v_all: All v images.
        u: u image.
        u_all: All u images.
        mse: Mean Squared Error.
        reg: Square Jacobian Spectral Norm.
        log_l: Log-Likelihood
        norm1: Primal Residual.
        norm2: Dual Residual.
        all_time: Time taken for every iteration.
    '''

    if CASToRParams is None:
        CASToRParams=CASToRReconsParams()
    if not isinstance(CASToRParams,PETLibs.recons.CASToRReconsParams):
        raise TypeError("CASToRParams type is not PETLibs.recons.CASToRReconsParams ")
    if not isinstance(dset_object,database_doserec.tensorDataSetDoserecParams):
        raise TypeError("dset_object type is not torchPETADMM.database.database_doserec.tensorDataSetDoserecParams")

    doserec_object=dset_object.doserecParams
    recons_vox_size=CASToRParams.vox_size_castor
    recons_dim=CASToRParams.im_dim_castor

    norm_sj=dset_object.norm_sj
    norm_train=dset_object.norm_train

    zdim,ydim,xdim=xref.shape
    zstart=zdim-dset_object.truncate #starting plane for network

    if count:
        t = time.time()

    if verbose:
            print('Initialization:-------------------------------------------------------------------------------------------------------------')

    v0,sum_v0=database_doserec.preprocess_data(xref+u0,dset_object,device=device)
    v = training.predict(model,v0, device) #x^{1/2} in DR
    v=database_doserec.postprocess_data(v,sum_v0,dset_object, device=device)
    x=xref

    u=xref+u0-v  #init point for u, which is u^(1) in DR
    xref=v-u ##init point for xref, which is x^(1/2)-u^(1) in DR
    if show_initial:
        _=PETLibs.utils.display3D_1cbar(xref,interpolation='none',title="xref")

    #Load sinograms to compute log likelhood
    dict_sino=database_sino.CASToR_load_sinograms(subject,real, doserec_object)

    if evaluate:
        criterion = torch.nn.MSELoss()
        loss = criterion(xref,target)
        mse = [loss.item()]

        reg_fun = jacobian.JacobianReg_l2(max_iter=10, eval_mode=True)
        reg_loss, reg_loss_all = jacobian.compute_reg(torch.unsqueeze(torch.unsqueeze(
                                        torch.tensor(xref[zstart:],device=device,dtype=torch.float32), 0), 0),
                                        torch.unsqueeze(torch.unsqueeze(torch.tensor(xref[zstart:],device=device,dtype=torch.float32), 0), 0),
                                        model, reg_fun, device = device, eval_mode = True)

        reg_loss = reg_loss.item()
        reg = [reg_loss]

        l, y = reconsEM.CASToR_log_likelihood(subject,real, doserec_object, test_dir, x,eps=0,
                                    vox_size=recons_vox_size,dict_sino=dict_sino,proj="joseph")
        log_l = [l]
        norm1 = []
        norm2 = []
    else:
        reg = []
        mse = []
        log_l = []
        norm1 = []
        norm2 = []

    if count:
        all_time = [time.time() - t]
    else:
        all_time = []

    for i in range(nit_admm):
        if count:
            t = time.time()

        if verbose:
            print('Iteration {}:-------------------------------------------------------------------------------------------------------------'.format(i+1))
            print('Step 1:-------------------------------------------------------------------')

        if evaluate:
            x_old = x

        x=reconsEM.CASToR_ProxEM_recons_dbase(subject, doserec_object, test_dir,
                CASToRParams=CASToRParams,real=real,xprox=xref,pnlt_beta=pnlt_beta,
                pnlt_params=pnlt_params,verbose = False,show = False)# x is np.array

        if evaluate:
            if verbose:
                print('Evaluation:-------------------------------------------------------------------')

        if i == 0:
            x_all = np.expand_dims(x, 0)
        else:
            x_all = np.concatenate((x_all,np.expand_dims(x, 0)), 0)

        if (show_x == "all"):
            _=PETLibs.utils.display3D_1cbar(x,interpolation='none',title=f"x_it{i}")
        elif (i == nit_admm-1) & (show_x == "last"):
            _=PETLibs.utils.display3D_1cbar(x,interpolation='none',title=f"x_last")

        if evaluate:
            if verbose:
                print('Evaluation MSE/LL:-------------------------------------------------------------------')
            loss = criterion(x,target)
            mse.append(loss.item())
            l, y = reconsEM.CASToR_log_likelihood(subject,real, doserec_object, test_dir, x,eps=0,
                                    vox_size=recons_vox_size,dict_sino=dict_sino,proj="joseph")
            log_l.append(l)

        if verbose:
            print('Updating X:-------------------------------------------------------------------')
            print('Step 2:-------------------------------------------------------------------')

        if evaluate:
            v_old = v

        n_image,sum_i=database_doserec.preprocess_data(x+u,dset_object,device=device)
        if evaluate:
            if verbose:
                print('Evaluation:JAC----------------------------------------------------------------')
            reg_loss, reg_loss_all = jacobian.compute_reg(n_image,n_image,model,
                                    reg_fun, device = device, eval_mode = True)
            reg_loss = reg_loss.item()
            print(f"\n\n\n reg_loss it{i}={reg_loss} \n\n\n")
            reg.append(reg_loss)

        v = training.predict(model,n_image, device)
        v=database_doserec.postprocess_data(v,sum_i,dset_object, device=device)# v is np.array

        if evaluate:
            if verbose:
                print('Evaluation convergence:-------------------------------------------------------------------')
            norm1.append(np.linalg.norm(x-v))
            norm2.append(np.linalg.norm(v-v_old))
            print(f"norm1={norm1},norm2={norm2}")

        if i == 0:
            v_all = np.expand_dims(v, 0)
        else:
            v_all = np.concatenate((v_all,np.expand_dims(v, 0)), 0)

        if show_v:
            _=PETLibs.utils.display3D_1cbar(v,interpolation='none',title=f"v_it{i}")
        if verbose:
            print('Step 3:-------------------------------------------------------------------')

        u = u + x - v

        if i == 0:
            u_all = np.expand_dims(u, 0)
        else:
            u_all = np.concatenate((u_all,np.expand_dims(u, 0)), 0)

        if show_u:
            _=PETLibs.utils.display3D_1cbar(u,interpolation='none',title=f"u_it{i}")
        if verbose:
            print('Updating Xref:-------------------------------------------------------------------')

        xref = v - u #New xref

        if count:
            all_time.append(time.time() - t)

    if show_target:
        _=PETLibs.utils.display3D_1cbar(target,interpolation='none')

    if show_metrics:
        plt.figure()
        plt.plot(range(len(log_l)), log_l)
        plt.xlabel('Iterations')
        plt.ylabel('Log-Likelihood')
        plt.title('Log-Likelihood over ADMM Iterations')
        plt.show()

        plt.figure()
        plt.plot(range(len(mse)), mse)
        plt.xlabel('Iterations')
        plt.ylabel('MSE')
        plt.title('MSE over ADMM Iterations')
        plt.show()

        plt.figure()
        plt.plot(range(len(reg)), reg)
        plt.xlabel('Iterations')
        plt.ylabel('Square Jacobian Spectral Norm')
        plt.title('Square Jacobian Spectral Norm over ADMM Iterations')
        plt.show()

        plt.figure()
        plt.plot(range(1, len(norm1)+1), norm1)
        plt.xlabel('Iterations')
        plt.ylabel('Primal Residual')
        plt.title('Primal Residual over ADMM Iterations')
        plt.show()

        plt.figure()
        plt.plot(range(1, len(norm2)+1), norm2)
        plt.xlabel('Iterations')
        plt.ylabel('Dual Residual')
        plt.title('Dual Residual over ADMM Iterations')
        plt.show()

    results={}
    results["x"]=x
    results["x_all"]=x_all
    results["v"]=v
    results["v_all"]=v_all
    results["u"]=u
    results["u_all"]=u_all
    results["mse"]=mse
    results["reg"]=reg
    results["logl"]=log_l
    results["norm1"]=norm1
    results["norm2"]=norm2
    results["all_time"]=all_time
    return results

##################################################################################

def GPU_ADMM_TV(subject,
             dset_object, 
             x0, 
             u0,
             nit_admm, 
             pnlt_beta, 
             device,
             reconsParams=None, 
             evaluate = False,
             target=None,
             count = False, 
             show_initial = False, 
             show_x = "all", 
             show_v = False,
             show_u = False, 
             vmax=None, 
             vmin=None,
             verbose = False,
             real=0,
             twriter=False,
             tlog_dir=None,
             phantom = None, 
             algo_prox = "em", 
             use_lpips = False, 
             lbd = 1.0,
             scanner="Biograph"
             ):
    

    if scanner == "Biograph":
        if reconsParams is None:
            reconsParams=GPUBiographReconsParams()
        if not isinstance(reconsParams,GPUBiographReconsParams):
            raise TypeError("ReconsParams type is not GPUBiographReconsParams")
    elif scanner == "Signa":
        if reconsParams is None:
            reconsParams=GPUSignaReconsParams()
        if not isinstance(reconsParams,GPUSignaReconsParams):
            raise TypeError("ReconsParams type is not GPUSignaReconsParams")
    else:
        raise TypeError('Scanner type {0} not enforced'.format(scanner))
    if not isinstance(dset_object,database_doserec.tensorDataSetDoserecParams):
        raise TypeError("dset_object type is not torchPETADMM.database.database_doserec.tensorDataSetDoserecParams")

    doserec_object=dset_object.doserecParams

    Dh = torch.tensor([[[0., 0., 0.],
                        [0., 0., 0.],
                        [0., 0., 0.]],
                        [[0., 0., 0.],
                        [-1, 1., 0.],
                        [0., 0., 0.]],
                        [[0., 0., 0.],
                        [0., 0., 0.],
                        [0., 0., 0.]]]).view(1,1,3,3,3).cuda()
        

    Dp = torch.tensor([[[0., 0., 0.],
                    [0., -1., 0.],
                    [0., 0., 0.]],
                    [[0., 0., 0.],
                    [0., 1., 0.],
                    [0., 0., 0.]],
                    [[0., 0., 0.],
                    [0., 0., 0.],
                    [0., 0., 0.]]]).view(1,1,3,3,3).cuda()
    
    Dv = torch.tensor([[[0., 0., 0.],
                    [0., 0., 0.],
                    [0., 0., 0.]],
                    [[0., -1., 0.],
                    [0., 1., 0.],
                    [0., 0., 0.]],
                    [[0., 0., 0.],
                    [0., 0., 0.],
                    [0., 0., 0.]]]).view(1,1,3,3,3).cuda()
    

    D = torch.concatenate([Dh, Dp, Dv], dim=0)
    
    Dh_star = torch.tensor([[[0., 0., 0.],
                        [0., 0., 0.],
                        [0., 0., 0.]],
                        [[0., 0., 0.],
                        [0., 1., -1.],
                        [0., 0., 0.]],
                        [[0., 0., 0.],
                        [0., 0., 0.],
                        [0., 0., 0.]]]).view(1,1,3,3,3).cuda()
        

    Dp_star = torch.tensor([[[0., 0., 0.],
                    [0., 0., 0.],
                    [0., 0., 0.]],
                    [[0., 0., 0.],
                    [0., 1., 0.],
                    [0., 0., 0.]],
                    [[0., 0., 0.],
                    [0., -1., 0.],
                    [0., 0., 0.]]]).view(1,1,3,3,3).cuda()
    
    Dv_star = torch.tensor([[[0., 0., 0.],
                    [0., 0., 0.],
                    [0., 0., 0.]],
                    [[0., 0., 0.],
                    [0., 1., 0.],
                    [0., -1., 0.]],
                    [[0., 0., 0.],
                    [0., 0., 0.],
                    [0., 0., 0.]]]).view(1,1,3,3,3).cuda()
    

    D_star = torch.concatenate([Dh_star, Dp_star, Dv_star], dim=1)


    if count:
        t = time.time()


    if twriter is True:
        writer=SummaryWriter(log_dir=tlog_dir)
        hparams_dict={}
        hparams_dict["subject"]=subject
        hparams_dict["real"]=real
        hparams_dict["nit_admm"]=nit_admm
        hparams_dict["pnlt_beta"]=pnlt_beta
        hparams2=copy.deepcopy(reconsParams.__dict__)
        lst_delete=[]
        dict_add={}
        for key in hparams2.keys():
            if torch.is_tensor(hparams2[key]):
                lst_delete+=[key]
            elif isinstance(hparams2[key],list):
                lst_delete+=[key]
                print(f"list {key}")
                for k in range(len(hparams2[key])):
                    new_k=f"{key}_{str(k)}"
                    dict_add[new_k]=hparams2[key][k]
        for key in lst_delete:
            del hparams2[key]
        hparams_dict.update(hparams2)
        hparams_dict.update(dict_add)
        fig=PETLibs.utils.display3D_1cbar(x0,interpolation='none',title=f"EM",vmax=vmax, vmin=vmin)
        writer.add_figure("EM",fig,global_step=0,close=True)
        plt.close(fig)

    if verbose:
            print('Initialization:-------------------------------------------------------------------------------------------------------------')

    fig=PETLibs.utils.display3D_1cbar(target,interpolation='none',vmax=vmax, vmin=vmin)
    if twriter is True:
        writer.add_figure("target",fig,global_step=0,close=True)
    xt_target= torch.reshape(torch.tensor(np.swapaxes(target,2,0),dtype=torch.float32, device = "cuda"),reconsParams.tb_im_dim)
    xt_mask = torch.where(xt_target > 0, torch.tensor(0.0, dtype=torch.float32, device = "cuda"), torch.tensor(1.0, dtype=torch.float32, device = "cuda"))
    xt_mask = np.swapaxes(xt_mask.squeeze().cpu().numpy(),2,0)

    fig=PETLibs.utils.display3D_1cbar(xt_mask,interpolation='none',title=f"mask_target") #,vmin=-vmax,vmax=vmax)
    if twriter is True:
        writer.add_figure("mask_target",fig,global_step=0,close=True)


    xt_target= torch.reshape(torch.tensor(np.swapaxes(phantom,2,0),dtype=torch.float32, device = "cuda"),reconsParams.tb_im_dim)
    xt_mask_ph = torch.where(xt_target > 0, torch.tensor(1.0, dtype=torch.float32, device = "cuda"), torch.tensor(0.0, dtype=torch.float32, device = "cuda"))
    xt_mask_ph = np.swapaxes(xt_mask_ph.squeeze().cpu().numpy(),2,0)
    # xt_mask_ph = np.ones_like(xt_mask_ph)

    fig=PETLibs.utils.display3D_1cbar(xt_mask_ph,interpolation='none',title=f"mask_phantom") #,vmin=-vmax,vmax=vmax)
    if twriter is True:
        writer.add_figure("mask_phantom",fig,global_step=0,close=True)

    fig=PETLibs.utils.display3D_1cbar(phantom,interpolation='none',vmax=vmax, vmin=vmin)
    if twriter is True:
        writer.add_figure("phantom",fig,global_step=0,close=True)


    u=u0 
    xref=x0

    
    #Load sinograms
    castor_df_ima,castor_df_hdr=doserec_object.get_fname_sinogram_CASToR_hdr(subject,real)
    castor_df_dir=doserec_object.get_gen_castor_dir(subject,real)
    castor_df_hdr_fpath=os.path.join(castor_df_dir,castor_df_hdr)
    dict_sino=GPURecons.GPUCASToRSinos(castor_df_hdr_fpath, castor_df_dir,
                                            reconsParams=reconsParams)
   
    if evaluate:
        criterion = torch.nn.MSELoss()
        criterion_MAE = torch.nn.L1Loss()
        criterion_tv = torchmetrics.TotalVariation(reduction="mean").cuda() #dim=3, data_range=1.0, 
        if use_lpips:
            criterion_lpips = LearnedPerceptualImagePatchSimilarity3D().cuda()

        loss = criterion(torch.tensor(x0, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda")) 
        loss_phantom = criterion(torch.tensor(x0, dtype=torch.float32,device="cuda"), torch.tensor(phantom, dtype=torch.float32,device="cuda")) 
        loss_MAE = criterion_MAE(torch.tensor(x0, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
        loss_tv = ((criterion_tv(torch.tensor(target, dtype=torch.float32,device="cuda").unsqueeze(0)) - criterion_tv(torch.tensor(x0, dtype=torch.float32,device="cuda").unsqueeze(0)))**2)**0.5
        if use_lpips:
            loss_lpips = criterion_lpips(torch.tensor(x0, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
        mse = [loss.item()]
        mae = [loss_MAE.item()]
        tv = [loss_tv.item()]
        if use_lpips:
            lpips = [loss_lpips.item()]

     
        log_l = []
        norm1 = []
        norm2 = []
        tv12 = []
    else:
        reg = []
        mse = []
        mae = []
        tv = []
        lpips = []
        log_l = []
        tv12 = []
        norm1 = []
        norm2 = []

    if count:
        all_time = [time.time() - t]
    else:
        all_time = []

    

    for i in range(nit_admm):
        
        # pnlt_beta = vec_pnlt_beta[i]
        print("pnlt_beta",pnlt_beta)
        if count:
            t = time.time()

        if verbose:
            print('Iteration {}:-------------------------------------------------------------------------------------------------------------'.format(i+1))
            print('Step 1:-------------------------------------------------------------------')

        if i > 0:
            x_old = x_ZYX

        fig=PETLibs.utils.display3D_1cbar(xref,interpolation='none',title=f"x_in_prox_it{i+1}",vmax=vmax, vmin=vmin)
        if twriter is True:
            writer.add_figure("x_in_prox",fig,global_step=i+1,close=True)

        if reconsParams.XYZ:
            xprox=np.swapaxes(xref,2,0)
        if algo_prox == "em":
            x=PETLibs.recons.GPUProxReconsDPEM(castor_df_hdr_fpath, castor_df_ima,
                    reconsParams=reconsParams,xprox=xprox,pnlt_beta=pnlt_beta,
                    dict_sino=dict_sino,eval_mode=True,verbose = False,show_step = False,tensor_output=False, img_mask = xt_mask_ph)# x is np.array
        
        elif algo_prox == "spdhg":
            x, list_init_dual=PETLibs.recons.GPUProxReconsSPDHG(castor_df_hdr_fpath, castor_df_ima,
                reconsParams=reconsParams,xprox=xprox,pnlt_beta=pnlt_beta,
                dict_sino=dict_sino,nb_iter=reconsParams.nit, 
                warm_start = True if i> 0 else False, list_init_dual = list_init_dual if i> 0 else [], xstart=xstart if i> 0 else None, 
                i_img_mask= xt_mask_ph)
            
        elif algo_prox == "dbfb":
            x, list_init_dual =PETLibs.recons.GPUProxReconsDBFB(castor_df_hdr_fpath, castor_df_ima,
                reconsParams=reconsParams,xprox=xprox,pnlt_beta=pnlt_beta,
                dict_sino=dict_sino,nb_iter=reconsParams.nit, 
                warm_start = True if i> 0 else False, list_init_dual = list_init_dual if i> 0 else [],  
                i_img_mask= xt_mask_ph)
        else :
            raise ValueError("algo_prox must be em, spdhg or dbfb")
        inv_precond = None
        if inv_precond is not None:
            if reconsParams.XYZ:
                inv_precond=np.swapaxes(inv_precond,4,2)
           
            if dset_object.truncate < inv_precond.shape[2]:
                t = inv_precond.shape[2] - dset_object.truncate
                inv_precond = inv_precond[:,:,t:,:,:]
        
        xstart=x
        if reconsParams.XYZ:
            x_ZYX=np.swapaxes(x,2,0)
        else:
            x_ZYX=x

        
        if i == 0:
            x_all = np.expand_dims(x_ZYX, 0)
        else:
            x_all = np.concatenate((x_all,np.expand_dims(x_ZYX, 0)), 0)

        if (show_x == "all"):

            fig=PETLibs.utils.display3D_1cbar(x_ZYX,interpolation='none',title=f"x_it{i+1}",vmax=vmax, vmin=vmin)
            if twriter is True:
                writer.add_figure("x",fig,global_step=i+1,close=True)


            # mask_proj = np.where(x_ZYX > 0, 1, 0)
            # fig=PETLibs.utils.display3D_1cbar(mask_proj,interpolation='none')
            # writer.add_figure("mask_x_ZYX",fig,global_step=i+1,close=True)

        elif (i == nit_admm-1) & (show_x == "last"):
            fig=PETLibs.utils.display3D_1cbar(x_ZYX,interpolation='none',title=f"x_last",vmax=vmax, vmin=vmin)
            if twriter is True:
                writer.add_figure("x",fig,global_step=i+1,close=True)

        if evaluate and i>0:
            if verbose:
                print('Evaluation Metric:-------------------------------------------------------------------')
            loss = criterion(torch.tensor(x_ZYX, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
            loss_phantom = criterion(torch.tensor(x_ZYX, dtype=torch.float32,device="cuda"), torch.tensor(phantom, dtype=torch.float32,device="cuda"))
            loss_tv = ((criterion_tv(torch.tensor(target, dtype=torch.float32,device="cuda").unsqueeze(0)) - criterion_tv(torch.tensor(x_ZYX, dtype=torch.float32,device="cuda").unsqueeze(0)))**2)**0.5
            if use_lpips:
                loss_lpips = criterion_lpips(torch.tensor(x_ZYX, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
                lpips.append(loss_lpips.item())
            loss_MAE = criterion_MAE(torch.tensor(x_ZYX, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
            mae.append(loss_MAE.item())
            mse.append(loss.item())
            tv.append(loss_tv.item())
            # 
            if verbose:
                print('Log Likelihood:-------------------------------------------------------------------')
            l = reconsEM.GPU_log_likelihood(subject,real,doserec_object,x, eps =0,
                                    reconsParams=reconsParams,dict_sino=dict_sino,eval_mode=True)#Note here x and not X_ZYX
            
            
            TV = lbd * torch.sum(torch.abs(F.conv3d(u,D,padding=1)))
            tv12.append(TV)

            log_l.append(l)
            if twriter is True:
                writer.add_scalar("Loss/MSE",loss.item(),i+1)
                writer.add_scalar("Loss/MSE_phantom",loss_phantom.item(),i+1)
                writer.add_scalar("Loss/TV",loss_tv.item(),i+1)
                writer.add_scalar("Loss/LL_TV", l - TV, i+1)
                if use_lpips:
                    writer.add_scalar("Loss/LPIPS",loss_lpips.item(),i+1)
                writer.add_scalar("Loss/MAE",loss_MAE.item(),i+1)
                writer.add_scalar("Loss/LogLikelihood",l,i+1)

        if verbose:
            print('Updating X:-------------------------------------------------------------------')
            print('Step 2:-------------------------------------------------------------------')

        if evaluate and i>0:
            v_old = v
        fig=PETLibs.utils.display3D_1cbar((x_ZYX+u)* xt_mask_ph,interpolation='none',title=f"x+u_it{i+1}",vmax=vmax, vmin=vmin)
        if twriter is True:
            writer.add_figure("x+u",fig,global_step=i+1,close=True)

        fig=PETLibs.utils.display3D_1cbar((x_ZYX+u)* xt_mask_ph,interpolation='none',title=f"x+u_it{i+1}",perc=0.7)
        if twriter is True:
            writer.add_figure("x+u_perc",fig,global_step=i+1,close=True)
            
        n_image,sum_i=database_doserec.preprocess_data(x_ZYX+u,dset_object,device=device) #n_image is tensor
        print("reg_TV = ",lbd/pnlt_beta)
        v = PETLibs.recons.tv_l2_pd(n_image,lbd/pnlt_beta)
        v=database_doserec.postprocess_data(v,sum_i,dset_object, device=device)# v is np.array

        # mask in D
        # v = v * xt_mask_ph

        if evaluate and i>0:
            if verbose:
                
                print('Evaluation: ADMM CONVERGENCE--------------------------------------------------')
            primalN=np.linalg.norm(x_ZYX-v)
            dualN=np.linalg.norm(v-v_old)

            if i > 0:
                var_v = (v-v_old)/dualN

                fig=PETLibs.utils.display3D_1cbar(var_v,interpolation='none',title=f"v-v_old/v_old_it{i+1}", perc= 0.7) #,vmin=-vmax,vmax=vmax)
                if twriter is True:
                    writer.add_figure("v-v_old",fig,global_step=i+1,close=True)

                var_x = (x_ZYX-x_old)/np.linalg.norm(x_ZYX-x_old)

                fig=PETLibs.utils.display3D_1cbar(var_x,interpolation='none',title=f"x-x_old/x_old_it{i+1}", perc= 0.7) #,vmin=-vmax,vmax=vmax)
                if twriter is True:
                    writer.add_figure("x-x_old",fig,global_step=i+1,close=True)

                
           
            norm1.append(primalN)
            norm2.append(dualN)
            if twriter is True:
                writer.add_scalar("Accuracy/NormPrimal",primalN,i+1)
                writer.add_scalar("Accuracy/NormDual",dualN,i+1)


        if i == 0:
            v_all = np.expand_dims(v, 0)
        else:
            v_all = np.concatenate((v_all,np.expand_dims(v, 0)), 0)

        if show_v:

            fig=PETLibs.utils.display3D_1cbar(v,interpolation='none',title=f"v_it{i+1}",vmax=vmax, vmin=vmin)
            if twriter is True:
                writer.add_figure("v",fig,global_step=i+1,close=True)

            # mask_proj = np.where(v > 0, 1, 0)
            # fig=PETLibs.utils.display3D_1cbar(mask_proj,interpolation='none')
            # writer.add_figure("mask_v",fig,global_step=i+1,close=True)
        if verbose:
            print('Step 3:-------------------------------------------------------------------')

        u = u + x_ZYX - v

        if i == 0:
            u_all = np.expand_dims(u, 0)
        else:
            u_all = np.concatenate((u_all,np.expand_dims(u, 0)), 0)


        
        
        xt= torch.reshape(torch.tensor(np.swapaxes(x_ZYX,2,0),dtype=torch.float32, device = "cuda"),reconsParams.tb_im_dim)
        xt_mask = torch.where(xt > 0, torch.tensor(0.0, dtype=torch.float32, device = "cuda"), torch.tensor(1.0, dtype=torch.float32, device = "cuda"))
        xt_mask = np.swapaxes(xt_mask.squeeze().cpu().numpy(),2,0)
        

        if show_u:

            fig=PETLibs.utils.display3D_1cbar(u,interpolation='none',title=f"u_it{i+1}", perc=0.7) #,vmin=-vmax,vmax=vmax)
            if twriter is True:
                writer.add_figure("u",fig,global_step=i+1,close=True)


            mask_proj = np.where(u > 0, 1, 0)
            fig=PETLibs.utils.display3D_1cbar(mask_proj,interpolation='none')
            writer.add_figure("mask_u",fig,global_step=i+1,close=True)


            fig=PETLibs.utils.display3D_1cbar(xt_mask,interpolation='none',title=f"mask_it{i+1}") #,vmin=-vmax,vmax=vmax)
            if twriter is True:
                writer.add_figure("mask",fig,global_step=i+1,close=True)

            fig=PETLibs.utils.display3D_1cbar(u,interpolation='none',title=f"u_it{i+1}",vmin=0,vmax=vmax)
            if twriter is True:
                writer.add_figure("window_u",fig,global_step=i+1,close=True)



        if verbose:
            print('Updating Xref:-------------------------------------------------------------------')

        xref = v - u  

        if count:
            all_time.append(time.time() - t)


    writer.close()



    results={}
    results["x"]=x_ZYX
    results["x_all"]=x_all
    results["v"]=v
    results["v_all"]=v_all
    results["u"]=u
    results["u_all"]=u_all
    results["mse"]=mse
    results["tv"]=tv
    if use_lpips:
        results["lpips"]=lpips
    results["mae"]=mae
    results["logl"]=log_l
    results["norm1"]=norm1
    results["norm2"]=norm2

    return results


##################################################################################

def GPU_ADMM_Fair(subject,
             dset_object, 
             x0, 
             u0,
             nit_admm, 
             pnlt_beta, 
             device,
             reconsParams=None, 
             evaluate = False,
             target=None,
             count = False, 
             show_initial = False, 
             show_x = "all", 
             show_v = False,
             show_u = False, 
             vmax=None, 
             vmin=None,
             verbose = False,
             real=0,
             twriter=False,
             tlog_dir=None,
             phantom = None, 
             algo_prox = "em", 
             use_lpips = False, 
             lbd = 1.0,
             delta = 1.0, 
             prec = 5e-04,
             scanner = "Biograph",
             dict_sino = None
             ):
    

    if scanner == "Biograph":
        if reconsParams is None:
            reconsParams=GPUBiographReconsParams()
        if not isinstance(reconsParams,GPUBiographReconsParams):
            raise TypeError("ReconsParams type is not GPUBiographReconsParams")
    elif scanner == "Signa":
        if reconsParams is None:
            reconsParams=GPUSignaReconsParams()
        if not isinstance(reconsParams,GPUSignaReconsParams):
            raise TypeError("ReconsParams type is not GPUSignaReconsParams")
    else:
        raise TypeError('Scanner type {0} not enforced'.format(scanner))
    if not isinstance(dset_object,database_doserec.tensorDataSetDoserecParams):
        raise TypeError("dset_object type is not torchPETADMM.database.database_doserec.tensorDataSetDoserecParams")

    doserec_object=dset_object.doserecParams

    Dh = torch.tensor([[[0., 0., 0.],
                        [0., 0., 0.],
                        [0., 0., 0.]],
                        [[0., 0., 0.],
                        [-1, 1., 0.],
                        [0., 0., 0.]],
                        [[0., 0., 0.],
                        [0., 0., 0.],
                        [0., 0., 0.]]]).view(1,1,3,3,3).cuda()
        

    Dp = torch.tensor([[[0., 0., 0.],
                    [0., -1., 0.],
                    [0., 0., 0.]],
                    [[0., 0., 0.],
                    [0., 1., 0.],
                    [0., 0., 0.]],
                    [[0., 0., 0.],
                    [0., 0., 0.],
                    [0., 0., 0.]]]).view(1,1,3,3,3).cuda()
    
    Dv = torch.tensor([[[0., 0., 0.],
                    [0., 0., 0.],
                    [0., 0., 0.]],
                    [[0., -1., 0.],
                    [0., 1., 0.],
                    [0., 0., 0.]],
                    [[0., 0., 0.],
                    [0., 0., 0.],
                    [0., 0., 0.]]]).view(1,1,3,3,3).cuda()
    

    D = torch.concatenate([Dh, Dp, Dv], dim=0)
    
    Dh_star = torch.tensor([[[0., 0., 0.],
                        [0., 0., 0.],
                        [0., 0., 0.]],
                        [[0., 0., 0.],
                        [0., 1., -1.],
                        [0., 0., 0.]],
                        [[0., 0., 0.],
                        [0., 0., 0.],
                        [0., 0., 0.]]]).view(1,1,3,3,3).cuda()
        

    Dp_star = torch.tensor([[[0., 0., 0.],
                    [0., 0., 0.],
                    [0., 0., 0.]],
                    [[0., 0., 0.],
                    [0., 1., 0.],
                    [0., 0., 0.]],
                    [[0., 0., 0.],
                    [0., -1., 0.],
                    [0., 0., 0.]]]).view(1,1,3,3,3).cuda()
    
    Dv_star = torch.tensor([[[0., 0., 0.],
                    [0., 0., 0.],
                    [0., 0., 0.]],
                    [[0., 0., 0.],
                    [0., 1., 0.],
                    [0., -1., 0.]],
                    [[0., 0., 0.],
                    [0., 0., 0.],
                    [0., 0., 0.]]]).view(1,1,3,3,3).cuda()
    

    D_star = torch.concatenate([Dh_star, Dp_star, Dv_star], dim=1)


    if count:
        t = time.time()


    if twriter :
        writer=SummaryWriter(log_dir=tlog_dir)
        hparams_dict={}
        hparams_dict["subject"]=subject
        hparams_dict["real"]=real
        hparams_dict["nit_admm"]=nit_admm
        hparams_dict["pnlt_beta"]=pnlt_beta
        hparams2=copy.deepcopy(reconsParams.__dict__)
        lst_delete=[]
        dict_add={}
        for key in hparams2.keys():
            if torch.is_tensor(hparams2[key]):
                lst_delete+=[key]
            elif isinstance(hparams2[key],list):
                lst_delete+=[key]
                print(f"list {key}")
                for k in range(len(hparams2[key])):
                    new_k=f"{key}_{str(k)}"
                    dict_add[new_k]=hparams2[key][k]
        for key in lst_delete:
            del hparams2[key]
        hparams_dict.update(hparams2)
        hparams_dict.update(dict_add)
        fig=PETLibs.utils.display3D_1cbar(x0,interpolation='none',title=f"EM",vmax=vmax, vmin=vmin)
        writer.add_figure("EM",fig,global_step=0,close=True)
        plt.close(fig)

    if verbose:
            print('Initialization:-------------------------------------------------------------------------------------------------------------')

    
    if twriter :
        fig=PETLibs.utils.display3D_1cbar(target,interpolation='none',vmax=vmax, vmin=vmin)
        writer.add_figure("target",fig,global_step=0,close=True)
    xt_target= torch.reshape(torch.tensor(np.swapaxes(target,2,0),dtype=torch.float32, device = "cuda"),reconsParams.tb_im_dim)
    xt_mask = torch.where(xt_target > 0, torch.tensor(0.0, dtype=torch.float32, device = "cuda"), torch.tensor(1.0, dtype=torch.float32, device = "cuda"))
    xt_mask = np.swapaxes(xt_mask.squeeze().cpu().numpy(),2,0)

    
    if twriter :
        fig=PETLibs.utils.display3D_1cbar(xt_mask,interpolation='none',title=f"mask_target") #,vmin=-vmax,vmax=vmax)
        writer.add_figure("mask_target",fig,global_step=0,close=True)


    xt_target= torch.reshape(torch.tensor(np.swapaxes(phantom,2,0),dtype=torch.float32, device = "cuda"),reconsParams.tb_im_dim)
    xt_mask_ph = torch.where(xt_target > 0, torch.tensor(1.0, dtype=torch.float32, device = "cuda"), torch.tensor(0.0, dtype=torch.float32, device = "cuda"))
    xt_mask_ph = np.swapaxes(xt_mask_ph.squeeze().cpu().numpy(),2,0)
    # xt_mask_ph = np.ones_like(xt_mask_ph)

    
    if twriter :
        fig=PETLibs.utils.display3D_1cbar(xt_mask_ph,interpolation='none',title=f"mask_phantom") #,vmin=-vmax,vmax=vmax)
        writer.add_figure("mask_phantom",fig,global_step=0,close=True)

        fig=PETLibs.utils.display3D_1cbar(phantom,interpolation='none',vmax=vmax, vmin=vmin)
        writer.add_figure("phantom",fig,global_step=0,close=True)


    u=u0 
    xref=x0

    
    #Load sinograms
    if dict_sino is None :
        castor_df_ima,castor_df_hdr=doserec_object.get_fname_sinogram_CASToR_hdr(subject,real)
        castor_df_dir=doserec_object.get_gen_castor_dir(subject,real)
        castor_df_hdr_fpath=os.path.join(castor_df_dir,castor_df_hdr)
        dict_sino=GPURecons.GPUCASToRSinos(castor_df_hdr_fpath, castor_df_dir,
                                                reconsParams=reconsParams)
    else :
        castor_df_hdr_fpath = None
        castor_df_ima = None
        castor_df_hdr_fpath = None
        castor_df_ima = None
        
    if evaluate:
        criterion = torch.nn.MSELoss()
        criterion_MAE = torch.nn.L1Loss()
        if use_lpips:
            criterion_lpips = LearnedPerceptualImagePatchSimilarity3D().cuda()

        loss = criterion(torch.tensor(x0, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda")) 
        loss_phantom = criterion(torch.tensor(x0, dtype=torch.float32,device="cuda"), torch.tensor(phantom, dtype=torch.float32,device="cuda")) 
        loss_MAE = criterion_MAE(torch.tensor(x0, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
        if use_lpips:
            loss_lpips = criterion_lpips(torch.tensor(x0, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
        mse = [loss.item()]
        mae = [loss_MAE.item()]
        tv = []
        if use_lpips:
            lpips = [loss_lpips.item()]

     
        log_l = []
        norm1 = []
        norm2 = []
        tv12 = []
    else:
        reg = []
        mse = []
        mae = []
        tv = []
        lpips = []
        log_l = []
        tv12 = []
        norm1 = []
        norm2 = []

    if count:
        all_time = [time.time() - t]
    else:
        all_time = []

    

    for i in range(nit_admm):
        
        # pnlt_beta = vec_pnlt_beta[i]
       
        if count:
            t = time.time()

        if verbose:
            print("pnlt_beta",pnlt_beta)
            print('Iteration {}:-------------------------------------------------------------------------------------------------------------'.format(i+1))
            print('Step 1:-------------------------------------------------------------------')

        if i > 0:
            x_old = x_ZYX

        
        if twriter :
            fig=PETLibs.utils.display3D_1cbar(xref,interpolation='none',title=f"x_in_prox_it{i+1}",vmax=vmax, vmin=vmin)
            writer.add_figure("x_in_prox",fig,global_step=i+1,close=True)

        if reconsParams.XYZ:
            xprox=np.swapaxes(xref,2,0)
        if algo_prox == "em":
            x=PETLibs.recons.GPUProxReconsDPEM(castor_df_hdr_fpath, castor_df_ima,
                    reconsParams=reconsParams,xprox=xprox,pnlt_beta=pnlt_beta,
                    dict_sino=dict_sino,eval_mode=True,verbose = False,show_step = False,tensor_output=False, img_mask = xt_mask_ph)# x is np.array
        
        elif algo_prox == "spdhg":
            x, list_init_dual=PETLibs.recons.GPUProxReconsSPDHG(castor_df_hdr_fpath, castor_df_ima,
                reconsParams=reconsParams,xprox=xprox,pnlt_beta=pnlt_beta,
                dict_sino=dict_sino,nb_iter=reconsParams.nit, 
                warm_start = True if i> 0 else False, list_init_dual = list_init_dual if i> 0 else [], xstart=xstart if i> 0 else None, 
                i_img_mask= xt_mask_ph)
            
        elif algo_prox == "dbfb":
            x, list_init_dual =PETLibs.recons.GPUProxReconsDBFB(castor_df_hdr_fpath, castor_df_ima,
                reconsParams=reconsParams,xprox=xprox,pnlt_beta=pnlt_beta,
                dict_sino=dict_sino,nb_iter=reconsParams.nit, 
                warm_start = True if i> 0 else False, list_init_dual = list_init_dual if i> 0 else [],  
                i_img_mask= xt_mask_ph)
        else :
            raise ValueError("algo_prox must be em, spdhg or dbfb")
        inv_precond = None
        if inv_precond is not None:
            if reconsParams.XYZ:
                inv_precond=np.swapaxes(inv_precond,4,2)
           
            if dset_object.truncate < inv_precond.shape[2]:
                t = inv_precond.shape[2] - dset_object.truncate
                inv_precond = inv_precond[:,:,t:,:,:]
        
        xstart=x
        if reconsParams.XYZ:
            x_ZYX=np.swapaxes(x,2,0)
        else:
            x_ZYX=x

        
        if i == 0:
            x_all = np.expand_dims(x_ZYX, 0)
        else:
            x_all = np.concatenate((x_all,np.expand_dims(x_ZYX, 0)), 0)

        if (show_x == "all"):

            
            if twriter  :
                fig=PETLibs.utils.display3D_1cbar(x_ZYX,interpolation='none',vmax=vmax, vmin=vmin)
                writer.add_figure("x",fig,global_step=i+1,close=True)


            # mask_proj = np.where(x_ZYX > 0, 1, 0)
            # fig=PETLibs.utils.display3D_1cbar(mask_proj,interpolation='none')
            # writer.add_figure("mask_x_ZYX",fig,global_step=i+1,close=True)

        elif (i == nit_admm-1) & (show_x == "last"):
            
            if twriter :
                fig=PETLibs.utils.display3D_1cbar(x_ZYX,interpolation='none',title=f"x_last",vmax=vmax, vmin=vmin)
                writer.add_figure("x",fig,global_step=i+1,close=True)

        if evaluate and i>0:
            if verbose:
                print('Evaluation Metric:-------------------------------------------------------------------')
            loss = criterion(torch.tensor(x_ZYX, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
            loss_phantom = criterion(torch.tensor(x_ZYX, dtype=torch.float32,device="cuda"), torch.tensor(phantom, dtype=torch.float32,device="cuda"))
            if use_lpips:
                loss_lpips = criterion_lpips(torch.tensor(x_ZYX, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
                lpips.append(loss_lpips.item())
            loss_MAE = criterion_MAE(torch.tensor(x_ZYX, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
            mae.append(loss_MAE.item())
            mse.append(loss.item())
            # 
            if verbose:
                print('Log Likelihood:-------------------------------------------------------------------')
            l = reconsEM.GPU_log_likelihood(subject,real,doserec_object,x, eps =0,
                                    reconsParams=reconsParams,dict_sino=dict_sino,eval_mode=True)#Note here x and not X_ZYX
            
            
            D_img = lambda x : F.conv3d(torch.tensor(x, dtype=torch.float32,device="cuda").unsqueeze(dim=1).unsqueeze(dim=1),D,padding=1)
            fair_reg = lbd*delta*delta*torch.sum(D_img(x_ZYX).abs()/delta - torch.log(1.0+D_img(x_ZYX).abs()/delta))
            tv12.append(fair_reg)

            log_l.append(l)
            if twriter :
                writer.add_scalar("Loss/MSE",loss.item(),i+1)
                writer.add_scalar("Loss/MSE_phantom",loss_phantom.item(),i+1)
                # writer.add_scalar("Loss/TV",loss_tv.item(),i+1)
                writer.add_scalar("Loss/LL_TV", l - fair_reg, i+1)
                if use_lpips:
                    writer.add_scalar("Loss/LPIPS",loss_lpips.item(),i+1)
                writer.add_scalar("Loss/MAE",loss_MAE.item(),i+1)
                writer.add_scalar("Loss/LogLikelihood",l,i+1)

        if verbose:
            print('Updating X:-------------------------------------------------------------------')
            print('Step 2:-------------------------------------------------------------------')

        if evaluate and i>0:
            v_old = v
        
        if twriter :
            fig=PETLibs.utils.display3D_1cbar((x_ZYX+u)* xt_mask_ph,interpolation='none',title=f"x+u_it{i+1}",vmax=vmax, vmin=vmin)
            writer.add_figure("x+u",fig,global_step=i+1,close=True)

            fig=PETLibs.utils.display3D_1cbar((x_ZYX+u)* xt_mask_ph,interpolation='none',title=f"x+u_it{i+1}",perc=0.7)
            writer.add_figure("x+u_perc",fig,global_step=i+1,close=True)
            
        n_image,sum_i=database_doserec.preprocess_data(x_ZYX+u,dset_object,device=device) #n_image is tensor
        # print("reg_fair = ",lbd/pnlt_beta, "max img = ",np.max(x_ZYX+u), "max post = ",n_image.max())
        v = PETLibs.recons.lange_GD(n_image,lbd/pnlt_beta, delta=delta)
        v=database_doserec.postprocess_data(v,sum_i,dset_object, device=device)# v is np.array

        # mask in D
        # v = v * xt_mask_ph

        if evaluate and i>0:
            if verbose:
                
                print('Evaluation: ADMM CONVERGENCE--------------------------------------------------')
            primalN=np.linalg.norm(x_ZYX-v)
            dualN=np.linalg.norm(v-v_old)

            if i > 0:
                var_v = (v-v_old)/dualN                  
                var_x = (x_ZYX-x_old)/np.linalg.norm(x_ZYX-x_old)
                
                if twriter  :
                    fig=PETLibs.utils.display3D_1cbar(var_x,interpolation='none',title=f"x-x_old/x_old_it{i+1}", perc= 0.7) #,vmin=-vmax,vmax=vmax)
                    writer.add_figure("x-x_old",fig,global_step=i+1,close=True)

                    fig=PETLibs.utils.display3D_1cbar(var_v,interpolation='none',title=f"v-v_old/v_old_it{i+1}", perc= 0.7) #,vmin=-vmax,vmax=vmax)
                    writer.add_figure("v-v_old",fig,global_step=i+1,close=True)

                    writer.add_scalar("Accuracy/scaled_NormPrimal",primalN/np.linalg.norm(v),i+1)
                    writer.add_scalar("Accuracy/scaled_NormDual",dualN/np.linalg.norm(v),i+1)

                if (dualN/np.linalg.norm(v)<prec) & (primalN/np.linalg.norm(v)<prec):
                    print("Convergence reached")
                    break


            
            norm1.append(primalN)
            norm2.append(dualN)
            if twriter  :
                writer.add_scalar("Accuracy/NormPrimal",primalN,i+1)
                writer.add_scalar("Accuracy/NormDual",dualN,i+1)


        if i == 0:
            v_all = np.expand_dims(v, 0)
        else:
            v_all = np.concatenate((v_all,np.expand_dims(v, 0)), 0)

        if show_v:
            if twriter :
                fig=PETLibs.utils.display3D_1cbar(v,interpolation='none',vmax=vmax, vmin=vmin)
                writer.add_figure("v",fig,global_step=i+1,close=True)

            # mask_proj = np.where(v > 0, 1, 0)
            # fig=PETLibs.utils.display3D_1cbar(mask_proj,interpolation='none')
            # writer.add_figure("mask_v",fig,global_step=i+1,close=True)
        if verbose:
            print('Step 3:-------------------------------------------------------------------')

        u = u + x_ZYX - v

        if i == 0:
            u_all = np.expand_dims(u, 0)
        else:
            u_all = np.concatenate((u_all,np.expand_dims(u, 0)), 0)


        xt= torch.reshape(torch.tensor(np.swapaxes(x_ZYX,2,0),dtype=torch.float32, device = "cuda"),reconsParams.tb_im_dim)
        xt_mask = torch.where(xt > 0, torch.tensor(0.0, dtype=torch.float32, device = "cuda"), torch.tensor(1.0, dtype=torch.float32, device = "cuda"))
        xt_mask = np.swapaxes(xt_mask.squeeze().cpu().numpy(),2,0)
        

        if show_u:

            mask_proj = np.where(u > 0, 1, 0)

            if twriter :
                fig=PETLibs.utils.display3D_1cbar(u,interpolation='none',title=f"u_it{i+1}", perc=0.7) #,vmin=-vmax,vmax=vmax)
                writer.add_figure("u",fig,global_step=i+1,close=True)

                fig=PETLibs.utils.display3D_1cbar(mask_proj,interpolation='none')
                writer.add_figure("mask_u",fig,global_step=i+1,close=True)

                fig=PETLibs.utils.display3D_1cbar(xt_mask,interpolation='none',title=f"mask_it{i+1}") #,vmin=-vmax,vmax=vmax)
                writer.add_figure("mask",fig,global_step=i+1,close=True)

                fig=PETLibs.utils.display3D_1cbar(u,interpolation='none',title=f"u_it{i+1}",vmin=0,vmax=vmax)
                writer.add_figure("window_u",fig,global_step=i+1,close=True)



        if verbose:
            print('Updating Xref:-------------------------------------------------------------------')

        xref = v - u  

        if count:
            all_time.append(time.time() - t)

    if twriter :
        writer.close()



    results={}
    results["x"]=x_ZYX
    results["x_all"]=x_all
    results["v"]=v
    results["v_all"]=v_all
    results["u"]=u
    results["u_all"]=u_all
    results["mse"]=mse
    results["tv"]=tv
    if use_lpips:
        results["lpips"]=lpips
    results["mae"]=mae
    results["logl"]=log_l
    results["norm1"]=norm1
    results["norm2"]=norm2

    return results


##################################################################################
# find the i_neigh-th neighbors (in the sense of the squared difference between adjacent voxel values) for each voxel in the 3D image x_mri
# the neighbors are found in the 27-neighborhood of each voxel
# output = N is a 3D array of size (x_mri.shape[0], x_mri.shape[1], x_mri.shape[2], 27) that contains 1 if the voxel is a neighbor and 0 otherwise

def find_nearest_neighbors(x_mri, i_neigh):
    # Define 3D offsets for 26-neighbors
    offsets = np.array([[di, dj, dk] for di in range(-1, 2) for dj in range(-1, 2) for dk in range(-1, 2)])
    # Exclude the central voxel
    offsets = np.delete(offsets, np.argmax(np.all(offsets == 0, axis=1)), axis=0)
    
    # Initialize output array
    N = np.zeros((x_mri.shape[0], x_mri.shape[1], x_mri.shape[2], 27), dtype=int)

    # Iterate over each voxel
    for i in range(x_mri.shape[0]):
        for j in range(x_mri.shape[1]):
            for k in range(x_mri.shape[2]):
                # Calculate pixel value differences with neighbors
                diffs = np.abs(x_mri[i, j, k] - x_mri[i + offsets[:, 0], j + offsets[:, 1], k + offsets[:, 2]])
                # Find indices of nearest neighbors based on pixel value differences
                nearest_indices = np.argsort(diffs)[:i_neigh]
                # Mark nearest neighbors
                N[i, j, k, nearest_indices] = 1

    return N




# Example usage:
# x_mri = np.random.rand(10, 10, 10)  # Example 3D image
# i_neigh = 6  # Number of nearest neighbors to find
# neighbors = find_nearest_neighbors(x_mri, i_neigh)
# print(neighbors.shape)
  

def create_tv_kernel(size=9, pos=(1, 1, 1)):
    kernel = torch.zeros(size, size, size)
    kernel_t = torch.zeros(size, size, size)
    
    kernel[size // 2, size // 2, size // 2] = 1
    kernel_t[size // 2, size // 2, size // 2] = 1
    offset = (pos[0]- size // 2, pos[1] - size // 2, pos[2]- size // 2)
    kernel[pos[0], pos[1], pos[2]] = -1
    new_pos = (size // 2 - offset[0], size // 2 - offset[1], size // 2 - offset[2])
    kernel_t[new_pos[0], new_pos[1], new_pos[2]] = -1
    return kernel, kernel_t

def create_all_tv_kernels(size=9):
    kernels = torch.zeros(size*size*size -1, size, size, size)
    kernels_t = torch.zeros(size*size*size -1, size, size, size)
    i_kernel = 0
    
    for x in range(size):
        for y in range(size):
            for z in range(size):
              if not (x == size//2 and y == size//2 and z == size//2) :
                kernels[i_kernel,:, :,:] = create_tv_kernel(size, pos=(x, y, z))[0]
                kernels_t[i_kernel,:,:,:] = create_tv_kernel(size, pos=(x, y, z))[1]
                i_kernel += 1
              
    return kernels, kernels_t, i_kernel

##################################################################################

def GPU_ADMM_Bow(subject,
             dset_object, 
             x0, 
             u0,
             nit_admm, 
             pnlt_beta, 
             device,
             reconsParams=None, 
             evaluate = False,
             target=None,
             count = False, 
             show_initial = False, 
             show_x = "all", 
             show_v = False,
             show_u = False, 
             vmax=None, 
             vmin=None,
             verbose = False,
             real=0,
             twriter=False,
             tlog_dir=None,
             phantom = None, 
             algo_prox = "em", 
             use_lpips = False, 
             lbd = 1.0,
             prec = 5e-04,
             similarity_mat = None,
             scanner = "Biograph"
             ):
    

    if scanner == "Biograph":
        if reconsParams is None:
            reconsParams=GPUBiographReconsParams()
        if not isinstance(reconsParams,GPUBiographReconsParams):
            raise TypeError("ReconsParams type is not GPUBiographReconsParams")
    elif scanner == "Signa":
        if reconsParams is None:
            reconsParams=GPUSignaReconsParams()
        if not isinstance(reconsParams,GPUSignaReconsParams):
            raise TypeError("ReconsParams type is not GPUSignaReconsParams")
    else:
        raise TypeError('Scanner type {0} not enforced'.format(scanner))
    if not isinstance(dset_object,database_doserec.tensorDataSetDoserecParams):
        raise TypeError("dset_object type is not torchPETADMM.database.database_doserec.tensorDataSetDoserecParams")

    doserec_object=dset_object.doserecParams

    

    all_tv_kernels, all_tv_kernels_t, nb_kernels = create_all_tv_kernels(size = 3)
    all_tv_kernels = all_tv_kernels.unsqueeze(1).cuda()
    all_tv_kernels_t = all_tv_kernels_t.unsqueeze(0).cuda()

    if count:
        t = time.time()


    if twriter is True:
        writer=SummaryWriter(log_dir=tlog_dir)
        hparams_dict={}
        hparams_dict["subject"]=subject
        hparams_dict["real"]=real
        hparams_dict["nit_admm"]=nit_admm
        hparams_dict["pnlt_beta"]=pnlt_beta
        hparams2=copy.deepcopy(reconsParams.__dict__)
        lst_delete=[]
        dict_add={}
        for key in hparams2.keys():
            if torch.is_tensor(hparams2[key]):
                lst_delete+=[key]
            elif isinstance(hparams2[key],list):
                lst_delete+=[key]
                print(f"list {key}")
                for k in range(len(hparams2[key])):
                    new_k=f"{key}_{str(k)}"
                    dict_add[new_k]=hparams2[key][k]
        for key in lst_delete:
            del hparams2[key]
        hparams_dict.update(hparams2)
        hparams_dict.update(dict_add)
        fig=PETLibs.utils.display3D_1cbar(x0,interpolation='none',title=f"EM",vmax=vmax, vmin=vmin)
        writer.add_figure("EM",fig,global_step=0,close=True)
        plt.close(fig)

    if verbose:
            print('Initialization:-------------------------------------------------------------------------------------------------------------')

    fig=PETLibs.utils.display3D_1cbar(target,interpolation='none',vmax=vmax, vmin=vmin)
    if twriter is True:
        writer.add_figure("target",fig,global_step=0,close=True)
    xt_target= torch.reshape(torch.tensor(np.swapaxes(target,2,0),dtype=torch.float32, device = "cuda"),reconsParams.tb_im_dim)
    xt_mask = torch.where(xt_target > 0, torch.tensor(0.0, dtype=torch.float32, device = "cuda"), torch.tensor(1.0, dtype=torch.float32, device = "cuda"))
    xt_mask = np.swapaxes(xt_mask.squeeze().cpu().numpy(),2,0)

    fig=PETLibs.utils.display3D_1cbar(xt_mask,interpolation='none',title=f"mask_target") #,vmin=-vmax,vmax=vmax)
    if twriter is True:
        writer.add_figure("mask_target",fig,global_step=0,close=True)


    xt_target= torch.reshape(torch.tensor(np.swapaxes(phantom,2,0),dtype=torch.float32, device = "cuda"),reconsParams.tb_im_dim)
    xt_mask_ph = torch.where(xt_target > 0, torch.tensor(1.0, dtype=torch.float32, device = "cuda"), torch.tensor(0.0, dtype=torch.float32, device = "cuda"))
    xt_mask_ph = np.swapaxes(xt_mask_ph.squeeze().cpu().numpy(),2,0)
    # xt_mask_ph = np.ones_like(xt_mask_ph)

    fig=PETLibs.utils.display3D_1cbar(xt_mask_ph,interpolation='none',title=f"mask_phantom") #,vmin=-vmax,vmax=vmax)
    if twriter is True:
        writer.add_figure("mask_phantom",fig,global_step=0,close=True)

    fig=PETLibs.utils.display3D_1cbar(phantom,interpolation='none',vmax=vmax, vmin=vmin)
    if twriter is True:
        writer.add_figure("phantom",fig,global_step=0,close=True)


    u=u0 
    xref=x0

    
    #Load sinograms
    castor_df_ima,castor_df_hdr=doserec_object.get_fname_sinogram_CASToR_hdr(subject,real)
    castor_df_dir=doserec_object.get_gen_castor_dir(subject,real)
    castor_df_hdr_fpath=os.path.join(castor_df_dir,castor_df_hdr)
    dict_sino=GPURecons.GPUCASToRSinos(castor_df_hdr_fpath, castor_df_dir,
                                            reconsParams=reconsParams)
   
    if evaluate:
        criterion = torch.nn.MSELoss()
        criterion_MAE = torch.nn.L1Loss()
        criterion_tv = torchmetrics.TotalVariation(reduction="mean").cuda()
        if use_lpips:
            criterion_lpips = LearnedPerceptualImagePatchSimilarity3D().cuda()

        loss = criterion(torch.tensor(x0, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda")) 
        loss_phantom = criterion(torch.tensor(x0, dtype=torch.float32,device="cuda"), torch.tensor(phantom, dtype=torch.float32,device="cuda")) 
        loss_MAE = criterion_MAE(torch.tensor(x0, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
        loss_tv = ((criterion_tv(torch.tensor(target, dtype=torch.float32,device="cuda").unsqueeze(0)) - criterion_tv(torch.tensor(x0, dtype=torch.float32,device="cuda").unsqueeze(0)))**2)**0.5
        if use_lpips:
            loss_lpips = criterion_lpips(torch.tensor(x0, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
        mse = [loss.item()]
        mae = [loss_MAE.item()]
        tv = [loss_tv.item()]
        if use_lpips:
            lpips = [loss_lpips.item()]

     
        log_l = []
        norm1 = []
        norm2 = []
        tv12 = []
    else:
        reg = []
        mse = []
        mae = []
        tv = []
        lpips = []
        log_l = []
        tv12 = []
        norm1 = []
        norm2 = []

    

    for i in range(nit_admm):
        
        # pnlt_beta = vec_pnlt_beta[i]
        print("pnlt_beta",pnlt_beta)
        if count:
            t = time.time()

        if verbose:
            print('Iteration {}:-------------------------------------------------------------------------------------------------------------'.format(i+1))
            print('Step 1:-------------------------------------------------------------------')

        if i > 0:
            x_old = x_ZYX

        fig=PETLibs.utils.display3D_1cbar(xref,interpolation='none',title=f"x_in_prox_it{i+1}",vmax=vmax, vmin=vmin)
        if twriter is True:
            writer.add_figure("x_in_prox",fig,global_step=i+1,close=True)

        if reconsParams.XYZ:
            xprox=np.swapaxes(xref,2,0)
        if algo_prox == "em":
            x=PETLibs.recons.GPUProxReconsDPEM(castor_df_hdr_fpath, castor_df_ima,
                    reconsParams=reconsParams,xprox=xprox,pnlt_beta=pnlt_beta,
                    dict_sino=dict_sino,eval_mode=True,verbose = False,show_step = False,tensor_output=False, img_mask = xt_mask_ph)# x is np.array
        
        elif algo_prox == "spdhg":
            x, list_init_dual=PETLibs.recons.GPUProxReconsSPDHG(castor_df_hdr_fpath, castor_df_ima,
                reconsParams=reconsParams,xprox=xprox,pnlt_beta=pnlt_beta,
                dict_sino=dict_sino,nb_iter=reconsParams.nit, 
                warm_start = True if i> 0 else False, list_init_dual = list_init_dual if i> 0 else [], xstart=xstart if i> 0 else None, 
                i_img_mask= xt_mask_ph)
            
        elif algo_prox == "dbfb":
            x, list_init_dual =PETLibs.recons.GPUProxReconsDBFB(castor_df_hdr_fpath, castor_df_ima,
                reconsParams=reconsParams,xprox=xprox,pnlt_beta=pnlt_beta,
                dict_sino=dict_sino,nb_iter=reconsParams.nit, 
                warm_start = True if i> 0 else False, list_init_dual = list_init_dual if i> 0 else [],  
                i_img_mask= xt_mask_ph)
        else :
            raise ValueError("algo_prox must be em, spdhg or dbfb")
        inv_precond = None
        if inv_precond is not None:
            if reconsParams.XYZ:
                inv_precond=np.swapaxes(inv_precond,4,2)
           
            if dset_object.truncate < inv_precond.shape[2]:
                t = inv_precond.shape[2] - dset_object.truncate
                inv_precond = inv_precond[:,:,t:,:,:]
        
        xstart=x
        if reconsParams.XYZ:
            x_ZYX=np.swapaxes(x,2,0)
        else:
            x_ZYX=x

        
        if i == 0:
            x_all = np.expand_dims(x_ZYX, 0)
        else:
            x_all = np.concatenate((x_all,np.expand_dims(x_ZYX, 0)), 0)

        if (show_x == "all"):

            fig=PETLibs.utils.display3D_1cbar(x_ZYX,interpolation='none',vmax=vmax, vmin=vmin)
            if twriter is True:
                writer.add_figure("x",fig,global_step=i+1,close=True)


            # mask_proj = np.where(x_ZYX > 0, 1, 0)
            # fig=PETLibs.utils.display3D_1cbar(mask_proj,interpolation='none')
            # writer.add_figure("mask_x_ZYX",fig,global_step=i+1,close=True)

        elif (i == nit_admm-1) & (show_x == "last"):
            fig=PETLibs.utils.display3D_1cbar(x_ZYX,interpolation='none',title=f"x_last",vmax=vmax, vmin=vmin)
            if twriter is True:
                writer.add_figure("x",fig,global_step=i+1,close=True)

        if evaluate and i>0:
            if verbose:
                print('Evaluation Metric:-------------------------------------------------------------------')
            loss = criterion(torch.tensor(x_ZYX, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
            loss_phantom = criterion(torch.tensor(x_ZYX, dtype=torch.float32,device="cuda"), torch.tensor(phantom, dtype=torch.float32,device="cuda"))
            loss_tv = ((criterion_tv(torch.tensor(target, dtype=torch.float32,device="cuda").unsqueeze(0)) - criterion_tv(torch.tensor(x_ZYX, dtype=torch.float32,device="cuda").unsqueeze(0)))**2)**0.5
            if use_lpips:
                loss_lpips = criterion_lpips(torch.tensor(x_ZYX, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
                lpips.append(loss_lpips.item())
            loss_MAE = criterion_MAE(torch.tensor(x_ZYX, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
            mae.append(loss_MAE.item())
            mse.append(loss.item())
            tv.append(loss_tv.item())
            # 
            if verbose:
                print('Log Likelihood:-------------------------------------------------------------------')
            l = reconsEM.GPU_log_likelihood(subject,real,doserec_object,x, eps =0,
                                    reconsParams=reconsParams,dict_sino=dict_sino,eval_mode=True)#Note here x and not X_ZYX
            
            
            D_img = lambda x : F.conv3d(torch.tensor(x, dtype=torch.float32,device="cuda").unsqueeze(dim=1).unsqueeze(dim=1),all_tv_kernels,padding=1)
            # bow_reg = lbd*torch.sum((similarity_mat*D_img(x_ZYX))**2)
            # tv12.append(bow_reg)

            log_l.append(l)
            if twriter is True:
                writer.add_scalar("Loss/MSE",loss.item(),i+1)
                writer.add_scalar("Loss/MSE_phantom",loss_phantom.item(),i+1)
                writer.add_scalar("Loss/TV",loss_tv.item(),i+1)
                # writer.add_scalar("Loss/LL_TV", l - bow_reg, i+1)
                if use_lpips:
                    writer.add_scalar("Loss/LPIPS",loss_lpips.item(),i+1)
                writer.add_scalar("Loss/MAE",loss_MAE.item(),i+1)
                writer.add_scalar("Loss/LogLikelihood",l,i+1)

        if verbose:
            print('Updating X:-------------------------------------------------------------------')
            print('Step 2:-------------------------------------------------------------------')

        if evaluate and i>0:
            v_old = v
        fig=PETLibs.utils.display3D_1cbar((x_ZYX+u)* xt_mask_ph,interpolation='none',title=f"x+u_it{i+1}",vmax=vmax, vmin=vmin)
        if twriter is True:
            writer.add_figure("x+u",fig,global_step=i+1,close=True)

        fig=PETLibs.utils.display3D_1cbar((x_ZYX+u)* xt_mask_ph,interpolation='none',title=f"x+u_it{i+1}",perc=0.7)
        if twriter is True:
            writer.add_figure("x+u_perc",fig,global_step=i+1,close=True)
            
        n_image,sum_i=database_doserec.preprocess_data(x_ZYX+u,dset_object,device=device) #n_image is tensor
        print("reg_fair = ",lbd/pnlt_beta, "max img = ",np.max(x_ZYX+u), "max post = ",n_image.max())
        v = PETLibs.recons.Bowsher_GD(n_image,similarity_mat,lbd/pnlt_beta)
        v=database_doserec.postprocess_data(v,sum_i,dset_object, device=device)# v is np.array

        # mask in D
        # v = v * xt_mask_ph

        if evaluate and i>0:
            if verbose:
                
                print('Evaluation: ADMM CONVERGENCE--------------------------------------------------')
            primalN=np.linalg.norm(x_ZYX-v)
            dualN=np.linalg.norm(v-v_old)

            if i > 0:
                var_v = (v-v_old)/dualN

                fig=PETLibs.utils.display3D_1cbar(var_v,interpolation='none',title=f"v-v_old/v_old_it{i+1}", perc= 0.7) #,vmin=-vmax,vmax=vmax)
                if twriter is True:
                    writer.add_figure("v-v_old",fig,global_step=i+1,close=True)

                var_x = (x_ZYX-x_old)/np.linalg.norm(x_ZYX-x_old)

                fig=PETLibs.utils.display3D_1cbar(var_x,interpolation='none',title=f"x-x_old/x_old_it{i+1}", perc= 0.7) #,vmin=-vmax,vmax=vmax)
                if twriter is True:
                    writer.add_figure("x-x_old",fig,global_step=i+1,close=True)

                writer.add_scalar("Accuracy/scaled_NormPrimal",primalN/np.linalg.norm(v),i+1)
                writer.add_scalar("Accuracy/scaled_NormDual",dualN/np.linalg.norm(v),i+1)
                if (dualN/np.linalg.norm(v)<prec) & (primalN/np.linalg.norm(v)<prec):
                    print("Convergence reached")
                    break


                
           
            norm1.append(primalN)
            norm2.append(dualN)
            if twriter is True:
                writer.add_scalar("Accuracy/NormPrimal",primalN,i+1)
                writer.add_scalar("Accuracy/NormDual",dualN,i+1)


        if i == 0:
            v_all = np.expand_dims(v, 0)
        else:
            v_all = np.concatenate((v_all,np.expand_dims(v, 0)), 0)

        if show_v:

            fig=PETLibs.utils.display3D_1cbar(v,interpolation='none',vmax=vmax, vmin=vmin)
            if twriter is True:
                writer.add_figure("v",fig,global_step=i+1,close=True)

            # mask_proj = np.where(v > 0, 1, 0)
            # fig=PETLibs.utils.display3D_1cbar(mask_proj,interpolation='none')
            # writer.add_figure("mask_v",fig,global_step=i+1,close=True)
        if verbose:
            print('Step 3:-------------------------------------------------------------------')

        u = u + x_ZYX - v

        if i == 0:
            u_all = np.expand_dims(u, 0)
        else:
            u_all = np.concatenate((u_all,np.expand_dims(u, 0)), 0)


        
        
        xt= torch.reshape(torch.tensor(np.swapaxes(x_ZYX,2,0),dtype=torch.float32, device = "cuda"),reconsParams.tb_im_dim)
        xt_mask = torch.where(xt > 0, torch.tensor(0.0, dtype=torch.float32, device = "cuda"), torch.tensor(1.0, dtype=torch.float32, device = "cuda"))
        xt_mask = np.swapaxes(xt_mask.squeeze().cpu().numpy(),2,0)
        

        if show_u:

            fig=PETLibs.utils.display3D_1cbar(u,interpolation='none',title=f"u_it{i+1}", perc=0.7) #,vmin=-vmax,vmax=vmax)
            if twriter is True:
                writer.add_figure("u",fig,global_step=i+1,close=True)


            mask_proj = np.where(u > 0, 1, 0)
            fig=PETLibs.utils.display3D_1cbar(mask_proj,interpolation='none')
            writer.add_figure("mask_u",fig,global_step=i+1,close=True)


            fig=PETLibs.utils.display3D_1cbar(xt_mask,interpolation='none',title=f"mask_it{i+1}") #,vmin=-vmax,vmax=vmax)
            if twriter is True:
                writer.add_figure("mask",fig,global_step=i+1,close=True)

            fig=PETLibs.utils.display3D_1cbar(u,interpolation='none',title=f"u_it{i+1}",vmin=0,vmax=vmax)
            if twriter is True:
                writer.add_figure("window_u",fig,global_step=i+1,close=True)



        if verbose:
            print('Updating Xref:-------------------------------------------------------------------')

        xref = v - u  

    writer.close()



    results={}
    results["x"]=x_ZYX
    results["x_all"]=x_all
    results["v"]=v
    results["v_all"]=v_all
    results["u"]=u
    results["u_all"]=u_all
    results["mse"]=mse
    results["tv"]=tv
    if use_lpips:
        results["lpips"]=lpips
    results["mae"]=mae
    results["logl"]=log_l
    results["norm1"]=norm1
    results["norm2"]=norm2

    return results


##################################################################################
def GPU_ADMM(subject,
             dset_object, 
             x0, 
             u0,
             nit_admm, 
             pnlt_beta, 
             model, 
             device,
             reconsParams=None, 
             evaluate = False,
             target=None,
             count = False, 
             show_initial = False, 
             show_x = "all", 
             show_v = False,
             show_u = False, 
             show_target = True, 
             show_metrics = True,
             vmax=None, 
             vmin=None,
             verbose = False,
             real=0,
             twriter=False,
             tlog_dir=None,
             model_name=None, 
             sigma_scale=None, 
             version_F = False, 
             max_iter_jacobian = 10, 
             phantom = None, 
             algo_prox = "em", 
             bUsePrecond = False, 
             init_ADMM = False, 
             denoised_img = None,
             prec = 5e-04, 
             bUseWeighted = False,
             bNE_Archi = False,
             gamma= None, 
             mri = None,
             bOpt = False,
             fElastic = 0.0,
             xem = None,
             frelax = 1.0,
             scaled_dose = 1.0,
             delta = 1.0,
             eta = 2.0, 
             evaluate_jac = False,
             scanner = "Biograph", 
             dict_sino = None,
             bSmoothEMDEQ = False,
             bWarmStart = False,
             bNoMask = False
             ):
    '''
    Applies the Alternating Direction Method of Multipliers using an input image and a reference image.
    The Reconstruction step is performed using a Proximal Method with GPU projectors,
    the denoising step is performed using a trained neural network.
    The algorithm is evaluated using Log-Likelihood (on x), MSE (on x), Square Jacobian Spectral Norm (on v-u),
    Primal (x-v) and Dual Residuals (v^{n}-v^{n-1}).
    The algorithm is initialized as a Douglas-Rachford algorithm with z^{(0)}=x^{(0)}+u^{(0)},
    with the first operator NN and the second operator Prox_{f/\beta} (the reconstuction step)
    ie v^{(0)}=NN(x^{(0)}+u^{(0)}), u^{(1)}=x^{(0)}+u^{(0)}-v^{(0)}. Then the following ADMM steps are computed:
    x^{(1)}=Prox_{f/\beta}(v^{(0)}-u^({1})), v^{(1)}=NN(x^{(1)}+u^{(1)}, u^{(2)}=x^{(1)}+u^{(1)}-v^{(1)}.


    Arguments:
        - subject: subject name (string).
        - dset_object: data set descriptor (tensorDataSetDoserecParams).
        - x0: Initial reference image for first step (numpy  ndarray, ZYX convention, x0 in DR).
        - u0: Initial u image (numpy  ndarray, ZYX convention, result of the 2nd step).
        - nit_admm: Number of ADMM iterations (int).
        - pnlt_beta: Proximal Method Beta/Rho.
        - model: Neural Network model.
        - device: Device used for prediction (Possible values: "cpu", "gpu").
        - reconsParams: parameters used for first subproblem (prox) (BiographReconsParams, default:None ie default parameters for Biograph).
        - evaluate: compute metrics (Default value: False)
        - target: target image to compute metrics (Default value: None).
        - count: Counts the time taken for every iteration (Default value: False).
        - show_initial: Displays the initial inputs (Default value: False).
        - show_x: Displays the x image every iteration (Default value: "all")
        - show_v: Displays the v image every iteration (Default value: False)
        - show_u: Displays the u image every iteration (Default value: False)
        - show_target: Displays the target image (Default value: True).
        - show_metrics: Plots True,  (Default value: True)
        - vmax: Maximum value for colorscale of images  (Default value: None)
        - truncate: Truncates the images' first dimension for neural network
                    (int, so that zrange=data_x.shape[1]-truncate, defqult: 104).
        - verbose: verbosity (Default value: False)
        - real: dose realization number (int, Default value: 0)
        - twriter: tensorboard writer on (boolean, Default value: False)
        - tlog_dir: tensorboard writer save directory (Default value: None)
        - model_name: name of model for tensorboard writer (string, Default value: None)

    Returns: dictionary with following key:values
        x: x image  (numpy ndarray, ZYX convention).
        x_all: All x images (list of numpy ndarray, ZYX convention).
        v: v image (numpy ndarray, ZYX convention).
        v_all: All v images (list of numpy ndarray, ZYX convention).
        u: u image  (numpy ndarray, ZYX convention).
        u_all: All u images (list of numpy ndarray, ZYX convention).
        mse: Mean Squared Error (computed on x).
        reg: Square Jacobian Spectral Norm (computed on input of NN).
        log_l: Log-Likelihood (computed on x).
        norm1: Primal Residual.
        norm2: Dual Residual.
        all_time: Time taken for every iteration.
    '''

    if scanner == "Biograph":
        if reconsParams is None:
            reconsParams=GPUBiographReconsParams()
        if not isinstance(reconsParams,GPUBiographReconsParams):
            raise TypeError("ReconsParams type is not GPUBiographReconsParams")
    elif scanner == "Signa":
        if reconsParams is None:
            reconsParams=GPUSignaReconsParams()
        if not isinstance(reconsParams,GPUSignaReconsParams):
            raise TypeError("ReconsParams type is not GPUSignaReconsParams")
    else:
        raise TypeError('Scanner type {0} not enforced'.format(scanner))
    if not isinstance(dset_object,database_doserec.tensorDataSetDoserecParams):
        raise TypeError("dset_object type is not torchPETADMM.database.database_doserec.tensorDataSetDoserecParams")

    doserec_object=dset_object.doserecParams
    use_lpips = False
    # norm_sj=dset_object.norm_sj
    # norm_train=dset_object.norm_train

    # zdim,ydim,xdim=x0.shape
    # zstart=zdim-dset_object.truncate #starting plane for network
   
    
    if count:
        t = time.time()


    if twriter :
        writer=SummaryWriter(log_dir=tlog_dir)
        hparams_dict={}
        if dict_sino is None:
            hparams_dict["subject"]=subject
            hparams_dict["real"]=real
        hparams_dict["nit_admm"]=nit_admm
        hparams_dict["pnlt_beta"]=pnlt_beta
        hparams_dict["model"]=model_name
        hparams2=copy.deepcopy(reconsParams.__dict__)
        lst_delete=[]
        dict_add={}
        for key in hparams2.keys():
            if torch.is_tensor(hparams2[key]):
                lst_delete+=[key]
            elif isinstance(hparams2[key],list):
                lst_delete+=[key]
                print(f"list {key}")
                for k in range(len(hparams2[key])):
                    new_k=f"{key}_{str(k)}"
                    dict_add[new_k]=hparams2[key][k]
        for key in lst_delete:
            del hparams2[key]
        hparams_dict.update(hparams2)
        hparams_dict.update(dict_add)
        fig=PETLibs.utils.display3D_1cbar(x0,interpolation='none',title=f"EM",vmax=vmax, vmin=vmin)
        writer.add_figure("EM",fig,global_step=0,close=True)
        plt.close(fig)

    if verbose:
            print('Initialization:-------------------------------------------------------------------------------------------------------------')
            print("delta", delta, "eta", eta)
    # if show_target:

    
    if twriter:
        fig=PETLibs.utils.display3D_1cbar(target,interpolation='none',vmax=vmax, vmin=vmin)
        writer.add_figure("target",fig,global_step=0,close=True)

    xt_target= torch.reshape(torch.tensor(np.swapaxes(target,2,0),dtype=torch.float32, device = "cuda"),reconsParams.tb_im_dim)
    xt_mask = torch.where(xt_target > 0, torch.tensor(0.0, dtype=torch.float32, device = "cuda"), torch.tensor(1.0, dtype=torch.float32, device = "cuda"))
    xt_mask = np.swapaxes(xt_mask.squeeze().cpu().numpy(),2,0)
    # xt_denoised = torch.reshape(torch.tensor(np.swapaxes(denoised_img,2,0),dtype=torch.float32, device = "cuda"),reconsParams.tb_im_dim)

    xt_target= torch.reshape(torch.tensor(np.swapaxes(phantom,2,0),dtype=torch.float32, device = "cuda"),reconsParams.tb_im_dim)
    xt_mask_ph = torch.where(xt_target > 0, torch.tensor(1.0, dtype=torch.float32, device = "cuda"), torch.tensor(0.0, dtype=torch.float32, device = "cuda"))
    xt_mask_ph = np.swapaxes(xt_mask_ph.squeeze().cpu().numpy(),2,0)
    # xt_mask_ph = np.ones_like(xt_mask_ph)


    if twriter :
        fig=PETLibs.utils.display3D_1cbar(phantom,interpolation='none',vmax=vmax, vmin=vmin)
        writer.add_figure("phantom",fig,global_step=0,close=True)


    xEM_G,_=database_doserec.preprocess_data(xem,dset_object,device=device)

    if bSmoothEMDEQ: 

        kernel_size = 5
        fwhm = 8
        sigma_gaussian = fwhm2sigma(fwhm)
        smoothing = GaussianSmoothing(1, kernel_size, sigma_gaussian, 3).to(device)
        xEM_G = smoothing(xEM_G)

    v0,sum_v0=database_doserec.preprocess_data(x0+u0,dset_object,device=device)
    sigma = torch.from_numpy(xt_mask_ph).to(device).unsqueeze(0).unsqueeze(0)
    if mri is not None:
        gpu_mri = mri #,_=database_doserec.preprocess_data(mri,dset_object,device=device)
    else :
        gpu_mri = None

    if dset_object.truncate < sigma.shape[2]:
        t = sigma.shape[2] - dset_object.truncate
        sigma = sigma[:,:,t:,:,:]
    if bNoMask :
        print("not using mask")
        sigma = 1.0
        xt_mask_ph = 1.0

    # if version_F : 
    #     v = model.base.forward(v0) 
    # else :
    #     print(sigma.shape)
    #     v = model.base.forward(v0, sigma) #training.predict(model,v0, device) #z^{1/2} in DR
    v=database_doserec.postprocess_data(v0,sum_v0,dset_object, device=device,tensorFlag=False)
    # mask in D
    v = v * xt_mask_ph
    # v is EM

    x=x0
    # x is EM

    
    if twriter :
        fig=PETLibs.utils.display3D_1cbar(x,interpolation='none',title="x0",vmax=vmax, vmin=vmin)
        writer.add_figure("x",fig,global_step=0,close=True)

    # EM + 0 - EM*mask
    u=x0+u0-v  #init point for u, which is u^(1) in DR
    # u = u0
    xref = v + (1.0-eta)*u ##init point for xref, which is x^(1/2)-u^(1) in DR

    
    #Load sinograms
    if dict_sino is None :
        castor_df_ima,castor_df_hdr=doserec_object.get_fname_sinogram_CASToR_hdr(subject,real)
        castor_df_dir=doserec_object.get_gen_castor_dir(subject,real)
        castor_df_hdr_fpath=os.path.join(castor_df_dir,castor_df_hdr)
        dict_sino=GPURecons.GPUCASToRSinos(castor_df_hdr_fpath, castor_df_dir,
                                                reconsParams=reconsParams)
    else :
        castor_df_hdr_fpath = None
        castor_df_ima = None
        castor_df_hdr_fpath = None
        castor_df_ima = None

    y_data = dict_sino["val"]
    dose = y_data.sum()
    invdose_scaled = scaled_dose/dose
    # print("scaled dose information", invdose_scaled)
    del y_data

    if bOpt:
        pnlt_beta = 1.0/(0.00408709*dose+13665.0)
    
    
    if init_ADMM:
        print("init_ADMM")
        u= (1.0/pnlt_beta)*reconsEM.GPU_gradient(subject,real,doserec_object, np.swapaxes(x0,2,0), eps =0, reconsParams=reconsParams,
                                            dict_sino=dict_sino,eval_mode=True)
        u = u*xt_mask_ph
        xref=v #EM

    criterion = torch.nn.MSELoss()
    criterion_MAE = torch.nn.L1Loss()
    # criterion_tv = torchmetrics.TotalVariation(reduction="mean").cuda()
    if use_lpips:
        criterion_lpips = LearnedPerceptualImagePatchSimilarity3D().cuda()

    if evaluate:
        loss = criterion(torch.tensor(x0, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda")) 
        loss_phantom = criterion(torch.tensor(x0, dtype=torch.float32,device="cuda"), torch.tensor(phantom, dtype=torch.float32,device="cuda")) 
        loss_MAE = criterion_MAE(torch.tensor(x0, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
        # loss_tv = ((criterion_tv(torch.tensor(target, dtype=torch.float32,device="cuda").unsqueeze(0)) - criterion_tv(torch.tensor(x0, dtype=torch.float32,device="cuda").unsqueeze(0)))**2)**0.5

        x_XYZ=np.swapaxes(phantom,2,0)
        l = PETLibs.GPURecons.GPU_log_likelihood(x_XYZ, eps =0, reconsParams=reconsParams,
                                        dict_sino=dict_sino,eval_mode=True, bUseWeighted= bUseWeighted)
        del x_XYZ
        writer.add_scalar("Loss/LogLikelihood_phantom",l,global_step=0)
        
        x_XYZ=np.swapaxes(target,2,0)
        l = PETLibs.GPURecons.GPU_log_likelihood(x_XYZ, eps =0, reconsParams=reconsParams,
                                        dict_sino=dict_sino,eval_mode=True, bUseWeighted= bUseWeighted)
        del x_XYZ
        
        writer.add_scalar("Loss/LogLikelihood_target",l,global_step=0)

        x_XYZ=np.swapaxes(xem,2,0)
        l = PETLibs.GPURecons.GPU_log_likelihood(x_XYZ, eps =0, reconsParams=reconsParams,
                                        dict_sino=dict_sino,eval_mode=True, bUseWeighted= bUseWeighted)
        del x_XYZ
        writer.add_scalar("Loss/LogLikelihood_EM",l,global_step=0)


        if use_lpips:
            loss_lpips = criterion_lpips(torch.tensor(x0, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
        mse = [loss.item()]
        mae = [loss_MAE.item()]
        # tv = [loss_tv.item()]
        if use_lpips:
            lpips = [loss_lpips.item()]
        reg_fun = jacobian.JacobianReg_l2(max_iter=max_iter_jacobian, eval_mode=True)

        if twriter :
            fig=PETLibs.utils.display3D_1cbar(x0+u0,interpolation='none',title=f"NN_init",vmax=vmax, vmin=vmin)
            writer.add_figure("NN_init",fig,global_step=0,close=True)

            fig=PETLibs.utils.display3D_1cbar(v,interpolation='none',title=f"postNN_init",vmax=vmax, vmin=vmin)
            writer.add_figure("postNN_init",fig,global_step=0,close=True)

            fig=PETLibs.utils.display3D_1cbar(u,interpolation='none',title=f"u0", perc=0.7)
            writer.add_figure("u0",fig,global_step=0,close=True)


        if version_F :
            reg_loss, reg_loss_all = jacobian.compute_reg(v0,v0,model.base, reg_fun,
                    device = device, eval_mode = True)

        else :
            reg_loss, reg_loss_all = jacobian.compute_reg(v0,v0,lambda v: model(v, sigma, bNE_Archi=bNE_Archi, gamma= gamma, xcond = gpu_mri, xEM=xEM_G, invdose= invdose_scaled, bTrain=False)[0], reg_fun,
                    device = device, eval_mode = True, bResNE=(fElastic == 0.5))#Jacobian on input point of NN
        reg_loss = reg_loss.item()
        reg_loss_all = reg_loss_all.detach().cpu().numpy()
        reg = [reg_loss]
        reg_loss_all=reg_loss_all[reg_loss_all>0]
        fig_sp=plt.figure()
        plt.plot(np.arange(len(reg_loss_all)),reg_loss_all,figure=fig_sp,label="it. 0")
        if reconsParams.XYZ:

            x_XYZ=np.swapaxes(x,2,0)
            l = PETLibs.GPURecons.GPU_log_likelihood(x_XYZ, eps =0, reconsParams=reconsParams,
                                        dict_sino=dict_sino,eval_mode=True, bUseWeighted= bUseWeighted)
            del x_XYZ
        else:
            l = PETLibs.GPURecons.GPU_log_likelihood(x, eps =0, reconsParams=reconsParams,
                                        dict_sino=dict_sino,eval_mode=True, bUseWeighted= bUseWeighted)

        log_l = [l]
        norm1 = []
        norm2 = []
    else:
        reg = []
        mse = []
        mae = []
        tv = []
        lpips = []
        log_l = []
        norm1 = []
        norm2 = []

    if count:
        all_time = [time.time() - t]
    else:
        all_time = []

    if twriter and evaluate :
        writer.add_scalar("Loss/LogLikelihood",l,global_step=0)
        writer.add_scalar("Loss/MSE",loss.item(),global_step=0)
        writer.add_scalar("Loss/MSE_phantom",loss_phantom.item(),global_step=0)
        # writer.add_scalar("Loss/TV",loss_tv.item(),global_step=0)
        writer.add_scalar("Loss/Beta",pnlt_beta,global_step=0)
        if use_lpips:
            writer.add_scalar("Loss/LPIPS",loss_lpips.item(),global_step=0)
        writer.add_scalar("Loss/MAE",loss_MAE.item(),global_step=0)
        writer.add_scalar("Loss/SRadiusJacobian",reg_loss,global_step=0)


    for i in range(nit_admm):
        
        # pnlt_beta = vec_pnlt_beta[i]
        if count:
            t = time.time()

        if verbose:
            print('Iteration {}:-------------------------------------------------------------------------------------------------------------'.format(i+1))
            print('Step 1:-------------------------------------------------------------------')

        if i > 0:
            x_old = x_ZYX

        if twriter :
            fig=PETLibs.utils.display3D_1cbar(xref,interpolation='none',title=f"x_in_prox_it{i+1}",vmax=vmax, vmin=vmin)
            writer.add_figure("x_in_prox",fig,global_step=i+1,close=True)

        if reconsParams.XYZ:
            if fElastic > 0.0:
                xprox=np.swapaxes((xref + delta*fElastic*xem)/(1.0+delta*fElastic),2,0)
                if twriter :
                    fig=PETLibs.utils.display3D_1cbar((xref + delta*fElastic*xem)/(1.0+delta*fElastic),interpolation='none',perc=0.7)
                    writer.add_figure("xref",fig,global_step=i+1,close=True)
                    fig=PETLibs.utils.display3D_1cbar(xem,interpolation='none',vmax=vmax, vmin=vmin)
                    writer.add_figure("xem",fig,global_step=i+1,close=True)

                weight = pnlt_beta*(1+delta*fElastic)/delta
            else :
                xprox=np.swapaxes(xref,2,0)
                weight = pnlt_beta/delta


        if algo_prox == "em":
            x=PETLibs.recons.GPUProxReconsDPEM(castor_df_hdr_fpath, castor_df_ima,
                reconsParams=reconsParams,xprox=xprox,pnlt_beta=weight, xstart=xstart if ((i> 0) and bWarmStart) else None, 
                dict_sino=dict_sino,eval_mode=True,verbose = False,show_step = False,
                tensor_output=False, img_mask = None if bNoMask else xt_mask_ph, bUseWeighted = bUseWeighted)
 
        
        elif algo_prox == "spdhg":
            x, list_init_dual=PETLibs.recons.GPUProxReconsSPDHG(castor_df_hdr_fpath, castor_df_ima,
                reconsParams=reconsParams,xprox=xprox,pnlt_beta=weight,
                dict_sino=dict_sino,nb_iter=reconsParams.nit, 
                warm_start = True if i> 0 else False, list_init_dual = list_init_dual if i> 0 else [], xstart=xstart if i> 0 else None, 
                i_img_mask= xt_mask_ph, use_precond = bUsePrecond, bUseWeighted = bUseWeighted)
            
        elif algo_prox == "dbfb":
            x, list_init_dual =PETLibs.recons.GPUProxReconsDBFB(castor_df_hdr_fpath, castor_df_ima,
                reconsParams=reconsParams,xprox=xprox,pnlt_beta=weight,
                dict_sino=dict_sino,nb_iter=reconsParams.nit, 
                warm_start = True if i> 0 else False, list_init_dual = list_init_dual if i> 0 else [],  
                i_img_mask= xt_mask_ph, use_precond = bUsePrecond)
        else :
            raise ValueError("algo_prox must be em, spdhg or dbfb")
        inv_precond = None
        if inv_precond is not None:
            if reconsParams.XYZ:
                inv_precond=np.swapaxes(inv_precond,4,2)
           
            if dset_object.truncate < inv_precond.shape[2]:
                t = inv_precond.shape[2] - dset_object.truncate
                inv_precond = inv_precond[:,:,t:,:,:]
        
        xstart=x
        if reconsParams.XYZ:
            x_ZYX=np.swapaxes(x,2,0)
        else:
            x_ZYX=x

        if evaluate:
            if verbose:
                print('Evaluation:-------------------------------------------------------------------')

        if i == 0:
            x_all = np.expand_dims(x_ZYX, 0)
        else:
            x_all = np.concatenate((x_all,np.expand_dims(x_ZYX, 0)), 0)

        if (show_x == "all"):

            if twriter :
                fig=PETLibs.utils.display3D_1cbar(x_ZYX,interpolation='none',vmax=vmax, vmin=vmin)
                writer.add_figure("x",fig,global_step=i+1,close=True)


        elif (i == nit_admm-1) & (show_x == "last"):
            if twriter :
                fig=PETLibs.utils.display3D_1cbar(x_ZYX,interpolation='none',vmax=vmax, vmin=vmin)

                writer.add_figure("x",fig,global_step=i+1,close=True)

        if evaluate or i == nit_admm-1:
            if verbose:
                print('Evaluation Metric:-------------------------------------------------------------------')
            loss = criterion(torch.tensor(x_ZYX, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
            loss_phantom = criterion(torch.tensor(x_ZYX, dtype=torch.float32,device="cuda"), torch.tensor(phantom, dtype=torch.float32,device="cuda"))
            # loss_tv = ((criterion_tv(torch.tensor(target, dtype=torch.float32,device="cuda").unsqueeze(0)) - criterion_tv(torch.tensor(x_ZYX, dtype=torch.float32,device="cuda").unsqueeze(0)))**2)**0.5
            if use_lpips:
                loss_lpips = criterion_lpips(torch.tensor(x_ZYX, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
                lpips.append(loss_lpips.item())
            loss_MAE = criterion_MAE(torch.tensor(x_ZYX, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
            mae.append(loss_MAE.item())
            mse.append(loss.item())
            # tv.append(loss_tv.item())
            # 
            if verbose:
                print('Log Likelihood:-------------------------------------------------------------------')
            if evaluate:
                l = PETLibs.GPURecons.GPU_log_likelihood(x, eps =0,
                                        reconsParams=reconsParams,dict_sino=dict_sino,eval_mode=True, bUseWeighted = bUseWeighted)#Note here x and not X_ZYX
                log_l.append(l)
                if twriter :
                    writer.add_scalar("Loss/MSE",loss.item(),i+1)
                    writer.add_scalar("Loss/MSE_phantom",loss_phantom.item(),i+1)
                    # writer.add_scalar("Loss/TV",loss_tv.item(),i+1)
                    if use_lpips:
                        writer.add_scalar("Loss/LPIPS",loss_lpips.item(),i+1)
                    writer.add_scalar("Loss/MAE",loss_MAE.item(),i+1)
                    writer.add_scalar("Loss/LogLikelihood",l,i+1)

        if verbose:
            print('Updating X:-------------------------------------------------------------------')
            print('Step 2:-------------------------------------------------------------------')

        v_old = v
        
        if ((frelax != 1.0) and (i>0)):
            in_NN = x_old+frelax*(x_ZYX - x_old)  + u
        else :
            in_NN = x_ZYX + u
        
        if twriter :
            fig=PETLibs.utils.display3D_1cbar(in_NN* xt_mask_ph,interpolation='none',title=f"x+u_it{i+1}",vmax=vmax, vmin=vmin)
            writer.add_figure("x+u",fig,global_step=i+1,close=True)

            fig=PETLibs.utils.display3D_1cbar(in_NN* xt_mask_ph,interpolation='none',title=f"x+u_it{i+1}",perc=0.7)
            writer.add_figure("x+u_perc",fig,global_step=i+1,close=True)
         
           
        n_image,sum_i=database_doserec.preprocess_data(in_NN,dset_object,device=device) #n_image is tensor

        # sigma = torch.from_numpy(xt_mask_ph).to(device).unsqueeze(0).unsqueeze(0)
        # if dset_object.truncate < sigma.shape[2]:
        #     t = sigma.shape[2] - dset_object.truncate
        #     sigma = sigma[:,:,t:,:,:]
        if version_F:
            v = model.base.forward(n_image)
        else :
            v = model(n_image,sigma, bNE_Archi= bNE_Archi, gamma= gamma, xcond = gpu_mri, xEM = xEM_G, invdose=invdose_scaled, bTrain=False)[0] #training.predict(model,n_image, device)
        # print("vmin",v.min(), "vmax",v.max())
        v=database_doserec.postprocess_data(v,sum_i,dset_object, device=device)# v is np.array
        # print("vmin",v.min(), "vmax",v.max())
        # mask in D
        # v = v * xt_mask_ph

        if evaluate:
            if verbose:
                print('Evaluation:JAC----------------------------------------------------------------')
            if version_F:   
                reg_loss, reg_loss_all = jacobian.compute_reg(n_image,n_image,model.base,
                                    reg_fun, device = device, eval_mode = True, precond = torch.pow(inv_precond, 0.5) if inv_precond is not None else None)
            else :
                reg_loss, reg_loss_all = jacobian.compute_reg(n_image,n_image,lambda v: model(v, sigma, bNE_Archi=bNE_Archi, gamma=gamma, xcond = gpu_mri, xEM=xEM_G, invdose=invdose_scaled, bTrain=False)[0],
                                    reg_fun, device = device, eval_mode = True, precond = torch.pow(inv_precond, 0.5) if inv_precond is not None else None, bResNE=(fElastic == 0.5))
                #Jacobian on input of network
            reg_loss = reg_loss.item()
            reg_loss_all = reg_loss_all.detach().cpu().numpy()
            reg.append(reg_loss)
            if twriter :
                writer.add_scalar("Loss/S2RadiusJacobian",reg_loss,i+1)
                reg_loss_all=reg_loss_all[reg_loss_all>0]
                plt.plot(np.arange(len(reg_loss_all)),reg_loss_all,figure=fig_sp,label=f"it. {i+1}")
                writer.add_figure("Spectral Radius",fig_sp,global_step=0,close=False)
        if verbose:
            print('Evaluation: ADMM CONVERGENCE--------------------------------------------------')
        primalN=np.linalg.norm(x_ZYX-v)
        dualN=np.linalg.norm(v-v_old)

        if i > 0:
            var_v = np.linalg.norm(v-v_old)**2/np.linalg.norm(v)**2

            # fig=PETLibs.utils.display3D_1cbar(var_v,interpolation='none',title=f"v-v_old/v_old_it{i+1}", perc= 0.7) #,vmin=-vmax,vmax=vmax)
            # if twriter is True:
            #     writer.add_figure("v-v_old",fig,global_step=i+1,close=True)

            var_x = np.linalg.norm(x_ZYX-x_old)**2/np.linalg.norm(x_ZYX)**2
            
            if twriter:
                writer.add_scalar("Accuracy/var_x",var_x,i+1)
                writer.add_scalar("Accuracy/var_v",var_v,i+1)

                # fig=PETLibs.utils.display3D_1cbar(var_x,interpolation='none',title=f"x-x_old/x_old_it{i+1}", perc= 0.7) #,vmin=-vmax,vmax=vmax)
                # if twriter is True:
                #     writer.add_figure("x-x_old",fig,global_step=i+1,close=True)

                
                writer.add_scalar("Accuracy/scaled_NormPrimal",primalN/np.linalg.norm(v),i+1)
                writer.add_scalar("Accuracy/scaled_NormDual",dualN/np.linalg.norm(v),i+1)

            if (dualN/np.linalg.norm(v)<prec) & (primalN/np.linalg.norm(v)<prec):
                print("Convergence reached")
                break


        norm1.append(primalN)
        norm2.append(dualN)
        if twriter :
            writer.add_scalar("Accuracy/NormPrimal",primalN,i+1)
            writer.add_scalar("Accuracy/NormDual",dualN,i+1)


        if i == 0:
            v_all = np.expand_dims(v, 0)
        else:
            v_all = np.concatenate((v_all,np.expand_dims(v, 0)), 0)

        if show_v:

            if twriter :
                fig=PETLibs.utils.display3D_1cbar(v,interpolation='none',vmax=vmax, vmin=vmin)
                writer.add_figure("v",fig,global_step=i+1,close=True)

                fig=PETLibs.utils.display3D_1cbar(x_ZYX-v,interpolation='none',perc=0.7)
                writer.add_figure("x_v",fig,global_step=i+1,close=True)

            # mask_proj = np.where(v > 0, 1, 0)
            # fig=PETLibs.utils.display3D_1cbar(mask_proj,interpolation='none')
            # writer.add_figure("mask_v",fig,global_step=i+1,close=True)
        if verbose:
            print('Step 3:-------------------------------------------------------------------')

        u = u + x_ZYX - v

        if i == 0:
            u_all = np.expand_dims(u, 0)
        else:
            u_all = np.concatenate((u_all,np.expand_dims(u, 0)), 0)


        
        
        xt= torch.reshape(torch.tensor(np.swapaxes(x_ZYX,2,0),dtype=torch.float32, device = "cuda"),reconsParams.tb_im_dim)
        xt_mask = torch.where(xt > 0, torch.tensor(0.0, dtype=torch.float32, device = "cuda"), torch.tensor(1.0, dtype=torch.float32, device = "cuda"))
        xt_mask = np.swapaxes(xt_mask.squeeze().cpu().numpy(),2,0)
        

        if show_u and twriter:

            fig=PETLibs.utils.display3D_1cbar(u,interpolation='none',title=f"u_it{i+1}", perc=0.7) #,vmin=-vmax,vmax=vmax)
            writer.add_figure("u",fig,global_step=i+1,close=True)


            mask_proj = np.where(u > 0, 1, 0)
            fig=PETLibs.utils.display3D_1cbar(mask_proj,interpolation='none')
            writer.add_figure("mask_u",fig,global_step=i+1,close=True)


            fig=PETLibs.utils.display3D_1cbar(xt_mask,interpolation='none',title=f"mask_it{i+1}") #,vmin=-vmax,vmax=vmax)
            writer.add_figure("mask",fig,global_step=i+1,close=True)

            fig=PETLibs.utils.display3D_1cbar(u,interpolation='none',title=f"u_it{i+1}",vmin=0,vmax=vmax)
            writer.add_figure("window_u",fig,global_step=i+1,close=True)



        if verbose:
            print('Updating Xref:-------------------------------------------------------------------')

        # xref = v - u  
        xref = v + (1.0-eta)*u

        if count:
            all_time.append(time.time() - t)

    if evaluate:
        plt.close(fig_sp)
    


    results={}
    results["x"]=x_ZYX
    results["x_all"]=x_all
    results["v"]=v
    results["v_all"]=v_all
    results["u"]=u
    results["u_all"]=u_all
    results["mse"]=mse
    if use_lpips:
        results["lpips"]=lpips
    results["mae"]=mae
    results["reg"]=reg
    results["logl"]=log_l
    results["norm1"]=norm1
    results["norm2"]=norm2
    results["all_time"]=all_time
    # writer.close()

    return results




def GPU_ADMM2(subject,dset_object, x0, u0,nit_admm, pnlt_beta, model, device,
         reconsParams=None, evaluate = False,target=None,
         count = False, show_initial = True, show_x = "all", show_v = True,
         show_u = True, show_target = True, show_metrics = True,vmax=None, vmin= None,
         verbose = False,real=0,twriter=False,tlog_dir=None,#model_name=None, 
         max_iter_jacobian = 10, phantom = None, scanner = "Biograph"):
    '''
    Applies the Alternating Direction Method of Multipliers using an input image and a reference image.
    The Reconstruction step is performed using a Proximal Method with GPU projectors,
    the denoising step is performed using a trained neural network.
    The algorithm is evaluated using Log-Likelihood (on v), MSE (on v), Square Jacobian Spectral Norm (on v+u),
    Primal (x-v) and Dual Residuals (v^{n}-v^{n-1}).
    The algorithm is initialized as a Douglas-Rachford algorithm with z^{(0)}=x^{(0)}-u^{(0)},
    with the first operator Prox_{f/\beta} (the reconstuction step) and the second operator NN, i.e.
    v^{(0)}=Prox_{f/\beta}(x^{(0)}-u^{(0)}),  u^{(1)}=u^{(0)}+v^{(0)}-x^{(0)}. Then the following ADMM steps are computed:
    x^{(1)}=NN(v^{(0)}+u^({1})), v^{(1)}=Prox_{f/\beta}(x^{(1)}-u^{(1)}, u^{(2)}=x^{(1)}+v^{(1)}-x^{(1)}.


    Arguments:
        - subject: subject name (string).
        - dset_object: data set descriptor (tensorDataSetDoserecParams).
        - x0: Initial reference image for first step (numpy  ndarray, ZYX convention, x0 in DR).
        - u0: Initial u image (numpy  ndarray, ZYX convention, result of the 2nd step).
        - nit_admm: Number of ADMM iterations (int).
        - pnlt_beta: Proximal Method Beta/Rho.
        - model: Neural Network model.
        - device: Device used for prediction (Possible values: "cpu", "gpu").
        - reconsParams: parameters used for first subproblem (prox) (BiographReconsParams, default:None ie default parameters for Biograph).
        - evaluate: compute metrics (Default value: False)
        - target: target image to compute metrics (Default value: None).
        - count: Counts the time taken for every iteration (Default value: False).
        - show_initial: Displays the initial inputs (Default value: False).
        - show_x: Displays the x image every iteration (Default value: "all")
        - show_v: Displays the v image every iteration (Default value: False)
        - show_u: Displays the u image every iteration (Default value: False)
        - show_target: Displays the target image (Default value: True).
        - show_metrics: Plots True,  (Default value: True)

        - vmax: Maximum value for colorscale of images  (Default value: None)
        - truncate: Truncates the images' first dimension for neural network
                    (int, so that zrange=data_x.shape[1]-truncate, defqult: 104).
        - verbose: verbosity (Default value: False)
        - real: dose realization number (int, Default value: 0)
        - twriter: tensorboard writer on (boolean, Default value: False)
        - tlog_dir: tensorboard writer save directory (Default value: None)
        - model_name: name of model for tensorboard writer (string, Default value: None)

    Returns: dictionary with following key:values
        x: x image  (numpy ndarray, ZYX convention).
        x_all: All x images (list of numpy ndarray, ZYX convention).
        v: v image (numpy ndarray, ZYX convention).
        v_all: All v images (list of numpy ndarray, ZYX convention).
        u: u image  (numpy ndarray, ZYX convention).
        u_all: All u images (list of numpy ndarray, ZYX convention).
        mse: Mean Squared Error (computed on x).
        reg: Square Jacobian Spectral Norm (computed on input of NN).
        log_l: Log-Likelihood (computed on x).
        norm1: Primal Residual.
        norm2: Dual Residual.
        all_time: Time taken for every iteration.
    '''

    if scanner == "Biograph":
        if reconsParams is None:
            reconsParams=GPUBiographReconsParams()
        if not isinstance(reconsParams,GPUBiographReconsParams):
            raise TypeError("ReconsParams type is not GPUBiographReconsParams")
    elif scanner == "Signa":
        if reconsParams is None:
            reconsParams=GPUSignaReconsParams()
        if not isinstance(reconsParams,GPUSignaReconsParams):
            raise TypeError("ReconsParams type is not GPUSignaReconsParams")
    else:
        raise TypeError('Scanner type {0} not enforced'.format(scanner))
    if not isinstance(dset_object,database_doserec.tensorDataSetDoserecParams):
        raise TypeError("dset_object type is not torchPETADMM.database.database_doserec.tensorDataSetDoserecParams")

    doserec_object=dset_object.doserecParams

    norm_sj=dset_object.norm_sj
    norm_train=dset_object.norm_train

    zdim,ydim,xdim=x0.shape
    zstart=zdim-dset_object.truncate #starting plane for network

    if count:
        t = time.time()

    if twriter is True:
        writer=SummaryWriter(log_dir=tlog_dir) #+"/"+model_name)
        hparams={}
        hparams["subject"]=subject
        hparams["real"]=real
        hparams["nit_admm"]=nit_admm
        hparams["pnlt_beta"]=pnlt_beta
        # hparams["model"]=model_name
        hparams["algo"]="admm"

        hparams2=copy.deepcopy(reconsParams.__dict__)
        lst_delete=[]
        dict_add={}
        for key in hparams2.keys():
            if torch.is_tensor(hparams2[key]):
                lst_delete+=[key]
            elif isinstance(hparams2[key],list):
                lst_delete+=[key]
                print(f"list {key}")
                for k in range(len(hparams2[key])):
                    new_k=f"{key}_{str(k)}"
                    dict_add[new_k]=hparams2[key][k]
        for key in lst_delete:
            del hparams2[key]
        hparams.update(hparams2)
        hparams.update(dict_add)

        fig=PETLibs.utils.display3D_1cbar(x0,interpolation='none',title=f"EM",vmax=vmax, vmin=vmin)
        writer.add_figure("EM",fig,global_step=0,close=True)
        plt.close(fig)


    #Load sinograms
    castor_df_ima,castor_df_hdr=doserec_object.get_fname_sinogram_CASToR_hdr(subject,real)
    castor_df_dir=doserec_object.get_gen_castor_dir(subject,real)
    castor_df_hdr_fpath=os.path.join(castor_df_dir,castor_df_hdr)
    dict_sino=GPURecons.GPUCASToRSinos(castor_df_hdr_fpath, castor_df_dir,
                                            reconsParams=reconsParams)

    if verbose:
            print('Initialization:-------------------------------------------------------------------------------------------------------------')
    if show_initial:

        fig=PETLibs.utils.display3D_1cbar(x0,interpolation='none',title="x0",vmax=vmax)
        if twriter is True:
            writer.add_figure("x",fig,global_step=0,close=True)

    fig=PETLibs.utils.display3D_1cbar(target,interpolation='none',vmax=vmax, vmin=vmin)
    if twriter is True:
        writer.add_figure("target",fig,global_step=0,close=True)


    fig=PETLibs.utils.display3D_1cbar(phantom,interpolation='none',vmax=vmax, vmin=vmin)
    if twriter is True:
        writer.add_figure("phantom",fig,global_step=0,close=True)


    if reconsParams.XYZ:
        xprox=np.swapaxes(x0-u0,2,0)
    v=PETLibs.recons.GPUProxReconsDPEM(castor_df_hdr_fpath, castor_df_ima,
            reconsParams=reconsParams,xprox=xprox,pnlt_beta=pnlt_beta,
            dict_sino=dict_sino,eval_mode=True,verbose = False,show_step = False,tensor_output=False)# x is np.array
    if reconsParams.XYZ:
        v_ZYX=np.swapaxes(v,2,0)
    else:
        v_ZYX=v


    fig=PETLibs.utils.display3D_1cbar(v_ZYX,interpolation='none',title="v0",vmax=vmax)
    if twriter is True:
        writer.add_figure("v",fig,global_step=0,close=True)

    u=u0+v_ZYX-x0  #init point for u, which is u^(1) in DR
    xref=v_ZYX+u ##init point for xref, which is x^(1/2)+u^(1) in DR
    x=x0

    if evaluate:
        criterion = torch.nn.MSELoss()
        loss = criterion(torch.tensor(v_ZYX, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))

        mse = [loss.item()]
        max_iter_jacobian=10
        reg_fun = jacobian.JacobianReg_l2(max_iter=max_iter_jacobian, eval_mode=True)
        reg = []
        l = reconsEM.GPU_log_likelihood(subject,real,doserec_object, v, eps =0, reconsParams=reconsParams,
                                        dict_sino=dict_sino,eval_mode=True)#note no swap here
        if twriter is True:
            writer.add_scalar("Loss/LogLikelihood",l,global_step=0)
            writer.add_scalar("Loss/MSE",loss.item(),global_step=0)
        log_l = [l]
        norm1 = []
        norm2 = []
    else:
        reg = []
        mse = []
        log_l = []
        norm1 = []
        norm2 = []

    if count:
        all_time = [time.time() - t]
    else:
        all_time = []

    fig_sp=plt.figure()
    for i in range(nit_admm):
        if count:
            t = time.time()

        if verbose:
            print('Iteration {}:-------------------------------------------------------------------------------------------------------------'.format(i+1))
            print('Step 1: Updating X (NN)-------------------------------------------------------------------')

        if evaluate:
            x_old = x

        x,sum_x=database_doserec.preprocess_data(xref,dset_object,device=device)
        if evaluate:
            if i==0:

                fig=PETLibs.utils.display3D_1cbar(xref,interpolation='none',title=f"NN_init",vmax=vmax)
                if twriter is True:
                    writer.add_figure("NN_init",fig,global_step=0,close=True)
            if verbose:
                print('Evaluation:JAC----------------------------------------------------------------')
            reg_loss, reg_loss_all = jacobian.compute_reg(x,x,lambda v: model(v, None)[0],
                                    reg_fun, device = device, eval_mode = True)
            reg_loss = reg_loss.item()
            reg_loss_all = reg_loss_all.detach().cpu().numpy()
            reg.append(reg_loss)
            if twriter is True:
                writer.add_scalar("Loss/S2RadiusJacobian",reg_loss,i+1)
                reg_loss_all=reg_loss_all[reg_loss_all>0]
                plt.plot(np.arange(len(reg_loss_all)),reg_loss_all,figure=fig_sp,label=f"it. {i+1}")
                writer.add_figure("Spectral Radius",fig_sp,global_step=0,close=False)
        x = model.base.forward(x, None) #training.predict(model,x, device) #z^{1/2} in DR
        x=database_doserec.postprocess_data(x,sum_x,dset_object, device=device,tensorFlag=False)

        if evaluate:
            if verbose:
                print('Evaluation:-------------------------------------------------------------------')

        if i == 0:
            x_all = np.expand_dims(x, 0)
        else:
            x_all = np.concatenate((x_all,np.expand_dims(x, 0)), 0)

        # if (show_x == "all"):

        fig=PETLibs.utils.display3D_1cbar(x,interpolation='none',title=f"x_it{i+1}",vmax=vmax)
        if twriter is True:
            writer.add_figure("x",fig,global_step=i+1,close=True)
        # elif (i == nit_admm-1) & (show_x == "last"):
        #     fig=PETLibs.utils.display3D_1cbar(x,interpolation='none',title=f"x_last",vmax=vmax)
        #     if twriter is True:
        #         writer.add_figure("x",fig,global_step=i+1,close=True)

        if verbose:
            print('Step 2:-------------------------------------------------------------------')
            print('Updating V (reconstruction)-------------------------------------------------------------------')

        if evaluate:
            v_old = v_ZYX

        if reconsParams.XYZ:
            xprox=np.swapaxes(x-u,2,0)
        v=PETLibs.recons.GPUProxReconsDPEM(castor_df_hdr_fpath, castor_df_ima,
                reconsParams=reconsParams,xprox=xprox,pnlt_beta=pnlt_beta,
                dict_sino=dict_sino,eval_mode=True,verbose = False,show_step = False,tensor_output=False)# x is np.array
        if reconsParams.XYZ:
            v_ZYX=np.swapaxes(v,2,0)
        else:
            v_ZYX=v

        if evaluate:
            if verbose:
                print('Evaluation:-------------------------------------------------------------------')
            # loss = criterion(v_ZYX, target)
            loss = criterion(torch.tensor(v_ZYX, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))

            mse.append(loss.item())
            l = reconsEM.GPU_log_likelihood(subject,real,doserec_object,v, eps =0,
                                    reconsParams=reconsParams,dict_sino=dict_sino,eval_mode=True)
            log_l.append(l)
            if twriter is True:
                writer.add_scalar("Loss/MSE",loss.item(),global_step=i+1)
                writer.add_scalar("Loss/LogLikelihood",l,global_step=i+1)


        if evaluate:
            if verbose:
                print('Evaluation:-------------------------------------------------------------------')
            primalN=np.linalg.norm(x-v_ZYX)
            dualN=np.linalg.norm(v_ZYX-v_old)
            norm1.append(primalN)
            norm2.append(dualN)
            if twriter is True:
                writer.add_scalar("Accuracy/NormPrimal",primalN,i+1)
                writer.add_scalar("Accuracy/NormDual",dualN,i+1)


        if i == 0:
            v_all = np.expand_dims(v_ZYX, 0)
        else:
            v_all = np.concatenate((v_all,np.expand_dims(v_ZYX, 0)), 0)

        if show_v:

            fig=PETLibs.utils.display3D_1cbar(v_ZYX,interpolation='none',title=f"v_it{i+1}",vmax=vmax)
            if twriter is True:
                writer.add_figure("v",fig,global_step=i+1,close=True)
        if verbose:
            print('Step 3:-------------------------------------------------------------------')

        u = u + v_ZYX - x
        xref = v_ZYX + u #New xref

        if i == 0:
            u_all = np.expand_dims(u, 0)
        else:
            u_all = np.concatenate((u_all,np.expand_dims(u, 0)), 0)


        y_data = dict_sino["val"]
        mult_array = dict_sino["mult"]
        add_array = dict_sino["add"]
        sinomask = dict_sino["mask"]
        if i == 0:
            reconsOps=GPURecons.GPUReconsOps(reconsParams)
        sen=reconsOps.backwardProj(sinomask,mult_factor=mult_array)
        xt= torch.reshape(torch.tensor(np.swapaxes(v_ZYX,2,0),dtype=torch.float32, device = "cuda"),reconsParams.tb_im_dim)
     

        # 
        
        fwd = reconsOps.forwardProj(xt,mult_factor=mult_array,add_factor=add_array)
        ratio = torch.where(fwd>0,torch.divide(y_data,fwd),torch.tensor(1.0, dtype = torch.float32, device = "cuda"))*sinomask
        bwd = reconsOps.backwardProj(ratio,mult_factor=mult_array,add_factor=0)
        grad_img = (sen-bwd)
        new_img = xt + grad_img/pnlt_beta
        new_img_sen = grad_img/sen 
        sen = np.swapaxes(sen.squeeze().cpu().numpy(),2,0)
        bwd = np.swapaxes(bwd.squeeze().cpu().numpy(),2,0)
        grad_img = np.swapaxes(grad_img.squeeze().cpu().numpy(),2,0)
        _new_img = np.swapaxes(new_img.squeeze().cpu().numpy(),2,0)
        _new_img_sen = np.swapaxes(new_img_sen.squeeze().cpu().numpy(),2,0)
        new_img, sum_i = database_doserec.preprocess_data(_new_img,dset_object,device=device) #n_image is tensor
        Dx = model.base.forward(new_img,None) #training.predict(model,n_image, device)
        Dx = database_doserec.postprocess_data(Dx,sum_i,dset_object, device=device)# v is np.array

        Dx_x = Dx - x

        if show_u:

            fig=PETLibs.utils.display3D_1cbar(u,interpolation='none',title=f"u_it{i+1}")
            if twriter is True:
                writer.add_figure("u",fig,global_step=i+1,close=True)

            fig=PETLibs.utils.display3D_1cbar(u,interpolation='none',title=f"u_it{i+1}",vmin=0,vmax=vmax)
            if twriter is True:
                writer.add_figure("window_u",fig,global_step=i+1,close=True)

            fig=PETLibs.utils.display3D_1cbar(grad_img,interpolation='none',title=f"grad KL(x)_it{i+1}") #,vmin=-vmax,vmax=vmax)
            if twriter is True:
                writer.add_figure("grad",fig,global_step=i+1,close=True)

            fig=PETLibs.utils.display3D_1cbar(sen,interpolation='none',title=f"sens_it{i+1}") #,vmin=-vmax,vmax=vmax)
            if twriter is True:
                writer.add_figure("sens",fig,global_step=i+1,close=True)

            fig=PETLibs.utils.display3D_1cbar(bwd,interpolation='none',title=f"bwd_it{i+1}") #,vmin=-vmax,vmax=vmax)
            if twriter is True:
                writer.add_figure("bwd",fig,global_step=i+1,close=True)

            fig=PETLibs.utils.display3D_1cbar(Dx,interpolation='none',title=f"Dx_it{i+1}") #,vmin=-vmax,vmax=vmax)
            if twriter is True:
                writer.add_figure("Dx",fig,global_step=i+1,close=True)

            fig=PETLibs.utils.display3D_1cbar(Dx_x,interpolation='none',title=f"Dx_x_it{i+1}") #,vmin=-vmax,vmax=vmax)
            if twriter is True:
                writer.add_figure("Dx-x",fig,global_step=i+1,close=True)

            fig=PETLibs.utils.display3D_1cbar(_new_img,interpolation='none',title=f"_new_img_it{i+1}") #,vmin=-vmax,vmax=vmax)
            if twriter is True:
                writer.add_figure("new_img",fig,global_step=i+1,close=True)

            fig=PETLibs.utils.display3D_1cbar(_new_img_sen,interpolation='none',title=f"_new_img_sen_it{i+1}") #,vmin=-vmax,vmax=vmax)
            if twriter is True:
                writer.add_figure("new_img_sen",fig,global_step=i+1,close=True)

            fig=PETLibs.utils.display3D_1cbar(_new_img,interpolation='none',title=f"_new_img_it{i+1}",vmin=0,vmax=vmax)
            if twriter is True:
                writer.add_figure("window_new_img",fig,global_step=i+1,close=True)


        if verbose:
            print('Updating Xref:-------------------------------------------------------------------')


        if count:
            all_time.append(time.time() - t)

    if evaluate:
        plt.close(fig_sp)
    if show_target:

        fig=PETLibs.utils.display3D_1cbar(target,interpolation='none',vmax=vmax)
        if twriter is True:
            writer.add_figure("target",fig,global_step=0,close=True)

    if twriter is True:
        if evaluate:
            metric_dict={}
            metric_dict["Loss/MSE"]=mse[-1]
            metric_dict["Loss/LogLikelihood"]=log_l[-1]
            metric_dict["Loss/S2RadiusJacobian"]=reg[-1]
            metric_dict["Convergence/NormPrimal"]=norm1[-1]
            metric_dict["Convergence/NormDual"]=norm2[-1]
            writer.add_hparams(hparams,metric_dict)


    if show_metrics:
        plt.figure()
        plt.plot(range(len(log_l)), log_l)
        plt.xlabel('Iterations')
        plt.ylabel('Log-Likelihood')
        plt.title('Log-Likelihood over ADMM Iterations')
        plt.show()

        plt.figure()
        plt.plot(range(len(mse)), mse)
        plt.xlabel('Iterations')
        plt.ylabel('MSE')
        plt.title('MSE over ADMM Iterations')
        plt.show()

        plt.figure()
        plt.plot(range(len(reg)), reg)
        plt.xlabel('Iterations')
        plt.ylabel('Square Jacobian Spectral Norm')
        plt.title('Square Jacobian Spectral Norm over ADMM Iterations')
        plt.show()

        plt.figure()
        plt.plot(range(1, len(norm1)+1), norm1)
        plt.xlabel('Iterations')
        plt.ylabel('Primal Residual')
        plt.title('Primal Residual over ADMM Iterations')
        plt.show()

        plt.figure()
        plt.plot(range(1, len(norm2)+1), norm2)
        plt.xlabel('Iterations')
        plt.ylabel('Dual Residual')
        plt.title('Dual Residual over ADMM Iterations')
        plt.show()

    results={}
    results["x"]=x
    results["x_all"]=x_all
    results["v"]=v_ZYX
    results["v_all"]=v_all
    results["u"]=u
    results["u_all"]=u_all
    results["mse"]=mse
    results["reg"]=reg
    results["logl"]=log_l
    results["norm1"]=norm1
    results["norm2"]=norm2
    results["all_time"]=all_time


    return results


