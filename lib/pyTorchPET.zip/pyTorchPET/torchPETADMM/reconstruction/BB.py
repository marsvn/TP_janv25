import os
import numpy as np
import torch
import matplotlib.pyplot as plt
import copy
import PETLibs
import PETLibs.recons
import PETLibs.recons.GPURecons as GPURecons
import torchPETADMM.learning.jacobian as jacobian
from torchPETADMM.database import database_doserec
import torchmetrics
from torchmetrics.image.lpip import LearnedPerceptualImagePatchSimilarity
from torchmetrics import Metric
import torchPETADMM.reconstruction.EM as reconsEM

# from tqdm.autonotebook import trange,tqdm
from torch.utils.tensorboard import SummaryWriter
from torch.utils.tensorboard.summary import hparams as hparams_tb



class LearnedPerceptualImagePatchSimilarity3D(Metric):
    def __init__(self):
        super().__init__()
        self.add_state("axial_metric", default=torch.tensor(0))
        self.add_state("sag_metric", default=torch.tensor(0))
        self.add_state("cor_metric", default=torch.tensor(0))

    def update(self, i_preds: torch.Tensor, i_target: torch.Tensor):
    
        # print(i_preds.shape)
        # print(i_target.shape)
        criterion = LearnedPerceptualImagePatchSimilarity(net_type='vgg', normalize=True).to(i_preds.device)
        assert i_preds.shape == i_target.shape
        preds = (i_preds.detach()/i_target.detach().max())
        target = (i_target.detach()/i_target.detach().max())
        preds = preds.clamp(0,1)
        assert(preds.max()<=1 and preds.min()>=0)
        assert(target.max()<=1 and target.min()>=0)
        preds = preds.unsqueeze(0).unsqueeze(0)
        target = target.unsqueeze(0).unsqueeze(0)
        # print(preds.shape)
        # print(target.shape)
        self.axial_metric = torch.tensor([criterion(preds[:,0,i,:,:].squeeze().view(-1, 1, preds.shape[3], preds.shape[4]).expand(preds.shape[0],3,-1,-1), target[:,0,i,:,:].squeeze().view(-1, 1, preds.shape[3], preds.shape[4]).expand(preds.shape[0],3,-1,-1)).mean() for i in range(preds.shape[2])]).mean()
        self.sag_metric = torch.tensor([criterion(preds[:,0,:,i,:].squeeze().view(-1, 1, preds.shape[2], preds.shape[4]).expand(preds.shape[0],3,-1,-1), target[:,0,:,i,:].squeeze().view(-1, 1, preds.shape[2], preds.shape[4]).expand(preds.shape[0],3,-1,-1)).mean() for i in range(preds.shape[3])]).mean()
        self.cor_metric = torch.tensor([criterion(preds[:,0,:,:,i].squeeze().view(-1, 1, preds.shape[2], preds.shape[3]).expand(preds.shape[0],3,-1,-1), target[:,0,:,:,i].squeeze().view(-1, 1, preds.shape[2], preds.shape[3]).expand(preds.shape[0],3,-1,-1)).mean() for i in range(preds.shape[4])]).mean()


    def compute(self):
        return (self.axial_metric.float()+ self.sag_metric.float()+ self.cor_metric.float())/3.0
    



def Backward_Backward(subject,
             dset_object, 
             x0, 
             nit_admm, 
             pnlt_beta, 
             model, 
             device,
             BiographParams=None, 
             evaluate = False,
             target=None,
             vmax=None, 
             vmin=None,
             real=0,
             twriter=False,
             tlog_dir=None,
             model_name=None, 
             version_F = False, 
             max_iter_jacobian = 10, 
             phantom = None, 
             algo_prox = "em", 
             bUsePrecond = False, 
             use_lpips = False, 
             prec = 5e-04, 
             bUseWeighted = False,
             xEM = None,
             bCompute_jac = True, 
             bUse_relax = False,
             mri = None
             ):
    

    if BiographParams is None:
        BiographParams=GPURecons.GPUBiographReconsParams()
    if not isinstance(BiographParams,GPURecons.GPUBiographReconsParams):
        raise TypeError("BiographParams type is not PETLibs.recons.BiographReconsParams ")
    if not isinstance(dset_object,database_doserec.tensorDataSetDoserecParams):
        raise TypeError("dset_object type is not torchPETADMM.database.database_doserec.tensorDataSetDoserecParams")

    doserec_object=dset_object.doserecParams
   



    if twriter :
        writer=SummaryWriter(log_dir=tlog_dir)
        hparams_dict={}
        hparams_dict["subject"]=subject
        hparams_dict["real"]=real
        hparams_dict["nit_admm"]=nit_admm
        hparams_dict["pnlt_beta"]=pnlt_beta
        hparams_dict["model"]=model_name
        hparams_dict["use_mri"] = (mri is not None)
        hparams2=copy.deepcopy(BiographParams.__dict__)
        lst_delete=[]
        dict_add={}
        for key in hparams2.keys():
            if torch.is_tensor(hparams2[key]):
                lst_delete+=[key]
            elif isinstance(hparams2[key],list):
                lst_delete+=[key]
                print(f"list {key}")
                for k in range(len(hparams2[key])):
                    new_k=f"{key}_{str(k)}"
                    dict_add[new_k]=hparams2[key][k]
        for key in lst_delete:
            del hparams2[key]
        hparams_dict.update(hparams2)
        hparams_dict.update(dict_add)
        fig=PETLibs.utils.display3D_1cbar(x0,interpolation='none',title=f"EM",vmax=vmax, vmin=vmin)
        writer.add_figure("EM",fig,global_step=0,close=True)
        plt.close(fig)

    # xt_target= torch.reshape(torch.tensor(np.swapaxes(target,2,0),dtype=torch.float32, device = "cuda"),BiographParams.tb_im_dim)

    if mri is not None:
        gpu_mri,_=database_doserec.preprocess_data(mri,dset_object,device=device)
    else :
        gpu_mri = None

    xt_target= torch.reshape(torch.tensor(np.swapaxes(phantom,2,0),dtype=torch.float32, device = "cuda"),BiographParams.tb_im_dim)
    xt_mask_ph = torch.where(xt_target > 0, torch.tensor(1.0, dtype=torch.float32, device = "cuda"), torch.tensor(0.0, dtype=torch.float32, device = "cuda"))
    xt_mask_ph = np.swapaxes(xt_mask_ph.squeeze().cpu().numpy(),2,0)

        


    x=x0 #np.swapaxes(x0, 2, 0)
    xEM,_=database_doserec.preprocess_data(xEM,dset_object,device=device) #n_image is tensor
    # x is EM

    if twriter :
        fig=PETLibs.utils.display3D_1cbar(target,interpolation='none',vmax=vmax, vmin=vmin)
        writer.add_figure("target",fig,global_step=0,close=True)

        fig=PETLibs.utils.display3D_1cbar(x,interpolation='none',title="x0",vmax=vmax, vmin=vmin)
        writer.add_figure("x0",fig,global_step=0,close=True)

        fig=PETLibs.utils.display3D_1cbar(phantom,interpolation='none',vmax=vmax, vmin=vmin)
        writer.add_figure("phantom",fig,global_step=0,close=True)

        fig=PETLibs.utils.display3D_1cbar(xt_mask_ph,interpolation='none',title=f"mask_phantom") #,vmin=-vmax,vmax=vmax)
        writer.add_figure("mask_phantom",fig,global_step=0,close=True)
    
    #Load sinograms
    castor_df_ima,castor_df_hdr=doserec_object.get_fname_sinogram_CASToR_hdr(subject,real)
    castor_df_dir=doserec_object.get_gen_castor_dir(subject,real)
    castor_df_hdr_fpath=os.path.join(castor_df_dir,castor_df_hdr)
    dict_sino=GPURecons.GPUCASToRBiographSinos(castor_df_hdr_fpath, castor_df_dir,
                                            BiographReconsParams=BiographParams)
    
    
    criterion = torch.nn.MSELoss()
    criterion_MAE = torch.nn.L1Loss()
    criterion_tv = torchmetrics.TotalVariation(reduction="mean").cuda()
    if use_lpips:
        criterion_lpips = LearnedPerceptualImagePatchSimilarity3D().cuda()

    mse = mae = tv = lpips = []
    reg_fun = jacobian.JacobianReg_l2(max_iter=max_iter_jacobian, eval_mode=True)
    reg = []
    if BiographParams.XYZ:
        x_XYZ=np.swapaxes(x,2,0)
        l = reconsEM.GPU_log_likelihood(subject,real,doserec_object, x_XYZ, eps =0, BiographParams=BiographParams,
                                    dict_sino=dict_sino,eval_mode=True) #, bUseWeighted= bUseWeighted)
        del x_XYZ
    else:
        l = reconsEM.GPU_log_likelihood(subject,real,doserec_object, x, eps =0, BiographParams=BiographParams,
                                    dict_sino=dict_sino,eval_mode=True) #, bUseWeighted= bUseWeighted)

    log_l = [l]


    # def my_prox(x) :

    #     xprox=np.swapaxes(database_doserec.postprocess_data(x,0,dset_object, device=device),2,0)
    #     x_rot=GPURecons.GPUBiographProxRecons(castor_df_hdr_fpath, castor_df_ima,
    #                     BiographReconsParams=BiographParams,xprox=xprox,pnlt_beta=pnlt_beta,
    #                     dict_sino=dict_sino,eval_mode=False,verbose = False,show_step = False,
    #                     tensor_output=False, img_mask = xt_mask_ph, bUseWeighted = bUseWeighted) 
    #     n_image,_=database_doserec.preprocess_data(np.swapaxes(x_rot,2,0),dset_object,device=device)  
            
    #     return model(n_image, sigma)[0]
            
   
    for i in range(nit_admm):      

        print('Iteration {}:-------------------------------------------------------------------------------------------------------------'.format(i+1))
        # x_deb,_=database_doserec.preprocess_data(x,dset_object,device=device) #n_image is tensor

        if i > 0:
            x_old = x

        
        if twriter :
            fig=PETLibs.utils.display3D_1cbar(x,interpolation='none',title=f"x_in_prox_it{i+1}",vmax=vmax, vmin=vmin)
            writer.add_figure("x_in_prox",fig,global_step=i+1,close=True)

        if BiographParams.XYZ:
            xprox=np.swapaxes(x,2,0)
        if algo_prox == "em":
            x_rot=GPURecons.GPUBiographProxRecons(castor_df_hdr_fpath, castor_df_ima,
                    BiographReconsParams=BiographParams,xprox=xprox,pnlt_beta=pnlt_beta,
                    dict_sino=dict_sino,eval_mode=True,verbose = False,show_step = False,
                    tensor_output=False, img_mask = xt_mask_ph, bUseWeighted = bUseWeighted) 
        
        elif algo_prox == "spdhg":
            x_rot, list_init_dual=PETLibs.recons.GPUBiographProxReconsSPDHG(castor_df_hdr_fpath, castor_df_ima,
                BiographReconsParams=BiographParams,xprox=xprox,pnlt_beta=pnlt_beta,
                dict_sino=dict_sino,nb_iter=BiographParams.nit, 
                warm_start = True if i> 0 else False, list_init_dual = list_init_dual if i> 0 else [], xstart=x0 if i> 0 else None, 
                i_img_mask= xt_mask_ph, use_precond = bUsePrecond, bUseWeighted = bUseWeighted)
            
        elif algo_prox == "dbfb":
            x_rot, list_init_dual =PETLibs.recons.GPUBiographProxReconsDBFB(castor_df_hdr_fpath, castor_df_ima,
                BiographReconsParams=BiographParams,xprox=xprox,pnlt_beta=pnlt_beta,
                dict_sino=dict_sino,nb_iter=BiographParams.nit, 
                warm_start = True if i> 0 else False, list_init_dual = list_init_dual if i> 0 else [],  
                i_img_mask= xt_mask_ph, use_precond = bUsePrecond)
        else :
            raise ValueError("algo_prox must be em, spdhg or dbfb")
        inv_precond = None
        if inv_precond is not None:
            if BiographParams.XYZ:
                inv_precond=np.swapaxes(inv_precond,4,2)
           
            if dset_object.truncate < inv_precond.shape[2]:
                t = inv_precond.shape[2] - dset_object.truncate
                inv_precond = inv_precond[:,:,t:,:,:]
        
        if BiographParams.XYZ:
            x=np.swapaxes(x_rot,2,0)
        else:
            x=x_rot


        if twriter :
            fig=PETLibs.utils.display3D_1cbar(x,interpolation='none',vmax=vmax, vmin=vmin)

            writer.add_figure("x",fig,global_step=i+1,close=True)

        if evaluate :
            loss = criterion(torch.tensor(x, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
            loss_phantom = criterion(torch.tensor(x, dtype=torch.float32,device="cuda"), torch.tensor(phantom, dtype=torch.float32,device="cuda"))
            loss_tv = ((criterion_tv(torch.tensor(target, dtype=torch.float32,device="cuda").unsqueeze(0)) - criterion_tv(torch.tensor(x, dtype=torch.float32,device="cuda").unsqueeze(0)))**2)**0.5
            if use_lpips:
                loss_lpips = criterion_lpips(torch.tensor(x, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
                lpips.append(loss_lpips.item())
            loss_MAE = criterion_MAE(torch.tensor(x, dtype=torch.float32,device="cuda"), torch.tensor(target, dtype=torch.float32,device="cuda"))
            mae.append(loss_MAE.item())
            mse.append(loss.item())
            tv.append(loss_tv.item())
        
            l = reconsEM.GPU_log_likelihood(subject,real,doserec_object,x_rot, eps =0,
                                    BiographParams=BiographParams,dict_sino=dict_sino,eval_mode=True) #, bUseWeighted = bUseWeighted)#Note here x and not X_ZYX
            log_l.append(l)
            if twriter :
                writer.add_scalar("Loss/MSE",loss.item(),i+1)
                writer.add_scalar("Loss/MSE_phantom",loss_phantom.item(),i+1)
                writer.add_scalar("Loss/TV",loss_tv.item(),i+1)
                if use_lpips:
                    writer.add_scalar("Loss/LPIPS",loss_lpips.item(),i+1)
                writer.add_scalar("Loss/MAE",loss_MAE.item(),i+1)
                writer.add_scalar("Loss/LogLikelihood",l,i+1)

    
            
        n_image,sum_i=database_doserec.preprocess_data(x,dset_object,device=device) #n_image is tensor
        # print("n_image",n_image.min(),n_image.max())
        sigma = torch.from_numpy(xt_mask_ph).to(device).unsqueeze(0).unsqueeze(0)
        if dset_object.truncate < sigma.shape[2]:
            t = sigma.shape[2] - dset_object.truncate
            sigma = sigma[:,:,t:,:,:]
        if version_F:
            v = model.base.forward(n_image)
        else :
            v = model(n_image,sigma, bNE_Archi= False, gamma= None, u=None, xEM = xEM, xcond = gpu_mri)[0]
            # v, _, _ = model(n_image,sigma) #training.predict(model,n_image, device)
        # print("vmin",v.min(), "vmax",v.max())
        x=database_doserec.postprocess_data(v,sum_i,dset_object, device=device)
        
        if bCompute_jac :
            print('Evaluation:JAC----------------------------------------------------------------')
            reg_loss, _ = jacobian.compute_reg(n_image,n_image,lambda v: model(v, sigma, bNE_Archi= False, gamma= None, u=None, xEM = xEM, xcond = gpu_mri)[0],
                                    reg_fun, device = device, eval_mode = True, precond = torch.pow(inv_precond, 0.5) if inv_precond is not None else None)
                #Jacobian on input of network
            reg_loss = reg_loss.item()
            reg.append(reg_loss)
            if twriter :
                writer.add_scalar("Loss/S2RadiusJacobian",reg_loss,i+1)

        # reg_loss_comp, all_reg = jacobian.compute_reg(x_deb,x_deb,lambda v: my_prox(v),
        #                         reg_fun, device = device, eval_mode = True, precond = torch.pow(inv_precond, 0.5) if inv_precond is not None else None)
        #     #Jacobian on input of network
        # reg_loss_comp = reg_loss_comp.item()
        # print(all_reg)
        # if twriter :
        #     writer.add_scalar("Loss/S2RadiusJacobian_comp",reg_loss_comp,i+1)

        if bUse_relax:
            x = x_old + 1.49*(x - x_old)
        
        if i > 0:
            var_x = np.linalg.norm(x-x_old)**2/np.linalg.norm(x)**2      
            if twriter :
                fig=PETLibs.utils.display3D_1cbar(x-x_old,interpolation='none')
                writer.add_figure("diff x",fig,global_step=i+1,close=True)
                writer.add_scalar("Accuracy/var_x",var_x,i+1)
            if (var_x<prec) :
                print("Convergence reached")
                break


    
    
    return x




