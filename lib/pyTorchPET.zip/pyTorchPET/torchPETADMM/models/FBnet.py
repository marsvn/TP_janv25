from collections import OrderedDict
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.autograd as autograd

from torchPETADMM.models.DRUnet import NFUNetRes2
from . import basicblock as B

def projball_linf(y, tau):
    return torch.clamp(y, min=-tau, max=tau)

def prox_l1(y, lambda_):
    return y - torch.clamp(y, min=-lambda_, max=lambda_)

def conv_layer(in_channels, out_channels, kernel_size, stride=1, dilation=1, groups=1, bias = True):
    padding = int((kernel_size - 1) / 2) * dilation
    return B.init_weights_conv(nn.Conv3d(in_channels, out_channels, kernel_size, stride, padding=padding,  dilation=dilation,
                     groups=groups, bias = bias), 'kaiming')



def pad(pad_type, padding):
    pad_type = pad_type.lower()
    if padding == 0:
        return None
    if pad_type == 'reflect':
        layer = nn.ReflectionPad3d(padding)
    elif pad_type == 'replicate':
        layer = nn.ReplicationPad3d(padding)
    else:
        raise NotImplementedError('padding layer [{:s}] is not implemented'.format(pad_type))
    return layer


def get_valid_padding(kernel_size, dilation):
    kernel_size = kernel_size + (kernel_size - 1) * (dilation - 1)
    padding = (kernel_size - 1) // 2
    return padding


def conv_block(in_nc, out_nc, kernel_size, stride=1, dilation=1, groups=1, bias=True,
               pad_type='zero', norm_type=None, act_type='relu'):
    padding = get_valid_padding(kernel_size, dilation)
    p = pad(pad_type, padding) if pad_type and pad_type != 'zero' else None
    padding = padding if pad_type == 'zero' else 0

    c = nn.Conv3d(in_nc, out_nc, kernel_size=kernel_size, stride=stride, padding=padding,
                  dilation=dilation, bias=bias, groups=groups)
    a = activation(act_type) if act_type else None
    n = None
    return sequential(p, c, n, a)


def activation(act_type, inplace=True, neg_slope=0.05, n_prelu=1):
    act_type = act_type.lower()
    if act_type == 'relu':
        layer = nn.ReLU(inplace)
    elif act_type == 'lrelu':
        layer = nn.LeakyReLU(neg_slope, inplace)
    elif act_type == 'prelu':
        layer = nn.PReLU(num_parameters=n_prelu, init=neg_slope)
    else:
        raise NotImplementedError('activation layer [{:s}] is not found'.format(act_type))
    return layer


class ShortcutBlock(nn.Module):
    def __init__(self, submodule):
        super(ShortcutBlock, self).__init__()
        self.sub = submodule

    def forward(self, x):
        output = x + self.sub(x)
        return output

def mean_channels(F):
    assert(F.dim() == 4)
    spatial_sum = F.sum(3, keepdim=True).sum(2, keepdim=True)
    return spatial_sum / (F.size(2) * F.size(3))

def stdv_channels(F):
    assert(F.dim() == 4)
    F_mean = mean_channels(F)
    F_variance = (F - F_mean).pow(2).sum(3, keepdim=True).sum(2, keepdim=True) / (F.size(2) * F.size(3))
    return F_variance.pow(0.5)

def sequential(*args):
    if len(args) == 1:
        if isinstance(args[0], OrderedDict):
            raise NotImplementedError('sequential does not support OrderedDict input.')
        return args[0]
    modules = []
    for module in args:
        if isinstance(module, nn.Sequential):
            for submodule in module.children():
                modules.append(submodule)
        elif isinstance(module, nn.Module):
            modules.append(module)
    return nn.Sequential(*modules)

class ESA(nn.Module):
    def __init__(self, n_feats, conv, bias = True):
        super(ESA, self).__init__()
        f = n_feats // 4
        self.conv1 = conv(n_feats, f, kernel_size=1, bias = bias)
        self.conv_f = conv(f, f, kernel_size=1, bias=bias)
        self.conv_max = conv(f, f, kernel_size=3, padding=1, bias=bias)
        self.conv2 = conv(f, f, kernel_size=3, stride=2, padding=0, bias=bias)
        self.conv3 = conv(f, f, kernel_size=3, padding=1, bias=bias)
        self.conv3_ = conv(f, f, kernel_size=3, padding=1, bias=bias)
        self.conv4 = conv(f, n_feats, kernel_size=1, bias=bias)
        self.sigmoid = nn.Sigmoid()
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        c1_ = (self.conv1(x))
        c1 = self.conv2(c1_)
        v_max = F.max_pool3d(c1, kernel_size=7, stride=3)
        v_range = self.relu(self.conv_max(v_max))
        c3 = self.relu(self.conv3(v_range))
        c3 = self.conv3_(c3)
        c3 = F.interpolate(c3, (x.size(2), x.size(3), x.size(4)), mode='trilinear', align_corners=False) 
        cf = self.conv_f(c1_)
        c4 = self.conv4(c3+cf)
        m = self.sigmoid(c4)
        
        return m


class RFDB(nn.Module):
    def __init__(self, in_channels, distillation_rate=0.25, bias = True):
        super(RFDB, self).__init__()
        self.dc = self.distilled_channels = in_channels//2
        self.rc = self.remaining_channels = in_channels
        self.c1_d = conv_layer(in_channels, self.dc, 1, bias=bias)
        self.c1_r = conv_layer(in_channels, self.rc, 3, bias=bias)
        self.c2_d = conv_layer(self.remaining_channels, self.dc, 1, bias=bias)
        self.c2_r = conv_layer(self.remaining_channels, self.rc, 3, bias=bias)
        self.c3_d = conv_layer(self.remaining_channels, self.dc, 1, bias=bias)
        self.c3_r = conv_layer(self.remaining_channels, self.rc, 3, bias=bias)
        self.c4 = conv_layer(self.remaining_channels, self.dc, 3, bias=bias)
        self.act = activation('lrelu', neg_slope=0.05)
        self.c5 = conv_layer(self.dc*4, in_channels, 1, bias=bias)
        self.esa = ESA(in_channels, nn.Conv3d, bias=bias)

    def forward(self, input):
        distilled_c1 = self.act(self.c1_d(input))
        r_c1 = (self.c1_r(input))
        r_c1 = self.act(r_c1+input)

        distilled_c2 = self.act(self.c2_d(r_c1))
        r_c2 = (self.c2_r(r_c1))
        r_c2 = self.act(r_c2+r_c1)

        distilled_c3 = self.act(self.c3_d(r_c2))
        r_c3 = (self.c3_r(r_c2))
        r_c3 = self.act(r_c3+r_c2)

        r_c4 = self.act(self.c4(r_c3))

        out = torch.cat([distilled_c1, distilled_c2, distilled_c3, r_c4], dim=1)
        out_fused = self.esa(self.c5(out)) 
        return out_fused


class PixelShuffle3d(nn.Module):
    '''
    This class is a 3d version of pixelshuffle.
    '''
    def __init__(self, scale):
        '''
        :param scale: upsample scale
        '''
        super().__init__()
        self.scale = scale

    def forward(self, input):
        batch_size, channels, in_depth, in_height, in_width = input.size()
        # print("input", input.shape)
        # print("scale", self.scale)
        nOut = channels // self.scale ** 3
        # print("nOUT", nOut)

        out_depth = in_depth * self.scale
        out_height = in_height * self.scale
        out_width = in_width * self.scale

        input_view = input.contiguous().view(batch_size, nOut, self.scale, self.scale, self.scale, in_depth, in_height, in_width)

        output = input_view.permute(0, 1, 5, 2, 6, 3, 7, 4).contiguous()

        return output.view(batch_size, nOut, out_depth, out_height, out_width)


def pixelshuffle_block(in_channels, out_channels, upscale_factor=2, kernel_size=3, stride=1, bias = True):
    conv = conv_layer(in_channels, out_channels * (upscale_factor ** 3), kernel_size, stride, bias=bias)
    pixel_shuffle = PixelShuffle3d(upscale_factor)
    return sequential(conv, pixel_shuffle)



class RFDN(nn.Module):
    def __init__(self, in_nc=3, nf=50, num_modules=4, out_nc=3, upscale=4, bias = True):
        super(RFDN, self).__init__()
        # nf div par upsacle^2
        self.norm_IN = nn.Identity() #InstanceNorm3d(in_nc, affine=True)
        self.fea_conv = conv_layer(in_nc, nf, kernel_size=3, bias = bias)

        self.B1 = RFDB(in_channels=nf, bias=bias)
        self.B2 = RFDB(in_channels=nf, bias=bias)
        # self.B3 = RFDB(in_channels=nf)
        # self.B4 = RFDB(in_channels=nf)
        self.c = conv_block(nf * 2, nf, kernel_size=1, act_type='lrelu', bias = bias)

        self.LR_conv = conv_layer(nf, nf, kernel_size=3, bias = bias)

        upsample_block = pixelshuffle_block
        self.upsampler = upsample_block(nf, out_nc, upscale_factor=upscale, bias=bias)
        self.scale_idx = 0


    def forward(self, input):
        out_fea = self.fea_conv(self.norm_IN(input))
        out_B1 = self.B1(out_fea)
        out_B2 = self.B2(out_B1)
        # out_B3 = self.B3(out_B2)
        # out_B4 = self.B4(out_B3)

        # out_B = self.c(out_B2)
        out_B = self.c(torch.cat([out_B1, out_B2], dim=1))
        out_lr = self.LR_conv(out_B) + out_fea
        # print("out_lr", out_lr.shape)
        output = F.sigmoid(self.upsampler(out_lr))
        # print("output", output.shape)

        return output

    def set_scale(self, scale_idx):
        self.scale_idx = scale_idx



#################################################



class FB_matched_block_3termsProx(torch.nn.Module):
    def __init__(self, 
                 N_nu,
                 N_kappa,
                 N_quad,
                 i_channels, 
                 i_kernel_size, 
                 N_rep=1,
                 bLast = False
                 ):
        super(FB_matched_block_3termsProx, self).__init__()
        

        self.N_nu = N_nu    
        self.N_kappa = N_kappa  
        self.N_quad = N_quad
        self.bLast = bLast 
        list_channels = [1]
        list_kernel_size = []
        for i in range(N_rep):
            list_channels.append(i_channels)
            list_kernel_size.append(i_kernel_size)
        self.convD = B.MultiConv3d(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = False, sn_size=128)
        self.convD_quad = B.MultiConv3d(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = False, sn_size=128)
        if not self.bLast:
            self.theta = nn.Parameter(-1.0*torch.ones(1)) 
        self.kappa = nn.Parameter(torch.zeros(1))

  


    def forward(self, xn, zref, nu, quad, NN = None, bPos = False):        
        sn = self.convD.spectral_norm(mode="Fourier", n_steps=100)
        sn2 = self.convD_quad.spectral_norm(mode="Fourier", n_steps=100).sqrt()      

        x_convD = self.convD(xn)
        kappa = x_convD.abs().max()*F.sigmoid(self.kappa) + 1e-6 #5.0*
        
        if NN is not None:
            test = NN(xn) 
        else :
            test = 1.0

        tau = 1.99/((test*self.N_nu*nu*sn)/kappa + 1.0)

        x_A = x_convD/kappa
        x_B = torch.sign(x_convD)
        x_AB = torch.where(torch.abs(x_convD) < kappa, x_A, x_B)
        # print("sum < kappa", torch.sum(torch.abs(x_convD) < kappa), "sum > kappa", torch.sum(torch.abs(x_convD) >= kappa), "kappa", kappa)

        xn_12 = xn - tau*(xn - zref + test*self.N_nu*nu*self.convD.transpose(x_AB))
        # print("sn2", sn2, "self.N_quad*quad*sn2", self.N_quad*quad*sn2)
        # print("pre max", xn_12.max())
        xn_12 = self.convD_quad.transpose(self.convD_quad(xn_12)- self.N_quad*quad*F.hardtanh(self.convD_quad(xn_12)/( self.N_quad*quad*sn2)))/sn2
        # print("post max", xn_12.max())
        if bPos :
            xn_12 = xn_12.clamp(min=0)
        else :
            xn_12 = torch.max(xn_12, -zref)
       
              
        if self.bLast:
            xn_1 = xn_12    
        else :
            theta = 1 + 0.99*F.sigmoid(5.0*self.theta)
            xn_1 = xn + theta*(xn_12-xn)
        return xn_1



class FB_unmatched_block_3termsProx(torch.nn.Module):
    def __init__(self, 
                 N_nu,
                 N_kappa,
                 N_quad,
                 i_channels, 
                 i_kernel_size, 
                 N_rep = 1,
                 bLast = False
                 ):
        super(FB_unmatched_block_3termsProx, self).__init__()
        

        self.N_nu = N_nu    
        self.N_kappa = N_kappa  
        self.N_quad = N_quad
        self.bLast = bLast 
        list_channels = [1]
        list_kernel_size = []
        for i in range(N_rep):
            list_channels.append(i_channels)
            list_kernel_size.append(i_kernel_size)
        self.convD = B.MultiConv3d(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = False, sn_size=128)
        self.convD_quad = B.UnmatchedMultiConv3dFB(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = False, sn_size=128)
        if not self.bLast:
            self.theta = nn.Parameter(-1.0*torch.ones(1)) 



    def forward(self, xn, zref, nu, quad, NN = None, bPos = False):    
            
       
        eta, eps = self.convD_quad.step_FB(self.N_nu*nu)
        tau = 1.99*eta
        
        # if NN is not None:
        #     test = NN(xn) 
        #     # print(test.min(), test.max(), test.mean(), test.std())
        # else :
        #     test = 1.0

        sn2 = self.convD.spectral_norm(mode="Fourier", n_steps=100).sqrt()      

        
        xn_12 = xn - tau*((1.0+eps)*(xn - zref) + self.N_quad*quad*self.convD_quad.transpose(self.convD_quad(xn)) )
        xn_1 =self.convD.transpose(self.convD(xn_12)- self.N_nu*nu*F.hardtanh(self.convD(xn_12)/( self.N_nu*nu*sn2)))/sn2
        if bPos :
            xn_1 = xn_1.clamp(min=0)
        else :
            xn_1 = torch.max(xn_1, -zref)
              
        if not self.bLast:
            theta = 1 + 0.99*F.sigmoid(5.0*self.theta)
            xn_1 = xn + theta*(xn_1-xn)
        return xn_1


# class FB_matched_block_3terms(torch.nn.Module):
#     def __init__(self, 
#                  N_nu,
#                  N_kappa,
#                  N_quad,
#                  i_channels, 
#                  i_kernel_size, 
#                  bLast = False
#                  ):
#         super(FB_matched_block_3terms, self).__init__()
        

#         self.N_nu = N_nu    
#         self.N_kappa = N_kappa  
#         self.N_quad = N_quad
#         self.bLast = bLast 
#         self.convD = B.MultiConv3d(num_channels=[1, i_channels, i_channels], size_kernels=[i_kernel_size, i_kernel_size], zero_mean = False, sn_size=128)
#         self.convD_quad = B.MultiConv3d(num_channels=[1, i_channels, i_channels], size_kernels=[i_kernel_size, i_kernel_size], zero_mean = False, sn_size=128)
#         if not self.bLast:
#             self.theta = nn.Parameter(-1.0*torch.ones(1)) 
#         self.kappa = nn.Parameter(torch.zeros(1))

  


#     def forward(self, xn, zref, nu, quad, NN = None):        
#         sn = self.convD.spectral_norm(mode="Fourier", n_steps=100)
#         sn2 = self.convD_quad.spectral_norm(mode="Fourier", n_steps=100)       

#         x_convD = self.convD(xn)
#         kappa = x_convD.abs().max()*F.sigmoid(self.kappa) + 1e-6 #5.0*
        
#         if NN is not None:
#             test = NN(xn) 
#         else :
#             test = 1.0

#         tau = 1.99/((test*self.N_nu*nu*sn)/kappa + self.N_quad*quad*sn2 + 1.0)

#         x_A = x_convD/kappa
#         x_B = torch.sign(x_convD)
#         x_AB = torch.where(torch.abs(x_convD) < kappa, x_A, x_B)
#         print("sum < kappa", torch.sum(torch.abs(x_convD) < kappa), "sum > kappa", torch.sum(torch.abs(x_convD) >= kappa), "kappa", kappa)

#         xn_12 = xn - tau*(xn - zref + self.N_quad*quad*self.convD_quad.transpose(self.convD_quad(xn)) + test*self.N_nu*nu*self.convD.transpose(x_AB))
        

#         xn_12 = torch.max(xn_12, -zref)
       
              
#         if self.bLast:
#             xn_1 = xn_12    
#         else :
#             theta = 1 + 0.99*F.sigmoid(5.0*self.theta)
#             xn_1 = xn + theta*(xn_12-xn)
#         return xn_1



# class FB_unmatched_block_3terms(torch.nn.Module):
#     def __init__(self, 
#                  N_nu,
#                  N_kappa,
#                  N_quad,
#                  i_channels, 
#                  i_kernel_size, 
#                  bLast = False
#                  ):
#         super(FB_unmatched_block_3terms, self).__init__()
        

#         self.N_nu = N_nu    
#         self.N_kappa = N_kappa  
#         self.N_quad = N_quad
#         self.bLast = bLast 
#         self.convD = B.MultiConv3d(num_channels=[1, i_channels, i_channels], size_kernels=[i_kernel_size, i_kernel_size], zero_mean = False, sn_size=128)
#         self.convD_quad = B.UnmatchedMultiConv3dFB(num_channels=[1, i_channels, i_channels], size_kernels=[i_kernel_size, i_kernel_size], zero_mean = False, sn_size=128)
#         if not self.bLast:
#             self.theta = nn.Parameter(-1.0*torch.ones(1)) 
#         self.kappa = nn.Parameter(torch.zeros(1))



#     def forward(self, xn, zref, nu, quad, NN = None):        
       
#         eta, eps = self.convD_quad.step_FB_with_conv(self.N_nu*nu, self.convD, self.N_quad*quad)
#         tau = 1.99*eta
#         x_convD = self.convD(xn)
#         kappa = x_convD.abs().max()*F.sigmoid(5.0*self.kappa) + 1e-6
        
#         if NN is not None:
#             test = NN(xn) 
#             # print(test.min(), test.max(), test.mean(), test.std())
#         else :
#             test = 1.0
        

        
#         xn_12_A = xn - tau*((1.0+eps)*(xn - zref) + self.N_quad*quad*self.convD_quad.transpose(self.convD_quad(xn)) + test*self.N_nu*nu*self.convD.transpose(x_convD/kappa))
#         xn_12_B = xn - tau*((1.0+eps)*(xn - zref) + self.N_quad*quad*self.convD_quad.transpose(self.convD_quad(xn)) + test*self.N_nu*nu*self.convD.transpose(torch.sign(x_convD)))
#         xn_12 = torch.where(torch.abs(xn) < kappa, xn_12_A, xn_12_B)

#         xn_12 = torch.max(xn_12, -zref)
       
              
#         if self.bLast:
#             xn_1 = xn_12    
#         else :
#             theta = 1 + 0.99*F.sigmoid(5.0*self.theta)
#             xn_1 = xn + theta*(xn_12-xn)
#         return xn_1






class FB_matched_block_2terms(torch.nn.Module):
    def __init__(self, 
                 N_nu,
                 N_kappa,
                 i_channels, 
                 i_kernel_size, 
                 N_rep =1,
                 bLast = False,
                 i_FNE = False 
                 ):
        super(FB_matched_block_2terms, self).__init__()
        

        self.N_nu = N_nu    
        self.N_kappa = N_kappa  
        self.bLast = bLast 
        list_channels = [1]
        list_kernel_size = []
        for _ in range(N_rep):
            list_channels.append(i_channels)
            list_kernel_size.append(i_kernel_size)
        self.convD = B.MultiConv3d(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = False, sn_size=128)
        if not self.bLast :
            if not i_FNE :
                self.theta = nn.Parameter(torch.zeros(1)) 
        self.kappa = nn.Parameter(torch.zeros(1))
        self.i_FNE = i_FNE

  


    def forward(self, xn, zref, nu, NN = None, bPos = False):        
        sn = self.convD.spectral_norm(mode="power_method", n_steps=100)

        x_convD = self.convD(xn)
        # print("min max", x_convD.min(), x_convD.max(), F.sigmoid(self.kappa))
        kappa = x_convD.abs().max()*F.sigmoid(self.kappa) + 1e-6 #5.0*
        
        if NN is not None:

            test = NN(xn) 
        else :
            test = 1.0
        if self.i_FNE:
            # theta = 0.5
            theta = 1
        else :
            theta =  1.999*F.sigmoid(5.0*self.theta)
        tau = 1.99/(theta*((test*self.N_nu*nu*sn) + 1.0))
        # print("theta", theta, "tau", tau.item() ,"kappa", kappa.item(), "sn", sn.item(), "nu", self.N_nu*nu.item())

        x_A = x_convD
        x_B = kappa*torch.sign(x_convD)
        x_AB = torch.where(torch.abs(x_convD) < kappa, x_A, x_B)
        # print("sum < kappa", torch.sum(torch.abs(x_convD) < kappa), "sum > kappa", torch.sum(torch.abs(x_convD) >= kappa), "kappa", kappa)

        xn_12 = xn - tau*(xn - zref + test*self.N_nu*nu*self.convD.transpose(x_AB))
        

        if bPos :
            xn_12 = xn_12.clamp(min=0)
        else :
            xn_12 = torch.max(xn_12, -zref)

       
              
        if self.bLast:
            xn_1 = xn_12    
        else :
            # theta = 1 + 0.99*F.sigmoid(5.0*self.theta)
            xn_1 = xn + theta*(xn_12-xn)
        # print("xn_1", xn_1.min(), xn_1.max())
        return xn_1



class FB_matched_block_multi(torch.nn.Module):
    def __init__(self, 
                 N_nu,
                 N_hub,
                 N_kappa,
                 i_channels, 
                 i_kernel_size, 
                 N_rep =1,
                 bLast = False,
                 N_prox = 1
                 
                 ):
        super(FB_matched_block_multi, self).__init__()
        

        self.N_nu = N_nu   
        self.N_hub = N_hub 
        self.N_kappa = N_kappa  
        self.N_prox = N_prox
 
        self.list_scal = nn.Parameter(torch.rand(N_prox))
        self.list_avg = nn.Parameter(torch.rand(N_prox))
        self.list2 = nn.Parameter(torch.rand(2))

        self.bLast = bLast 
        list_channels = [1]
        list_kernel_size = []
        for _ in range(N_rep):
            list_channels.append(i_channels)
            list_kernel_size.append(i_kernel_size)
        self.convD = B.MultiConv3d(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = True, sn_size=128)
        self.convD2 = B.MultiConv3d(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = True, sn_size=128)
        
        # self.convD = B.MultiConvScale3d(num_channels=[1, i_channels], size_kernels=[i_kernel_size], zero_mean = False, sn_size=128)
        # self.convD2 = B.MultiConvScale3d(num_channels=[1, i_channels], size_kernels=[3, 3], zero_mean = False, sn_size=128)
        if not self.bLast :
            self.theta = nn.Parameter(torch.ones(1)) 
        self.kappa = nn.Parameter(torch.zeros(1))
        self.hub = nn.Parameter(torch.ones(1))

  


    def forward(self, xn, zref, hub, nu, mask, bPos = False):        
        sn = self.convD.spectral_norm(mode="Fourier", n_steps=100)
        # self.convD2.check_tranpose()
        sn2 = self.convD2.spectral_norm(mode="Fourier", n_steps=200).sqrt()
        

        x_convD = self.convD(xn)
        # print("min max", x_convD.min(), x_convD.max(), F.sigmoid(self.kappa))
        kappa = self.N_kappa*x_convD.abs().max()*F.sigmoid(self.kappa) + 1e-6 #5.0*
        
        if self.bLast:
            theta = 1.0
        else :
            # theta =  1.0+0.99*F.sigmoid(5.0*self.theta)
            theta =  1.99*F.sigmoid(-2.0*self.theta)
        # tau = 1.99/(theta*((self.N_hub*hub*sn) + 1.0))

        x_A = x_convD
        x_B = kappa*torch.sign(x_convD)
        x_AB = torch.where(torch.abs(x_convD) < kappa, x_A, x_B)
        hub = torch.norm(xn - zref )/torch.norm(self.N_hub*self.convD.transpose(x_AB))*F.softplus(self.hub)
        tau = 1.99/(theta*((self.N_hub*hub*sn) + 1.0))
        #tau = 1.99/(theta*((self.N_hub*hub*sn) ))
        if self.bLast:
            tau = 0.5*tau

        # print("theta", theta.item(), "tau", tau.item() ,"kappa", kappa.item(), "sn", sn.item(), "sn2", sn2.item()) #, "nu", self.N_nu*nu.item())
        # print("sum < kappa", torch.sum(torch.abs(x_convD) < kappa).item(), "sum > kappa", torch.sum(torch.abs(x_convD) >= kappa).item(), "kappa", kappa.item())

        #xn_12 = xn - tau*( self.N_hub*hub*self.convD.transpose(x_AB))
        xn_12 = xn - tau*(xn - zref + self.N_hub*hub*self.convD.transpose(x_AB))
        un_12 = torch.zeros_like(xn_12)
        avg_weights = F.softmax(self.list_avg, dim=0)
        avg_weights2 = F.softmax(self.list2, dim=0)
        print("sn2", sn2)
        # print("convD2",(self.convD2(xn_12)/sn2).min().item(), (self.convD2(xn_12)/sn2).max().item())
        for i in range(self.N_prox):
            # print(self.N_nu*nu*F.softplus(self.list_scal[i]))
            un_12 += avg_weights[i]*self.convD2.transpose(projball_linf(self.convD2(xn_12)/sn2, self.N_nu*nu*F.softplus(self.list_scal[i])))/sn2
        # print("un_12", un_12.min().item(), un_12.max().item(), "xn_12", xn_12.min().item(), xn_12.max().item())
        xn_12 = avg_weights2[0]*un_12+avg_weights2[1]*xn_12

        if bPos :
            xn_12 = mask*xn_12.clamp(min=0)
        else :
            xn_12 = mask*torch.max(xn_12, -zref)

        # xn_12 = mask*xn_12.clamp(min=0)

       
              
        if self.bLast:
            xn_1 = xn_12    
        else :
            # theta = 1 + 0.99*F.sigmoid(5.0*self.theta)
            xn_1 = xn + theta*(xn_12-xn)
        # print("xn_1", xn_1.min(), xn_1.max())
        return xn_1 ,un_12
    
class FB_matched_block_multichan(torch.nn.Module):
    def __init__(self, 
                 N_nu,
                 N_hub,
                 N_kappa,
                 i_channels, 
                 i_kernel_size, 
                 N_rep =1,
                 bLast = False,
                 N_prox = 1
                 
                 ):
        super(FB_matched_block_multichan, self).__init__()
        

        self.N_nu = N_nu   
        self.N_hub = N_hub 
        self.N_kappa = N_kappa  
        self.N_prox = N_prox
        self.chan = i_channels
 
        self.list_scal = nn.Parameter(torch.rand(N_prox, i_channels))
        self.list_avg_chan = nn.Parameter(torch.rand(i_channels))
        self.list_avg_prox = nn.Parameter(torch.rand(N_prox))
        self.list2 = nn.Parameter(torch.rand(2))

        self.bLast = bLast 
        list_channels = [1]
        list_kernel_size = []

        for _ in range(N_rep):
            list_channels.append(i_channels)
            list_kernel_size.append(i_kernel_size)

        self.convD = B.MultiConv3d(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = True, sn_size=128)
        self.convD2 = B.MultiConv3d(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = True, sn_size=128)
        
        if not self.bLast :
            self.theta = nn.Parameter(torch.ones(1)) 
        self.kappa = nn.Parameter(torch.zeros(1))
        self.hub = nn.Parameter(torch.ones(1))

  


    def forward(self, xn, zref, hub, nu, mask, bPos = False):        
        sn = self.convD.spectral_norm(mode="Fourier", n_steps=100)
        # self.convD2.check_tranpose()
        sn2 = self.convD2.spectral_norm(mode="Fourier", n_steps=200).sqrt()
        

        x_convD = self.convD(xn)
        # print("min max", x_convD.min(), x_convD.max(), F.sigmoid(self.kappa))
        kappa = self.N_kappa*x_convD.abs().max()*F.sigmoid(self.kappa) + 1e-6 #5.0*
        
        if self.bLast:
            theta = 1.0
        else :
            theta =  1.99*F.sigmoid(-2.0*self.theta)

        x_A = x_convD
        x_B = kappa*torch.sign(x_convD)
        x_AB = torch.where(torch.abs(x_convD) < kappa, x_A, x_B)
        hub = torch.norm(xn - zref )/torch.norm(self.N_hub*self.convD.transpose(x_AB))*F.softplus(self.hub)
        tau = 1.99/(theta*((self.N_hub*hub*sn) + 1.0))
        if self.bLast:
            tau = 0.5*tau


        xn_12 = xn - tau*(xn - zref + self.N_hub*hub*self.convD.transpose(x_AB))
        un_12 = torch.zeros_like(xn_12)
        avg_weights_chan = F.softmax(self.list_avg_chan, dim=0)
        avg_weights_prox = F.softmax(self.list_avg_prox, dim=0)
        avg_weights2 = F.softmax(self.list2, dim=0)

        v = self.convD2(xn_12)/sn2
        for i in range(self.chan) :

            for j in range(self.N_prox):

                v[:,i,:,:,:] = avg_weights_prox[j]*avg_weights_chan[i]*projball_linf(v[:,i,:,:,:], self.N_nu*nu[:,i,:,:,:]*F.softplus(self.list_scal[j,i]))

        un_12 = self.convD2.transpose(v)/sn2

        xn_12 = avg_weights2[0]*un_12+avg_weights2[1]*xn_12

        if bPos :
            xn_12 = mask*xn_12.clamp(min=0)
        else :
            xn_12 = mask*torch.max(xn_12, -zref)
              
        if self.bLast:
            xn_1 = xn_12    
        else :
            xn_1 = xn + theta*(xn_12-xn)
        return xn_1 ,un_12
#################################################################


class FB_matched_block_multiScale(torch.nn.Module):
    def __init__(self, 
                 N_nu,
                 N_hub,
                 N_kappa,
                 i_channels, 
                 i_kernel_size, 
                 N_rep =1,
                 bLast = False,
                 N_prox = 1
                 
                 ):
        super(FB_matched_block_multiScale, self).__init__()
        

        self.N_nu = N_nu   
        self.N_hub = N_hub 
        self.N_kappa = N_kappa  
        self.N_prox = N_prox
        if N_prox == 1:
            self.list_bias = [0.0]
        else :
            self.list_bias = nn.Parameter(torch.rand(N_prox))
        self.list_scal = nn.Parameter(torch.rand(N_prox))

        self.bLast = bLast 
        list_channels = [1]
        list_kernel_size = []
        for _ in range(N_rep):
            list_channels.append(i_channels)
            list_kernel_size.append(i_kernel_size)
        
        self.convD = B.MultiConvScale3d(num_channels=[1, i_channels], size_kernels=[3, 3], zero_mean = False, sn_size=128)
        self.convD2 = B.MultiConvScale3d(num_channels=[1, i_channels], size_kernels=[3, 3], zero_mean = False, sn_size=128)
        if not self.bLast :
            self.theta = nn.Parameter(torch.zeros(1)) 
        self.kappa = nn.Parameter(torch.zeros(1))
        self.hub = nn.Parameter(torch.ones(1))

  


    def forward(self, xn, zref, hub, nu, mask, bPos = False):        
        sn = self.convD.spectral_norm(mode="Fourier", n_steps=100)
        # self.convD2.check_tranpose()
        sn2 = self.convD2.spectral_norm(mode="Fourier", n_steps=200).sqrt()
        

        x_convD = self.convD(xn)
        # print("min max", x_convD.min(), x_convD.max(), F.sigmoid(self.kappa))
        kappa = self.N_kappa*x_convD.abs().max()*F.sigmoid(self.kappa) + 1e-6 #5.0*
        
        theta =  1.0+0.99*F.sigmoid(5.0*self.theta)

        x_A = x_convD
        x_B = kappa*torch.sign(x_convD)
        x_AB = torch.where(torch.abs(x_convD) < kappa, x_A, x_B)
        hub = torch.norm(xn - zref )/torch.norm(self.N_hub*self.convD.transpose(x_AB))*F.softplus(self.hub)
        tau = 1.99/(theta*((self.N_hub*hub*sn) + 1.0))
        if self.bLast:
            tau = 0.5*tau

        # print("theta", theta.item(), "tau", tau.item() ,"kappa", kappa.item(), "sn", sn.item(), "sn2", sn2.item()) #, "nu", self.N_nu*nu.item())
        # print("sum < kappa", torch.sum(torch.abs(x_convD) < kappa).item(), "sum > kappa", torch.sum(torch.abs(x_convD) >= kappa).item(), "kappa", kappa.item())

        xn_12 = xn - tau*(xn - zref + self.N_hub*hub*self.convD.transpose(x_AB))
        un_12 = torch.zeros_like(xn_12)
        # print("convD2",(self.convD2(xn_12)/sn2).min().item(), (self.convD2(xn_12)/sn2).max().item())
        for i in range(self.N_prox):
            # toto = ( projball_linf(self.convD2(xn_12)/sn2 - 100*self.list_bias[i], self.N_nu*nu*F.softplus(self.list_scal[i])))
            # print("toto", toto.min().item(), toto.max().item(), "nu", (self.N_nu*nu*F.softplus(self.list_scal[i])).item())
            un_12 += self.convD2.transpose(100*self.list_bias[i] + projball_linf(self.convD2(xn_12)/sn2 - 100*self.list_bias[i], self.N_nu*nu*F.softplus(self.list_scal[i])))/sn2
        un_12 = un_12/self.N_prox
        # print("un_12", un_12.min().item(), un_12.max().item(), "xn_12", xn_12.min().item(), xn_12.max().item())
        xn_12 = 0.5*un_12+0.5*xn_12


        xn_12 = mask*xn_12.clamp(min=0)      
              
        xn_1 = xn + theta*(xn_12-xn)
        return xn_1 ,un_12

class FB_matched_block_multi2(torch.nn.Module):
    def __init__(self, 
                 N_nu,
                 N_hub,
                 N_kappa,
                 i_channels, 
                 i_kernel_size, 
                 N_rep =1,
                 bLast = False
                 ):
        super(FB_matched_block_multi2, self).__init__()
        

        self.N_nu = N_nu   
        self.N_hub = N_hub 
        self.N_kappa = N_kappa  
        
        self.bLast = bLast 
        list_channels = [1]
        list_kernel_size = []
        for _ in range(N_rep):
            list_channels.append(i_channels)
            list_kernel_size.append(i_kernel_size)
        self.convD = B.MultiConv3d(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = False, sn_size=128)
        if not self.bLast :
            self.theta = nn.Parameter(torch.zeros(1)) 
        self.kappa = nn.Parameter(torch.zeros(1))
        self.hub = nn.Parameter(torch.ones(1))

  


    def forward(self, xn, zref, hub, nu, mask, bPos = False):        
        sn = self.convD.spectral_norm(mode="Fourier", n_steps=100)

        x_convD = self.convD(xn)
        # print("min max", x_convD.min(), x_convD.max(), F.sigmoid(self.kappa))
        kappa = self.N_kappa*x_convD.abs().max()*F.sigmoid(self.kappa) + 1e-6 #5.0*
        
        
        if self.bLast:
            theta = 1.0
        else :
            theta =  1.0+0.99*F.sigmoid(5.0*self.theta)
        

        x_A = x_convD
        x_B = kappa*torch.sign(x_convD)
        x_AB = torch.where(torch.abs(x_convD) < kappa, x_A, x_B)
        #print("theta", theta.item(), "tau", tau.item() ,"kappa", kappa.item()) #, "sn", sn.item(), "sn2", sn2.item()) #, "nu", self.N_nu*nu.item())
        # print("sum < kappa", torch.sum(torch.abs(x_convD) < kappa).item(), "sum > kappa", torch.sum(torch.abs(x_convD) >= kappa).item(), "kappa", kappa.item())

        
        hub = torch.norm(xn - zref )/torch.norm(self.N_hub*self.convD.transpose(x_AB))*F.softplus(self.hub)
        tau = 1.99/(theta*((self.N_hub*hub*sn) + 1.0))
        if self.bLast:
            tau = 0.5*tau
        # xn_12 = xn - tau*(self.N_hub*hub*self.convD.transpose(x_AB))
        xn_12 = xn - tau*(xn - zref + self.N_hub*hub*self.convD.transpose(x_AB))
        # print("tau", tau.item(), (tau*torch.norm(xn - zref )).item(), (tau*torch.norm(self.N_hub*hub*self.convD.transpose(x_AB))).item())
        
        # if bPos :
        #     xn_12 = mask*xn_12.clamp(min=0)
        # else :
        #     xn_12 = mask*torch.max(xn_12, -zref)

       
        xn_12 = mask*xn_12.clamp(min=0)
        if self.bLast:
            xn_1 = xn_12    
        else :
            # theta = 1 + 0.99*F.sigmoid(5.0*self.theta)
            xn_1 = xn + theta*(xn_12-xn)
        # print("xn_1", xn_1.min(), xn_1.max())
        return xn_1, xn_1

class FB_unmatched_block_2terms(torch.nn.Module):
    def __init__(self, 
                 N_nu,
                 N_kappa,
                 i_channels, 
                 i_kernel_size, 
                 N_rep =1,
                 bLast = False
                 ):
        super(FB_unmatched_block_2terms, self).__init__()
        

        self.N_nu = N_nu    
        self.N_kappa = N_kappa  
        self.bLast = bLast 
        list_channels = [1]
        list_kernel_size = []
        for i in range(N_rep):
            list_channels.append(i_channels)
            list_kernel_size.append(i_kernel_size)
        self.convD = B.UnmatchedMultiConv3dFB(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = False, sn_size=128)
        if not self.bLast:
            self.theta = nn.Parameter(-1.0*torch.ones(1)) 



    def forward(self, xn, zref, nu, NN = None, bPos = False):        
       
        eta, eps = self.convD.step_FB_with_conv(self.N_nu*nu, self.convD, self.N_nu*nu)
        tau = 1.99*eta
        
        if NN is not None:
            test = NN(xn) 
        else :
            test = 1.0
        
        xn_12 = xn - tau*((1.0+eps)*(xn - zref) + self.N_nu*nu*self.convD.transpose(self.convD(xn)))

       
        if bPos :
            xn_12 = xn_12.clamp(min=0)
        else :
            xn_12 = torch.max(xn_12, -zref)
       
              
        if self.bLast:
            xn_1 = xn_12    
        else :
            theta = 1 + 0.99*F.sigmoid(5.0*self.theta)
            xn_1 = xn + theta*(xn_12-xn)
        return xn_1

#################################################

class FB_matched_block(torch.nn.Module):
    def __init__(self, 
                 N_nu,
                 N_kappa,
                 i_channels, 
                 i_kernel_size, 
                 bLast = False, 
                 b_NE = False
                 ):
        super(FB_matched_block, self).__init__()
        

        self.N_nu = N_nu    
        self.N_kappa = N_kappa  
        self.bLast = bLast 
        self.convD = B.MultiConv3d(num_channels=[1, i_channels], size_kernels=[i_kernel_size], zero_mean = False, sn_size=128)
        if not self.bLast:
            self.theta = nn.Parameter(-1.0*torch.ones(1)) 
        self.kappa = nn.Parameter(torch.zeros(1))
        self.b_NE = b_NE

  

    def forward(self, xn, zref, nu, quad = None, bPos = False, NN = None):        
        sn = self.convD.spectral_norm(mode="Fourier", n_steps=100)
        # kappa = 100000*F.softplus(10*self.kappa)+1e-6
        # kappa = 10000*F.softplus(5.0*self.kappa)+1e-6
        

        x_convD = self.convD(xn)
        kappa = x_convD.abs().max()*F.sigmoid(5.0*self.kappa) + 1e-6
        
        if NN is not None:
            test = NN(xn) #/10000)
            # print(self.N_nu*nu*test.min(), self.N_nu*nu*test.max(), self.N_nu*nu*test.mean(), self.N_nu*nu*test.std())  

        else :
            test = 1.0

        # print("sn", sn, "kappa", kappa, "F.sigmoid(5.0*kappa)=", F.sigmoid(5.0*self.kappa))
        # print("test*self.N_nu*nu", test*self.N_nu*nu)
        tau = 1.99/((test*self.N_nu*nu*sn)/kappa + 1.0)
        # print("!!!!! tau min", tau.min(), "tau max", tau.max())
        
        xn_12_A = xn - tau*(xn - zref + test*self.N_nu*nu*self.convD.transpose(x_convD/kappa))
        # print("sum < kappa", torch.sum(torch.abs(x_convD) < kappa), "sum > kappa", torch.sum(torch.abs(x_convD) > kappa))
        # print("min max sum", test*self.N_nu*nu*self.convD.transpose(x_convD/kappa).min(), test*self.N_nu*nu*self.convD.transpose(x_convD/kappa).max())
        xn_12_B = xn - tau*(xn - zref + test*self.N_nu*nu*self.convD.transpose(torch.sign(x_convD)))
        xn_12 = torch.where(torch.abs(xn) < kappa, xn_12_A, xn_12_B)

        if self.b_NE:
            xn_12 = torch.max(xn_12, -zref)
        else :
            xn_12 = xn_12.clamp(min=0)
        # min_zref = torch.min(zref)
        # max_zref = torch.max(zref)
        # xn_12 = xn_12.clamp(min=min_zref, max=max_zref) 
        # xn_12 = xn_12.clamp(min=-min_t) 
        # print("max", torch.max(xn_12), "min", torch.min(xn_12))
        if bPos :
            xn_12 = xn_12.clamp(min=0)        
        # theta = F.sigmoid(100*self.theta)*2
        if self.bLast:
            xn_1 = xn_12    
        else :
            theta = 1 + 0.99*F.sigmoid(5.0*self.theta)
            # print("tau", tau, "theta", theta, "kappa", kappa, "sum <= kappa", torch.sum(torch.abs(xn) <= kappa), "sum > kappa", torch.sum(torch.abs(xn) > kappa))
            xn_1 = xn + theta*(xn_12-xn)
        return xn_1


#################################################
    
class FB_unmatched_block(torch.nn.Module):
    def __init__(self, 
                 N_nu,
                 i_channels, 
                 i_kernel_size, 
                 ):
        super(FB_unmatched_block, self).__init__()
        

        self.N_nu = N_nu       
        self.convD = B.UnmatchedMultiConv3dFB(num_channels=[1, i_channels], size_kernels=[i_kernel_size], zero_mean = False, sn_size=128)
        self.theta = nn.Parameter(-1.0*torch.ones(1)) 
  

    def forward(self, xn, zref, nu, quad = None):        
        eta, eps = self.convD.step_FB(self.N_nu*nu)
        tau = 1.99*eta
        # delta = 2 - (1.99/2)
        print("tau", tau, "eps", eps)

        xn_12 = xn - tau*((1.0+eps)*(xn - zref) + self.N_nu*nu*self.convD.transpose(self.convD(xn)))
        xn_12 = xn_12.clamp(min=0)        
        theta = 1 + 0.99*F.sigmoid(5.0*self.theta)
        # print("theta", theta)
        xn_1 = xn + theta*(xn_12-xn)
        return xn_1


 #################################################
    
class FB_matched_block_l2(torch.nn.Module):
    def __init__(self, 
                 N_nu,
                 i_channels, 
                 i_kernel_size, 
                 ):
        super(FB_matched_block_l2, self).__init__()
        

        self.N_nu = N_nu       
        self.convD = B.MultiConv3d(num_channels=[1, i_channels], size_kernels=[i_kernel_size], zero_mean = False, sn_size=128)
        self.theta = nn.Parameter(-1.0*torch.ones(1)) 
  

    def forward(self, xn, zref, nu):        

        sn = self.convD.spectral_norm(mode="Fourier", n_steps=100)       
        tau = 1.99/((self.N_nu*nu*sn) + 1.0)

        xn_12 = xn - tau*(xn - zref + self.N_nu*nu*self.convD.transpose(self.convD(xn)))
        # xn_12 = xn_12.clamp(min=0)    
        xn_12 = torch.max(xn_12, -zref)    
        theta = 1 + 0.99*F.sigmoid(5.0*self.theta)
        # print("theta", theta)
        xn_1 = xn + theta*(xn_12-xn)
        return xn_1


       


#################################################

class FBnet(torch.nn.Module):
    def __init__(self, 
                 N_kappa,
                 N_nu,
                 i_channels, 
                 i_kernel_size, 
                 i_num_iter, 
                 i_num_iter_u,
                 b_spatial = False, 
                 b_NE = False,
                 N_quad = 0,
                 N_rep = 1,
                 i_FNE = False,
                 N_prox = 1, 
                 b_multiScale = False
                 ):
        super(FBnet, self).__init__()
        
        self.N_kappa = N_kappa
        self.N_nu = N_nu
        self.N_quad = N_quad
        if N_quad > 0 :
            self.quad = nn.Parameter(torch.zeros(1))
        self.i_channels = i_channels
        self.i_kernel_size = i_kernel_size
        self.i_num_iter = i_num_iter
        self.i_num_iter_u = i_num_iter_u
        self.b_NE = b_NE
        self.b_Pos = not b_NE
        self.i_FNE = i_FNE
        self.N_prox = N_prox
  
        self.Layers   = nn.ModuleList()
        self.Layers_u = nn.ModuleList()
        # if N_prox > 0:
        #     self.nu = nn.Parameter(torch.ones(1))
        # else :
        #     self.nu = 1.0
        # self.hub = nn.Parameter(torch.zeros(1))
        self.b_spatial = b_spatial

        if b_spatial:
            self.NN = RFDN(in_nc=1, nf=8, num_modules=1, out_nc=i_channels, upscale=1)
            # self.NN = NFUNetRes2(in_nc=1, out_nc=1, nb=1, wf= 2, depth = 4, act_mode = 'E', upsample_mode='upconv',
            #                  norm = 'nonorm.v1', type_init='kaiming', 
            #                  keep_bias=False, repeat=False, bUseAtt=False, bUseComposition=False, 
            #                  bUseMask=False, bUseClamp=False, use_gamma=False)
        else:
            self.NN = torch.ones((1, i_channels, 1, 1, 1), device='cuda')
        
        for k in range(self.i_num_iter):    
            if N_prox == 0 :
                self.Layers.append(FB_matched_block_multi2(100*N_nu,N_nu, 0.1*N_kappa, i_channels, i_kernel_size, N_rep = N_rep, bLast=False)) 
            elif b_multiScale:
                self.Layers.append(FB_matched_block_multiScale(100*N_nu,N_nu, 0.1*N_kappa, i_channels, i_kernel_size, N_rep = N_rep, N_prox=N_prox, bLast=False))
            else :
                self.Layers.append(FB_matched_block_multi(100.0,100.0, 0.1, i_channels, i_kernel_size, N_rep = N_rep, N_prox=N_prox, bLast=False))

      
        # for _ in range(self.i_num_iter):    
        #     # self.Layers.append(FB_matched_block(N_nu, N_kappa, i_channels, i_kernel_size, bLast= False, b_NE=b_NE)) 
        #     if N_quad == 0:   
        #         self.Layers.append(FB_matched_block_multi(N_nu, N_nu, N_kappa, i_channels, i_kernel_size, N_rep = N_rep, N_prox=10)) 

        #         # self.Layers.append(FB_matched_block_l2(N_nu, i_channels, i_kernel_size)) 
        #         # self.Layers.append(FB_matched_block_2terms(N_nu, N_kappa, i_channels, i_kernel_size, N_rep = N_rep, i_FNE=i_FNE )) 
        #     else :
        #         self.Layers.append(FB_matched_block_3termsProx(N_nu, N_kappa, N_quad, i_channels, i_kernel_size, N_rep = N_rep )) 


        # for _ in range(self.i_num_iter_u):    
        #     if N_quad == 0:
        #         # self.Layers_u.append(FB_matched_block_l2(N_nu, i_channels, i_kernel_size)) 
        #         self.Layers_u.append(FB_unmatched_block_2terms(N_nu, N_kappa, i_channels, i_kernel_size, N_rep = N_rep )) 

        #     else :
        #         self.Layers_u.append(FB_unmatched_block_3termsProx(N_nu, N_kappa, N_quad, i_channels, i_kernel_size, N_rep = N_rep )) 

            # self.Layers_u.append(FB_unmatched_block(N_nu, i_channels, i_kernel_size)) 
                      
    def forward(self, x0,u0, zref, mask, nu, b_training = False, b_pos = False):
        xk = x0 #.clamp(min=0) #torch.zeros(zref.shape[0], 1, zref.shape[2], zref.shape[3], zref.shape[4], device=zref.device)
        vec_x = torch.zeros(zref.shape[0], self.i_num_iter + self.i_num_iter_u, zref.shape[2], zref.shape[3], zref.shape[4], device=zref.device)
        vec_u = torch.zeros(zref.shape[0], self.i_num_iter + self.i_num_iter_u, zref.shape[2], zref.shape[3], zref.shape[4], device=zref.device)

        # if self.N_prox > 0:
        #     reg_nu = nu*F.softplus(self.nu)
        # else 
        if self.b_spatial:
            reg_nu = nu*self.NN(x0)
        else :
            reg_nu = nu*self.NN
        for k in range(self.i_num_iter):
            # print("Layer", k, xk.min().item(), xk.max().item(),nu*F.softplus(self.nu).item())
            if self.N_quad>0:
                xk  = self.Layers[k](xk, zref, nu=  reg_nu, quad = F.softplus(self.quad), NN = self.NN, bPos = self.b_Pos) 
            else :
                xk,uk  = self.Layers[k](xk, zref, nu= reg_nu, hub = 1.0, mask = mask, bPos = self.b_Pos)
            # if mask is not None:
            #     xk = xk*mask
            vec_x[:,k,:,:,:] = xk.squeeze()
            vec_u[:,k,:,:,:] = uk.squeeze()

        # for k in range(self.i_num_iter_u):
        #     # print("Layer", k, "nu", nu*F.softplus(10*self.nu))
        #     if self.N_quad>0:
        #         xk  = self.Layers_u[k](xk, zref, nu = reg_nu, quad = F.softplus(self.quad), NN = self.NN, bPos = self.b_Pos) #, bPos = b_pos) 
        #     else :
        #         xk  = self.Layers_u[k](xk, zref, nu = reg_nu, NN = self.NN, bPos = self.b_Pos)
        #     if mask is not None:
        #         xk = xk*mask
        #     # if b_pos:
        #     #     xk = xk.clamp(min=0)
        #     vec_x[:,k+self.i_num_iter,:,:,:] = xk.squeeze()
        return xk, vec_x, vec_u
    


####################################################################################




class FBDEQ(torch.nn.Module):
    def __init__(self, 
                 N_hub,
                 N_kappa,
                 i_channels, 
                 i_kernel_size, 
                 N_rep =1,
                 bMultiScale = False
                 ):
        super(FBDEQ, self).__init__()
        

        self.N_hub = N_hub 
        self.N_kappa = N_kappa  
        if bMultiScale :
            self.convD = B.MultiConvScale3d(num_channels=[1, i_channels], size_kernels=[i_kernel_size, i_kernel_size], zero_mean = False, sn_size=128)

        else :
            list_channels = [1]
            list_kernel_size = []
            for _ in range(N_rep):
                list_channels.append(i_channels)
                list_kernel_size.append(i_kernel_size)
            self.convD = B.MultiConv3d(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = True, sn_size=128)
        # self.theta = nn.Parameter(torch.zeros(1)) 
        self.kappa = nn.Parameter(torch.zeros(1))
        # self.hub = nn.Parameter(torch.ones(1))

  


    def forward(self, xn, zref, hub, mask):  
        # kernel_weights = conv_layer.weight.data
        # mean_value = torch.mean(kernel_weights)

        # # Adjust the kernel weights to have a mean of 0
        # with torch.no_grad():
        #     conv_layer.weight.data -= mean_value   
        sn = self.convD.spectral_norm(mode="Fourier", n_steps=100)

        x_convD = self.convD(xn)
        kappa = self.N_kappa*x_convD.abs().min()*F.softplus(self.kappa) + 1e-6 
        
        
        theta =  1.0 #99*F.sigmoid(5.0*self.theta)
        

        x_A = x_convD
        x_B = kappa*torch.sign(x_convD)
        x_AB = torch.where(torch.abs(x_convD) < kappa, x_A, x_B)

        
        # hub = torch.norm(xn - zref )/torch.norm(self.N_hub*self.convD.transpose(x_AB))*F.softplus(self.hub)
        tau = 1.99/(theta*((self.N_hub*hub*sn) + 1.0))
        #tau = 1.99/(theta*((self.N_hub*hub*F.softplus(self.hub)*sn) + 1.0))
        xn_12 = xn - tau*(xn - zref + self.N_hub*hub*self.convD.transpose(x_AB))
       
       
        xn_12 = mask*xn_12.clamp(min=0)
        # xn_1 = xn + theta*(xn_12-xn)
        return xn_12

    def loss(self, xn, zref, hub, mask):
        x_convD = self.convD(xn)
        kappa = self.N_kappa*x_convD.abs().max()*F.sigmoid(self.kappa) + 1e-6 

        # compute Huber penalty on x_convD (param Huber: kappa)
        x_AB = torch.where(torch.abs(x_convD) < kappa, 0.5*x_convD**2, kappa*torch.abs(x_convD) - 0.5*kappa**2)

       
        return (0.5*torch.norm(xn - zref,2),self.N_hub*hub*torch.sum(x_AB))

class FBnetDEQFixedPoint(nn.Module):
    def __init__(self, params_bw, params_fw, params_model):
        super().__init__()
        self.model = FBDEQ(N_hub=params_model['N_hub'], i_channels=params_model['i_channels'], i_kernel_size=params_model['i_kernel_size'], N_kappa=params_model['N_kappa'], N_rep=params_model['N_rep'], bMultiScale=params_model['bMultiScale'])
        self.solver = safe_anderson_acceleration
        self.params_fw = params_fw
        self.params_bw = params_bw
        self.f = None
        # self.fjvp = None
        self.backward_res = None
        self.backward_iter = None
        self.lamb_bck = None
        self.lamb_fwd = None
        self.moving_avg_res_bck = None
        self.moving_avg_res_fwd = None
        self.forward_res = None
        self.forward_iter = self.params_fw['max_iter']
        self.i_channels = params_model['i_channels']
        
    def forward(self, x_noisy, mask=None, nu = 1, bTrain = True, xstart = None, **kwargs):

            
        # fixed point iteration
        def f(z, x_noisy, nu, mask):
             z1 = self.model(z, x_noisy,hub= nu, mask=mask)
             return(z1)
        
        def loss(z, x_noisy, nu, mask):
            l = self.model.loss(z, x_noisy,hub= nu, mask=mask)
            return l

        # # jacobian vector product of the fixed point iteration
        # def fjvp(x, y):
        #     with torch.no_grad():
        #         return(y - self.model.hvp_denoising(x, y, sigma=sigma))

        self.f = f
        self.loss = loss
        # self.fjvp = fjvp


        # compute the fixed point
        with torch.no_grad():
            # if model is an instance of CVnetDEQ
            # z, self.forward_iter, self.forward_res, self.lamb_fwd, self.moving_avg_res_fwd = self.solver(lambda z : self.f(z, x_noisy, nu, mask), torch.zeros_like(x_noisy) if (xstart is None) else xstart, **self.params_fw)
            
            # if xstart is None :
            #     xk = torch.zeros(x_noisy.shape[0], 1, x_noisy.shape[2], x_noisy.shape[3], x_noisy.shape[4], device=x_noisy.device)
            # else :
            #     xk = xstart
            xk = torch.zeros(x_noisy.shape[0], 1, x_noisy.shape[2], x_noisy.shape[3], x_noisy.shape[4], device=x_noisy.device)
            self.forward_res = []
            for k in range(self.params_fw['max_iter']):
                x = xk
                xk = self.model(xk, x_noisy, hub=nu, mask=mask)
                self.forward_res.append(((xk - x).norm() / (1e-5 + xk.norm())).detach().cpu().numpy())
                if (xk - x).norm() / (1e-5 + xk.norm()) < self.params_fw['tol']:
                    self.forward_iter = k
                    
                    break
            z=xk    
        z = self.f(z, x_noisy, nu, mask)
        l1, l2 = self.loss(z, x_noisy, nu, mask)
  
        # z0 = z.clone().detach()

        # def backward_hook(grad):
        #     g, self.backward_niter = self.solver(lambda y : self.fjvp(z0, y) + grad,
        #                                    grad, **self.params_bw)
        #     return g

        # if self.model.training:
        #     z.register_hook(backward_hook)

        z0 = z.clone().detach().requires_grad_()
        f0 = self.f(z0,x_noisy, nu, mask)
        def backward_hook(grad):
            """
            A hook needed during the backward pass
            """
            g, self.backward_iter, self.backward_res, self.lamb_bck, self.moving_avg_res_bck = self.solver(lambda y : autograd.grad(f0, z0, y, retain_graph=True)[0] + grad,
                                               grad, **self.params_bw)
            return g
                
        if bTrain :
            z.register_hook(backward_hook)
       
        return z, [self.forward_iter, self.backward_iter], [self.forward_res, self.backward_res], [self.lamb_fwd, self.lamb_bck], [self.moving_avg_res_fwd, self.moving_avg_res_bck], [l1, l2]









def safe_anderson_acceleration(f, x0, m=5, lam=1e-4, max_iter=50, tol=1e-5, beta=1.0, average_iter=20, deb_average=50, plateau_iter=20, verbose = False):
    """Safe version of Anderson acceleration for fixed point iteration.
    Ensures that the Hessian is invertible by adding a small value to the diagonal depending on the conditioning of G.
    If the moving average of residual is increasing, the method is restarted with a larger value of lam (fac 1.1).
    
    Args:
    - f (callable): The function for fixed point iteration.
    - x0 (torch.Tensor): The initial guess tensor.
    - m (int): Number of previous iterates to store.
    - lam (float): Regularization parameter.
    - max_iter (int): Maximum number of iterations.
    - tol (float): Tolerance for convergence.
    - beta (float): Mixing coefficient for the accelerated iterate.
    - average_iter (int): Number of iterations to compute the movign average of residuals.
    - deb_average (int): Number of iterations before starting to compute the moving average of residuals.
    
    Returns:
    - x (torch.Tensor): The final iterate.
    - f_x (torch.Tensor): The value of f at the final iterate.
    - res (list): List of residuals for each iteration.
    """
    bsz, d, D, H, W = x0.shape
    X = torch.zeros(bsz, m, d * D * H * W, dtype=x0.dtype, device=x0.device)
    F = torch.zeros(bsz, m, d * D * H * W, dtype=x0.dtype, device=x0.device)
    X[:, 0], F[:, 0] = x0.view(bsz, -1), f(x0).view(bsz, -1)
    X[:, 1], F[:, 1] = F[:, 0], f(F[:, 0].view_as(x0)).view(bsz, -1)

    H_mat = torch.zeros(bsz, m + 1, m + 1, dtype=x0.dtype, device=x0.device)
    H_mat[:, 0, 1:] = H_mat[:, 1:, 0] = 1
    y = torch.zeros(bsz, m + 1, 1, dtype=x0.dtype, device=x0.device)
    y[:, 0] = 1
    
    plateau_count = 0  # Count for plateau iterations
    # prev_res_norm = float('inf')  # Initial previous residual norm
    res = []
    
    moving_avg_res = []

    k = 2
    while k < max_iter:
        n = min(k, m)
        G = F[:, :n] - X[:, :n]

        # Compute the conditioning of G
        g_norm = G.norm(dim=(1, 2))
        cond_G = g_norm.max() / g_norm.min()

        # Update the diagonal of H_mat with a small value based on the conditioning of G
        H_mat[:, 1:n + 1, 1:n + 1] = torch.bmm(G, G.transpose(1, 2)) + lam * cond_G * torch.eye(n, dtype=x0.dtype, device=x0.device)[None]

        # Solve for alpha
        alpha = torch.linalg.solve(H_mat[:, :n + 1, :n + 1], y[:, :n + 1])[:, 1:n + 1, 0]

        # Update X and F
        X[:, k % m] = beta * (alpha[:, None] @ F[:, :n])[:, 0] + (1 - beta) * (alpha[:, None] @ X[:, :n])[:, 0]
        F[:, k % m] = f(X[:, k % m].view_as(x0)).view(bsz, -1)

        # Compute residual and check for convergence
        res_norm = (F[:, k % m] - X[:, k % m]).norm() / (1e-5 + F[:, k % m].norm())
        res.append(res_norm.item())

        if res_norm < tol:
            if verbose:
                print("Converged in", k, "iterations.")
            break
        
        # compute the moving average of residuals
        if k >= deb_average + average_iter: #and k % average_iter == 0:
            if k == (average_iter + deb_average) : #first one
                moving_avg_res = res[-average_iter:]
                current_sum = sum(moving_avg_res) 
            else:
                moving_avg_res.append(res_norm.item())
                moving_avg_res = moving_avg_res[1:]
                prec_sum = current_sum
                current_sum = sum(moving_avg_res)


        # check if the moving average of residuals is increasing
        if k > (deb_average+average_iter) :
            if verbose :
                print("prec_sum", prec_sum, "current_sum", current_sum, "res_norm", res_norm.item(), "cond_G", cond_G)
            if current_sum > prec_sum:
                if verbose:
                    print("Increasing plateau.")
                plateau_count += 1
            else:
                plateau_count = 0
            if plateau_count == plateau_iter :
                plateau_count = 0
                deb_average = k
                if verbose:
                    print("####################################")
                    print("Iteration", k, ": Restarting Anderson acceleration with larger regularization parameter.")
                    print("prec_sum", prec_sum, "current_sum", current_sum)
                k = 1
                res = []
                moving_avg_res = []
                X[:, 0], F[:, 0] = x0.view(bsz, -1), f(x0).view(bsz, -1)
                X[:, 1], F[:, 1] = F[:, 0], f(F[:, 0].view_as(x0)).view(bsz, -1)

                H_mat = torch.zeros(bsz, m + 1, m + 1, dtype=x0.dtype, device=x0.device)
                H_mat[:, 0, 1:] = H_mat[:, 1:, 0] = 1

                y = torch.zeros(bsz, m + 1, 1, dtype=x0.dtype, device=x0.device)
                y[:, 0] = 1
                
                # Restart with a larger value of lam
                lam *= 1.5 #1.1
                if verbose :
                    print("lam", lam)
                    print("####################################")

        k += 1

    if verbose :
        print("Anderson acceleration done.")
    return X[:, k % m].view_as(x0), k, res, lam, moving_avg_res