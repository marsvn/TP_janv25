import torch
import torch.nn as nn
import torch.nn.functional as F
from . import basicblock as B
from . import CVnet as C

class CP_block_relax_unit(torch.nn.Module):
    def __init__(self, 
                 N_nu,
                 i_channels, 
                 i_kernel_size, 
                 N_rep = 1
                 ):
        super(CP_block_relax_unit, self).__init__()
        

        self.N_nu = N_nu 
        list_channels = [1]
        list_kernel_size = []
        for i in range(N_rep):
            list_channels.append(i_channels)
            list_kernel_size.append(i_kernel_size)      
        self.convD = B.UnmatchedMultiConv3dUnit(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = False, sn_size=128)
        # self.theta = nn.Parameter(torch.ones(1))
               
    # f(x)+g(Dx)+12 ||x - zref||^2
    # xn -> x
    # un -> u
    # p1n -> x
    # p2n -> u
    def forward(self, xn, un, zref, nu, bLast = False):

        gamma, epsilon = self.convD.step_CP()


        # print("gamma", gamma.item(), "epsilon", epsilon)

        v1n = xn + gamma *(xn - zref + self.convD.transpose(un))
        p1n = torch.clamp(v1n, min = 0) #/(1.0+gamma)
        v2n = un + gamma * (self.convD(xn) + epsilon * un)
        p2n = self.N_nu*nu*F.hardtanh(v2n/(self.N_nu*nu + 1e-6))
        q2n = p2n + gamma*(self.convD(p1n)+epsilon*p2n)
        q1n = p1n - gamma*(p1n-zref+self.convD.transpose(p2n))
        theta = 0.5 #F.relu(self.theta)
        # # print("theta", theta)
        xn_1 = theta*(xn - v1n + q1n)+(1-theta)*xn
        un_1 = theta*(un - v2n + q2n) + (1-theta)*un
        # xn_1 = (xn - v1n + q1n)
        # un_1 = (un - v2n + q2n)
        
        if bLast:
            v1n = xn_1 + gamma *(xn_1 - zref + self.convD.transpose(un_1))
            pfin = torch.clamp(v1n, min = 0)
            return xn_1, un_1, p1n, pfin
        else:
            return xn_1, un_1, p1n
        
        
        

class CP_block_relax_unit_Nprox(torch.nn.Module):
    def __init__(self, 
                 N_nu,
                 i_channels, 
                 i_kernel_size, 
                 N_rep = 1
                 ):
        super(CP_block_relax_unit_Nprox, self).__init__()
        
        self.N_prox = 5
        self.N_nu = N_nu 
        list_channels = [1]
        list_kernel_size = []
        self.list_scal = nn.Parameter(torch.randn(self.N_prox))
        for i in range(N_rep):
            list_channels.append(i_channels)
            list_kernel_size.append(i_kernel_size)      
        self.convD = B.UnmatchedMultiConv3dUnit(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = False, sn_size=128)
        # self.theta = nn.Parameter(torch.ones(1))
               
    # f(x)+g(Dx)+12 ||x - zref||^2
    # xn -> x
    # un -> u
    # p1n -> x
    # p2n -> u
    def forward(self, xn, un, zref, nu, bLast = False):

        gamma, epsilon = self.convD.step_CP()


        # print("gamma", gamma.item(), "epsilon", epsilon)

        v1n = xn + gamma *(xn - zref + self.convD.transpose(un))
        p1n = torch.clamp(v1n, min = 0) #/(1.0+gamma)
        v2n = un + gamma * (self.convD(xn) + epsilon * un)
        
        scal = self.N_nu*nu+ 0.1*self.N_nu*nu*self.list_scal[0]
        p2n = scal*F.hardtanh(v2n/(scal + 1e-6)) 
        for i in range(1,self.N_prox) :
            scal = self.N_nu*nu+ 0.1*self.N_nu*nu*self.list_scal[i]
            p2n += scal*F.hardtanh(v2n/(scal + 1e-6))
        p2n /= self.N_prox
        q2n = p2n + gamma*(self.convD(p1n)+epsilon*p2n)
        q1n = p1n - gamma*(p1n-zref+self.convD.transpose(p2n))
        theta = 0.5 #F.relu(self.theta)
        # # print("theta", theta)
        xn_1 = theta*(xn - v1n + q1n)+(1-theta)*xn
        un_1 = theta*(un - v2n + q2n) + (1-theta)*un
        # xn_1 = (xn - v1n + q1n)
        # un_1 = (un - v2n + q2n)
        
        if bLast:
            v1n = xn_1 + gamma *(xn_1 - zref + self.convD.transpose(un_1))
            pfin = torch.clamp(v1n, min = 0)
            return xn_1, un_1, p1n, pfin
        else:
            return xn_1, un_1, p1n
        
        
class CP_block_relax(torch.nn.Module):
    def __init__(self, 
                 N_nu,
                 i_channels, 
                 i_kernel_size, 
                 N_rep = 1
                 ):
        super(CP_block_relax, self).__init__()
        

        self.N_nu = N_nu 
        list_channels = [1]
        list_kernel_size = []
        for i in range(N_rep):
            list_channels.append(i_channels)
            list_kernel_size.append(i_kernel_size)      
        self.convD = B.UnmatchedMultiConv3d(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = False, sn_size=128)
        # self.theta = nn.Parameter(torch.ones(1))
               
    # f(x)+g(Dx)+12 ||x - zref||^2
    # xn -> x
    # un -> u
    # p1n -> x
    # p2n -> u
    def forward(self, xn, un, zref, nu, bLast = False):

        gamma, epsilon = self.convD.step_CP()


        # print("gamma", gamma.item(), "epsilon", epsilon.item())

        v1n = xn + gamma *(xn - zref + self.convD.transpose(un))
        p1n = torch.clamp(v1n, min = 0) #/(1.0+gamma)
        v2n = un + gamma * (self.convD(xn) + epsilon * un)
        p2n = self.N_nu*nu*F.hardtanh(v2n/(self.N_nu*nu + 1e-6))
        q2n = p2n + gamma*(self.convD(p1n)+epsilon*p2n)
        q1n = p1n - gamma*(p1n-zref+self.convD.transpose(p2n))
        theta = 0.5 #F.relu(self.theta)
        # print("theta", theta)
        xn_1 = theta*(xn - v1n + q1n)+(1-theta)*xn
        un_1 = theta*(un - v2n + q2n) + (1-theta)*un
        if bLast:
            v1n = xn_1 + gamma *(xn_1 - zref + self.convD.transpose(un_1))
            pfin = torch.clamp(v1n, min = 0)
            return xn_1, un_1, p1n, pfin
        else:
            return xn_1, un_1, p1n



class CP_block_relax_matched(torch.nn.Module):
    def __init__(self, 
                 N_nu,
                 i_channels, 
                 i_kernel_size, 
                 N_rep = 1
                 ):
        super(CP_block_relax_matched, self).__init__()
        

        self.N_nu = N_nu 
        list_channels = [1]
        list_kernel_size = []
        for i in range(N_rep):
            list_channels.append(i_channels)
            list_kernel_size.append(i_kernel_size)      
        self.convD = B.MultiConv3d(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = False, sn_size=128)
        # self.theta = nn.Parameter(torch.ones(1))
               
    # f(x)+g(Dx)+12 ||x - zref||^2
    # xn -> x
    # un -> u
    # p1n -> x
    # p2n -> u
    def forward(self, xn, un, zref, nu, bLast = False):

        sn = self.convD.spectral_norm(mode="Fourier") #, n_steps=100)
        gamma = 0.9/(1.0+sn.sqrt())



        v1n = xn + gamma *(xn - zref + self.convD.transpose(un))
        p1n = torch.clamp(v1n, min = 0) #/(1.0+gamma)
        v2n = un + gamma * (self.convD(xn) )
        p2n = self.N_nu*nu*F.hardtanh(v2n/(self.N_nu*nu + 1e-6))
        q2n = p2n + gamma*(self.convD(p1n))
        q1n = p1n - gamma*(p1n-zref+self.convD.transpose(p2n))
        theta = 0.5 #F.relu(self.theta)
        # print("theta", theta)
        xn_1 = theta*(xn - v1n + q1n)+(1-theta)*xn
        un_1 = theta*(un - v2n + q2n) + (1-theta)*un
        if bLast:
            v1n = xn_1 + gamma *(xn_1 - zref + self.convD.transpose(un_1))
            pfin = torch.clamp(v1n, min = 0)
            return xn_1, un_1, p1n, pfin
        else:
            return xn_1, un_1, p1n

class CP_block(torch.nn.Module):
    def __init__(self, 
                 N_nu,
                 i_channels, 
                 i_kernel_size,
                 N_rep=1
                 ):
        super(CP_block, self).__init__()
        

        self.N_nu = N_nu   
        list_channels = [1]
        list_kernel_size = []
        for i in range(N_rep):
            list_channels.append(i_channels)
            list_kernel_size.append(i_kernel_size)        
        self.convD = B.UnmatchedMultiConv3d(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = False, sn_size=128)
               
    # f(x)+g(Dx)+12 ||x - zref||^2
    # xn -> x
    # un -> u
    # p1n -> x
    # p2n -> u
    def forward(self, xn, un, zref, nu, bLast = False):

        gamma, epsilon = self.convD.step_CP()

        print("gamma", gamma, "epsilon", epsilon)

        v1n = xn + gamma *(xn - zref + self.convD.transpose(un))
        p1n = torch.clamp(v1n, min = 0) #/(1.0+gamma)
        v2n = un + gamma * (self.convD(xn) + epsilon * un)
        p2n = self.N_nu*nu*F.hardtanh(v2n/(self.N_nu*nu + 1e-6))
        q2n = p2n + gamma*(self.convD(p1n)+epsilon*p2n)
        q1n = p1n - gamma*(p1n-zref+self.convD.transpose(p2n))
        xn_1 = xn - v1n + q1n
        un_1 = un - v2n + q2n
        if bLast:
            v1n = xn + gamma *(xn - zref + self.convD.transpose(un))
            pfin = torch.clamp(v1n, min = 0)
            return xn_1, un_1, p1n, pfin
        else:
            return xn_1, un_1, p1n

################################################
        
class CP_block_relax_noConv(torch.nn.Module):
    def __init__(self, 
                 N_nu,
                 i_channels, 
                 i_kernel_size, 
                 ):
        super(CP_block_relax_noConv, self).__init__()
        

        self.N_nu = N_nu       
        self.convD = B.UnmatchedMultiConv3d(num_channels=[1, i_channels], size_kernels=[i_kernel_size], zero_mean = False, sn_size=128)
        self.gamma = nn.Parameter(torch.ones(1))
               
    # f(x)+g(Dx)+12 ||x - zref||^2
    # xn -> x
    # un -> u
    # p1n -> x
    # p2n -> u
    def forward(self, xn, un, zref, nu, bLast = False):

        gamma = F.softplus(self.gamma)


        v1n = xn + gamma *(xn - zref + self.convD.transpose(un))
        p1n = torch.clamp(v1n, min = 0) #/(1.0+gamma)
        v2n = un + gamma * (self.convD(xn) )
        p2n = self.N_nu*nu*F.hardtanh(v2n/(self.N_nu*nu + 1e-6))
        q2n = p2n + gamma*(self.convD(p1n))
        q1n = p1n - gamma*(p1n-zref+self.convD.transpose(p2n))
        theta = 0.5 
        
        xn_1 = theta*(xn - v1n + q1n)+(1-theta)*xn
        un_1 = theta*(un - v2n + q2n) + (1-theta)*un
        if bLast:
            v1n = xn_1 + gamma *(xn_1 - zref + self.convD.transpose(un_1))
            pfin = torch.clamp(v1n, min = 0)
            return xn_1, un_1, p1n, pfin
        else:
            return xn_1, un_1, p1n

#################################################
        

class CP_block_relax_multiscale(torch.nn.Module):
    def __init__(self, 
                 N_nu,
                 i_channels, 
                 i_kernel_size, 
                 N_rep = 1
                 ):
        super(CP_block_relax_multiscale, self).__init__()
        

        self.N_nu = N_nu 
        list_channels = [1, i_channels]
        list_kernel_size = [i_kernel_size, i_kernel_size]
      
        self.convD = B.UnmatchedMultiScaleConv3d(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = False, sn_size=128)
        # self.theta = nn.Parameter(torch.ones(1))
               
    # f(x)+g(Dx)+12 ||x - zref||^
    # xn -> x
    # un -> u
    # p1n -> x
    # p2n -> u
    def forward(self, xn, un, zref, nu, bLast = False):

        gamma, epsilon = self.convD.step_CP()

        # print("gamma", gamma.item(), "epsilon", epsilon)

        v1n = xn + gamma *(xn - zref + self.convD.transpose(un))
        p1n = torch.clamp(v1n, min = 0) #/(1.0+gamma)
        v2n = un + gamma * (self.convD(xn) + epsilon * un)
        p2n = self.N_nu*nu*F.hardtanh(v2n/(self.N_nu*nu + 1e-6))
        q2n = p2n + gamma*(self.convD(p1n)+epsilon*p2n)
        q1n = p1n - gamma*(p1n-zref+self.convD.transpose(p2n))
        theta = 0.5 #F.relu(self.theta)
        # print("theta", theta)
        xn_1 = theta*(xn - v1n + q1n)+(1-theta)*xn
        un_1 = theta*(un - v2n + q2n) + (1-theta)*un
        if bLast:
            v1n = xn_1 + gamma *(xn_1 - zref + self.convD.transpose(un_1))
            pfin = torch.clamp(v1n, min = 0)
            return xn_1, un_1, p1n, pfin
        else:
            return xn_1, un_1, p1n


#################################################
class RFDN(nn.Module):
    def __init__(self, in_nc=3, nf=50, num_modules=4, out_nc=3, upscale=4, bias = True):
        super(RFDN, self).__init__()
        # nf div par upsacle^2
        self.norm_IN = nn.InstanceNorm3d(in_nc, affine=True)
        self.fea_conv = C.conv_layer(in_nc, nf, kernel_size=3, bias = bias)
        self.B1 = C.RFDB(in_channels=nf, bias=bias)
        self.B2 = C.RFDB(in_channels=nf, bias=bias)
        self.c = C.conv_block(nf * 2, nf, kernel_size=1, act_type='lrelu', bias = bias)

        self.LR_conv = C.conv_layer(nf, nf, kernel_size=3, bias = bias)

        upsample_block = C.pixelshuffle_block
        self.upsampler = upsample_block(nf, out_nc, upscale_factor=upscale, bias=bias)
        self.scale_idx = 0


    def forward(self, input):
        out_fea = self.fea_conv(self.norm_IN(input))
        out_B1 = self.B1(out_fea)
        out_B2 = self.B2(out_B1)
        out_B = self.c(torch.cat([out_B1, out_B2], dim=1))
        out_lr = self.LR_conv(out_B) + out_fea
        up = self.upsampler(out_lr)
        output = torch.clamp(F.sigmoid(up), min=1e-6)

        return output
    

# class RFDN(nn.Module):
#     def __init__(self, in_nc=3, nf=50, num_modules=4, out_nc=3, upscale=4, bias = True):
#         super(RFDN, self).__init__()
#         # nf div par upsacle^2
#         self.norm_IN = nn.InstanceNorm3d(in_nc, affine=True)
#         self.fea_conv = C.conv_layer(in_nc, nf, kernel_size=3, bias = bias)
#         self.norm_IN2 = nn.InstanceNorm3d(nf, affine=True)
#         self.B1 = C.RFDB(in_channels=nf, bias=bias)
#         self.B2 = C.RFDB(in_channels=nf, bias=bias)
#         self.B3 = C.RFDB(in_channels=nf, bias=bias)
#         self.B4 = C.RFDB(in_channels=nf, bias=bias)
#         self.c = C.conv_block(nf * 4, nf, kernel_size=1, act_type='lrelu', bias = bias)

#         self.LR_conv = C.conv_layer(nf, nf, kernel_size=3, bias = bias)

#         upsample_block = C.pixelshuffle_block
#         self.upsampler = upsample_block(nf, out_nc, upscale_factor=upscale, bias=bias)
#         self.scale_idx = 0


#     def forward(self, input):
#         out_fea = self.fea_conv(self.norm_IN(input))
#         out_B1 = self.B1(self.norm_IN2(out_fea))
#         out_B2 = self.B2(self.norm_IN2(out_B1))
#         out_B3 = self.B3(self.norm_IN2(out_B2))
#         out_B4 = self.B4(self.norm_IN2(out_B3))
#         out_B = self.c(torch.cat([out_B1, out_B2, out_B3, out_B4], dim=1))
#         out_lr = self.LR_conv(out_B) + out_fea
#         up = self.upsampler(out_lr)
#         output = torch.clamp(F.sigmoid(up), min=1e-6)

#         return output
    
class CPnet(torch.nn.Module):
    def __init__(self, 
                 N_rho, 
                 N_nu,
                 i_channels, 
                 i_kernel_size, 
                 i_num_iter, 
                 b_shareD = False, 
                 b_inertia = True, 
                 b_fista = False,
                 b_transpose = False,
                 N_rep = 1, 
                 b_multiscale = False,
                 b_NN = True
                 ):
        super(CPnet, self).__init__()
        
        self.N_rho = N_rho
        self.N_nu = N_nu
        self.i_channels = i_channels
        self.i_kernel_size = i_kernel_size
        self.i_num_iter = i_num_iter
        # self.b_shareD = b_shareD
        # self.b_transpose = b_transpose

        self.Layers   = nn.ModuleList()
        self.nu = nn.Parameter(torch.ones(1))
        self.b_NN = b_NN
        if self.b_NN:
            self.NN = RFDN(in_nc=1, nf=4, num_modules=1, out_nc=i_channels, upscale=1, bias=False)

        # if self.b_shareD:
        #     self.convD = B.MultiConv3d(num_channels=[1, i_channels], size_kernels=[i_kernel_size], zero_mean = False, sn_size=128, C)
        #     #nn.Parameter(torch.Tensor(i_channels, 1, i_kernel_size, i_kernel_size, i_kernel_size).cuda())
        #     if not self.b_transpose:
        #         self.convDt = B.MultiConv3d(num_channels=[1, i_channels], size_kernels=[i_kernel_size], zero_mean = False, sn_size=128)
        #         #nn.Parameter(torch.Tensor(1, i_channels, i_kernel_size, i_kernel_size, i_kernel_size).cuda())
        #     else:
        #         self.convDt = None
        for _ in range(self.i_num_iter):  
            if b_multiscale: 
                self.Layers.append(CP_block_relax_multiscale(N_nu, i_channels, i_kernel_size))  
            else :
                self.Layers.append(CP_block_relax_unit(N_nu, i_channels, i_kernel_size, N_rep=N_rep))    
            # if self.b_shareD:
            #     self.Layers.append(DiFB_block_shareD(N_rho, N_nu, i_kernel_size, b_inertia))
            # else :
            #     self.Layers.append(DiFB_block(N_rho, N_nu, i_channels, i_kernel_size, b_inertia, b_transpose))
    def reg_map(self, zref) :
        return self.NN(zref) 
          
    def forward(self,x0, u0, zref, mask, nu, b_training = False):
        uk = torch.zeros(x0.shape[0], self.i_channels, x0.shape[2], x0.shape[3], x0.shape[4], device=x0.device)
        xk = torch.zeros(x0.shape[0], 1, x0.shape[2], x0.shape[3], x0.shape[4], device=x0.device)
        vec_x = torch.zeros(x0.shape[0], self.i_num_iter, x0.shape[2], x0.shape[3], x0.shape[4], device=x0.device)
        # if self.b_shareD and self.b_transpose:
        #     _ = self.convD.spectral_norm(mode="Fourier", n_steps=100)
        if self.b_NN : 
            reg_map = self.NN(zref)*nu # ref = EM, x0 = noisy
        else :
            reg_map = nu
        for k in range(self.i_num_iter):
           
            if k < self.i_num_iter-1:
                xk, uk, p1n  = self.Layers[k](xk, uk, x0, reg_map*F.softplus(self.nu))
            else:
                xk, uk, p1n, pfin  = self.Layers[k](xk, uk, x0, reg_map*F.softplus(self.nu), bLast = True) 
            if k > 0:
                if mask is not None:
                    p1n = p1n*mask
                vec_x[:,k-1,:,:,:] = p1n.squeeze()
        if mask is not None:
            pfin = pfin*mask
            vec_x[:,self.i_num_iter-1,:,:,:] = pfin.squeeze()
    
        return pfin, vec_x, vec_x