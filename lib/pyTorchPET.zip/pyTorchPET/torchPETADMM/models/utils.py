import sys
import torch
import torch.nn.functional as F
import math
class SigmoidStraightThrough(torch.autograd.Function):

    @staticmethod
    def forward(ctx, u):
        return torch.sigmoid(u)

    @staticmethod
    def backward(ctx, dx):
        return dx


def sigmoid_straight_through(u):
    return SigmoidStraightThrough.apply(u)



class BinarizeStraightThrough(torch.autograd.Function):

    @staticmethod
    def forward(ctx, input):
        return (input > 0.0).float()

    @staticmethod
    def backward(ctx, grad_output):
        return F.hardtanh(grad_output)


def binarize_straight_through(u):
    return BinarizeStraightThrough.apply(u)


class ReLUThrough(torch.autograd.Function):

    @staticmethod
    def forward(ctx, input):
        return F.relu(input)+1e-6

    @staticmethod
    def backward(ctx, dx):
        return dx


def relu_straight_through(u):
    return ReLUThrough.apply(u)



class HardtanhStraightThrough(torch.autograd.Function):

    @staticmethod
    def forward(ctx, input):
        return F.hardtanh(input)

    @staticmethod
    def backward(ctx, grad_output):
        return grad_output


def hardtanh_straight_through(u):
    return HardtanhStraightThrough.apply(u)


class ClampStraightThrough(torch.autograd.Function):

    @staticmethod
    def forward(ctx, input):
        return input.clamp(min=0, max=1)

    @staticmethod
    def backward(ctx, grad_output):
        return grad_output


def clamp_straight_through(u):
    return ClampStraightThrough.apply(u)



def str_to_class(classname):
    return getattr(sys.modules[__name__], classname)


def check_conv(X_prev, X, it, crit_conv="residual", thres_conv=1e-3, verbose=False):
    if crit_conv == "residual":
        if isinstance(X_prev, dict):
            X_prev = X_prev["est"][0]
        if isinstance(X, dict):
            X = X["est"][0]
        crit_cur = (X_prev - X).norm() / (X.norm() + 1e-06)
    elif crit_conv == "cost":
        F_prev = X_prev["cost"]
        F = X["cost"]
        crit_cur = (F_prev - F).norm() / (F.norm() + 1e-06)
    else:
        raise ValueError("convergence criteria not implemented")
    if crit_cur < thres_conv:
        if verbose:
            print(
                f"Iteration {it}, current converge crit. = {crit_cur:.2E}, objective = {thres_conv:.2E} \r"
            )
        return True
    else:
        return False


def conjugate_gradient(A, b, max_iter=1e2, tol=1e-5):
    """
    Standard conjugate gradient algorithm to solve Ax=b
        see: http://en.wikipedia.org/wiki/Conjugate_gradient_method
    :param A: Linear operator as a callable function, has to be square!
    :param b: input tensor
    :param max_iter: maximum number of CG iterations
    :param tol: absolute tolerance for stopping the CG algorithm.
    :return: torch tensor x verifying Ax=b

    """

    def dot(s1, s2):
        return (s1 * s2).flatten().sum()

    x = torch.zeros_like(b)

    r = b
    p = r
    rsold = dot(r, r)

    for i in range(int(max_iter)):
        Ap = A(p)
        alpha = rsold / dot(p, Ap)
        x = x + alpha * p
        r = r - alpha * Ap
        rsnew = dot(r, r)
        # print(rsnew.sqrt())
        if rsnew.sqrt() < tol:
            break
        p = r + (rsnew / rsold) * p
        rsold = rsnew

    return x


def gradient_descent(grad_f, x, step_size=1.0, max_iter=1e2, tol=1e-5):
    """
    Standard gradient descent algorithm to solve min_x f(x)
    :param grad_f: gradient of function to bz minimized as a callable function.
    :param x: input tensor
    :param step_size: (constant) step size of the gradient descent algorithm.
    :param max_iter: maximum number of iterations
    :param tol: absolute tolerance for stopping the algorithm.
    :return: torch tensor x verifying min_x f(x)

    """

    for i in range(int(max_iter)):
        x_prev = x
        x = x - step_size * grad_f(x)
        if check_conv(x_prev, x, i, thres_conv=tol):
            break
    return x



def accelerated_gd_batch(x_noisy, model, sigma=None, ada_restart=False, stop_condition=None, lmbd=1, grad_op=None, **kwargs):
    """compute the proximal operator using the FISTA accelerated rule"""

    max_iter = kwargs.get('max_iter', 500)
    tol = kwargs.get('tol', 1e-4)


    # initial value: noisy image
    x = torch.clone(x_noisy)
    z = torch.clone(x_noisy)
    t = torch.ones(x.shape[0], device=x.device).view(-1,1,1,1,1)

    # print("***** deb scaling *****")
    # cache values of scaling coeff for efficiency
    scaling = model.get_scaling(sigma=sigma)
    # print("***** end scaling *****")

    # print("scaling shape", scaling.shape)

    # # the index of the images that have not converged yet
    idx = torch.arange(0, x.shape[0], device=x.device)
    # relative change in the estimate
    res = torch.ones(x.shape[0], device=x.device, dtype=x.dtype)

    # mean number of iterations over the batch
    i_mean = 0

    for i in range(max_iter):
        # print("i", i)

        model.scaling = scaling[idx]
        
        x_old = torch.clone(x)        

        
        if grad_op is None:
            grad = model.grad_denoising(z[idx], x_noisy[idx], sigma=sigma[idx], cache_wx=False, lmbd=lmbd)
        else:
            grad = grad_op(z[idx])

        x[idx] = z[idx] - grad


        t_old = torch.clone(t)
        t = 0.5 * (1 + torch.sqrt(1 + 4*t**2))
        z[idx] = x[idx] + (t_old[idx] - 1)/t[idx] * (x[idx] - x_old[idx])

        if i > 0:
            res[idx] = torch.norm(x[idx] - x_old[idx], p=2, dim=(-1,-2,-3, -4)) / (torch.norm(x[idx], p=2, dim=(-1,-2,-3, -4)))

       

        if ada_restart:
            esti = torch.sum(grad*(x[idx] - x_old[idx]), dim=(-1,-2,-3, -4))
            id_restart = (esti > 0).nonzero().view(-1)
            t[idx[id_restart]] = 1
            z[idx[id_restart]] = x[idx[id_restart]]


        condition = (res > tol)
        if stop_condition is None:
            idx = condition.nonzero().view(-1)

        i_mean += torch.sum(condition).item() / x.shape[0]

        # if i == max_iter - 1:
        #     print("stop at", i+1, "out of", max_iter, "res", torch.max(res))

        if stop_condition is None:
            if torch.max(res) < tol:
                # print("early stop at", i+1, "out of", max_iter, "tol", tol)
                break
        else:

            sct = stop_condition(x, i)

            if sct:
                # print("early stop at", i+1, "out of", max_iter)
                break


    model.clear_scaling()
    return(x, i, i_mean)
    

def accelerated_gd_single(x_noisy, model, sigma=None, ada_restart=False, stop_condition=None, lmbd=1, grad_op=None, t_init=1, **kwargs):
    """compute the proximal operator using the FISTA accelerated rule"""

    max_iter = kwargs.get('max_iter', 500)
    tol = kwargs.get('tol', 1e-4)

    # initial value: noisy image
    x = torch.clone(x_noisy)
    z = torch.clone(x_noisy)
    t = t_init

    model.clear_scaling()
    model.scaling = model.get_scaling(sigma=sigma)
    # the index of the images that have not converged yet
    # relative change in the estimate
    res = 100000


    for i in range(max_iter):

        
        x_old = torch.clone(x)

        if grad_op is None:
            grad = model.grad_denoising(z, x_noisy, sigma=sigma, cache_wx=False, lmbd=lmbd)
        else:
            grad = grad_op(z)

        x = z - grad



        t_old = t
        t = 0.5 * (1 + math.sqrt(1 + 4*t**2))
        z = x + (t_old - 1)/t * (x - x_old)

        if i > 0:
            res = (torch.norm(x - x_old) / (torch.norm(x))).item()

       


        if ada_restart:
            esti = torch.sum(grad*(x[idx] - x_old[idx]), dim=(-1,-2,-3, -4))
            id_restart = (esti > 0).nonzero().view(-1)
            if len(id_restart) > 0:
                print(i, " restart", len(id_restart))
            t[idx[id_restart]] = 1
            z[idx[id_restart]] = x[idx[id_restart]]


        condition = (res > tol)
        if stop_condition is None:
            idx = condition.nonzero().view(-1)



        if stop_condition is None:
            if torch.max(res) < tol:
                break
        else:

            sct = stop_condition(x, i)

            if sct:
                break


        
    model.clear_scaling()
    return(x, i, t)
    