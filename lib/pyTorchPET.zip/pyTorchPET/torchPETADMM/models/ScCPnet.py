import torch
import torch.nn as nn
import torch.nn.functional as F
from . import basicblock as B


class UnmatchedMultiConv3d(nn.Module):
    """ Convolutional layer with different kernels for conv and conv transpose
    """
    def __init__(self, num_channels=[1, 64], size_kernels=[3], zero_mean=True, sn_size=256):
        super().__init__()
        # parameters and options
        self.size_kernels = size_kernels
        self.num_channels = num_channels
        self.sn_size = sn_size
        self.zero_mean = zero_mean

        
        # list of convolutionnal layers
        self.conv_layers = nn.ModuleList()
        self.transpose_conv_layers = nn.ModuleList()
        
        for j in range(len(num_channels) - 1):
            self.conv_layers.append(nn.Conv3d(in_channels=num_channels[j], out_channels=num_channels[j+1], kernel_size=size_kernels[j], padding=size_kernels[j]//2, stride=1, bias=False, padding_mode='circular'))
            self.transpose_conv_layers.append(nn.Conv3d(in_channels=num_channels[j], out_channels=num_channels[j+1], kernel_size=size_kernels[j], padding=size_kernels[j]//2, stride=1, bias=False, padding_mode='circular'))
        
        self.padding_total = sum([kernel_size//2 for kernel_size in size_kernels])
        self.dirac = torch.zeros((1, 1) + (4 * self.padding_total + 1, 4 * self.padding_total + 1, 4 * self.padding_total + 1))
        self.dirac[0, 0, 2 * self.padding_total, 2 * self.padding_total, 2 * self.padding_total] = 1


    def forward(self, x):
        return(self.convolution(x))

    def convolution(self, x):
        for conv in self.conv_layers:
            weight = conv.weight
            x = nn.functional.conv3d(x, weight, bias=None, dilation=conv.dilation, padding=conv.padding, groups=conv.groups, stride=conv.stride)
        return(x)

    def transpose(self, x):
        for conv in reversed(self.transpose_conv_layers):
            weight = conv.weight
            x = nn.functional.conv_transpose3d(x, weight, bias = None, padding=conv.padding, groups=conv.groups, dilation=conv.dilation, stride=conv.stride)
        return(x)
    


class MultiConv3d(nn.Module):
    """ Convolutional layer with same kernel for conv and conv transpose
    """
    def __init__(self, num_channels=[1, 64], size_kernels=[3], zero_mean=True, sn_size=256):
        
        super().__init__()
        # parameters and options
        self.size_kernels = size_kernels
        self.num_channels = num_channels
        self.sn_size = sn_size
        self.zero_mean = zero_mean
        self.conv_layers = nn.ModuleList()
        
        for j in range(len(num_channels) - 1):
            self.conv_layers.append(nn.Conv3d(in_channels=num_channels[j], out_channels=num_channels[j+1], kernel_size=size_kernels[j], padding=size_kernels[j]//2, stride=1, bias=False, padding_mode='circular'))
           
        # cache the estimation of the spectral norm
        self.L = torch.tensor(1., requires_grad=True)
        # cache dirac impulse used to estimate the spectral norm
        self.padding_total = sum([kernel_size//2 for kernel_size in size_kernels])
        self.dirac = torch.zeros((1, 1) + (4 * self.padding_total + 1, 4 * self.padding_total + 1, 4 * self.padding_total + 1))
        self.dirac[0, 0, 2 * self.padding_total, 2 * self.padding_total, 2 * self.padding_total] = 1


    def forward(self, x):
        return(self.convolution(x))

    def convolution(self, x):
        for conv in self.conv_layers:
            weight = conv.weight
            x = nn.functional.conv3d(x, weight, bias=None, dilation=conv.dilation, padding=conv.padding, groups=conv.groups, stride=conv.stride)

        return(x)

    def transpose(self, x):
        for conv in reversed(self.conv_layers):
            weight = conv.weight
            x = nn.functional.conv_transpose3d(x, weight, bias = None, padding=conv.padding, groups=conv.groups, dilation=conv.dilation, stride=conv.stride)

        return(x)
    
    def spectral_norm(self, mode="Fourier", n_steps=1000):
        """ Compute the spectral norm of the convolutional layer
                Args:
                    mode: "Fourier" or "power_method"
                        - "Fourier" computes the spectral norm by computing the DFT of the equivalent convolutional kernel. This is only an estimate (boundary effects are not taken into account) but it is differentiable and fast
                        - "power_method" computes the spectral norm by power iteration. This is more accurate and used before testing
                    n_steps: number of steps for the power method
        """

        if mode =="Fourier":
            # temporary set L to 1 to get the spectral norm of the unnormalized filter
            self.L = torch.tensor([1.], device=self.conv_layers[0].weight.device)
            # get the convolutional kernel corresponding to WtW
            kernel = self.get_kernel_WtW()
            # pad the kernel and compute its DFT. The spectral norm of WtW is the maximum of the absolute value of the DFT
            padding = (self.sn_size - 1) // 2 - self.padding_total
            self.L = torch.fft.fftn(torch.nn.functional.pad(kernel, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()
            return(self.L)
        
        elif mode == "power_method":
            self.L = torch.tensor([1.], device=self.conv_layers[0].weight.device)
            u = torch.empty((1, 1, self.sn_size, self.sn_size, self.sn_size), device= self.conv_layers[0].weight.device).normal_()
            with torch.no_grad():
                for _ in range(n_steps):
                    u = self.transpose(self.convolution(u))
                    u = u / torch.linalg.norm(u)

                
                # The largest eigen value can now be estimated in a differentiable way
                sn = torch.linalg.norm(self.transpose(self.convolution(u)))
                self.L = sn
                return sn


    def spectrum(self):
        kernel = self.get_kernel_WtW()
        padding = (self.sn_size - 1) // 2 - self.padding_total
        return(torch.fft.fftn(torch.nn.functional.pad(kernel, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)))
    
    def get_filters(self):
        # we collapse the convolutions to get one kernel per channel
        # this done by computing the response of a dirac impulse
        self.dirac = self.dirac.to(self.conv_layers[0].weight.device)
        kernel = self.convolution(self.dirac)[:,:,self.padding_total:3*self.padding_total+1, self.padding_total:3*self.padding_total+1, self.padding_total:3*self.padding_total+1]
        return(kernel)


    def get_kernel_WtW(self):
        self.dirac = self.dirac.to(self.conv_layers[0].weight.device)
        return(self.transpose(self.convolution(self.dirac)))
       


class ScCP_block(torch.nn.Module):
    """Unit block of the ScCPnet: performs one iteration of the chambolle pock algorithm in the strongly convex case
    Args:
        N_nu: regularization strength scaling factor  
        i_channels: number of channels of the convolutional layers
        i_kernel_size: size of the convolutional kernels
        b_transpose: if True, matched convolution kernels are used for each layer
    """
    def __init__(self, 
                 N_nu,
                 i_channels, 
                 i_kernel_size, 
                 N_rep = 1,
                 b_transpose = False,
                 N_prox =1
                 ):
        super(ScCP_block, self).__init__()
        
        self.N_nu = N_nu
        self.b_transpose = b_transpose  
        self.list_nu = []
        for _ in range(N_prox):
            self.list_nu.append(nn.Parameter(torch.ones(1)))

        list_channels = [1]
        list_kernel_size = []
        for _ in range(N_rep):
            list_channels.append(i_channels)
            list_kernel_size.append(i_kernel_size)
        
        if b_transpose:
            self.convD = B.MultiConv3d(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = False, sn_size=128) 

            # self.convD = MultiConv3d(num_channels=[1, i_channels], size_kernels=[i_kernel_size], zero_mean = False, sn_size=128) 
            self.mu = nn.Parameter(torch.ones(1))  
        else :
            self.convD = UnmatchedMultiConv3d(num_channels=[1, i_channels], size_kernels=[i_kernel_size], zero_mean = False, sn_size=128) 

        

    def forward(self, xk, uk, zref, nu, mu):
        
        if self.b_transpose:
            
            muk = self.mu
            alphak = 1.0/(1.0+2*muk).sqrt()
            sn = self.convD.spectral_norm(mode="Fourier", n_steps=100)
            tau = 0.99/(sn*muk)
            
        else :
            tau = 1.0
            alphak = 1.0/(1.0+2*mu).sqrt()  
            muk = mu         

        xk_1 = torch.clamp((muk*(zref- self.convD.transpose(uk)) + xk)/(1+muk), min=0, max = None)
        uk_1 = self.N_nu*nu*F.hardtanh((uk+ self.convD((1+alphak)*xk_1 - alphak*xk)*tau)/(self.N_nu*nu+1e-6))

        return xk_1, uk_1, alphak*muk




#################################################

class ScCPnet(torch.nn.Module):
    """ScCPnet: performs the chambolle pock algorithm in the strongly convex case
    Args:
        N_nu: regularization strength scaling factor  
        i_channels: number of channels of the convolutional layers
        i_kernel_size: size of the convolutional kernels
        i_num_iter: number of iterations of the algorithm = number of layers of the network
        b_transpose: if True, matched convolution kernels are used for each layer
    Outputs:
        xk: final reconstruction
        vec_x: intermediate reconstructions at each iteration (to be used for the loss)
    """

    def __init__(self, 
                 N_nu,
                 i_channels, 
                 i_kernel_size, 
                 i_num_iter, 
                 b_transpose = False
                 ):
        super(ScCPnet, self).__init__()
        
        self.N_nu = N_nu
        self.i_channels = i_channels
        self.i_kernel_size = i_kernel_size
        self.i_num_iter = i_num_iter
        self.b_transpose = b_transpose

        self.Layers   = nn.ModuleList()
        self.nu = nn.Parameter(torch.ones(1))

        if self.b_transpose :
            self.mu = 1.0
        else :
            self.mu = nn.Parameter(torch.ones(1))
            

        for _ in range(self.i_num_iter):        
           self.Layers.append(ScCP_block(N_nu, i_channels, i_kernel_size, b_transpose))
                     
    def forward(self, zref, nu):
        vk = torch.zeros(zref.shape[0], self.i_channels, zref.shape[2], zref.shape[3], zref.shape[4], device=zref.device)
        uk = torch.zeros(zref.shape[0], 1, zref.shape[2], zref.shape[3], zref.shape[4], device=zref.device)
        vec_x = torch.zeros(zref.shape[0], self.i_num_iter, zref.shape[2], zref.shape[3], zref.shape[4], device=zref.device)
        muk = self.mu 
        for k in range(self.i_num_iter):
            xk, uk, muk = self.Layers[k](vk, uk, zref, nu*F.softplus(self.nu), muk)
            vec_x[:,k,:,:,:] = xk.squeeze()
      
        return xk, vec_x