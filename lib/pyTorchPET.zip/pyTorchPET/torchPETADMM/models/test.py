# import torch as th
# import torch.nn as nn    
# import torch.nn.functional as F
# import numpy as np
# from scipy.stats import norm
# import numpy.matlib as mtlb
# from .conv_utils import *
# from .conv_kernels import *

# ##################################################### NON TRAINABLE ##################################################### NON TRAINABLE 
# # NON Trainable Convolutional layers 
# ##################################################### NON TRAINABLE ##################################################### NON TRAINABLE 

# class GenericConvolution(nn.Module):
#     def __init__(self, kernel, input_channels, stride=1, padding=1, dilation=1, requires_grad=False):
#         """
#         for 1D kernel size must be Nfilters x Support
#         for 2D kernel size must be Nfilters x Support_dim0 x Support_dim1
#         for 3D kernel size must be Nfilters x Support_dim0 x Support_dim1 x Support_dim2
#         """
#         super(GenericConvolution, self).__init__()
#         self.convfun = conv_funs[len(kernel.shape)-1]
#         kernel = kernel.unsqueeze(1).float()
#         kernel = th.cat([kernel]*input_channels, axis=0)
#         # THIS IS SO IMPORTANT ....
#         self.kernel_tensor = th.nn.Parameter(kernel)
#         self.kernel_tensor.requires_grad = requires_grad
#         self.input_channels = input_channels
#         self.dilation, self.stride, self.padding = dilation, stride, padding
        
#     def forward(self, x):
#         x = self.convfun(x, self.kernel_tensor, groups=int(self.input_channels), 
#                          stride=self.stride, padding=self.padding, dilation=self.dilation)
#         return x

# class Laplacian(nn.Module):
    
#     def __init__(self, input_channels, sigma=1, mode='3d', sign=-1):
#         super(Laplacian, self).__init__()
#         if mode == '3d':
#             lap = sign*th.from_numpy(kernels3D['Laplacian'](1)).unsqueeze(0)
#         if mode == '2d':
#             lap = sign*th.from_numpy(kernels2D['Laplacian'](1)).unsqueeze(0)
#         self.L = GenericConvolution(lap, input_channels)
        
#     def forward(self, x):
#         return self.L(x)

# class Kurvature3D(th.nn.Module):
    
#     def __init__(self):
#         super(Kurvature3D, self).__init__()
#         self.grad_fwd = Gradient3D(1,method='+')
#         self.Dx3D_bwd = Dx3D(1,method='-')
#         self.Dy3D_bwd = Dy3D(1,method='-')
#         self.Dz3D_bwd = Dz3D(1,method='-')
                
#     def forward(self,u):
#         grad_u = self.grad_fwd(u)
#         norm_grad_u  =  F.normalize(grad_u, dim=1, p=2)
#         dxdx = self.Dx3D_bwd(norm_grad_u[:,0:1,...])
#         dydy = self.Dy3D_bwd(norm_grad_u[:,1:2,...])
#         dzdz = self.Dz3D_bwd(norm_grad_u[:,2:3,...])
#         divergence = dxdx + dydy + dzdz
#         return divergence
    
# class Dx3D(nn.Module):
#     def __init__(self, input_channels,  method='0'):
#         super(Dx3D, self).__init__()
#         if method == '0':
#             dx = kernels3D['dx0']() 
#             self.padx = nn.ReplicationPad3d(list(reversed([1,1,0,0,0,0])))
#         if method == '+':
#             dx = kernels3D['dx+-']() 
#             self.padx = nn.ReplicationPad3d(list(reversed([1,0,0,0,0,0])))
#         if method == '-':
#             dx = kernels3D['dx+-']() 
#             self.padx = nn.ReplicationPad3d(list(reversed([0,1,0,0,0,0])))
#         self.conv_dx = NonTrainableConv(dx, input_channels, padding=0)
        
#     def forward(self,x):
#         dx = self.conv_dx(self.padx(x))
#         return dx
    
# class Dy3D(nn.Module):
#     def __init__(self, input_channels,  method='0'):        
#         super(Dy3D, self).__init__()
#         if method == '0':
#             dy = kernels3D['dy0']()
#             self.pady = nn.ReplicationPad3d(list(reversed([0,0,1,1,0,0])))
#         if method == '+':
#             dy = kernels3D['dy+-']()
#             self.pady = nn.ReplicationPad3d(list(reversed([0,0,1,0,0,0])))
#         if method == '-':
#             dy = kernels3D['dy+-']()
#             self.pady = nn.ReplicationPad3d(list(reversed([0,0,0,1,0,0])))
#         self.conv_dy = NonTrainableConv(dy, input_channels, padding=0)
        
#     def forward(self,x):
#         dy = self.conv_dy(self.pady(x))
#         return dy
    
# class Dz3D(nn.Module):
#     def __init__(self, input_channels,  method='0'):        
#         super(Dz3D, self).__init__()
#         if method == '0':
#             dz = kernels3D['dz0']()
#             self.padz = nn.ReplicationPad3d(list(reversed([0,0,0,0,1,1])))
#         if method == '+':
#             dz = kernels3D['dz+-']()
#             self.padz = nn.ReplicationPad3d(list(reversed([0,0,0,0,1,0])))
#         if method == '-':
#             dz = kernels3D['dz+-']()
#             self.padz = nn.ReplicationPad3d(list(reversed([0,0,0,0,0,1])))
#         self.conv_dz = NonTrainableConv(dz, input_channels, padding=0)
        
#     def forward(self,x):
#         dz = self.conv_dz(self.padz(x))
#         return dz
    
# class Gradient3D(nn.Module):
    
#     def __init__(self, input_channels, method='0'):        
#         super(Gradient3D, self).__init__()
#         self.dx = Dx3D(input_channels, method=method)
#         self.dy = Dy3D(input_channels, method=method)
#         self.dz = Dz3D(input_channels, method=method)
        
#     def forward(self,x):
#         dx = self.dx(x)
#         dy = self.dy(x)
#         dz = self.dz(x)
#         return th.cat([dx, dy, dz], axis=1)
    
# class Hessian3D(nn.Module):
    
#     def __init__(self, input_channels):
#         super(Hessian3D, self).__init__()
#         self.gradient = Gradient3D(input_channels)
        
#     def forward(self,x):
#         dx, dy, dz = self.gradient(x)
#         dxx = self.gradient.conv_dx(self.gradient.padx(dx))
#         dyy = self.gradient.conv_dy(self.gradient.pady(dy))
#         dzz = self.gradient.conv_dz(self.gradient.padz(dz))
        
#         dxy = self.gradient.conv_dx(self.gradient.padx(dy))
#         dxz = self.gradient.conv_dx(self.gradient.padx(dz))
#         dyz = self.gradient.conv_dz(self.gradient.padz(dy))
#         return dx, dy, dxx, dyy, dxy, dxz, dyz
    
# class Gaussian(nn.Module):
    
#     def __init__(self, sigma, input_channels, mode='3d', density=True):
#         super(Gaussian, self).__init__()
#         if sigma%2 == 0:
#             print('warning: not symmetric, fallback to sigma - 1')
#             sigma -= 1
#         if mode == '3d':
#             kernel = kernels3D['Gxyz'](sigma)
#             if not density: kernel /= kernel.max()
#             else: kernel /= kernel.sum()
#             self.pad = nn.ReplicationPad3d(list(reversed([sigma,sigma,sigma,sigma,sigma,sigma])))
#             self.conv_G = NonTrainableConv(kernel, input_channels, padding=0)
#         else:
#             kernel = kernels2D['Gxy'](sigma)
#             if not density: kernel /= kernel.max()
#             else: kernel /= kernel.sum()
#             self.pad = nn.ReplicationPad2d(list(reversed([sigma,sigma,sigma,sigma])))
#             self.conv_G = NonTrainableConv(kernel, input_channels, padding=0)
            
#     def forward(self,x):
#         out = self.conv_G(self.pad(x))
#         return out

# class NonTrainableConv(nn.Module):
#     """
#     Non trainable convolution
#     """
#     def __init__(self, kernel, input_channels, stride=1, padding=1, dilation=1):
#         super(NonTrainableConv, self).__init__()
#         self.convfun = conv_funs[len(kernel.shape)]
#         kernel = kernel[np.newaxis,np.newaxis]
#         kernel = np.concatenate([kernel]*input_channels, axis=0)
#         # THIS IS SO IMPORTANT ....
#         self.kernel_tensor = th.nn.Parameter(th.from_numpy(kernel).float())
#         self.kernel_tensor.requires_grad = False
#         self.input_channels = input_channels
#         self.dilation, self.stride, self.padding = dilation, stride, padding
        
#     def forward(self, x):
#         x = self.convfun(x, self.kernel_tensor, groups=int(self.input_channels), 
#                          stride=self.stride, padding=self.padding, dilation=self.dilation)
#         return x
    
# ##################################################### MISC ##################################################### MISC 
# # Functions MISC
# ##################################################### MISC ##################################################### MISC 

# class EmbeddingCat(nn.Module):
#     def __init__(self):
#         super(EmbeddingCat, self).__init__()
        
#     def forward(self, emb_x):
#         emb,x = emb_x
#         batch_size_x, feature_x = x.shape[:2]
#         spatial_dims_x = x.shape[2:]
#         batch_size_emb, feature_emb = emb.shape[:2]
#         len_shape_x = len(x.shape)
#         len_shape_emb = len(emb.shape)
#         for i in range(len_shape_x-len_shape_emb): emb = emb[...,np.newaxis]
#         assert batch_size_emb == batch_size_x
#         emb = emb.expand([ batch_size_emb, feature_emb, *spatial_dims_x ])
#         return th.cat([emb, x], dim=1) 

# class Normalize(th.nn.Module):
#     def __init__(self, mean, std):
#         super(Normalize, self).__init__()
#         self.mean = mean
#         self.std2 = std**2
                     
#     def forward(self, x):
#         return (x - self.mean)/self.std2
    
# class Wl(nn.Module):
#     """Implementation of https://arxiv.org/pdf/1812.00572.pdf U is set to 1"""
#     def __init__(self, input_channels, output_channels, wl=0.5, ww=1.0, eps=1e-3):
#         super(Wl, self).__init__()
#         self._op0 = nn.Conv3d(input_channels, output_channels, kernel_size=1, groups=input_channels)
#         self._op0.weight.data.fill_(1)
#         self._op0.weight.data.mul_( (2./ww) * np.log(1./eps - 1.) ) # log_e(x)
#         self._op0.bias.data.fill_(1)
#         self._op0.bias.data.mul_( ((-2.*wl)/ww) * np.log(1./eps - 1.) ) # log_e(x)
#         self._op0.requires_grad = False
#         self.act = th.nn.Sigmoid()
        
#     def forward(self,x):
#         return self.act(self._op0(x))

# ##################################################### TRAINABLE ##################################################### TRAINABLE 
# # Trainable Convolutional layers 
# ##################################################### TRAINABLE ##################################################### TRAINABLE 
    
# class MultiNNWl(nn.Module):
    
#     def __init__(self, input_channels, wls=[0.5], wws=[1.0], eps=1e-3):
#         super(MultiNNWl, self).__init__()
#         self.nnwl = []
#         for wl,ww in zip(wls,wws):
#             self.nnwl += [NNWl(input_channels, input_channels, wl=wl, ww=ww, eps=eps)]
            
#     def forward(self,x):
#         xwl = th.cat([ l(x) for l in self.nnwl ], axis=1)
#         return xwl
    
    
# class NNWl(nn.Module):
#     """Implementation of https://arxiv.org/pdf/1812.00572.pdf U is set to 1"""
#     def __init__(self, input_channels, output_channels, wl=0.5, ww=1.0, eps=1e-3):
#         super(NNWl, self).__init__()
#         self._op0 = nn.Conv3d(input_channels, output_channels, kernel_size=1, groups=input_channels)
#         self._op0.weight.data.fill_(1)
#         self._op0.weight.data.mul_( (2./ww) * np.log(1./eps - 1.) ) # log_e(x)
#         self._op0.bias.data.fill_(1)
#         self._op0.bias.data.mul_( ((-2.*wl)/ww) * np.log(1./eps - 1.) ) # log_e(x)
#         self.act = th.nn.Sigmoid()
        
#     def forward(self,x):
#         return self.act(self._op0(x))

# class NNHist(nn.Module):
#     def __init__(self, K, B, dims=3, reduce='mean', keep_dims=True, min_xk=-1, max_xk=1):
#         """Implementation of learnable histograms https://arxiv.org/abs/1804.09398.
#         args:
#             K: number of feature channel in input.
#             B: number of bins for the histogram.
#             reduce: reduce features via average (normalized histogram)
#         forward:
#             outputs feature bins are NOT reduced (average, sum).
#         """
#         super(NNHist, self).__init__()
#         conv_fun = [ nn.Conv1d, nn.Conv2d, nn.Conv3d ][dims-1]
#         self.mu = conv_fun(K,B*K, kernel_size=1, groups=K, bias=True)
#         bin_width = (max_xk - min_xk)/(B-1)
#         mu_data = min_xk + th.range(0,B-1)*bin_width 
#         self.mu.bias.data = - mu_data.repeat(K)
#         self.mu.weight.data.fill_(1)
#         self.mu.weight.requires_grad = False
#         self.w = conv_fun(B*K,B*K, kernel_size=1, groups=B*K, bias=False)
#         self.w.weight.data.fill_(1)
#         self.w.weight.data.mul_(1/float(bin_width))
#         self.act = nn.ReLU(inplace=True)
#         self.reduce = reduce
#         self.dims = dims
#         self.keep_dims = keep_dims
        
#     def freeze(self):
#         self.mu.requires_grad = False
#         self.w.requires_grad = False
        
#     def forward(self,x):
#         a = self.act(1 - self.w(th.abs(self.mu(x))))
#         if self.reduce == 'mean': 
#             dim_list = list(range(-self.dims,0))
#             a = a.mean(dim_list, self.keep_dims)
#         if self.reduce == 'sum': 
#             dim_list = list(range(-self.dims,0))
#             a = a.sum(dim_list, self.keep_dims)
#         return a
    
#     def clamp_after_update(self):
#         """
#         can be called after update to avoid negative bins
#         """
#         self.w.data.clamp_(1e-8)
    
# class Upsample(nn.Module):
#     def __init__(self, size=None, scale_factor=None, mode='nearest', align_corners=False):
#         super(Upsample, self).__init__()
#         self.align_corners = align_corners
#         self.mode = mode
#         self.scale_factor = scale_factor
#         self.size = size

#     def forward(self, x):
#         return nn.functional.interpolate(x, size=self.size, scale_factor=self.scale_factor, mode=self.mode,
#                                          align_corners=self.align_corners)
    
# class MaxPooling(nn.Module):
    
#     def __init__(self, down_scale=2, kernel_size=2, mode='3d'):
#         super(MaxPooling, self).__init__()
#         assert mode != '1d', "MaxPooling 1d not yet available."
#         if mode=='2d':
#             self.down = nn.MaxPool2d(kernel_size=kernel_size, stride=down_scale)
#         if mode=='3d':
#             self.down = nn.MaxPool3d(kernel_size=kernel_size, stride=down_scale)
        
#     def forward(self, x):
#         return self.down(x)
    
# class UpConv(nn.Module):
#     """
#     Implementing generic upsampling strategy
#     Parameters:
#     up_scale: int
#         as a result spatial dimensions of the output will be scaled by up_scale.
#     """
#     def __init__(self, in_channels, out_channels,
#                  kernel_size=3, dilation=1, groups=1, up_scale=2, bias=True, mode='3d'):
#         super(UpConv, self).__init__()
#         padding_in = compute_upconv_input_padding(2,4,up_scale,1,2*up_scale,output_padding=0)
#         conv_type = nn.ConvTranspose3d if mode == '3d' else nn.ConvTranspose2d
#         assert mode != '1d', "UpConv 1d not yet available."
#         self.up = conv_type(in_channels, out_channels, kernel_size=2*up_scale, dilation=dilation,
#                             stride=up_scale, padding=padding_in)
            
#     def forward(self, x):
#         x = self.up(x)
#         return x
    
# class Conv(nn.Module):
#     """
#     Wrapping Conv with advanced padding options.
#     args:
#         in_channels, out_channels, kernel_size, dilation, 
#         groups, stride, bias: look at torch.nn.Conv3d
#         padding: string {same, valid} same: input and output have the same shape, 
#                                       valid: no zero padding.
#     """

#     def __init__(self, in_channels, out_channels, kernel_size=3, dilation=1, groups=1, bias=True,
#                  stride=1, padding='same', mode='3d'):
#         super(Conv, self).__init__()
#         if mode == '1d': conv_type = nn.Conv1d
#         if mode == '2d': conv_type = nn.Conv2d
#         if mode == '3d': conv_type = nn.Conv3d
#         self.layer = conv_type(in_channels, out_channels, kernel_size, stride=stride, 
#                                padding=0, dilation=dilation, groups=groups, bias=bias)
#         self.stride, self.dilation, self.padding, self.kernel_size = stride, dilation, padding, kernel_size

#     def forward(self, x):
#         input_shape = list(x.shape)[2:]
#         pad_func, output_padding = conv_padding_func(self.padding, input_shape, 
#                                                      self.kernel_size, self.dilation, self.stride)
#         return self.layer(pad_func(x))
    
# class DistanceBasedConv(Conv):
#     """
#     Distance based layer (orientation invariant)
#     """
#     def __init__(self, in_channels, out_channels, kernel_size=3, dilation=1, groups=1, bias=True,
#                  stride=1, padding='same', mode='3d'):
#         super(DistanceBasedConv, self).__init__(in_channels, out_channels, kernel_size=kernel_size, dilation=dilation, groups=1, bias=bias,
#                                                 stride=stride, padding=padding, mode=mode)
#         assert mode == '3d', "DistanceBasedConv 2d,1d not yet available."
#         c = kernel_size//2
#         parameter_reference = {}
#         for i in range(kernel_size):
#             for j in range(kernel_size):
#                 for k in range(kernel_size):
#                     ic,jc,kc = i-c, j-c, k-c 
#                     dc = (ic**2 + jc**2 + kc**2)
#                     if dc in parameter_reference.keys():
#                         self.layer.weight.data[:,:,i,j,k] = parameter_reference[dc]
#                     else:
#                         parameter_reference[dc] = self.layer.weight.data[:,:,i,j,k]
                        
# class VariationalConv(Conv):
#     """
#     Variational layer for CVAE (Convolutiona Variational Autoencoders)
#     """
#     def __init__(self, in_channels, out_channels, kernel_size=3, dilation=1, groups=1, bias=True,
#                  stride=1, padding='same', mode='3d'):
#         super(VariationalConv, self).__init__(in_channels, 2*out_channels, kernel_size=kernel_size, dilation=dilation, groups=groups, bias=bias,
#                                                 stride=stride, padding=padding, mode=mode)
#         self.out_channels = out_channels
                         
#     def forward(self, x):
#         a = super(VariationalConv, self).forward(x)
#         mu = a[:,:self.out_channels,...]
#         logvar = a[:,self.out_channels:,...]
#         z = self._reparameterize(mu, logvar)
#         return z, mu, logvar
        
#     def predict(self,x):
#         return self.forward(x)[1]
        
#     def _reparameterize(self, mu, logvar):
#         """ parametrization trick """
#         std = logvar.mul(0.5).exp_()
#         esp = th.randn(*mu.size()).type_as(mu)
#         z = mu + std * esp
#         return z
    
# class ResBlock(nn.Module):
#     """
   
#     """
#     def __init__(self, in_channels, out_channels, conv_type=Conv,
#                  kernel_size=3, stride=1, dilation=1, groups_in=1, groups_out=1, init_depth=0, 
#                  bias=True, mode='3d', additional_convs=3,
#                  padding='same', activation=nn.LeakyReLU(inplace=True)):
#         super(ResBlock, self).__init__()
        
#         # activation   
#         self.act = activation
#         self.conv_0 = conv_type(in_channels, out_channels, kernel_size, stride=stride, padding=padding, 
#                                  dilation=dilation, groups=groups_in, bias=bias, mode=mode)
#         self.conv_1 = conv_type(out_channels, out_channels, kernel_size, stride=stride, padding=padding, 
#                                  dilation=dilation, groups=groups_in, bias=bias, mode=mode)
#         self.conv_2 = conv_type(out_channels, out_channels, kernel_size, stride=stride, padding=padding, 
#                                  dilation=dilation, groups=groups_in, bias=bias, mode=mode)
        
#         self.bn_1  = nn.BatchNorm3d(out_channels) if mode =='3d' else nn.BatchNorm2d(out_channels)
#         self.bn_2  = nn.BatchNorm3d(out_channels) if mode =='3d' else nn.BatchNorm2d(out_channels)
        
#     def forward(self,x):
#         x = self.act(self.conv_0(x))
#         x = self.act(self.bn_1(self.conv_1(x)+x))
#         x = self.act(self.bn_2(self.conv_2(x)+x))
#         return x
    
# class ResBlock2(th.nn.Module):
    
#     def __init__(self, input_channels, output_channels, batch_norm=True, activation=th.nn.ReLU(inplace=True), dropout=False):
#         super().__init__()
#         self.conv1 = th.nn.Conv3d(input_channels, output_channels, kernel_size=3, padding=1)
#         self.conv2 = th.nn.Conv3d(output_channels, output_channels, kernel_size=3, padding=1)
#         self.batch_norm = th.nn.BatchNorm3d(output_channels) if batch_norm else None
#         self.dropout = th.nn.Dropout(output_channels) if dropout else None
#         self.act = activation
        
#     def batch_and_drop(self,x):
#         x = self.batch_norm(x) if self.batch_norm else x
#         x = self.dropout(x) if self.dropout else x
#         return x
        
#     def forward(self,x):
#         x = self.conv1(x)
#         x = self.batch_and_drop(x)
#         x = self.act(x)
#         x_res = self.conv2(x)
#         x = self.batch_norm(x_res) if self.batch_norm else x_res
#         x = self.dropout(x) if self.dropout else x
#         x = self.act(x + x_res)
#         return x
            
# class ConvBlock(nn.Module):
#     """
#     ConvBlock3D is the main building block of a convolutional neural network, it is parametrized to cover
#     most use cases for conv nets like resblocks and batch norm.
#     It mainly consists of a series of convolutions each followed by an activation function.
        
#     the first convolution transforms:
#         R^in_channels->R^out_channels
#     the num_blocks - 1 following convolutions transforms: 
#         R^out_channels->R^out_channels.
    
#     Parametrizations:
#     - residual and batch_norm are unset:
#     >---|conv_0|act|---...---|conv_i|act|---...---|conv_{num_blocks-1}|act|--->
                                
#     - residual is unset and batch_norm is set:
#     >---|conv_0|act|---...---|conv_{num_blocks-1}|act|---|batch_norm|--->
    
#     - residual is set and batch_norm is unset:
#     >---|conv_0|act|---...---|conv_i|act|---...---|conv_{num_blocks-1}|act|-(+)->
#                     |__...__________________...______________________________| 
           
#     - residual and batch_norm are set:
#     >---|conv_0|act|---...---|conv_i|act|---...---|conv_{num_blocks-1}|act|-(+)-|batch_norm|--->
#                     |__...__________________...______________________________| 
#     Attributes:
#     act: nn.Module 
#         activation funtion.
#     initial_conv: nn.Conv3D
#         corresponds to conv_0.
#     convs: nn.ModuleList
#         list of convolutions layers.
#     bns: nn.ModuleList
#         list of batch norm layers.
        
#     Parameters:
#     num_convs: int
#         number of convolution in this block
#     in_channels: int
#         number of input channels in this block
#     out_channels: int
#         number of output channels in this block
#     kernel_size: {int, tuple of int}
#         size of convolution kernel.
#     stride:  {int, tuple of int}
#         sampling step of convolution function, each convolution is computed each stride pixels.
#     dilatation:  {int, tuple of int}
#         implement atrous convolution, a trick to have bigger support and sparse kernels.
#     groups_in: int
#         depth wise convolution of conv 0
#     groups_out: int
#         depth wise convolution of conv 1,...,num_convs-1
#     depth_initialization: int
#         use fixup initialization starting at depth depth_initialization.
#     bias: bool
#         use bias in conv.
#     residual: bool
#         use residual scheme.
#     batch_norm: bool
#         use batch norm residual scheme.
#     padding: string 
#         {'same','valid'} padding schemes.
#     activation: nn.Module
#         activation to be used.
#     """
#     def __init__(self,  in_channels, out_channels, num_convs=3, conv_type=Conv,
#                  kernel_size=3, stride=1, dilation=1, groups_in=1, groups_out=1, init_depth=0, 
#                  bias=True, residual=True, batch_norm=True, mode='3d',
#                  padding='same', activation=nn.LeakyReLU(inplace=True)):
#         super(ConvBlock, self).__init__()
        
#         # activation   
#         self.act = activation
        
#         # conv input_channels -> output_channels
#         self.initial_conv = conv_type(in_channels, out_channels, kernel_size, stride=stride, padding=padding, 
#                                  dilation=dilation, groups=groups_in, bias=bias, mode=mode)
#         # convs output_channels -> output_channels 
#         self.convs = nn.ModuleList([conv_type(out_channels, out_channels, kernel_size, stride=stride, padding=padding, 
#                                          dilation=dilation, groups=groups_out, bias=bias, mode=mode)] * (num_convs - 1))
        
#         # depth fixup initialization arXiv:1901.09321v2
#         if init_depth>0:
#             self.initial_conv.apply(depth_scale_weights(init_depth))
#             for i,conv in enumerate(self.convs): conv.apply(zero_weights())
        
#         # batch normalization
#         # bn output_channels * (num_blocks-1)
#         if batch_norm: 
#             self.bn  = nn.BatchNorm3d(out_channels) if mode =='3d' else nn.BatchNorm2d(out_channels)
        
#         # instruction prefetch
#         self.pre_forward = self.vanilla_forward
#         self.pre_forward = self.residual_forward if residual else self.pre_forward
#         self.pre_forward = self.batch_norm_forward if batch_norm else self.pre_forward
#         self.pre_forward = self.residual_batch_norm_forward if residual and batch_norm else self.pre_forward
        
#     def batch_norm_forward(self,x):
#         x = self.vanilla_forward(x)
#         return self.bn(x)
        
#     def residual_batch_norm_forward(self,x):
#         x = self.residual_forward(x)
#         return self.bn(x)

#     def residual_forward(self, x):
#         identity_x = x
#         for conv in self.convs: x = self.act(conv(x))
#         x, identity_x = cropAndMatch(x,identity_x)
#         return x + identity_x

#     def vanilla_forward(self, x):
#         for conv in self.convs: x = self.act(conv(x))
#         return x

#     def forward(self, x):
#         x = self.act(self.initial_conv(x))
#         return self.pre_forward(x)
    
# class ExpThrsConv(th.nn.Module):
#     """Implementation of https://arxiv.org/pdf/1812.00572.pdf U is set to 1"""
    
#     def __init__(self, wc, ww, input_channels=1, normalize=False, trainable=False):
#         th.nn.Module.__init__(self)
#         if type(wc) is not list:
#             wc = [wc]
#             ww = [ww]
#         assert len(wc) == len(ww), "must have same num of wc and ww"
#         output_channels = len(wc)            
#         self._op0 = th.nn.Conv3d(input_channels, output_channels, kernel_size=1, groups=input_channels)
        
#         for idx, (wc_i, ww_i) in enumerate(zip(wc, ww)):
#             min_w_i = wc_i - ww_i/2.
#             max_w_i = wc_i + ww_i/2. 
#             self._op0.weight.data[idx,...].fill_(1./ww_i)
#             self._op0.bias.data[idx,...].fill_(-(wc_i/ww_i))
        
#         if not trainable: 
#             self._op0.requires_grad = False
            
#         self.normalize = normalize
        
#     def forward(self,x):
#         op0 = self._op0
#         thrs = th.exp(-(op0(x)**2)) 
#         if not self.normalize:
#             return x * thrs
#         return thrs

# class WindowLevelConv(th.nn.Module):
#     """Implementation of https://arxiv.org/pdf/1812.00572.pdf U is set to 1"""
    
#     def __init__(self, wc, ww, input_channels=1, normalize=False, trainable=False):
#         th.nn.Module.__init__(self)
#         if type(wc) is not list:
#             wc = [wc]
#             ww = [ww]
#         assert len(wc) == len(ww), "must have same num of wc and ww"
#         output_channels = len(wc)
            
#         self._op0 = th.nn.Conv3d(input_channels, output_channels, kernel_size=1, groups=input_channels)
#         self._op1 = th.nn.Conv3d(output_channels, output_channels, kernel_size=1, groups=output_channels)
    
#         for idx, (wc_i, ww_i) in enumerate(zip(wc, ww)):
#             min_w_i = wc_i - ww_i/2.
#             max_w_i = wc_i + ww_i/2. 
#             self._op0.weight.data[idx,...].fill_(1)
#             self._op0.bias.data[idx,...].fill_(- (min_w_i))
#             self._op1.weight.data[idx,...].fill_(1)
#             self._op1.bias.data[idx,...].fill_(min_w_i - max_w_i)
        
#         if not trainable: 
#             self._op0.requires_grad = False
#             self._op1.requires_grad = False
#         self.relu = th.nn.ReLU(inplace=True)
        
#     def forward(self,x):
#         relu = self.relu
#         op0 = self._op0
#         op1 = self._op1
#         x = op0(x) # x = x - min_ww
#         x = relu(x)
#         x = op1(x) # x + (min_ww - max_ww)
#         x = -relu(-x)
#         return x
# ```