"""
Created on March 2023

@author: florent.sureau
"""

import os
import numpy as np
import torch 

#DnCNN: no skip connection
class dnCNN_noskip(torch.nn.Module):
    def __init__(self, depth=17, n_channels=64, image_channels=1):
        super(d1, self).__init__()
        self.depth=_depth
        self.n_channels=n_channels
        kernel_size=3
        padding = 1
        layers = []

        layers.append(torch.nn.Conv3d(in_channels=image_channels, out_channels=n_channels, kernel_size=kernel_size, padding=padding, bias=True))
        layers.append(torch.nn.ReLU(inplace=True))
        for _ in range(depth-2):
            layers.append(torch.nn.Conv3d(in_channels=n_channels, out_channels=n_channels, kernel_size=kernel_size, padding=padding, bias=False))
            layers.append(torch.nn.BatchNorm3d(n_channels, eps=0.0001, momentum = 0.95))
            layers.append(torch.nn.ReLU(inplace=True))
        layers.append(torch.nn.Conv3d(in_channels=n_channels, out_channels=image_channels, kernel_size=kernel_size, padding=padding, bias=False))
        self.dncnn = torch.nn.Sequential(*layers)

    def get_name(self):
        return self._get_name()+f"_depth{self.depth}_n_channels{self.n_channels}"

    def forward(self, x):
        out = self.dncnn(x)
        return out

#DnCNN: skip connection
class dnCNN_skip(torch.nn.Module):
    def __init__(self, depth=17, n_channels=64, image_channels=1):
        super(d2, self).__init__()
        self.depth=_depth
        self.n_channels=n_channels
        kernel_size=3
        padding = 1
        layers = []

        layers.append(torch.nn.Conv3d(in_channels=image_channels, out_channels=n_channels, kernel_size=kernel_size, padding=padding, bias=True))
        layers.append(torch.nn.ReLU(inplace=True))
        for _ in range(depth-2):
            layers.append(torch.nn.Conv3d(in_channels=n_channels, out_channels=n_channels, kernel_size=kernel_size, padding=padding, bias=False))
            layers.append(torch.nn.BatchNorm3d(n_channels, eps=0.0001, momentum = 0.95))
            layers.append(torch.nn.ReLU(inplace=True))
        layers.append(torch.nn.Conv3d(in_channels=n_channels, out_channels=image_channels, kernel_size=kernel_size, padding=padding, bias=False))
        self.dncnn = torch.nn.Sequential(*layers)

    def get_name(self):
        return self._get_name()+f"_depth{self.depth}_n_channels{self.n_channels}"

    def forward(self, x):
        out = self.dncnn(x)
        return torch.add(out, x)
