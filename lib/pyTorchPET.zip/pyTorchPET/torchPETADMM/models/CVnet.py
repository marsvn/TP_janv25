from collections import OrderedDict
import torch
import torch.nn as nn
import torch.nn.functional as F
from . import basicblock as B
import torch.autograd as autograd

def projball_linf(y, tau):
    # print(y.max(), y.min(), tau)
    return torch.clamp(y, min=-tau, max=tau)

def Prox_1(u,sigma):
    return torch.mul(torch.sign(u),F.relu(torch.abs(u)-sigma))

def Prox_inf_2(u,sigma):
    return u/(1e-6+torch.clamp(torch.sqrt(torch.sum(torch.mul(u,u),1,True))/sigma,1))

def conv_layer(in_channels, out_channels, kernel_size, stride=1, dilation=1, groups=1, bias = True):
    padding = int((kernel_size - 1) / 2) * dilation
    return B.init_weights_conv(nn.Conv3d(in_channels, out_channels, kernel_size, stride, padding=padding,  dilation=dilation,
                     groups=groups, bias = bias), 'kaiming')



def pad(pad_type, padding):
    pad_type = pad_type.lower()
    if padding == 0:
        return None
    if pad_type == 'reflect':
        layer = nn.ReflectionPad3d(padding)
    elif pad_type == 'replicate':
        layer = nn.ReplicationPad3d(padding)
    else:
        raise NotImplementedError('padding layer [{:s}] is not implemented'.format(pad_type))
    return layer


def get_valid_padding(kernel_size, dilation):
    kernel_size = kernel_size + (kernel_size - 1) * (dilation - 1)
    padding = (kernel_size - 1) // 2
    return padding


def conv_block(in_nc, out_nc, kernel_size, stride=1, dilation=1, groups=1, bias=True,
               pad_type='zero', norm_type=None, act_type='relu'):
    padding = get_valid_padding(kernel_size, dilation)
    p = pad(pad_type, padding) if pad_type and pad_type != 'zero' else None
    padding = padding if pad_type == 'zero' else 0

    c = nn.Conv3d(in_nc, out_nc, kernel_size=kernel_size, stride=stride, padding=padding,
                  dilation=dilation, bias=bias, groups=groups)
    a = activation(act_type) if act_type else None
    n = None
    return sequential(p, c, n, a)


def activation(act_type, inplace=True, neg_slope=0.05, n_prelu=1):
    act_type = act_type.lower()
    if act_type == 'relu':
        layer = nn.ReLU(inplace)
    elif act_type == 'lrelu':
        layer = nn.LeakyReLU(neg_slope, inplace)
    elif act_type == 'prelu':
        layer = nn.PReLU(num_parameters=n_prelu, init=neg_slope)
    else:
        raise NotImplementedError('activation layer [{:s}] is not found'.format(act_type))
    return layer


class ShortcutBlock(nn.Module):
    def __init__(self, submodule):
        super(ShortcutBlock, self).__init__()
        self.sub = submodule

    def forward(self, x):
        output = x + self.sub(x)
        return output

def mean_channels(F):
    assert(F.dim() == 4)
    spatial_sum = F.sum(3, keepdim=True).sum(2, keepdim=True)
    return spatial_sum / (F.size(2) * F.size(3))

def stdv_channels(F):
    assert(F.dim() == 4)
    F_mean = mean_channels(F)
    F_variance = (F - F_mean).pow(2).sum(3, keepdim=True).sum(2, keepdim=True) / (F.size(2) * F.size(3))
    return F_variance.pow(0.5)

def sequential(*args):
    if len(args) == 1:
        if isinstance(args[0], OrderedDict):
            raise NotImplementedError('sequential does not support OrderedDict input.')
        return args[0]
    modules = []
    for module in args:
        if isinstance(module, nn.Sequential):
            for submodule in module.children():
                modules.append(submodule)
        elif isinstance(module, nn.Module):
            modules.append(module)
    return nn.Sequential(*modules)

class ESA(nn.Module):
    def __init__(self, n_feats, conv, bias = True):
        super(ESA, self).__init__()
        f = n_feats // 4
        self.conv1 = conv(n_feats, f, kernel_size=1, bias = bias)
        self.conv_f = conv(f, f, kernel_size=1, bias=bias)
        self.conv_max = conv(f, f, kernel_size=3, padding=1, bias=bias)
        self.conv2 = conv(f, f, kernel_size=3, stride=2, padding=0, bias=bias)
        self.conv3 = conv(f, f, kernel_size=3, padding=1, bias=bias)
        self.conv3_ = conv(f, f, kernel_size=3, padding=1, bias=bias)
        self.conv4 = conv(f, n_feats, kernel_size=1, bias=bias)
        self.sigmoid = nn.Sigmoid()
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        c1_ = (self.conv1(x))
        c1 = self.conv2(c1_)
        v_max = F.max_pool3d(c1, kernel_size=7, stride=3)
        v_range = self.relu(self.conv_max(v_max))
        c3 = self.relu(self.conv3(v_range))
        c3 = self.conv3_(c3)
        c3 = F.interpolate(c3, (x.size(2), x.size(3), x.size(4)), mode='trilinear', align_corners=False) 
        cf = self.conv_f(c1_)
        c4 = self.conv4(c3+cf)
        m = self.sigmoid(c4)
        
        return m


class RFDB(nn.Module):
    def __init__(self, in_channels, distillation_rate=0.25, bias = True):
        super(RFDB, self).__init__()
        self.dc = self.distilled_channels = in_channels//2
        self.rc = self.remaining_channels = in_channels
        self.c1_d = conv_layer(in_channels, self.dc, 1, bias=bias)
        self.c1_r = conv_layer(in_channels, self.rc, 3, bias=bias)
        self.c2_d = conv_layer(self.remaining_channels, self.dc, 1, bias=bias)
        self.c2_r = conv_layer(self.remaining_channels, self.rc, 3, bias=bias)
        self.c3_d = conv_layer(self.remaining_channels, self.dc, 1, bias=bias)
        self.c3_r = conv_layer(self.remaining_channels, self.rc, 3, bias=bias)
        self.c4 = conv_layer(self.remaining_channels, self.dc, 3, bias=bias)
        self.act = activation('lrelu', neg_slope=0.05)
        self.c5 = conv_layer(self.dc*4, in_channels, 1, bias=bias)
        self.esa = ESA(in_channels, nn.Conv3d, bias=bias)

    def forward(self, input):
        distilled_c1 = self.act(self.c1_d(input))
        r_c1 = (self.c1_r(input))
        r_c1 = self.act(r_c1+input)

        distilled_c2 = self.act(self.c2_d(r_c1))
        r_c2 = (self.c2_r(r_c1))
        r_c2 = self.act(r_c2+r_c1)

        distilled_c3 = self.act(self.c3_d(r_c2))
        r_c3 = (self.c3_r(r_c2))
        r_c3 = self.act(r_c3+r_c2)

        r_c4 = self.act(self.c4(r_c3))

        out = torch.cat([distilled_c1, distilled_c2, distilled_c3, r_c4], dim=1)
        out_fused = self.esa(self.c5(out)) 
        return out_fused


class PixelShuffle3d(nn.Module):
    '''
    This class is a 3d version of pixelshuffle.
    '''
    def __init__(self, scale):
        '''
        :param scale: upsample scale
        '''
        super().__init__()
        self.scale = scale

    def forward(self, input):
        batch_size, channels, in_depth, in_height, in_width = input.size()
        # print("input", input.shape)
        # print("scale", self.scale)
        nOut = channels // self.scale ** 3
        # print("nOUT", nOut)

        out_depth = in_depth * self.scale
        out_height = in_height * self.scale
        out_width = in_width * self.scale

        input_view = input.contiguous().view(batch_size, nOut, self.scale, self.scale, self.scale, in_depth, in_height, in_width)

        output = input_view.permute(0, 1, 5, 2, 6, 3, 7, 4).contiguous()

        return output.view(batch_size, nOut, out_depth, out_height, out_width)


def pixelshuffle_block(in_channels, out_channels, upscale_factor=2, kernel_size=3, stride=1, bias = True):
    conv = conv_layer(in_channels, out_channels * (upscale_factor ** 3), kernel_size, stride, bias=bias)
    pixel_shuffle = PixelShuffle3d(upscale_factor)
    return sequential(conv, pixel_shuffle)



class RFDN(nn.Module):
    def __init__(self, in_nc=3, nf=50, num_modules=4, out_nc=3, upscale=4, bias = True):
        super(RFDN, self).__init__()
        # nf div par upsacle^2
        self.norm_IN = nn.InstanceNorm3d(in_nc, affine=True)
        self.fea_conv = conv_layer(in_nc, nf, kernel_size=3, bias = bias)
        self.norm_IN2 = nn.InstanceNorm3d(nf, affine=True)
        self.norm_IN3 = nn.InstanceNorm3d(out_nc, affine=True)
        self.B1 = RFDB(in_channels=nf, bias=bias)
        self.B2 = RFDB(in_channels=nf, bias=bias)
        # self.B3 = RFDB(in_channels=nf)
        # self.B4 = RFDB(in_channels=nf)
        self.c = conv_block(nf * 2, nf, kernel_size=1, act_type='lrelu', bias = bias)

        self.LR_conv = conv_layer(nf, nf, kernel_size=3, bias = bias)

        upsample_block = pixelshuffle_block
        self.upsampler = upsample_block(nf, out_nc, upscale_factor=upscale, bias=bias)
        self.scale_idx = 0


    def forward(self, input):
        out_fea = self.fea_conv(self.norm_IN(input))
        out_B1 = self.B1(self.norm_IN2(out_fea))
        out_B2 = self.B2(self.norm_IN2(out_B1))
        # out_B3 = self.B3(out_B2)
        # out_B4 = self.B4(out_B3)

        # out_B = self.c(out_B2)
        out_B = self.c(torch.cat([out_B1, out_B2], dim=1))
        out_lr = self.LR_conv(out_B) + out_fea
        # print("out_lr", out_lr.shape)
        up = self.upsampler(out_lr)
        output = torch.clamp(F.sigmoid(self.norm_IN3(up)), min=1e-6)
        # print("output", output.shape)

        return output
    

class RFDN(nn.Module):
    def __init__(self, in_nc=3, nf=50, num_modules=4, out_nc=3, upscale=4, bias = True):
        super(RFDN, self).__init__()
        # nf div par upsacle^2
        self.norm_IN = nn.InstanceNorm3d(in_nc, affine=True)
        self.fea_conv = conv_layer(in_nc, nf, kernel_size=3, bias = bias)
        self.norm_IN2 = nn.InstanceNorm3d(nf, affine=True)
        self.norm_IN3 = nn.InstanceNorm3d(out_nc, affine=True)
        self.B1 = RFDB(in_channels=nf, bias=bias)
        self.B2 = RFDB(in_channels=nf, bias=bias)
        self.B3 = RFDB(in_channels=nf, bias=bias)
        # self.B4 = RFDB(in_channels=nf, bias=bias)
        self.c = conv_block(nf * 3, nf, kernel_size=1, act_type='lrelu', bias = bias)

        self.LR_conv = conv_layer(nf, nf, kernel_size=3, bias = bias)

        upsample_block = pixelshuffle_block
        self.upsampler = upsample_block(nf, out_nc, upscale_factor=upscale, bias=bias)
        self.scale_idx = 0


    def forward(self, input):
        out_fea = self.fea_conv(self.norm_IN(input))
        out_B1 = self.B1(self.norm_IN2(out_fea))
        out_B2 = self.B2(self.norm_IN2(out_B1))
        out_B3 = self.B3(self.norm_IN2(out_B2))
        # out_B4 = self.B4(self.norm_IN2(out_B3))

        # out_B = self.c(out_B2)
        out_B = self.c(torch.cat([out_B1, out_B2, out_B3], dim=1))
        out_lr = self.LR_conv(out_B) + out_fea
        # print("out_lr", out_lr.shape)
        up = self.upsampler(out_lr)
        output = torch.clamp(F.sigmoid(self.norm_IN3(up)), min=1e-6)
        # print("output", output.shape)

        return output
    
    # def forward(self, input):
    #     out_fea = self.fea_conv(self.norm_IN(input))
    #     out_B1 = self.B1(out_fea)
    #     out_B2 = self.B2(out_B1)
    #     # out_B3 = self.B3(out_B2)
    #     # out_B4 = self.B4(out_B3)

    #     # out_B = self.c(out_B2)
    #     out_B = self.c(torch.cat([out_B1, out_B2], dim=1))
    #     out_lr = self.LR_conv(out_B) + out_fea
    #     # print("out_lr", out_lr.shape)
    #     up = self.upsampler(out_lr)
    #     # output =F.sigmoid(up)

    #     output = torch.clamp(F.sigmoid(up), min=1e-3)

    #     return output

    def set_scale(self, scale_idx):
        self.scale_idx = scale_idx



#################################################

class CV_block(torch.nn.Module):
    def __init__(self, 
                 N_nu,
                 i_channels, 
                 i_kernel_size, 
                 ):
        super(CV_block, self).__init__()
        

        self.N_nu = N_nu   
            
        self.convD = B.MultiConv3d(num_channels=[1, i_channels], size_kernels=[i_kernel_size], zero_mean = False, sn_size=128)
        self.convQ = B.UnmatchedMultiConv3d(num_channels=[1, i_channels], size_kernels=[i_kernel_size], zero_mean = False, sn_size=128) 
        self.theta = nn.Parameter(torch.zeros(1)) 
  

    def forward(self, xn, un, zref, nu, quad, mask):
        # tau * sigma ||D||^2 < 1
        
        eta = self.convQ.step_CV()
        sn = self.convD.spectral_norm(mode="Fourier", n_steps=100)

        print("eta", eta, "sn", sn)

        sigma = 0.1
        tau = 0.99/(sn*sigma + 0.5/eta)
        delta = 2-(1/(2*eta))*(1/tau - sigma*sn) # theta <= delta 

        print("delta", delta, "sigma", sigma, "tau", tau)

        xn_12 = (xn - tau*(self.convQ.transpose(self.convQ(xn))+self.convD.transpose(un)) + quad*tau*zref)/(1.0+quad*tau)
        xn_12 = mask*xn_12.clamp(min=0)        
        un_12 = self.N_nu*nu*F.hardtanh((un+ sigma*self.convD(2*xn_12 - xn )/(self.N_nu*nu+1e-6)))
        theta = F.sigmoid(100*self.theta)*delta
        xn_1 = xn + theta*(xn_12-xn)
        un_1 = un + theta*(un_12-un)
        return xn_1, un_1


################

class CV_block_mat(torch.nn.Module):
    def __init__(self, 
                 N_nu,
                 i_channels, 
                 i_kernel_size, 
                 i_FNE,
                 N_rep = 1 
                 ):
        super(CV_block_mat, self).__init__()
        

        self.N_nu = N_nu      
        self.i_FNE = i_FNE 
        list_channels = [1]
        list_kernel_size = []
        for _ in range(N_rep):
            list_channels.append(i_channels)
            list_kernel_size.append(i_kernel_size)
        self.convD = B.MultiConv3d(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = False, sn_size=128)
        if not self.i_FNE:
            self.theta = nn.Parameter(torch.zeros(1)) 
        self.sigma = nn.Parameter(torch.zeros(1))
  

    def forward(self, xn, un, zref, nu, mask):
        # tau * sigma ||D||^2 < 1
        sn = self.convD.spectral_norm(mode="Fourier", n_steps=100)
        sigma = F.softplus(self.sigma)
        B = 0.5
        tau = 0.99/(sn*sigma + B)
        delta = 1.0 #2-B/(1.0/tau - sigma*sn) # theta <= delta 
        # print("delta", delta.item(), "sigma", sigma.item(), "tau", tau.item())


        xn_12 = xn - tau*(self.convD.transpose(un) + (xn-zref))
                 
        xn_12 = mask*xn_12.clamp(min=0)        
        # print("scale",(self.N_nu*nu+1e-6), un.max(), (sigma*self.convD(2*xn_12 - xn )).max())
        un_12 = self.N_nu*nu*F.hardtanh((un+ sigma*self.convD(2*xn_12 - xn ))/(self.N_nu*nu+1e-6))
        if self.i_FNE:
            theta = 0.5*delta
        else:
            
            theta = F.sigmoid(5.0*self.theta)*delta
        print("delta", delta, "theta", theta.item(), "tau", tau.item())

        xn_1 = xn + theta*(xn_12-xn)
        un_1 = un + theta*(un_12-un)
        return xn_1, un_1
    

#######################################################"
    

class CV_block_l2(torch.nn.Module):
    def __init__(self, 
                 N_nu,
                 i_channels, 
                 i_kernel_size, 
                 i_FNE,
                 N_rep = 1 
                 ):
        super(CV_block_l2, self).__init__()
        

        self.N_nu = N_nu      
        self.i_FNE = i_FNE 
        list_channels = [1]
        list_kernel_size = []
        for _ in range(N_rep):
            list_channels.append(i_channels)
            list_kernel_size.append(i_kernel_size)
        self.convD = B.MultiConv3d(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = False, sn_size=128)
        # if not self.i_FNE:
        #     self.theta = nn.Parameter(torch.zeros(1)) 
        self.sigma = nn.Parameter(torch.zeros(1))
  

    def forward(self, xn, un, zref, nu, mask):
        # tau * sigma ||D||^2 < 1
        sigma = F.softplus(self.sigma)
        # sn = self.convD.shifted_spectral_norm(mode="power_method", n_steps=100, shift = 1.0, scale = sigma)
        # sn_PM = self.convD.shifted_spectral_norm(mode="power_method", n_steps=1000, shift = 1.0, scale = sigma)
        
        sn = self.convD.spectral_norm(mode="Fourier", n_steps=100)+1

        # sn_PM = self.convD.spectral_norm(mode="power_method", n_steps=1000)
        # print("sn", sn.item(), "sn_PM", sn_PM.item())
        # sn2 = 1.0+sigma*sn
        # print("sn", sn.item())

        #tau = 0.99/(0.5+sigma*sn) # no 1.669
        # delta = 2-0.5/(1.0/tau - sigma*sn) # theta <= delta 

        t1 = 0.8*0.99/(sn*sigma) # no 2.75
        t2 = 0.8*1.0/(1.0+sigma*sn)
        tau = min(t1, t2) #t2 smallest
        delta = 2.0  
        
        
        # sigma = 0.99/(sn*tau) # + B)
        
        # print("delta", delta.item(), "sigma", sigma.item(), "tau", tau.item())


        xn_12 = xn - tau*(self.convD.transpose(un) + (xn-zref))
                 
        # xn_12 = mask*xn_12.clamp(min=0)        
        # print("scale",(self.N_nu*nu+1e-6), un.max(), (sigma*self.convD(2*xn_12 - xn )).max())
        un_12 = projball_linf(un+ sigma*self.convD(2*xn_12 - xn ), self.N_nu*nu)
        if self.i_FNE:
            # theta = 0.5*delta
            theta = 0.5 #delta
        else:
            
            theta = 0.9*delta #1.0+F.sigmoid(5.0*self.theta)*delta "delta", delta, 
        print("theta", theta, "tau", tau.item(), "sn", sn.item(), "sigma", sigma.item())
        # self.convD.check_tranpose()

        xn_1 = xn + theta*(xn_12-xn)
        un_1 = un + theta*(un_12-un)
        return xn_1, un_1


#################################################
    
class CV_simple(torch.nn.Module):
    def __init__(self, 
                 N_nu,
                 i_channels, 
                 i_kernel_size, 
                 i_FNE,
                 N_rep = 1 
                 ):
        super(CV_simple, self).__init__()
        

        self.N_nu = N_nu      
        self.i_FNE = i_FNE 
        # list_channels = [1]
        # list_kernel_size = []
        # for _ in range(N_rep):
        #     list_channels.append(i_channels)
        #     list_kernel_size.append(i_kernel_size)
        # self.convD = B.MultiConv3d(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = False, sn_size=128)
        # if not self.i_FNE:
        #     self.theta = nn.Parameter(torch.zeros(1)) 
        self.sigma = nn.Parameter(torch.zeros(1))

        Dh = torch.tensor([[[0., 0., 0.],
                        [0., 0., 0.],
                        [0., 0., 0.]],
                        [[0., 0., 0.],
                        [-1, 1., 0.],
                        [0., 0., 0.]],
                        [[0., 0., 0.],
                        [0., 0., 0.],
                        [0., 0., 0.]]]).view(1,1,3,3,3).cuda()
        

        Dp = torch.tensor([[[0., 0., 0.],
                        [0., -1., 0.],
                        [0., 0., 0.]],
                        [[0., 0., 0.],
                        [0., 1., 0.],
                        [0., 0., 0.]],
                        [[0., 0., 0.],
                        [0., 0., 0.],
                        [0., 0., 0.]]]).view(1,1,3,3,3).cuda()
        
        Dv = torch.tensor([[[0., 0., 0.],
                        [0., 0., 0.],
                        [0., 0., 0.]],
                        [[0., -1., 0.],
                        [0., 1., 0.],
                        [0., 0., 0.]],
                        [[0., 0., 0.],
                        [0., 0., 0.],
                        [0., 0., 0.]]]).view(1,1,3,3,3).cuda()
        

        self.D = torch.concatenate([Dh, Dp, Dv], dim=0)
        
        Dh_star = torch.tensor([[[0., 0., 0.],
                            [0., 0., 0.],
                            [0., 0., 0.]],
                            [[0., 0., 0.],
                            [0., 1., -1.],
                            [0., 0., 0.]],
                            [[0., 0., 0.],
                            [0., 0., 0.],
                            [0., 0., 0.]]]).view(1,1,3,3,3).cuda()
            

        Dp_star = torch.tensor([[[0., 0., 0.],
                        [0., 0., 0.],
                        [0., 0., 0.]],
                        [[0., 0., 0.],
                        [0., 1., 0.],
                        [0., 0., 0.]],
                        [[0., 0., 0.],
                        [0., -1., 0.],
                        [0., 0., 0.]]]).view(1,1,3,3,3).cuda()
        
        Dv_star = torch.tensor([[[0., 0., 0.],
                        [0., 0., 0.],
                        [0., 0., 0.]],
                        [[0., 0., 0.],
                        [0., 1., 0.],
                        [0., -1., 0.]],
                        [[0., 0., 0.],
                        [0., 0., 0.],
                        [0., 0., 0.]]]).view(1,1,3,3,3).cuda()
        

        self.D_star = torch.concatenate([Dh_star, Dp_star, Dv_star], dim=1)
  

    def forward(self, xn, un, zref, nu, mask):
        # tau * sigma ||D||^2 < 1
        sn = 12 #self.convD.spectral_norm(mode="Fourier", n_steps=1000)
        sigma = F.softplus(self.sigma)
        # B = 0.5

        # sigma = 0.99/(sn*tau) 
        # delta = 2.0 

        # tau = 0.99/(0.5+sigma*sn)
        # delta = 2-0.5/(1.0/tau - sigma*sn) # theta <= delta 

        t1 = 0.99/(sn*sigma)
        t2 = 1.0/(1.0+sigma*sn)
        tau = min(t1, t2) #t2 smallest
        delta = 2.0  


        # u = torch.ones_like(xn).normal_()
        # with torch.no_grad():
        #     for _ in range(2000):
        #         u = F.conv3d(F.conv3d(u,self.D,padding=1),self.D_star,padding=1)
        #         u = u / torch.linalg.norm(u)

            
        #     # The largest eigen value can now be estimated in a differentiable way
        #     sn = torch.linalg.norm(F.conv3d(F.conv3d(u,self.D,padding=1),self.D_star,padding=1))
        #     sn = torch.ceil(sn)
        # print("spectral norm", sn)


        xn_12 = xn - tau*(F.conv3d(un,self.D_star,padding=1)+ (xn-zref))
                 
        xn_12 = mask*xn_12.clamp(min=0)        
        # print("scale",(self.N_nu*nu+1e-6), un.max(), (sigma*self.convD(2*xn_12 - xn )).max())
        un_12 = projball_linf(un+ sigma*F.conv3d(2*xn_12 - xn,self.D,padding=1), self.N_nu*nu)
        if self.i_FNE:
            # theta = 0.5*delta
            theta = delta
        else:
            
            theta = 0.9*delta #F.sigmoid(5.0*self.theta)*delta
        print("delta", delta, "theta", theta, "tau", tau.item(), "sn", sn, "sigma", sigma.item())

        xn_1 = xn + theta*(xn_12-xn)
        un_1 = un + theta*(un_12-un)
        return xn_1, un_1

#################################################
class CV_block_mat_multiprox_end(torch.nn.Module):
    def __init__(self, 
                 N_nu,
                 i_channels, 
                 i_kernel_size, 
                 i_FNE,
                 N_rep = 1, 
                 bPos = True
                 ):
        super(CV_block_mat_multiprox_end, self).__init__()
        

       
        self.N_nu = N_nu      
        self.i_FNE = i_FNE 
        list_channels = [1]
        list_kernel_size = []
        for _ in range(N_rep):
            list_channels.append(i_channels)
            list_kernel_size.append(i_kernel_size)
        self.convD = B.MultiConv3d(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = False, sn_size=128)
        if not self.i_FNE:
            self.theta = nn.Parameter(torch.zeros(1)) 
        self.tau = nn.Parameter(torch.zeros(1))
        self.bPos = bPos
  

    def forward(self, xn, un, zref, mask):
  
        tau = F.sigmoid(5.0*self.tau)*1.99
        

        xn_12 = xn - tau*(self.convD.transpose(un) + (xn-zref))    
        # if self.bPos:      
        #     xn_12 = mask*xn_12.clamp(min=0)   
        # else :
        #     xn_12 = mask*torch.max(xn_12, -zref)
        
        
        if self.i_FNE:
            theta = 0.5
        else:
            
            theta = F.sigmoid(5.0*self.theta)
        # print("tau", tau.item(), "theta", theta.item() )
        xn_1 = xn + theta*(xn_12-xn)
        return xn_1
    
class CV_block_mat_multiprox(torch.nn.Module):
    def __init__(self, 
                 N_nu,
                 i_channels, 
                 i_kernel_size, 
                 i_FNE,
                 N_rep = 1, 
                 N_prox = 1,
                 bPos = True
                 ):
        super(CV_block_mat_multiprox, self).__init__()
        
        self.N_prox = N_prox
        if N_prox == 1:
            self.list_bias = [0.0]
        else :
            self.list_bias = nn.Parameter(torch.rand(N_prox))
        self.list_scal = nn.Parameter(torch.rand(N_prox))

       
        self.N_nu = N_nu      
        self.i_FNE = i_FNE 
        list_channels = [1]
        list_kernel_size = []
        for _ in range(N_rep):
            list_channels.append(i_channels)
            list_kernel_size.append(i_kernel_size)
        self.convD = B.MultiConv3d(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = False, sn_size=128)
        if not self.i_FNE:
            self.theta = nn.Parameter(torch.zeros(1)) 
        self.sigma = nn.Parameter(torch.zeros(1))
        self.bPos = bPos
  

    def forward(self, xn, un, zref, nu, mask, b_training = True):
        # tau * sigma ||D||^2 < 1
        sn = 1.1*self.convD.spectral_norm(mode="Fourier" if b_training else "power_method", n_steps=200)
        sigma = F.softplus(self.sigma)
        # B = 0.5
        tau = 0.99/(sn*sigma + 0.5)
        delta = 1.0 #2-0.5/(1.0/tau - sigma*sn) # theta <= delta 
        # print("delta", delta.item(), "sigma", sigma.item(), "tau", tau.item())


        xn_12 = xn - tau*(self.convD.transpose(un) + (xn-zref))
        # if self.bPos:
        #     xn_12 = mask*xn_12.clamp(min=0)  
        # else :
        #     xn_12 = mask*torch.max(xn_12, -zref)
        
        
        vn = sigma*self.convD(2*xn_12 - xn )
        # print("max un + vn", (un+ vn).max().item(), (un+ vn).min().item(), "threshold", self.N_nu*nu*F.softplus(self.list_scal[0]).item())
        # un_12 = projball_linf(un+ vn , self.N_nu*nu*F.softplus(self.list_scal[0]))
        un_12 = projball_linf(un+ vn -self.list_bias[0], self.N_nu*nu*F.softplus(self.list_scal[0]))+self.list_bias[0]
        #print( "threshold", self.N_nu*nu*F.softplus(self.list_scal[0 ]).item(), "shift", self.list_bias[0].item())
        for i in range(1,self.N_prox):
            #print( "threshold", self.N_nu*nu*F.softplus(self.list_scal[i ]).item(), "shift", self.list_bias[i].item())

            un_12 += projball_linf(un+ vn-1000*self.list_bias[i], self.N_nu*nu*F.softplus(self.list_scal[i]))+1000*self.list_bias[i]
        un_12 = un_12/self.N_prox

        if self.i_FNE:
            theta = 0.5*delta
        else:
            
            theta = 0.99*F.sigmoid(5.0*self.theta)*delta
        # print( "sigma", sigma.item(), "theta", theta.item(), "tau", tau.item(), un_12.max(), un_12.min())
        # self.convD.check_tranpose()
        xn_1 = xn + theta*(xn_12-xn)
        un_1 = un + theta*(un_12-un)
        # print( "sigma", sigma.item(), "theta", theta, "tau", tau.item())
        # print(un_12.max().item(), un_12.min().item(), un_1.max().item(), un_1.min().item(), xn_12.max().item(), xn_12.min().item(), xn_1.max().item(), xn_1.min().item(),  (0.5*xn_1+0.5*zref).max().item(), (0.5*xn_1+0.5*zref).min().item())
        return xn_1, un_1




#################################################

class CVnet(torch.nn.Module):
    def __init__(self, 
                 N_quad,
                 N_nu,
                 i_channels, 
                 i_kernel_size, 
                 i_num_iter, 
                 i_FNE = False,
                 N_rep = 1,
                 N_prox = 1,
                 bPos = True
                 ):
        super(CVnet, self).__init__()
        
        # self.N_quad = N_quad
        self.N_nu = N_nu
        self.i_channels = i_channels
        self.i_kernel_size = i_kernel_size
        self.i_num_iter = i_num_iter
        self.N_prox = N_prox

  
        self.Layers   = nn.ModuleList()
        self.nu = nn.Parameter(torch.zeros(1))
        # self.quad = nn.Parameter(torch.zeros(1))

      
        for i in range(self.i_num_iter):   
            if  i == self.i_num_iter-1:
                self.Layers.append(CV_block_mat_multiprox_end(N_nu, i_channels, i_kernel_size, i_FNE, N_rep=N_rep, bPos=bPos)) 
            else : # N_prox > 1 :
                self.Layers.append(CV_block_mat_multiprox(N_nu, i_channels, i_kernel_size, i_FNE, N_rep=N_rep, N_prox=N_prox, bPos=bPos)) 
            # else :
            #     self.Layers.append(CV_block_l2(N_nu, i_channels, i_kernel_size, i_FNE, N_rep=N_rep))    
                      
    def forward(self, x0, u0, zref, mask, nu, b_training = False, nbIter = None):
        if u0 is None:
            uk = torch.zeros(zref.shape[0], self.i_channels, zref.shape[2], zref.shape[3], zref.shape[4], device=zref.device)
        else :
            uk = u0 #torch.zeros(zref.shape[0], self.i_channels, zref.shape[2], zref.shape[3], zref.shape[4], device=zref.device)
        xk = x0 #torch.zeros(zref.shape[0], 1, zref.shape[2], zref.shape[3], zref.shape[4], device=zref.device)
        vec_x = torch.zeros(zref.shape[0], self.i_num_iter, zref.shape[2], zref.shape[3], zref.shape[4], device=zref.device)
        vec_u = torch.zeros(zref.shape[0], self.i_num_iter, self.i_channels, zref.shape[2], zref.shape[3], zref.shape[4], device=zref.device)
        if nbIter is not None:
            num_iter = nbIter
        else :
            num_iter = self.i_num_iter
        for k in range(num_iter):
            if k == self.i_num_iter-1 : #and self.N_prox > 1:
                xk = self.Layers[k](xk, uk, zref, mask)
            else :
                xk, uk  = self.Layers[k](xk, uk,  zref, F.softplus(self.nu), mask, b_training=True) #, 1.0) #self.N_quad*F.softplus(self.quad) 
                # if k == 0 :
                #     u1 = uk
                # else :
                #     uk = u1
            
            vec_x[:,k,:,:,:] = xk.squeeze()
            vec_u[:,k,:,:,:,:] = uk
      
        return xk, vec_x , vec_u
    



# class CVnetDEQ(torch.nn.Module):
#     def __init__(self, 
#                  N_nu,
#                  i_channels, 
#                  i_kernel_size, 
#                  N_rep = 1,
#                  N_prox = 1,
#                  bMultiScale = False
#                  ):
#         super(CVnetDEQ, self).__init__()
        
#         self.N_nu = N_nu
#         self.i_channels = i_channels
#         self.i_kernel_size = i_kernel_size
#         self.N_prox = N_prox

  
#         self.Layers   = nn.ModuleList()
#         # self.nu = nn.Parameter(torch.zeros(1))
        
#         if N_prox == 1:
#             self.list_bias = [0.0]
#         else :
#             self.list_bias = nn.Parameter(torch.rand(N_prox))
#         self.list_scal = nn.Parameter(torch.rand(N_prox))

       
#         self.N_nu = N_nu  
#         if bMultiScale :
#             self.convD = B.MultiConvScale3d(num_channels=[1, i_channels], size_kernels=[i_kernel_size, i_kernel_size], zero_mean = False, sn_size=128)

#         else :
#             list_channels = [1]
#             list_kernel_size = []
#             for _ in range(N_rep):
#                 list_channels.append(i_channels)
#                 list_kernel_size.append(i_kernel_size)
#             self.convD = B.MultiConv3d(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = False, sn_size=128)


       
#         self.theta = nn.Parameter(torch.zeros(1)) 
#         self.sigma = nn.Parameter(torch.zeros(1))
  

#     def forward(self, xn, un, zref, nu, mask, b_training = True):
#         # tau * sigma ||D||^2 < 1
#         sn = 1.1*self.convD.spectral_norm(mode="Fourier" if b_training else "power_method", n_steps=200)
#         sigma = F.softplus(self.sigma)
#         tau = 0.99/(sn*sigma + 0.5)
#         delta = 1.0 

#         xn_12 = xn - tau*(self.convD.transpose(un) + (xn-zref))
#         xn_12 = mask*xn_12.clamp(min=0)  
      
        
#         vn = sigma*self.convD(2*xn_12 - xn )
#         un_12 = projball_linf(un+ vn -self.list_bias[0], self.N_nu*nu*F.softplus(self.list_scal[0]))+self.list_bias[0]
#         for i in range(1,self.N_prox):
 
#             un_12 += projball_linf(un+ vn-1000*self.list_bias[i], self.N_nu*nu*F.softplus(self.list_scal[i]))+1000*self.list_bias[i]
#         un_12 = un_12/self.N_prox

#         theta = 0.99*F.sigmoid(5.0*self.theta)*delta

#         xn_1 = xn + theta*(xn_12-xn)
#         un_1 = un + theta*(un_12-un)
#         return xn_1, un_1

#     def loss(self, xn, un, zref, nu, mask):
#         x_convD = self.convD(xn)
       
       
#         return (0.5*torch.norm(xn - zref,2),(x_convD**2).sum())
        
    

    

class CVnetDEQ(torch.nn.Module):
    def __init__(self, 
                 N_nu,
                 i_channels, 
                 i_kernel_size, 
                 N_rep = 1,
                 N_prox = 1,
                 bMultiScale = False,
                 bZeroMean = True
                 ):
        super(CVnetDEQ, self).__init__()
        
        self.N_nu = N_nu
        self.i_channels = i_channels
        self.i_kernel_size = i_kernel_size
        self.N_prox = N_prox

  
        self.Layers   = nn.ModuleList()
        # self.nu = nn.Parameter(torch.zeros(1))
               
        if bMultiScale :
            self.convD = B.MultiConvScale3d(num_channels=[1, i_channels], size_kernels=[i_kernel_size, i_kernel_size], zero_mean = bZeroMean, sn_size=128)

        else :
            list_channels = [1]
            list_kernel_size = []
            for _ in range(N_rep):
                list_channels.append(i_channels)
                list_kernel_size.append(i_kernel_size)
            self.convD = B.MultiConv3d(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = bZeroMean, sn_size=128)


       
        # self.sigma = nn.Parameter(torch.zeros(1))
        # self.nu = nn.Parameter(torch.ones(1))
  

    def forward(self, xn, un, zref, nu, mask, bTrain = True):
        
        # tau * sigma ||D||^2 < 1
        sn = 1.1*self.convD.spectral_norm(mode="Fourier" if bTrain else "power_method", n_steps=200)
        sigma = 0.001 #F.softplus(self.sigma)
        tau = 0.99/(sn*sigma + 0.5)
        delta = 1.0 

        xn_12 = xn - tau*(self.convD.transpose(un) + (xn-zref))
        xn_12 = mask*xn_12.clamp(min=0) 
         
      
        
        vn = sigma*self.convD(2*xn_12 - xn )
        un_12 = projball_linf(un+ vn , self.N_nu*nu)
        

        theta = 0.99*delta
        
        xn_1 = xn + theta*(xn_12-xn)
        un_1 = un + theta*(un_12-un)

        print(xn.min(), xn.max(), (xn_1-xn).min(), (xn_1-xn).max())
        return xn_1, un_1

    def loss(self, xn, un, zref, nu, mask):
        x_convD = self.convD(xn)
       
       
        return (0.5*torch.norm(xn - zref,2),(x_convD**2).sum())
        

#######################################################################


class DFBnetDEQSpatial(torch.nn.Module):
    def __init__(self, 
                 N_nu,
                 i_channels, 
                 i_kernel_size, 
                 N_rep = 1,
                 N_prox = 1,
                 bMultiScale = False,
                 bZeroMean = True,
                 bBias = True, 
                 bHalfZeroMean = False,
                 b_precond = False
                 ):
        super(DFBnetDEQSpatial, self).__init__()
        
        self.N_nu = N_nu
        self.i_channels = i_channels
        self.i_kernel_size = i_kernel_size
        self.N_prox = N_prox
        self.b_precond = b_precond
  
        self.Layers   = nn.ModuleList()
        self.NN = RFDN(in_nc=1, nf=8, num_modules=1, out_nc=i_channels, upscale=1, bias=bBias)
        # self.nu = nn.Parameter(torch.zeros(1))
               
        if bMultiScale :
            self.convD = B.MultiConvScale3d(num_channels=[1, i_channels], size_kernels=[i_kernel_size, i_kernel_size], zero_mean = bZeroMean, sn_size=128)

        else :
            list_channels = [1]
            list_kernel_size = []
            for _ in range(N_rep):
                list_channels.append(i_channels)
                list_kernel_size.append(i_kernel_size)
            self.convD = B.MultiConv3d(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = bZeroMean, half_zero_mean=bHalfZeroMean, sn_size=128)


       
        # self.sigma = nn.Parameter(torch.zeros(1))
        # self.nu = nn.Parameter(torch.ones(1))
  

    def forward(self, xn, un, zref, nu, mask, bTrain = True, xEM = None, precond = None):
        # tau * sigma ||D||^2 < 1
        Lambda_reg = mask*self.reg_weight(xEM)
        sn = 1.1*self.convD.spectral_norm(mode="Fourier" if bTrain else "power_method", n_steps=200)*(Lambda_reg**2).max()
        sigma = 0.001 #F.softplus(self.sigma)
        tau = 0.99/(sn*sigma + 0.5*precond)
        delta = 1.0 
        
        if self.b_precond:
            xn = precond

            xn_12 = xn - tau*(self.convD.transpose(Lambda_reg*un) + precond*(xn-zref))
        else :
            xn_12 = xn - tau*(self.convD.transpose(Lambda_reg*un) + (xn-zref))
        xn_12 = mask*xn_12.clamp(min=0) 
         
      
        
        vn = Lambda_reg*sigma*self.convD(2*xn_12 - xn )
        un_12 = projball_linf(un+ vn , self.N_nu*nu)
        

        theta = 0.99*delta

        xn_1 = xn + theta*(xn_12-xn)
        un_1 = un + theta*(un_12-un)
        return xn_1, un_1

    def loss(self, xn, un, zref, nu, mask):
        x_convD = self.convD(xn)
       
       
        return (0.5*torch.norm(xn - zref,2),(x_convD**2).sum())
    
    def reg_weight(self, zref) :
        return self.NN(zref)
    

class CVnetDEQSpatial(torch.nn.Module):
    def __init__(self, 
                 N_nu,
                 i_channels, 
                 i_kernel_size, 
                 N_rep = 1,
                 N_prox = 1,
                 bMultiScale = False,
                 bZeroMean = True,
                 bBias = True, 
                 bHalfZeroMean = False,
                 b_precond = False
                 ):
        super(CVnetDEQSpatial, self).__init__()
        
        self.N_nu = N_nu/(N_rep*i_channels/8.0)
        self.i_channels = i_channels
        self.i_kernel_size = i_kernel_size
        self.N_prox = N_prox
        self.b_precond = b_precond
  
        self.Layers   = nn.ModuleList()
        self.NN = RFDN(in_nc=1, nf=8, out_nc=i_channels, upscale=1, bias=bBias)
        # self.nu = nn.Parameter(torch.zeros(1))
               
        if bMultiScale :
            self.convD = B.MultiConvScale3d(num_channels=[1, i_channels], size_kernels=[i_kernel_size, i_kernel_size], zero_mean = bZeroMean, sn_size=128)

        else :
            list_channels = [1]
            list_kernel_size = []
            for _ in range(N_rep):
                list_channels.append(i_channels)
                list_kernel_size.append(i_kernel_size)
            self.convD = B.MultiConv3d(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = bZeroMean, half_zero_mean=bHalfZeroMean, sn_size=128)


        self._SN = torch.tensor(-1.)
        # self.sigma = nn.Parameter(torch.zeros(1))
        # self.nu = nn.Parameter(torch.ones(1))
  
    def update_SN(self, bTrain = True):
        self._SN = self.convD.spectral_norm(mode="Fourier" if bTrain else "power_method", n_steps=200)
        # self._SN = self.convD.spectral_norm(mode="power_method", n_steps=200)
        # print("spectral norm", self._SN.item())

    def forward(self, xn, un, zref, nu, mask, bTrain = True, xEM = None, precond = None, bComputeSN = True):
        # tau * sigma ||D||^2 < 1
        Lambda_reg = mask*self.reg_weight(xEM)
        # print("Lambda_reg", Lambda_reg.max().item(), Lambda_reg.min().item())
        
        # sigma = 0.001 #F.softplus(self.sigma)
        delta = 1.0 
        if bComputeSN :
            self.update_SN(bTrain)
        
        if self.b_precond:
            sn = 1.1*(self._SN**2) #*(Lambda_reg.max()**2)
            max_precond = precond.max()
            # tau = 0.99/(sn*sigma + 0.5*max_precond)

            tau = 0.3
            sigma = (0.99-tau*0.5*max_precond)/(tau*sn)
            # if bComputeSN :
            #     print("tau", tau, "sn", sn, "sigma", sigma, "max_precond", max_precond, "sn*sigma", sn*sigma)
            xn_12 = xn - tau*(self.convD.transpose(Lambda_reg*un) + precond*(xn-zref))
            
        else :
            sn = 1.1*self._SN*(Lambda_reg**2).max()
            tau = 0.3
            sigma = (0.99-tau*0.5)/(tau*sn)
            # tau = 0.99/(sn*sigma + 0.5)
            xn_12 = xn - tau*(self.convD.transpose(Lambda_reg*un) + (xn-zref))
        xn_12 = mask*xn_12.clamp(min=0) 
         
      
        
        vn = Lambda_reg*sigma*self.convD(2*xn_12 - xn )
        # print("vn", vn.max().item(), vn.min().item())
        un_12 = projball_linf(un+ vn , self.N_nu*nu.view(-1,1,1,1,1))
        # un_12 = Prox_1(un+ vn , sigma)
        

        theta = 0.99*delta

        xn_1 = xn + theta*(xn_12-xn)
        un_1 = un + theta*(un_12-un)
        # print(xn.min(), xn.max(), (xn_1-xn).min(), (xn_1-xn).max())
        return xn_1, un_1

    def loss(self, xn, zref, nu, mask, xEM=None, precond=None):
        Lambda_reg = mask*self.reg_weight(xEM)
        x_convD = Lambda_reg*self.convD(xn)  
        if self.b_precond:
            data_fit = 0.5*torch.sum(precond*torch.mul(xn-zref,xn-zref))  
        else :
            data_fit = 0.5*torch.sum(torch.mul(xn-zref,xn-zref)) 
       
        return (data_fit,self.N_nu*nu*(x_convD.abs().sum()))
    
    def reg_weight(self, zref) :
        return self.NN(zref)
    



# class CVnetDEQSpatial(torch.nn.Module):
#     def __init__(self, 
#                  N_nu,
#                  i_channels, 
#                  i_kernel_size, 
#                  N_rep = 1,
#                  N_prox = 1,
#                  bMultiScale = False,
#                  bZeroMean = True,
#                  bBias = True
#                  ):
#         super(CVnetDEQSpatial, self).__init__()
        
#         self.N_nu = N_nu
#         self.i_channels = i_channels
#         self.i_kernel_size = i_kernel_size
#         self.N_prox = N_prox
#         self.list_scal = nn.Parameter(torch.randn(self.N_prox))

  
#         self.Layers   = nn.ModuleList()
#         self.NN = RFDN(in_nc=1, nf=8, num_modules=1, out_nc=i_channels, upscale=1, bias=bBias)
#         # self.nu = nn.Parameter(torch.zeros(1))
               
#         if bMultiScale :
#             self.convD = B.MultiConvScale3d(num_channels=[1, i_channels], size_kernels=[i_kernel_size, i_kernel_size], zero_mean = bZeroMean, sn_size=128)

#         else :
#             list_channels = [1]
#             list_kernel_size = []
#             for _ in range(N_rep):
#                 list_channels.append(i_channels)
#                 list_kernel_size.append(i_kernel_size)
#             self.convD = B.MultiConv3d(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = bZeroMean, sn_size=128)


       
#         # self.sigma = nn.Parameter(torch.zeros(1))
#         # self.nu = nn.Parameter(torch.ones(1))
  

#     def forward(self, xn, un, zref, nu, mask, bTrain = True, xEM = None):
#         # tau * sigma ||D||^2 < 1
#         Lambda_reg = mask*self.reg_weight(xEM)
#         sn = 1.1*self.convD.spectral_norm(mode="Fourier" if bTrain else "power_method", n_steps=200)*(Lambda_reg**2).max()
#         sigma = 0.001 #F.softplus(self.sigma)
#         tau = 0.99/(sn*sigma + 0.5)
#         delta = 1.0 
        

#         xn_12 = xn - tau*(self.convD.transpose(Lambda_reg*un) + (xn-zref))
#         xn_12 = mask*xn_12.clamp(min=0) 
         
      
        
#         vn = Lambda_reg*sigma*self.convD(2*xn_12 - xn )
#         scal = 0.2*self.N_nu*nu+ 0.1*self.N_nu*nu*self.list_scal[0]
#         un_12 = projball_linf(un+ vn , scal)
#         # sum_uv = un+vn
#         # print("input", sum_uv.min(), sum_uv.max())

#         for i in range(1,self.N_prox):
#             scal = 0.2*self.N_nu*nu+ 0.1*self.N_nu*nu*self.list_scal[i]
#             # print(i, "scal", scal, "ref", 0.2*self.N_nu*nu)
#             un_12 += projball_linf(un+ vn, scal)
#         un_12 = un_12/self.N_prox
        

#         theta = 0.99*delta

#         xn_1 = xn + theta*(xn_12-xn)
#         un_1 = un + theta*(un_12-un)
#         return xn_1, un_1

#     def loss(self, xn, un, zref, nu, mask):
#         x_convD = self.convD(xn)
       
       
#         return (0.5*torch.norm(xn - zref,2),(x_convD**2).sum())
    
#     def reg_weight(self, zref) :
#         return self.NN(zref)


#######################################################################


class CV_simple(torch.nn.Module):
    def __init__(self, 
                 N_nu,
                 ):
        super(CV_simple, self).__init__()
        

        self.N_nu = N_nu      

        Dh = torch.tensor([[[0., 0., 0.],
                        [0., 0., 0.],
                        [0., 0., 0.]],
                        [[0., 0., 0.],
                        [-1, 1., 0.],
                        [0., 0., 0.]],
                        [[0., 0., 0.],
                        [0., 0., 0.],
                        [0., 0., 0.]]]).view(1,1,3,3,3).cuda()
        

        Dp = torch.tensor([[[0., 0., 0.],
                        [0., -1., 0.],
                        [0., 0., 0.]],
                        [[0., 0., 0.],
                        [0., 1., 0.],
                        [0., 0., 0.]],
                        [[0., 0., 0.],
                        [0., 0., 0.],
                        [0., 0., 0.]]]).view(1,1,3,3,3).cuda()
        
        Dv = torch.tensor([[[0., 0., 0.],
                        [0., 0., 0.],
                        [0., 0., 0.]],
                        [[0., -1., 0.],
                        [0., 1., 0.],
                        [0., 0., 0.]],
                        [[0., 0., 0.],
                        [0., 0., 0.],
                        [0., 0., 0.]]]).view(1,1,3,3,3).cuda()
        

        self.D = torch.concatenate([Dh, Dp, Dv], dim=0)
        
        Dh_star = torch.tensor([[[0., 0., 0.],
                            [0., 0., 0.],
                            [0., 0., 0.]],
                            [[0., 0., 0.],
                            [0., 1., -1.],
                            [0., 0., 0.]],
                            [[0., 0., 0.],
                            [0., 0., 0.],
                            [0., 0., 0.]]]).view(1,1,3,3,3).cuda()
            

        Dp_star = torch.tensor([[[0., 0., 0.],
                        [0., 0., 0.],
                        [0., 0., 0.]],
                        [[0., 0., 0.],
                        [0., 1., 0.],
                        [0., 0., 0.]],
                        [[0., 0., 0.],
                        [0., -1., 0.],
                        [0., 0., 0.]]]).view(1,1,3,3,3).cuda()
        
        Dv_star = torch.tensor([[[0., 0., 0.],
                        [0., 0., 0.],
                        [0., 0., 0.]],
                        [[0., 0., 0.],
                        [0., 1., 0.],
                        [0., -1., 0.]],
                        [[0., 0., 0.],
                        [0., 0., 0.],
                        [0., 0., 0.]]]).view(1,1,3,3,3).cuda()
        

        self.D_star = torch.concatenate([Dh_star, Dp_star, Dv_star], dim=1)
        self.nu = nn.Parameter(torch.ones(1))
  

    def forward(self, xn, un, zref, nu, mask, bComputeSN = False, bTrain = True, xEM=None, precond = None):
        # tau * sigma ||D||^2 < 1
        sn = 12 #self.convD.spectral_norm(mode="Fourier", n_steps=1000)
        sigma = 0.001
        # B = 0.5

        # sigma = 0.99/(sn*tau) 
        # delta = 2.0 

        # tau = 0.99/(0.5+sigma*sn)
        # delta = 2-0.5/(1.0/tau - sigma*sn) # theta <= delta 

        t1 = 0.99/(sn*sigma)
        t2 = 1.0/(1.0+sigma*sn)
        tau = min(t1, t2) #t2 smallest
        delta = 2.0  

        tau = 0.99/(sn*sigma + 0.5)
        delta = 1.0 



        xn_12 = mask*(xn - tau*(F.conv3d(un,self.D_star,padding=1)+ (xn-zref)))
                 
        xn_12 = xn_12.clamp(min=0)        
        un_12 = projball_linf(un+ sigma*F.conv3d(2*xn_12 - xn,self.D,padding=1), self.N_nu*nu*F.softplus(self.nu))
    
        theta = 0.99*delta 

        xn_1 = xn + theta*(xn_12-xn)
        un_1 = un + theta*(un_12-un)
        return xn_1, un_1

    def loss(self, xn, zref, nu, mask, xEM =None, precond=None):
        x_convD = F.conv3d(xn,self.D,padding=1)
        print(self.N_nu*nu*F.softplus(self.nu))
       
       
        return (0.5*torch.sum(torch.mul(xn-zref,xn-zref)),self.N_nu*nu*F.softplus(self.nu)*(x_convD.abs()).sum())
    
class CVnetDEQFixedPoint(nn.Module):
    def __init__(self, params_bw, params_fw, params_model):
        super().__init__()
        # self.model = CV_simple(N_nu=params_model['N_nu'])
        self.model = CVnetDEQSpatial(N_rep = params_model['N_rep'], bBias=params_model['bias'], bZeroMean = params_model['ZeroMean'], N_nu=params_model['N_nu'], i_channels=params_model['i_channels'], 
                                     i_kernel_size=params_model['i_kernel_size'], N_prox=params_model['N_prox'], 
                                     bMultiScale=params_model['bMultiScale'], bHalfZeroMean=params_model['bHalfZeroMean'], b_precond=params_model['b_precond'])
        self.solver = safe_anderson_acceleration
        self.params_fw = params_fw
        self.params_bw = params_bw
        self.f = None
        # self.fjvp = None
        self.backward_res = None
        self.backward_iter = None
        self.lamb_bck = None
        self.lamb_fwd = None
        self.moving_avg_res_bck = None
        self.moving_avg_res_fwd = None
        self.forward_res = None
        self.forward_iter = self.params_fw['max_iter']
        self.i_channels = params_model['i_channels']

    def reg_weight(self, zref) :
        return self.model.reg_weight(zref)
    
        
    def forward(self, x_noisy, mask=None, nu = 1, bTrain = True,  xEM = None, xstart = None, precond = None, **kwargs):

            
        # fixed point iteration
        def f(z, x_noisy, nu, mask, xEM, precond):
             x, u = z[:,0,0,:,:,:].unsqueeze(1), z[:,1,:,:,:,:]
             x1, u1 = self.model(x, u, x_noisy, nu, mask=mask, xEM= xEM, precond = precond, bComputeSN = True)
       
             z1 = torch.cat([x1.expand(x_noisy.shape[0], self.i_channels, x_noisy.shape[2], x_noisy.shape[3], x_noisy.shape[4]).unsqueeze(1), u1.unsqueeze(1)], dim=1)
             return(z1)
        
        def loss(x, x_noisy,nu, mask, xEM, precond):
            # x, u = z[:,0,0,:,:,:].unsqueeze(1), z[:,1,:,:,:,:]
            l = self.model.loss(x, x_noisy, nu, mask, xEM, precond)
            return l

        # # jacobian vector product of the fixed point iteration
        # def fjvp(x, y):
        #     with torch.no_grad():
        #         return(y - self.model.hvp_denoising(x, y, sigma=sigma))

        self.f = f
        self.loss = loss
        # self.fjvp = fjvp


        # compute the fixed point
        with torch.no_grad():
            # if model is an instance of CVnetDEQ
            if bTrain :
                vec_init = torch.zeros(x_noisy.shape[0], 2, self.i_channels,  x_noisy.shape[2], x_noisy.shape[3], x_noisy.shape[4], device=x_noisy.device)
                # if xstart is not None:
                #     print("xstart", xstart.shape)
                #     vec_init[:,0,0,:,:,:] = xstart.view(xstart.shape[0], 1, xstart.shape[1], xstart.shape[2], xstart.shape[3])
                loss_all = []
                z, self.forward_iter, self.forward_res, self.lamb_fwd, self.moving_avg_res_fwd = self.solver(lambda z : self.f(z, x_noisy, nu, mask, xEM, precond), vec_init, **self.params_fw)
            else :
                uk = torch.zeros(x_noisy.shape[0], self.i_channels, x_noisy.shape[2], x_noisy.shape[3], x_noisy.shape[4], device=x_noisy.device)
                xk = x_noisy.clone()
                # torch.zeros(x_noisy.shape[0], 1, x_noisy.shape[2], x_noisy.shape[3], x_noisy.shape[4], device=x_noisy.device)
                self.forward_res = []
                loss_all = []
                for k in range(self.params_fw['max_iter']):
                    # print("k", k)
                    x= xk
                    u = uk
                    xk, uk = self.model(xk, uk, x_noisy, nu, mask, bTrain = False, xEM = xEM, precond = precond, bComputeSN = True if k == 0 else False)
                    # l1, l2 = self.loss(xk, x_noisy, nu, mask, xEM, precond)
                    # loss_all.append((l1+l2).item())
                    self.forward_res.append(((xk - x).norm() / (1e-5 + xk.norm())).detach().cpu().numpy())
                    if (xk - x).norm() / (1e-5 + xk.norm()) < self.params_fw['tol'] and (u - uk).norm() / (1e-5 + uk.norm()) < self.params_fw['tol']:
                        self.forward_iter = k          
                        break
                z = torch.cat([xk.expand(x_noisy.shape[0], self.i_channels, x_noisy.shape[2], x_noisy.shape[3], x_noisy.shape[4]).unsqueeze(1), uk.unsqueeze(1)], dim=1)
                self.moving_avg_res_fwd = self.forward_res
        z = self.f(z, x_noisy, nu, mask, xEM, precond)
        # l1, l2 = self.loss(z, x_noisy, nu, mask, xEM)
  
        # z0 = z.clone().detach()

        # def backward_hook(grad):
        #     g, self.backward_niter = self.solver(lambda y : self.fjvp(z0, y) + grad,
        #                                    grad, **self.params_bw)
        #     return g

        # if self.model.training:
        #     z.register_hook(backward_hook)

        z0 = z.clone().detach().requires_grad_()
        f0 = self.f(z0,x_noisy, nu, mask, xEM, precond)
        def backward_hook(grad):
            """
            A hook needed during the backward pass
            """
            g, self.backward_iter, self.backward_res, self.lamb_bck, self.moving_avg_res_bck = self.solver(lambda y : autograd.grad(f0, z0, y, retain_graph=True)[0] + grad,
                                               grad, **self.params_bw)
            return g
                
        if bTrain :
            z.register_hook(backward_hook)
       
        return z[:,0,0,:,:,:].unsqueeze(1), [self.forward_iter, self.backward_iter], [self.forward_res, self.backward_res], [self.lamb_fwd, self.lamb_bck], [self.moving_avg_res_fwd, self.moving_avg_res_bck], loss_all




def safe_anderson_acceleration(f, x0, m=5, lam=1e-4, max_iter=50, tol=1e-5, beta=1.0, average_iter=20, deb_average=50, plateau_iter=20, verbose = True):
    """Safe version of Anderson acceleration for fixed point iteration.
    Ensures that the Hessian is invertible by adding a small value to the diagonal depending on the conditioning of G.
    If the moving average of residual is increasing, the method is restarted with a larger value of lam (fac 1.1).
    
    Args:
    - f (callable): The function for fixed point iteration.
    - x0 (torch.Tensor): The initial guess tensor.
    - m (int): Number of previous iterates to store.
    - lam (float): Regularization parameter.
    - max_iter (int): Maximum number of iterations.
    - tol (float): Tolerance for convergence.
    - beta (float): Mixing coefficient for the accelerated iterate.
    - average_iter (int): Number of iterations to compute the movign average of residuals.
    - deb_average (int): Number of iterations before starting to compute the moving average of residuals.
    
    Returns:
    - x (torch.Tensor): The final iterate.
    - f_x (torch.Tensor): The value of f at the final iterate.
    - res (list): List of residuals for each iteration.
    """
    bsz, c, d, D, H, W = x0.shape
    X = torch.zeros(bsz, m, c * d * D * H * W, dtype=x0.dtype, device=x0.device)
    F = torch.zeros(bsz, m, c * d * D * H * W, dtype=x0.dtype, device=x0.device)
    X[:, 0], F[:, 0] = x0.view(bsz, -1), f(x0).view(bsz, -1)
    X[:, 1], F[:, 1] = F[:, 0], f(F[:, 0].view_as(x0)).view(bsz, -1)

    H_mat = torch.zeros(bsz, m + 1, m + 1, dtype=x0.dtype, device=x0.device)
    H_mat[:, 0, 1:] = H_mat[:, 1:, 0] = 1
    y = torch.zeros(bsz, m + 1, 1, dtype=x0.dtype, device=x0.device)
    y[:, 0] = 1
    
    plateau_count = 0  # Count for plateau iterations
    # prev_res_norm = float('inf')  # Initial previous residual norm
    res = []
    
    moving_avg_res = []

    k = 2
    while k < max_iter:
        n = min(k, m)
        G = F[:, :n] - X[:, :n]

        # Compute the conditioning of G
        g_norm = G.norm(dim=(1, 2))
        cond_G = g_norm.max() / g_norm.min()

        # Update the diagonal of H_mat with a small value based on the conditioning of G
        H_mat[:, 1:n + 1, 1:n + 1] = torch.bmm(G, G.transpose(1, 2)) + lam * cond_G * torch.eye(n, dtype=x0.dtype, device=x0.device)[None]

        # Solve for alpha
        alpha = torch.linalg.solve(H_mat[:, :n + 1, :n + 1], y[:, :n + 1])[:, 1:n + 1, 0]

        # Update X and F
        X[:, k % m] = beta * (alpha[:, None] @ F[:, :n])[:, 0] + (1 - beta) * (alpha[:, None] @ X[:, :n])[:, 0]
        F[:, k % m] = f(X[:, k % m].view_as(x0)).view(bsz, -1)

        # Compute residual and check for convergence
        res_norm = (F[:, k % m] - X[:, k % m]).norm() / (1e-5 + F[:, k % m].norm())
        res.append(res_norm.item())

        if res_norm < tol:
            if verbose:
                print("Converged in", k, "iterations.")
            break
        
        # compute the moving average of residuals
        if k >= deb_average + average_iter: #and k % average_iter == 0:
            if k == (average_iter + deb_average) : #first one
                moving_avg_res = res[-average_iter:]
                current_sum = sum(moving_avg_res) 
            else:
                moving_avg_res.append(res_norm.item())
                moving_avg_res = moving_avg_res[1:]
                prec_sum = current_sum
                current_sum = sum(moving_avg_res)


        # check if the moving average of residuals is increasing
        if k > (deb_average+average_iter) :
            if verbose :
                print("prec_sum", prec_sum, "current_sum", current_sum, "res_norm", res_norm.item(), "cond_G", cond_G)
            if current_sum > prec_sum:
                if verbose:
                    print("Increasing plateau.")
                plateau_count += 1
            else:
                plateau_count = 0
            if plateau_count == plateau_iter :
                plateau_count = 0
                deb_average = k
                if verbose:
                    print("####################################")
                    print("Iteration", k, ": Restarting Anderson acceleration with larger regularization parameter.")
                    print("prec_sum", prec_sum, "current_sum", current_sum)
                k = 1
                res = []
                moving_avg_res = []
                X[:, 0], F[:, 0] = x0.view(bsz, -1), f(x0).view(bsz, -1)
                X[:, 1], F[:, 1] = F[:, 0], f(F[:, 0].view_as(x0)).view(bsz, -1)

                H_mat = torch.zeros(bsz, m + 1, m + 1, dtype=x0.dtype, device=x0.device)
                H_mat[:, 0, 1:] = H_mat[:, 1:, 0] = 1

                y = torch.zeros(bsz, m + 1, 1, dtype=x0.dtype, device=x0.device)
                y[:, 0] = 1
                
                # Restart with a larger value of lam
                lam *= 1.5 #1.1
                if verbose :
                    print("lam", lam)
                    print("####################################")

        k += 1

    if verbose :
        print("Anderson acceleration done.")
    del H_mat, y, F, G
    return X[:, k % m].view_as(x0), k, res, lam, moving_avg_res