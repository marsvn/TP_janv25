import torch
import torch.nn as nn
import torch.nn.functional as F
from . import basicblock as B

def projball_linf(y, tau):
    return torch.clamp(y, min=-tau, max=tau)

class PDDR_block(torch.nn.Module):
    # the minimization of f + g ◦ L + h in the quadratic case where h(x) = 1 /2 〈x, Qx〉  for some self-adjoint, positive, nonzero, bounded linear operator Q
    # f(x) = 1/2 (x - zref)**2 
    # g(x) = nu ||x||_1

    # Primal-dual Douglas–Rachford iteration
    def __init__(self, 
                 N_nu,
                 i_channels, 
                 i_kernel_size,
                 i_FNE,
                 N_rep = 1
                 ):
        super(PDDR_block, self).__init__()
        
        self.N_nu = N_nu
        list_channels = [1]
        list_kernel_size = []
        for i in range(N_rep):
            list_channels.append(i_channels)
            list_kernel_size.append(i_kernel_size)
        
        self.convD = B.MultiConv3d(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = False, sn_size=128) 
        self.tau = nn.Parameter(torch.zeros(1))
        if not i_FNE:
            self.theta = nn.Parameter(torch.zeros(1))
        self.i_FNE = i_FNE
        self.convQ = B.MultiConv3d(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = False, sn_size=128) 
       

    def forward(self, sk, uk, zref, nu, quad, mask):

        sn = 1.2*self.convD.spectral_norm(mode="Fourier", n_steps=100)
        snQ = 1.2*self.convQ.spectral_norm(mode="Fourier", n_steps=100).sqrt()
        tau = (1.99*F.sigmoid(5*self.tau))/(snQ*quad)
        sigma = 0.99/(sn*tau)
        if self.i_FNE:
            theta = 0.5     
        else :
            theta = 1.99*F.sigmoid(5*self.theta)

        # print("tau = ", tau, "nu = ", nu, "quad = ", quad, "sigma = ", sigma, "rho = ", rho)

        xk_12 = (sk - 0.5*tau*quad*self.convQ.transpose(self.convQ(sk)) + tau*zref)/(1.0+tau)
        # print("(pre) x min max = ", xk_12.min(), xk_12.max())
        xk_12 = mask*xk_12.clamp(min=0)
        uk_12 = projball_linf(uk+ sigma*self.convD(2*xk_12 - sk - 0.5*tau*quad*self.convQ.transpose(self.convQ(2*xk_12 - sk)) - tau*self.convD.transpose(uk)) ,self.N_nu*nu+1e-6)
        sk_12 = xk_12 - 0.5*tau*quad*self.convQ.transpose(self.convQ(2*xk_12 - sk)) - tau*self.convD.transpose(uk_12)
        sk_1 = sk + theta*(sk_12 - sk)
        uk_1 = uk + theta*(uk_12 - uk)
        # print("x min max = ", xk_12.min(), xk_12.max())
      
        return xk_12, sk_1, uk_1 
    

class PDDR_block_last(torch.nn.Module):
    # the minimization of f + g ◦ L + h in the quadratic case where h(x) = 1 /2 〈x, Qx〉  for some self-adjoint, positive, nonzero, bounded linear operator Q
    # f(x) = 1/2 (x - zref)**2 
    # g(x) = nu ||x||_1

    # Primal-dual Douglas–Rachford iteration
    def __init__(self, 
                 N_nu,
                 i_channels, 
                 i_kernel_size,
                 N_rep = 1
                 ):
        super(PDDR_block_last, self).__init__()
        
        # self.N_nu = N_nu
        list_channels = [1]
        list_kernel_size = []
        for _ in range(N_rep):
            list_channels.append(i_channels)
            list_kernel_size.append(i_kernel_size)
        self.tau = nn.Parameter(torch.zeros(1))
        self.convQ = B.MultiConv3d(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = False, sn_size=128) 
       

    def forward(self, sk, zref, quad, mask):

        snQ = 1.2*self.convQ.spectral_norm(mode="Fourier", n_steps=100).sqrt()
        tau = (1.99*F.sigmoid(5*self.tau))/(snQ*quad)      
        # print("tau = ", tau,  "quad = ", quad)

        xk_12 = (sk - 0.5*tau*quad*self.convQ.transpose(self.convQ(sk)) + tau*zref)/(1.0+tau)
        # print("(pre) x min max = ", xk_12.min(), xk_12.max())
        xk_12 = mask*xk_12.clamp(min=0)
        # print("x min max = ", xk_12.min(), xk_12.max())


      
        return xk_12

#################################################
    
class PDDR_block_multiprox(torch.nn.Module):
    # the minimization of f + g ◦ L + h in the quadratic case where h(x) = 1 /2 〈x, Qx〉  for some self-adjoint, positive, nonzero, bounded linear operator Q
    # f(x) = 1/2 (x - zref)**2 
    # g(x) = nu ||x||_1

    # Primal-dual Douglas–Rachford iteration
    def __init__(self, 
                 N_nu,
                 i_channels, 
                 i_kernel_size,
                 i_FNE,
                 N_rep = 1,
                 N_prox = 1,
                 bPos = True
                 ):
        super(PDDR_block_multiprox, self).__init__()
        
        self.N_nu = N_nu
        self.list_scal = nn.Parameter(torch.rand(N_prox))
        self.N_prox = N_prox

        list_channels = [1]
        list_kernel_size = []
        for _ in range(N_rep):
            list_channels.append(i_channels)
            list_kernel_size.append(i_kernel_size)
        
        self.convD = B.MultiConv3d(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = False, sn_size=128) 
        self.tau = nn.Parameter(torch.zeros(1))
        if not i_FNE:
            self.theta = nn.Parameter(torch.zeros(1))
        self.i_FNE = i_FNE
        self.convQ = B.MultiConv3d(num_channels=list_channels, size_kernels=list_kernel_size, zero_mean = False, sn_size=128) 
        self.bPos = bPos

    def forward(self, sk, uk, zref, nu, quad, mask):

        sn = 1.2*self.convD.spectral_norm(mode="Fourier", n_steps=100)
        snQ = 1.2*self.convQ.spectral_norm(mode="Fourier", n_steps=100).sqrt()
        tau = (1.99*F.sigmoid(5*self.tau))/(snQ*quad)
        sigma = 0.99/(sn*tau)
        if self.i_FNE:
            theta = 0.5     
        else :
            theta = 1.99*F.sigmoid(5*self.theta)

        # print("tau = ", tau, "nu = ", nu, "quad = ", quad, "sigma = ", sigma, "rho = ", rho)

        xk_12 = (sk - 0.5*tau*quad*self.convQ.transpose(self.convQ(sk)) + tau*zref)/(1.0+tau)
        # print("(pre) x min max = ", xk_12.min(), xk_12.max())
        if self.bPos:
            xk_12 = mask*xk_12.clamp(min=0)
        else :
            xk_12 = mask*torch.max(xk_12, -zref)
        # uk_12 = self.N_nu*nu*F.hardtanh((uk+ sigma*self.convD(2*xk_12 - sk - 0.5*tau*quad*self.convQ.transpose(self.convQ(2*xk_12 - sk)) - tau*self.convD.transpose(uk)) )/(self.N_nu*nu+1e-6))
        
        uk_12 = torch.zeros_like(uk)
        for i in range(self.N_prox):
            uk_12 += projball_linf(uk+ sigma*self.convD(2*xk_12 - sk - 0.5*tau*quad*self.convQ.transpose(self.convQ(2*xk_12 - sk)) - tau*self.convD.transpose(uk)) , self.N_nu*nu*F.softplus(self.list_scal[i]))
            # self.N_nu*nu*F.softplus(self.list_scal[i])*F.hardtanh((uk+ sigma*self.convD(2*xk_12 - sk - 0.5*tau*quad*self.convQ.transpose(self.convQ(2*xk_12 - sk)) - tau*self.convD.transpose(uk)) )/(self.N_nu*nu*F.softplus(self.list_scal[i])+1e-6))
        
        uk_12 = uk_12/self.N_prox
        sk_12 = xk_12 - 0.5*tau*quad*self.convQ.transpose(self.convQ(2*xk_12 - sk)) - tau*self.convD.transpose(uk_12)
        sk_1 = sk + theta*(sk_12 - sk)
        uk_1 = uk + theta*(uk_12 - uk)
        # print("x min max = ", xk_12.min(), xk_12.max())
      
        return xk_12, sk_1, uk_1 
    

#################################################

class PDDRnet(torch.nn.Module):


    def __init__(self, 
                 N_nu,
                 N_quad,
                 i_channels, 
                 i_kernel_size, 
                 i_num_iter, 
                 i_FNE = False,
                 N_rep = 1,
                 N_prox = 1,
                 bPos = True
                 ):
        super(PDDRnet, self).__init__()
        
        self.N_nu = N_nu
        self.N_quad = N_quad
        self.i_channels = i_channels
        self.i_kernel_size = i_kernel_size
        self.i_num_iter = i_num_iter

        self.Layers   = nn.ModuleList()
        self.nu = nn.Parameter(torch.zeros(1))
        self.quad = nn.Parameter(torch.zeros(1))



                 

        for _ in range(self.i_num_iter):     
            if N_prox > 1:
               self.Layers.append(PDDR_block_multiprox(N_nu, i_channels, i_kernel_size, i_FNE, N_rep=N_rep, N_prox=N_prox, bPos=bPos))
            else :
               self.Layers.append(PDDR_block(N_nu, i_channels, i_kernel_size, i_FNE, N_rep=N_rep))
        self.Layers.append(PDDR_block_last(N_nu, i_channels, i_kernel_size, N_rep=N_rep))
                     
    def forward(self, zref, mask, nu, b_training = False):
        uk = torch.zeros(zref.shape[0], self.i_channels, zref.shape[2], zref.shape[3], zref.shape[4], device=zref.device)
        sk = torch.zeros(zref.shape[0], 1, zref.shape[2], zref.shape[3], zref.shape[4], device=zref.device)
        vec_x = torch.zeros(zref.shape[0], self.i_num_iter, zref.shape[2], zref.shape[3], zref.shape[4], device=zref.device)
        for k in range(self.i_num_iter):
            xk, sk, uk = self.Layers[k](sk, uk, zref, nu*F.softplus(self.nu), self.N_quad*F.softplus(self.quad), mask = mask)
            if k > 0 :
                vec_x[:,k-1,:,:,:] = xk.squeeze()
        
        xk = self.Layers[self.i_num_iter](sk, zref, self.N_quad*F.softplus(self.quad), mask = mask)
       
        vec_x[:,self.i_num_iter-1,:,:,:] = xk.squeeze()
        return xk, vec_x


 