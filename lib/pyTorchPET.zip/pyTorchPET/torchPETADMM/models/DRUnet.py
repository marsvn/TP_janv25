from os import setxattr
import torch
import torch.nn as nn
import numpy as np
from . import basicblock as B
import torch.nn.functional as F
from . import utils
import math






'''
# ====================
# unet
# ====================
'''


# class UNet(nn.Module):
#     def __init__(self, in_nc=1, out_nc=1, nc=[64, 128, 256, 512], nb=2, act_mode='R', downsample_mode='strideconv', upsample_mode='convtranspose'):
#         super(UNet, self).__init__()

#         self.m_head = B.conv(in_nc, nc[0], mode='C'+act_mode[-1])

#         # downsample
#         if downsample_mode == 'avgpool':
#             downsample_block = B.downsample_avgpool
#         elif downsample_mode == 'maxpool':
#             downsample_block = B.downsample_maxpool
#         elif downsample_mode == 'strideconv':
#             downsample_block = B.downsample_strideconv
#         else:
#             raise NotImplementedError('downsample mode [{:s}] is not found'.format(downsample_mode))

#         self.m_down1 = B.sequential(*[B.conv(nc[0], nc[0], mode='C'+act_mode) for _ in range(nb)], downsample_block(nc[0], nc[1], mode='2'+act_mode))
#         self.m_down2 = B.sequential(*[B.conv(nc[1], nc[1], mode='C'+act_mode) for _ in range(nb)], downsample_block(nc[1], nc[2], mode='2'+act_mode))
#         self.m_down3 = B.sequential(*[B.conv(nc[2], nc[2], mode='C'+act_mode) for _ in range(nb)], downsample_block(nc[2], nc[3], mode='2'+act_mode))

#         self.m_body  = B.sequential(*[B.conv(nc[3], nc[3], mode='C'+act_mode) for _ in range(nb+1)])

#         # upsample
#         if upsample_mode == 'upconv':
#             upsample_block = B.upsample_upconv
#         elif upsample_mode == 'pixelshuffle':
#             upsample_block = B.upsample_pixelshuffle
#         elif upsample_mode == 'convtranspose':
#             upsample_block = B.upsample_convtranspose
#         else:
#             raise NotImplementedError('upsample mode [{:s}] is not found'.format(upsample_mode))

#         self.m_up3 = B.sequential(upsample_block(nc[3], nc[2], mode='2'+act_mode), *[B.conv(nc[2], nc[2], mode='C'+act_mode) for _ in range(nb)])
#         self.m_up2 = B.sequential(upsample_block(nc[2], nc[1], mode='2'+act_mode), *[B.conv(nc[1], nc[1], mode='C'+act_mode) for _ in range(nb)])
#         self.m_up1 = B.sequential(upsample_block(nc[1], nc[0], mode='2'+act_mode), *[B.conv(nc[0], nc[0], mode='C'+act_mode) for _ in range(nb)])

#         self.m_tail = B.conv(nc[0], out_nc, bias=True, mode='C')

#     def forward(self, x0):

#         x1 = self.m_head(x0)
#         x2 = self.m_down1(x1)
#         x3 = self.m_down2(x2)
#         x4 = self.m_down3(x3)
#         x = self.m_body(x4)
#         x = self.m_up3(x+x4)
#         x = self.m_up2(x+x3)
#         x = self.m_up1(x+x2)
#         x = self.m_tail(x+x1) + x0

        
#         return x
def get_norm_layer(norm, act_mode, repeat=True):
    match norm :
        case 'nonorm.v1' :
            mode = 'C' +act_mode 
        case 'nonorm.v2' :
            mode = act_mode +'C'
        case 'batchnorm.v1' :
            mode = 'CB'+act_mode
        case 'instancenorm.v1' :
            mode = 'CI'+act_mode 
        case 'batchnorm.v2' :
            mode = 'B'+act_mode+ 'C'
        case 'instancenorm.v2' :
            mode = 'I'+act_mode+'C'
        case 'instancenormbf.v1' :
            mode = 'Ci'+act_mode
        case 'instancenormbf.v2' :
            mode = 'i'+act_mode+'C'
        case _:
            raise NotImplementedError('norm mode [{:s}] is not found'.format(norm))
    if repeat:
        mode = mode + mode
    return mode
            

def repeat_lam(func, times):
    def wrapper(arg, arg2):
        for i in range(times):
            arg = func(arg, arg2)
        return arg
    return wrapper

class UNetAtt(nn.Module):
    def __init__(self, 
                 in_nc=2, 
                 out_nc=1,  
                 nb=2, 
                 depth = 2, 
                 wf=16,
                 act_mode='R', 
                 downsample_mode='strideconv', 
                 upsample_mode='convtranspose', 
                 norm = 'nonorm', 
                 attention=False, 
                 type_init='xavier'
                 ):
        super(UNetAtt, self).__init__() 
        print('not used')


        # downsample
        if downsample_mode == 'avgpool':
            downsample_block = B.downsample_avgpool
        elif downsample_mode == 'maxpool':
            downsample_block = B.downsample_maxpool
        elif downsample_mode == 'strideconv':
            downsample_block = B.downsample_strideconv
        else:
            raise NotImplementedError('downsample mode [{:s}] is not found'.format(downsample_mode))


        # upsample
        if upsample_mode == 'upconv':
            upsample_block = B.upsample_upconv
        elif upsample_mode == 'pixelshuffle':
            upsample_block = B.upsample_pixelshuffle
        elif upsample_mode == 'convtranspose':
            upsample_block = B.upsample_convtranspose
        else:
            raise NotImplementedError('upsample mode [{:s}] is not found'.format(upsample_mode))


        self.down_path = nn.ModuleList()
        self.down_path.append(B.conv(in_nc, wf, bias=False, mode='C'))

        prev_channels = wf
        match norm :
            case 'nonorm' :
                mode = 'C'+act_mode+'C'
            case 'batchnorm' :
                mode = 'CB'+act_mode+'C'
            case 'instancenorm' :
                mode = 'CI'+act_mode+'C'
            case 'batchnorm_inv' :
                mode = 'BC'+act_mode+ 'C'
            case 'instancenorm_inv' :
                mode = 'IC'+act_mode+'C'
            case 'instancenorm_bf' :
                mode = 'Ci'+act_mode+'C'
            case _:
                raise NotImplementedError('norm mode [{:s}] is not found'.format(norm))

        for i in range(depth-1):
            if attention : 
                self.down_path.append(B.sequential(*[B.ResBlock(prev_channels, prev_channels, bias=False, mode=mode, type_init=type_init) for _ in range(nb)],
                                            downsample_block(prev_channels, wf*(2 ** (i+1)), bias=False, mode='2', type_init=type_init), 
                                            B.SelfAttention(wf*(2 ** (i+1)),1)
                                            ))
            else :
                self.down_path.append(B.sequential(*[B.ResBlock(prev_channels, prev_channels, bias=False, mode=mode, type_init=type_init) for _ in range(nb)], 
                                            downsample_block(prev_channels, wf*(2 ** (i+1)), bias=False, mode='2', type_init=type_init)
                                            ))
            
            
            prev_channels = wf*(2 ** (i+1))
        self.down_path.append(B.sequential(*[B.ResBlock(prev_channels, prev_channels, bias=False, mode=mode, type_init=type_init) for _ in range(nb)]))
        

        self.up_path = nn.ModuleList()
        for i in reversed(range(depth-1)):
            if attention :
                self.up_path.append(
                    B.sequential(upsample_block(prev_channels, wf*(2 ** i), bias=False, mode='2', type_init=type_init), 
                                    *[B.ResBlock(wf*(2 ** i), wf*(2 ** i), bias=False, mode=mode, type_init=type_init) for _ in range(nb)],
                                    B.SelfAttention(wf*(2 ** i),1))
                )
            else :
                self.up_path.append(
                    B.sequential(upsample_block(prev_channels, wf*(2 ** i), bias=False, mode='2', type_init=type_init), *[B.ResBlock(wf*(2 ** i), wf*(2 ** i), bias=False, mode=mode, type_init=type_init) for _ in range(nb)])
                )
            prev_channels = wf*(2 ** i)

    
        
 
        self.up_path.append(B.conv(wf, out_nc, bias=False, mode='C'))



    def forward(self, x):
        blocks = []
        for i, down in enumerate(self.down_path):
            x = down(x)
            if i != len(self.down_path) - 1:
                blocks.append(x)

        for i, up in enumerate(self.up_path):

            x = up(x+ blocks[-i - 1])
        return x



# class UNetCond(nn.Module):
#     def __init__(self, 
#                  in_nc=2, 
#                  out_nc=1,  
#                  nb=2, 
#                  depth = 2, 
#                  wf=16,
#                  act_mode='R', 
#                  downsample_mode='strideconv', 
#                  upsample_mode='convtranspose', 
#                  norm = 'nonorm', 
#                  attention=False, 
#                  time_dim=256, 
#                  type_init='xavier'
#                  ):
#         super(UNetCond, self).__init__() 

#         self.time_dim = time_dim

#         # downsample
#         if downsample_mode == 'avgpool':
#             downsample_block = B.downsample_avgpool
#         elif downsample_mode == 'maxpool':
#             downsample_block = B.downsample_maxpool
#         elif downsample_mode == 'strideconv':
#             downsample_block = B.downsample_strideconv
#         else:
#             raise NotImplementedError('downsample mode [{:s}] is not found'.format(downsample_mode))


#         # upsample
#         if upsample_mode == 'upconv':
#             upsample_block = B.upsample_upconv
#         elif upsample_mode == 'pixelshuffle':
#             upsample_block = B.upsample_pixelshuffle
#         elif upsample_mode == 'convtranspose':
#             upsample_block = B.upsample_convtranspose
#         else:
#             raise NotImplementedError('upsample mode [{:s}] is not found'.format(upsample_mode))


#         self.down_path = nn.ModuleList()
#         self.down_path.append(B.conv(in_nc, wf, bias=False, mode='C'))


#         prev_channels = wf

#         # match norm :
#         #     case 'nonorm' :
#         #         mode = 'C'+act_mode+'C'
#         #     case 'batchnorm' :
#         #         mode = 'CB'+act_mode+'C'
#         #     case 'instancenorm' :
#         #         mode = 'CI'+act_mode+'C'
#         #     case 'batchnorm_inv' :
#         #         mode = 'BC'+act_mode+ 'C'
#         #     case 'instancenorm_inv' :
#         #         mode = 'IC'+act_mode+'C'
#         #     case 'instancenorm_bf' :
#         #         mode = 'Ci'+act_mode+'C'
#         #     case _:
#         #         raise NotImplementedError('norm mode [{:s}] is not found'.format(norm))

#         match norm :
#             case 'nonorm.v1' :
#                 mode = 'C'+act_mode+'C'+act_mode
#             case 'nonorm.v2' :
#                 mode = act_mode+'C'+act_mode+'C'
#             case 'batchnorm.v1' :
#                 mode = 'CB'+act_mode+'CB'+act_mode
#             case 'instancenorm.v1' :
#                 mode = 'CI'+act_mode+'CI'+act_mode
#             case 'batchnorm.v2' :
#                 mode = 'B'+act_mode+ 'CB'+act_mode+'C'
#             case 'instancenorm.v2' :
#                 mode = 'I'+act_mode+'CI'+act_mode+'C'
#             case 'instancenormbf.v1' :
#                 mode = 'Ci'+act_mode+'Ci'+act_mode
#             case 'instancenormbf.v2' :
#                 mode = 'i'+act_mode+'Ci'+act_mode+'C'
#             case _:
#                 raise NotImplementedError('norm mode [{:s}] is not found'.format(norm))

#         for i in range(depth-1):
#             if attention : 
#                 self.down_path.append(B.sequential(*[B.ResEmbBlock(prev_channels, prev_channels, bias=False, mode=mode, type_init=type_init) for _ in range(nb)],
#                                             downsample_block(prev_channels, wf*(2 ** (i+1)), bias=False, mode='2', type_init=type_init), 
#                                             B.SelfAttention(wf*(2 ** (i+1)),1)
#                                             ))
#             else :
#                 self.down_path.append(B.sequential(*[B.ResEmbBlock(prev_channels, prev_channels, bias=False, mode=mode, type_init=type_init) for _ in range(nb)], 
#                                             downsample_block(prev_channels, wf*(2 ** (i+1)), bias=False, mode='2', type_init=type_init)
#                                             ))
            
            
#             prev_channels = wf*(2 ** (i+1))
#         self.down_path.append(B.sequential(*[B.ResBlock(prev_channels, prev_channels, bias=False, mode=mode, type_init=type_init) for _ in range(nb)]))
        

#         self.up_path = nn.ModuleList()
#         for i in reversed(range(depth-1)):
#             if attention :
#                 self.up_path.append(
#                     B.sequential(upsample_block(prev_channels, wf*(2 ** i), bias=False, mode='2', type_init=type_init), 
#                                     *[B.ResEmbBlock(wf*(2 ** i), wf*(2 ** i), bias=False, mode=mode, type_init=type_init) for _ in range(nb)],
#                                     B.SelfAttention(wf*(2 ** i),1))
#                 )
#             else :
#                 self.up_path.append(
#                     B.sequential(upsample_block(prev_channels, wf*(2 ** i), bias=False, mode='2', type_init=type_init), *[B.ResEmbBlock(wf*(2 ** i), wf*(2 ** i), bias=False, mode=mode, type_init=type_init) for _ in range(nb)])
#                 )
#             prev_channels = wf*(2 ** i)

              
 
#         self.up_path.append(B.conv(wf, out_nc, bias=False, mode='C'))

#     def pos_encoding(self, t, channels):
#         inv_freq = 1.0 / (
#             10000
#             ** (torch.arange(0, channels, 2, device=self.device).float() / channels)
#         )
#         pos_enc_a = torch.sin(t.repeat(1, channels // 2) * inv_freq)
#         pos_enc_b = torch.cos(t.repeat(1, channels // 2) * inv_freq)
#         pos_enc = torch.cat([pos_enc_a, pos_enc_b], dim=-1)
#         return pos_enc

#     def forward(self, x, t):
#         blocks = []

#         t = t.unsqueeze(-1).type(torch.float)
#         t = self.pos_encoding(t, self.time_dim)

#         for i, down in enumerate(self.down_path):
#             x = down(x, t)
#             if i != len(self.down_path) - 1:
#                 blocks.append(x)

#         for i, up in enumerate(self.up_path):

#             x = up(x+ blocks[-i - 1],x)
#         return x

#####################################################################################



class Block(nn.Module):
    def __init__(self, in_ch, out_ch, time_emb_dim, up=False):
        super().__init__()
        self.time_mlp =  nn.Linear(time_emb_dim, out_ch)
        if up:
            self.conv1 = nn.Conv3d(2*in_ch, out_ch, 3, padding=1)
            self.transform = nn.ConvTranspose3d(out_ch, out_ch, 4, 2, 1)
        else:
            self.conv1 = nn.Conv3d(in_ch, out_ch, 3, padding=1)
            self.transform = nn.Conv3d(out_ch, out_ch, 4, 2, 1)
        self.conv2 = nn.Conv3d(out_ch, out_ch, 3, padding=1)
        self.bnorm1 = nn.Identity() #BatchNorm2d(out_ch)
        self.bnorm2 = nn.Identity()   #BatchNorm2d(out_ch)
        self.relu  = nn.ReLU()
        
    def forward(self, x, t ):
        # First Conv
        h = self.bnorm1(self.relu(self.conv1(x)))
        # Time embedding
        time_emb = self.relu(self.time_mlp(t))
        # Extend last 2 dimensions
        # print("time_emb.shape = ", time_emb.shape)
        time_emb = time_emb[(..., ) + (None, ) * 3]
        # print("time_emb.shape = ", time_emb.shape)
        # Add time channel
        h = h + time_emb
        # Second Conv
        h = self.bnorm2(self.relu(self.conv2(h)))
        # Down or Upsample
        return self.transform(h)


class SinusoidalPositionEmbeddings(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.dim = dim

    def forward(self, time):
        device = time.device
        half_dim = self.dim // 2
        embeddings = math.log(10000) / (half_dim - 1)
        embeddings = torch.exp(torch.arange(half_dim, device=device) * -embeddings)
        embeddings = time[:, None] * embeddings[None, :]
        embeddings = torch.cat((embeddings.sin(), embeddings.cos()), dim=-1)
        # TODO: Double check the ordering here
        return embeddings


class SimpleUnet(nn.Module):
    """
    A simplified variant of the Unet architecture.
    """
    def __init__(self):
        super().__init__()
        image_channels = 1
        down_channels = (32, 64, 128)
        up_channels = (64, 32, 16)
        out_dim = 1 
        time_emb_dim = 32

        # Time embedding
        self.time_mlp = nn.Sequential(
                SinusoidalPositionEmbeddings(time_emb_dim),
                nn.Linear(time_emb_dim, time_emb_dim),
                nn.ReLU()
            )
        
        # Initial projection
        self.conv0 = nn.Conv3d(image_channels, down_channels[0], 3, padding=1)

        # Downsample
        self.downs = nn.ModuleList([Block(down_channels[i], down_channels[i+1], \
                                    time_emb_dim) \
                    for i in range(len(down_channels)-1)])
        # Upsample
        self.ups = nn.ModuleList([Block(2*up_channels[i], up_channels[i], \
                                        time_emb_dim, up=True) \
                    for i in range(len(up_channels)-1)])
        
        self.output = nn.Conv3d(2*up_channels[-1], out_dim, 1)

    def forward(self, x, sigma):
        # Embedd time
        t = self.time_mlp(sigma)
        # Initial conv
        x = self.conv0(x)
        # Unet
        residual_inputs = []
        for down in self.downs:
            x = down(x, t)
            residual_inputs.append(x)

        for up in self.ups:
            residual_x = residual_inputs.pop()
            # Add residual x as additional channels
            x = torch.cat((x, residual_x), dim=1)  
            x = up(x, t)
        return self.output(x)

#####################################################################################

class UNetResWeightCond(nn.Module):
    def __init__(self, 
                 in_nc=2, 
                 out_nc=1,  
                 nb=2, 
                 depth = 2, 
                 wf=16,
                 act_mode='R', 
                 downsample_mode='strideconv', 
                 upsample_mode='convtranspose', 
                 norm = 'nonorm', 
                 type_init= 'xavier', 
                 skip_weight = None, 
                 type_cond = 'bottleneck',
                 keep_bias = False,
                 repeat = True
                 ) :
        super(UNetResWeightCond, self).__init__() #nc=[16, 32, 64, 128],

        self.skip_weight = skip_weight
        self.type_cond = type_cond

        self.down_path = nn.ModuleList()
        # self.init_i = B.conv(in_nc, in_nc, bias=False, mode='B')
        self.down_path.append(B.conv(in_nc, wf, bias=False, mode='C'))
        prev_channels = wf

        mode = get_norm_layer(norm, act_mode, repeat)

        for i in range(depth-1):
            self.down_path.append(NFDownBlock(downsample_mode=downsample_mode, prev_channels= prev_channels, wf = wf*(2 ** (i+1)), skip_weight=skip_weight,
                                               nb = nb, keep_bias=keep_bias, mode=mode, type_init=type_init, block_type='Wresblock', use_sigma=(self.type_cond == 'weight_scaling') )
            )
            # self.down_path.append(B.sequential(*[B.ResBlockWeight(prev_channels, prev_channels, bias=False, mode=mode, type_init=type_init, skip_weight=skip_weight) for _ in range(nb)], 
            #                                 downsample_block(prev_channels, wf*(2 ** (i+1)), bias=False, mode='2', type_init=type_init)))
            
            
            prev_channels = wf*(2 ** (i+1))
        
        if self.type_cond == 'bottleneck' : # or weight scaling
            self.down_path.append(B.sequential(*[B.ConvBlock(prev_channels+1, prev_channels, bias=False, mode=mode[:-1], type_init=type_init) for _ in range(1)]))
        else :
            self.down_path.append(NFDownBlock(prev_channels= prev_channels, downsample=False, nb = nb, keep_bias=keep_bias, skip_weight=skip_weight,
                                         mode=mode, type_init=type_init, block_type='Wresblock',use_sigma=(self.type_cond == 'weight_scaling'))
                                         )
            # self.down_path.append(B.sequential(*[B.ResBlockWeight(prev_channels, prev_channels, bias=False, mode=mode, type_init=type_init, skip_weight=skip_weight) for _ in range(nb)]))
        
        self.up_path = nn.ModuleList()
        if self.skip_weight == 'sigmoid' or self.skip_weight == 'softplus':
            self.res_weights = nn.ParameterList([nn.Parameter(torch.FloatTensor([-6.0])) for i in range(depth)])
        elif self.skip_weight == 'relu':
             self.res_weights = nn.ParameterList([nn.Parameter(torch.FloatTensor([1e-6])) for i in range(depth)])
        else :
            self.res_weights = nn.ParameterList([nn.Parameter(torch.FloatTensor([0.])) for i in range(depth)])  
       
        for i in reversed(range(depth-1)):
            self.up_path.append(NFUpBlock(upsample_mode=upsample_mode, prev_channels= prev_channels, nb=nb, skip_weight = skip_weight,
                                          wf=wf*(2 ** i), keep_bias=keep_bias, mode=mode,type_init=type_init, block_type='Wresblock',use_sigma=(self.type_cond == 'weight_scaling'))
                                        )
            # self.up_path.append(
            #     B.sequential(upsample_block(prev_channels, wf*(2 ** i), bias=False, mode='2',type_init=type_init), *[B.ResBlockWeight(wf*(2 ** i), wf*(2 ** i), bias=False, mode=mode, type_init=type_init, skip_weight=skip_weight) for _ in range(nb)])
            # )
            prev_channels = wf*(2 ** i)

        self.final = B.conv(wf, out_nc, bias=False, mode='C', type_init=type_init)



    def forward(self, x, sigma=None):
        sigma_init = sigma
        sigma = torch.arctanh(sigma).clamp(0, 5.0)
        # print(sigma)
        # t = 2*sigma-torch.full(sigma.shape, 1.2, device="cuda")
        # sigma = torch.arctanh(t) + 2*torch.full(sigma.shape, 1.0, device="cuda")

        # t = 2.39*sigma-torch.full(sigma.shape, 1.4, device="cuda") #test4
        # sigma = torch.arctanh(t.clamp(-0.95, 0.99)) + 2*torch.full(sigma.shape, 1.0, device="cuda")

        # t = 2.19*sigma-torch.full(sigma.shape, 1.2, device="cuda") #test3
        # sigma = torch.arctanh(t) + 2*torch.full(sigma.shape, 1.0, device="cuda")
        
        blocks = []
        xinit = x
        # x = self.init_i(x)
        for i, down in enumerate(self.down_path):
            
            if i != len(self.down_path) - 1:
                if i == 0 :
                    x = down(x)
                else :
                    x = down(x, sigma)
                blocks.append(x)
            else :
                if self.type_cond == 'bottleneck' :
                    x = torch.cat((x, sigma.view(-1,1,1,1,1).expand(-1,1,x.size(2),x.size(3),x.size(4))), dim=1)
                    x = down(x)
                else :
                    x = down(x, sigma)

        for i, up in enumerate(self.up_path):
            current_weight = self.res_weights[i]
            if self.type_cond == 'weight_scaling' :
                current_weight = (current_weight*sigma).view(-1, 1, 1, 1, 1)


            if self.skip_weight is None:
                # print("sigma_init", sigma_init.detach().squeeze().cpu().numpy(), "sigma", sigma.detach().squeeze().cpu().numpy(), "current_weight", (current_weight).detach().squeeze().cpu().numpy())
                x= up(current_weight*x+ blocks[-i - 1], sigma)
            elif self.skip_weight == 'softplus':
                print("sigma_init", sigma_init.detach().squeeze().cpu().numpy(), "sigma", sigma.detach().squeeze().cpu().numpy(), "current_weight", F.softplus(current_weight).detach().squeeze().cpu().numpy())
                x = up(F.softplus(current_weight)*x+ blocks[-i - 1], sigma)
            elif self.skip_weight == 'sigmoid':
                print("sigma_init", sigma_init.detach().squeeze().cpu().numpy(), "sigma", sigma.detach().squeeze().cpu().numpy(), "current_weight", F.sigmoid(current_weight).detach().squeeze().cpu().numpy())
                x = up(F.sigmoid(current_weight)*x+ blocks[-i - 1], sigma)
            elif self.skip_weight == 'relu':#"t", t.detach().squeeze().cpu().numpy(),
                print("sigma_init", sigma_init.detach().squeeze().cpu().numpy(),  "sigma", sigma.detach().squeeze().cpu().numpy(), "current_weight", utils.relu_straight_through(current_weight).detach().squeeze().cpu().numpy())
                x = up(utils.relu_straight_through(current_weight)*x+ blocks[-i - 1],sigma)
            else:
                raise NotImplementedError('skip_weight mode [{:s}] is not found'.format(self.skip_weight))

        x = self.final(x)
        current_weight = self.res_weights[-1]
        if self.type_cond == 'weight_scaling' :
            current_weight = (current_weight*sigma).view(-1, 1, 1, 1, 1)

        if self.skip_weight is None:
            x = xinit+current_weight*x
        elif self.skip_weight == 'softplus':
            x = xinit+F.softplus(current_weight)*x
        elif self.skip_weight == 'sigmoid':
            x = xinit+F.sigmoid(current_weight)*x
        elif self.skip_weight == 'relu':
            # print("sigma_init", sigma_init.detach().squeeze().cpu().numpy(),  "sigma", sigma.detach().squeeze().cpu().numpy(), "current_weight", utils.relu_straight_through(current_weight).detach().squeeze().cpu().numpy())

            x = xinit+utils.relu_straight_through(current_weight)*x
        else:
            raise NotImplementedError('skip_weight mode [{:s}] is not found'.format(self.skip_weight)) 
        
        return F.relu(x)
    
    @torch.no_grad()
    def signal_prop(self, x, sigma=None,dim=(0, -1, -2, -3)):

        blocks = []
        xinit = x
        x_s = xinit

        statistics_down = [] 
        statistics_up = []
    
        lists_stats = [(
                torch.mean(xinit.mean(dim) ** 2).item(),
                torch.mean(xinit.var(dim)).item(),
                float('nan'),
             )]
        for i, down in enumerate(self.down_path):
            if i == 0:
                x_s = down(x_s)

            elif  i < len(self.down_path) - 1 :
                x_s, stats = down.signal_prop(x_s, dim=dim, sigma=sigma)
                statistics_down.append(stats)
            else :
                if self.type_cond == 'bottleneck' :
                
                    x_s = torch.cat((x_s, sigma.view(-1,1,1,1,1).expand(-1,1,x_s.size(2),x_s.size(3),x_s.size(4))), dim=1)
                    x_s = down(x_s)
                else :
                    x_s, stats = down.signal_prop(x_s, dim=dim, sigma=sigma)
                    statistics_down.append(stats)

            if i != len(self.down_path) - 1:
                # print('keeping x_s', x_s.shape)
                blocks.append(x_s)

        
            

        for i, up in enumerate(self.up_path):
            current_weight = self.res_weights[i]
            if self.type_cond == 'weight_scaling' :
                current_weight = (current_weight*sigma).view(-1, 1, 1, 1, 1)


            if self.skip_weight == 'softplus':
                current_weight = F.softplus(current_weight)
            elif self.skip_weight == 'sigmoid':
                current_weight = F.sigmoid(current_weight)
            elif self.skip_weight == 'relu':
                current_weight = utils.relu_straight_through(current_weight)

            out= current_weight*x_s+ blocks[-i - 1]
            
    

            out_mu2 = torch.mean(out.mean(dim) ** 2).item()
            out_var = torch.mean(out.var(dim)).item()
            res_var = torch.mean(x_s.var(dim)).item()
            x_s, stats = up.signal_prop(out, dim=dim, sigma=sigma)
            statistics_up.append(stats)
            lists_stats.append((out_mu2, out_var, res_var))
           
        x_s = self.final(x_s)    
        res_var = torch.mean(x_s.var(dim)).item()
        current_weight = self.res_weights[-1]
        if self.type_cond == 'weight_scaling' :
            current_weight = (current_weight*sigma).view(-1, 1, 1, 1, 1)

        if self.skip_weight == 'softplus':
            current_weight = F.softplus(current_weight)
        elif self.skip_weight == 'sigmoid':
            current_weight = F.sigmoid(current_weight)
        elif self.skip_weight == 'relu':
            current_weight = utils.relu_straight_through(current_weight)
        


        x_s = current_weight*x_s+xinit
        

        out_mu2 = torch.mean(x_s.mean(dim) ** 2).item()
        out_var = torch.mean(x_s.var(dim)).item()
        lists_stats.append((out_mu2, out_var, res_var))
  
                
        # convert list of tuples to tuple of lists
        lists_stats = tuple(map(list, zip(*lists_stats)))
        return x_s, statistics_down, statistics_up, lists_stats
#####################################################################################


class UNetResWeightCond2(nn.Module):
    def __init__(self, 
                 in_nc=2, 
                 out_nc=1,  
                 nb=2, 
                 depth = 2, 
                 wf=16,
                 act_mode='R', 
                 downsample_mode='strideconv', 
                 upsample_mode='convtranspose', 
                 norm = 'nonorm', 
                 type_init= 'xavier', 
                 skip_weight = None, 
                 type_cond = 'bottleneck',
                 keep_bias = False,
                 repeat = True
                 ) :
        super(UNetResWeightCond2, self).__init__() #nc=[16, 32, 64, 128],

        self.skip_weight = skip_weight
        self.type_cond = type_cond

        self.down_path = nn.ModuleList()
        # self.init_i = B.conv(in_nc, in_nc, bias=False, mode='B')
        self.down_path.append(B.conv(in_nc, wf, bias=False, mode='C'))
        prev_channels = wf

        mode = get_norm_layer(norm, act_mode, repeat)

        for i in range(depth-1):
            self.down_path.append(NFDownBlock(downsample_mode=downsample_mode, prev_channels= prev_channels, wf = wf*(2 ** (i+1)), skip_weight=skip_weight,
                                               nb = nb, keep_bias=keep_bias, mode=mode, type_init=type_init, block_type='Wresblock', use_sigma=(self.type_cond == 'weight_scaling') )
            )
            # self.down_path.append(B.sequential(*[B.ResBlockWeight(prev_channels, prev_channels, bias=False, mode=mode, type_init=type_init, skip_weight=skip_weight) for _ in range(nb)], 
            #                                 downsample_block(prev_channels, wf*(2 ** (i+1)), bias=False, mode='2', type_init=type_init)))
            
            
            prev_channels = wf*(2 ** (i+1))
        
        self.down_path.append(NFDownBlock(prev_channels= prev_channels, downsample=False, nb = nb, keep_bias=keep_bias, skip_weight=skip_weight,
                                         mode=mode, type_init=type_init, block_type='Wresblock',use_sigma=(self.type_cond == 'weight_scaling'))
                                         )
            # self.down_path.append(B.sequential(*[B.ResBlockWeight(prev_channels, prev_channels, bias=False, mode=mode, type_init=type_init, skip_weight=skip_weight) for _ in range(nb)]))
        
        self.up_path = nn.ModuleList()
        self.res_weight = nn.Parameter(torch.FloatTensor([6.]))
        self.res_weights = nn.ParameterList([nn.Parameter(torch.FloatTensor([0])) for i in range(depth-1)])  
       
        for i in reversed(range(depth-1)):
            self.up_path.append(NFUpBlock(upsample_mode=upsample_mode, prev_channels= prev_channels, nb=nb, skip_weight = skip_weight,
                                          wf=wf*(2 ** i), keep_bias=keep_bias, mode=mode,type_init=type_init, block_type='Wresblock',use_sigma=(self.type_cond == 'weight_scaling'))
                                        )
            # self.up_path.append(
            #     B.sequential(upsample_block(prev_channels, wf*(2 ** i), bias=False, mode='2',type_init=type_init), *[B.ResBlockWeight(wf*(2 ** i), wf*(2 ** i), bias=False, mode=mode, type_init=type_init, skip_weight=skip_weight) for _ in range(nb)])
            # )
            prev_channels = wf*(2 ** i)

        self.final = B.conv(wf, out_nc, bias=False, mode='C', type_init=type_init)



    def forward(self, x, sigma=None):
        print("sigma init = ", sigma)
        sigma = 1.0-torch.sigmoid(sigma)

        
        blocks = []
        xinit = x

        for i, down in enumerate(self.down_path):
            
            if i != len(self.down_path) - 1:
                if i == 0 :
                    x = down(x)
                else :
                    x = down(x, None)
                blocks.append(x)
            else :
                x = down(x, sigma)

        for i, up in enumerate(self.up_path):
            current_weight = self.res_weights[i].view(-1, 1, 1, 1, 1)
            # current_weight = (current_weight*sigma).view(-1, 1, 1, 1, 1)


            x= up(current_weight*x+ blocks[-i - 1], sigma)
            
        x = self.final(x)
        current_weight = self.res_weight #s[-1]
        print("sigma=", sigma)
        current_weight = (current_weight*sigma).view(-1, 1, 1, 1, 1)

        x = xinit+current_weight*x
        
        
        return x
    
    @torch.no_grad()
    def signal_prop(self, x, sigma=None,dim=(0, -1, -2, -3)):

        blocks = []
        xinit = x
        x_s = xinit

        statistics_down = [] 
        statistics_up = []
    
        lists_stats = [(
                torch.mean(xinit.mean(dim) ** 2).item(),
                torch.mean(xinit.var(dim)).item(),
                float('nan'),
             )]
        for i, down in enumerate(self.down_path):
            if i == 0:
                x_s = down(x_s)

            elif  i < len(self.down_path) - 1 :
                x_s, stats = down.signal_prop(x_s, dim=dim, sigma=sigma)
                statistics_down.append(stats)
            else :
                if self.type_cond == 'bottleneck' :
                
                    x_s = torch.cat((x_s, sigma.view(-1,1,1,1,1).expand(-1,1,x_s.size(2),x_s.size(3),x_s.size(4))), dim=1)
                    x_s = down(x_s)
                else :
                    x_s, stats = down.signal_prop(x_s, dim=dim, sigma=sigma)
                    statistics_down.append(stats)

            if i != len(self.down_path) - 1:
                # print('keeping x_s', x_s.shape)
                blocks.append(x_s)

        
            

        for i, up in enumerate(self.up_path):
            current_weight = self.res_weights[i]
            if self.type_cond == 'weight_scaling' :
                current_weight = (current_weight*sigma).view(-1, 1, 1, 1, 1)


            if self.skip_weight == 'softplus':
                current_weight = F.softplus(current_weight)
            elif self.skip_weight == 'sigmoid':
                current_weight = F.sigmoid(current_weight)
            elif self.skip_weight == 'relu':
                current_weight = utils.relu_straight_through(current_weight)

            out= current_weight*x_s+ blocks[-i - 1]
            
    

            out_mu2 = torch.mean(out.mean(dim) ** 2).item()
            out_var = torch.mean(out.var(dim)).item()
            res_var = torch.mean(x_s.var(dim)).item()
            x_s, stats = up.signal_prop(out, dim=dim, sigma=sigma)
            statistics_up.append(stats)
            lists_stats.append((out_mu2, out_var, res_var))
           
        x_s = self.final(x_s)    
        res_var = torch.mean(x_s.var(dim)).item()
        current_weight = self.res_weights[-1]
        if self.type_cond == 'weight_scaling' :
            current_weight = (current_weight*sigma).view(-1, 1, 1, 1, 1)

        if self.skip_weight == 'softplus':
            current_weight = F.softplus(current_weight)
        elif self.skip_weight == 'sigmoid':
            current_weight = F.sigmoid(current_weight)
        elif self.skip_weight == 'relu':
            current_weight = utils.relu_straight_through(current_weight)
        


        x_s = current_weight*x_s+xinit
        

        out_mu2 = torch.mean(x_s.mean(dim) ** 2).item()
        out_var = torch.mean(x_s.var(dim)).item()
        lists_stats.append((out_mu2, out_var, res_var))
  
                
        # convert list of tuples to tuple of lists
        lists_stats = tuple(map(list, zip(*lists_stats)))
        return x_s, statistics_down, statistics_up, lists_stats

#####################################################################################

class UNetResWeightEmb(nn.Module):
    def __init__(self, 
                 in_nc=2, 
                 out_nc=1,  
                 nb=2, 
                 depth = 2, 
                 wf=16,
                 act_mode='R', 
                 downsample_mode='strideconv', 
                 upsample_mode='convtranspose', 
                 norm = 'nonorm', 
                 type_init= 'xavier', 
                 skip_weight = None, 
                 type_cond = 'bottleneck',
                 keep_bias = False,
                 repeat = True
                 ) :
        super(UNetResWeightEmb, self).__init__() #nc=[16, 32, 64, 128],

        self.skip_weight = skip_weight
        self.type_cond = type_cond

        self.down_path = nn.ModuleList()
        self.down_path.append(B.conv(in_nc, wf, bias=False, mode='C'))
        prev_channels = wf

        mode = get_norm_layer(norm, act_mode, repeat)


        for i in range(depth-1):
            self.down_path.append(NFDownBlock(downsample_mode=downsample_mode, prev_channels= prev_channels, wf = wf*(2 ** (i+1)), skip_weight=skip_weight,
                                               nb = nb, keep_bias=keep_bias, mode=mode, type_init=type_init, block_type='WresblockEmb', use_sigma=True )
            )
            # self.down_path.append(B.sequential(*[B.ResBlockWeight(prev_channels, prev_channels, bias=False, mode=mode, type_init=type_init, skip_weight=skip_weight) for _ in range(nb)], 
            #                                 downsample_block(prev_channels, wf*(2 ** (i+1)), bias=False, mode='2', type_init=type_init)))
            
            
            prev_channels = wf*(2 ** (i+1))
        
        self.down_path.append(NFDownBlock(prev_channels= prev_channels, downsample=False, nb = nb, keep_bias=keep_bias, skip_weight=skip_weight,
                                         mode=mode, type_init=type_init, block_type='WresblockEmb',use_sigma=True)
                                         )
            # self.down_path.append(B.sequential(*[B.ResBlockWeight(prev_channels, prev_channels, bias=False, mode=mode, type_init=type_init, skip_weight=skip_weight) for _ in range(nb)]))
        
        self.up_path = nn.ModuleList()
        if self.skip_weight == 'sigmoid' or self.skip_weight == 'softplus':
            self.res_weights = nn.ParameterList([nn.Parameter(torch.FloatTensor([-6.0])) for i in range(depth)])
        elif self.skip_weight == 'relu':
             self.res_weights = nn.ParameterList([nn.Parameter(torch.FloatTensor([1e-6])) for i in range(depth)])
        else :
            self.res_weights = nn.ParameterList([nn.Parameter(torch.FloatTensor([0.])) for i in range(depth)])  
       
        for i in reversed(range(depth-1)):
            self.up_path.append(NFUpBlock(upsample_mode=upsample_mode, prev_channels= prev_channels, nb=nb, skip_weight = skip_weight,
                                          wf=wf*(2 ** i), keep_bias=keep_bias, mode=mode,type_init=type_init, block_type='WresblockEmb',use_sigma=True)
                                        )
            # self.up_path.append(
            #     B.sequential(upsample_block(prev_channels, wf*(2 ** i), bias=False, mode='2',type_init=type_init), *[B.ResBlockWeight(wf*(2 ** i), wf*(2 ** i), bias=False, mode=mode, type_init=type_init, skip_weight=skip_weight) for _ in range(nb)])
            # )
            prev_channels = wf*(2 ** i)

        self.final = B.conv(wf, out_nc, bias=False, mode='C', type_init=type_init)



    def forward(self, x, sigma=None):
        blocks = []
        xinit = x
        for i, down in enumerate(self.down_path):
            
            if i != len(self.down_path) - 1:
                if i == 0 :
                    x = down(x)
                else :
                    x = down(x, sigma)
                blocks.append(x)
            else :
                x = down(x, sigma)
        for i, up in enumerate(self.up_path):
            current_weight = self.res_weights[i]
            


            if self.skip_weight is None:
                x= up(current_weight*x+ blocks[-i - 1], sigma)
            elif self.skip_weight == 'softplus':
                x = up(F.softplus(current_weight)*x+ blocks[-i - 1], sigma)
            elif self.skip_weight == 'sigmoid':
                x = up(F.sigmoid(current_weight)*x+ blocks[-i - 1], sigma)
            elif self.skip_weight == 'relu':
                x = up(utils.relu_straight_through(current_weight)*x+ blocks[-i - 1],sigma)
            else:
                raise NotImplementedError('skip_weight mode [{:s}] is not found'.format(self.skip_weight))

        x = self.final(x)
        current_weight = self.res_weights[-1]
        

        if self.skip_weight is None:
            x = xinit+current_weight*x
        elif self.skip_weight == 'softplus':
            x = xinit+F.softplus(current_weight)*x
        elif self.skip_weight == 'sigmoid':
            x = xinit+F.sigmoid(current_weight)*x
        elif self.skip_weight == 'relu':
            x = xinit+utils.relu_straight_through(current_weight)*x
        else:
            raise NotImplementedError('skip_weight mode [{:s}] is not found'.format(self.skip_weight)) 
        
        return F.relu(x)
    
    @torch.no_grad()
    def signal_prop(self, x, sigma=None,dim=(0, -1, -2, -3)):

        blocks = []
        xinit = x
        x_s = xinit


        statistics_down = [] 
        statistics_up = []
    
        lists_stats = [(
                torch.mean(xinit.mean(dim) ** 2).item(),
                torch.mean(xinit.var(dim)).item(),
                float('nan'),
             )]
        for i, down in enumerate(self.down_path):
            if i == 0:
                x_s = down(x_s)

            elif  i < len(self.down_path) - 1 :
                x_s, stats = down.signal_prop(x_s, dim=dim, sigma=sigma)
                statistics_down.append(stats)
            else :
                x_s, stats = down.signal_prop(x_s, dim=dim, sigma=sigma)
                statistics_down.append(stats)

            if i != len(self.down_path) - 1:
                # print('keeping x_s', x_s.shape)
                blocks.append(x_s)

        
            

        for i, up in enumerate(self.up_path):
            current_weight = self.res_weights[i]
           

            if self.skip_weight == 'softplus':
                current_weight = F.softplus(current_weight)
            elif self.skip_weight == 'sigmoid':
                current_weight = F.sigmoid(current_weight)
            elif self.skip_weight == 'relu':
                current_weight = utils.relu_straight_through(current_weight)

            out= current_weight*x_s+ blocks[-i - 1]
            
    

            out_mu2 = torch.mean(out.mean(dim) ** 2).item()
            out_var = torch.mean(out.var(dim)).item()
            res_var = torch.mean(x_s.var(dim)).item()
            x_s, stats = up.signal_prop(out, dim=dim, sigma=sigma)
            statistics_up.append(stats)
            lists_stats.append((out_mu2, out_var, res_var))
           
        x_s = self.final(x_s)    
        res_var = torch.mean(x_s.var(dim)).item()
        current_weight = self.res_weights[-1]
        
        if self.skip_weight == 'softplus':
            current_weight = F.softplus(current_weight)
        elif self.skip_weight == 'sigmoid':
            current_weight = F.sigmoid(current_weight)
        elif self.skip_weight == 'relu':
            current_weight = utils.relu_straight_through(current_weight)
        


        x_s = current_weight*x_s+xinit
        

        out_mu2 = torch.mean(x_s.mean(dim) ** 2).item()
        out_var = torch.mean(x_s.var(dim)).item()
        lists_stats.append((out_mu2, out_var, res_var))
  
                
        # convert list of tuples to tuple of lists
        lists_stats = tuple(map(list, zip(*lists_stats)))
        return x_s, statistics_down, statistics_up, lists_stats

######################################################################
#The NFDownBlock class handles the downsampling operation. 
# It takes as input the previous number of channels (prev_channels) and the desired number of output channels (wf). 
# It also has parameters for controlling the type of initialization, bias usage, normalization mode, and skip weight. 
# The block applies a sequence of residual blocks (NFResBlock, ResBlockWeight, or ResBlock) with the specified number of blocks (nb). 
# The downsampling operation is performed using the specified downsample_mode (e.g., stride convolution). 
# If downsample is set to True, the block applies the downsampling operation; otherwise, it applies an identity operation.

class NFDownBlock(nn.Module):

    expansion = 4

    def __init__(self,
        downsample_mode='strideconv',
        nb=2, 
        wf=16,
        type_init= 'xavier', 
        prev_channels = 64,
        keep_bias = False,
        mode = 'CRC',
        alpha = 1.0, 
        downsample = True, 
        expected_std=1.0, 
        block_type = 'resblock',
        skip_weight = None, 
        gain = 1.0,
        conditioned = None,
        use_linear=None, 
        use_sigma=False

    ):
        super().__init__()
        self.block_type = block_type

        self.use_sigma = use_sigma
    
        # downsample
        if downsample_mode == 'avgpool':
            downsample_block = B.downsample_avgpool
        elif downsample_mode == 'maxpool':
            downsample_block = B.downsample_maxpool
        elif downsample_mode == 'strideconv':
            downsample_block = B.downsample_strideconv
        else:
            raise NotImplementedError('downsample mode [{:s}] is not found'.format(downsample_mode))


        if block_type == 'NFblock':#(expected_std**2+(i+1)*alpha**2)**0.5
            self.branch = nn.Sequential(
                    *[B.NFResBlock(prev_channels, prev_channels, bias=keep_bias, mode=mode, type_init=type_init, 
                                beta = expected_std, alpha = alpha, gain=gain) for i in range(nb)]
                    )
        elif block_type == 'Halfresblock':
            self.branch = nn.Sequential(
                    *[B.HalfResBlock(prev_channels, prev_channels, bias=keep_bias, mode=mode, type_init=type_init, 
                                alpha = alpha) for _ in range(nb)]
                    )
        elif block_type == 'Wresblock':
            self.branch = nn.Sequential(
                *[B.ResBlockWeight(prev_channels, prev_channels, bias=keep_bias,
                                    mode=mode, type_init=type_init, skip_weight = skip_weight) for _ in range(nb)]
            )
        elif block_type == 'WresblockEmb':
            self.branch = nn.Sequential(
                *[B.ResBlockWeightEmb(prev_channels, prev_channels, bias=keep_bias,
                                    mode=mode, type_init=type_init, skip_weight = skip_weight) for _ in range(nb)]
            )
        elif block_type == 'resblock':
            self.branch = nn.Sequential(
                *[B.ResBlock(prev_channels, prev_channels, bias=keep_bias,
                                    mode=mode, type_init=type_init) for _ in range(nb)]
            )
        elif block_type == 'RCABlock':
            self.branch = nn.Sequential(
                *[B.RCABlock(prev_channels, prev_channels, bias=keep_bias,
                                    mode=mode, type_init=type_init,conditioned=conditioned, use_linear=use_linear, skip_weight=skip_weight) for _ in range(nb)]
            )



        else:
            raise NotImplementedError('block type [{:s}] is not found'.format(block_type))
            



        self.downsample = downsample_block(prev_channels, wf, bias=keep_bias, mode='2', type_init=type_init) if downsample else nn.Identity()

    def forward(self, x, sigma=None):
        if self.block_type == 'RCABlock' or self.use_sigma:
            for _, down in enumerate(self.branch):
                x = down(x, sigma=sigma)
            out = x
        else:
           out = self.branch(x)
        return self.downsample(out) 


    @torch.no_grad()
    def signal_prop(self, x, dim=(0, -1, -2), sigma = None):
        statistics = [(
            torch.mean(x.mean(dim) ** 2).item(),
            torch.mean(x.var(dim)).item(),
            float('nan'),
        )]
        # forward code
        for i, down in enumerate(self.branch):
            if self.block_type == 'RCABlock' or self.use_sigma:
                x, stats = down.signal_prop(x, dim=dim, sigma=sigma)
            else :
                x, stats = down.signal_prop(x,dim= dim)
            statistics.append(stats)
        # downsample
        out = self.downsample(x)
        # print("current statistics", statistics)
        sp = tuple(map(list, zip(*statistics)))

        return out, sp
    
#The NFUpBlock class handles the upsampling operation.
#  It takes similar input parameters as the NFDownBlock, including the upsample mode, number of blocks, weight initialization, etc. 
# The block applies an upsampling operation (e.g., convolution transpose) to increase the spatial dimensions of the input tensor. 
# It then applies a sequence of residual blocks similar to the NFDownBlock. 
# The upsampling operation is controlled by the upsample parameter, 
# and if set to True, the block performs the upsampling operation; otherwise, it applies an identity operation.
class NFUpBlock(nn.Module):


    def __init__(self,
        upsample_mode='upconv',
        nb=2, 
        wf=16,
        type_init= 'xavier', 
        prev_channels = 64,
        keep_bias = False,
        mode = 'CRC',
        alpha = 1.0, 
        upsample = True, 
        expected_std=1.0,
        block_type = 'resblock',
        skip_weight = None, 
        gain = 1.0, 
        use_linear=None,
        conditioned = None,
        use_sigma = False, 
        bUseComposition = False
    ):
        super().__init__()
        self.use_sigma = use_sigma

        # upsample
        if upsample_mode == 'upconv':
            upsample_block = B.upsample_upconv
        elif upsample_mode == 'pixelshuffle':
            upsample_block = B.upsample_pixelshuffle
        elif upsample_mode == 'convtranspose':
            upsample_block = B.upsample_convtranspose
        else:
            raise NotImplementedError('upsample mode [{:s}] is not found'.format(upsample_mode))

        self.upsample = upsample_block(prev_channels, wf, bias=keep_bias, mode='2', type_init=type_init) if upsample else nn.Identity()
        self.block_type = block_type

        if self.block_type == 'NFblock':
            self.branch = nn.Sequential(
                    *[B.NFResBlock(in_channels= wf, out_channels =wf, bias=keep_bias, mode=mode, type_init=type_init, 
                                beta = (expected_std**2+(i+1)*alpha**2)**0.5, alpha = alpha, gain=gain) for i in range(nb)]
                    )
        elif self.block_type == 'Halfresblock':
            self.branch = nn.Sequential(
                    *[B.HalfResBlock(in_channels= wf, out_channels =wf, bias=keep_bias, mode=mode, type_init=type_init, 
                               alpha = alpha) for i in range(nb)]
                    )
        elif self.block_type == 'Wresblock':
            self.branch = nn.Sequential(
                *[B.ResBlockWeight(in_channels= wf, out_channels =wf, bias=keep_bias,
                                    mode=mode, type_init=type_init, skip_weight = skip_weight) for _ in range(nb)]
            )
        elif self.block_type == 'WresblockEmb':
            self.branch = nn.Sequential(
                *[B.ResBlockWeightEmb(in_channels= wf, out_channels =wf, bias=keep_bias,
                                    mode=mode, type_init=type_init, skip_weight = skip_weight) for _ in range(nb)]
            )
        elif self.block_type == 'resblock':
            self.branch = nn.Sequential(
                *[B.ResBlock(in_channels= wf, out_channels =wf, bias=keep_bias,
                                    mode=mode, type_init=type_init) for _ in range(nb)]
            )
        elif self.block_type == 'RCABlock':
            self.branch = nn.Sequential(
                *[B.RCABlock(in_channels= wf, out_channels =wf, bias=keep_bias,
                                    mode=mode, type_init=type_init,conditioned=conditioned, use_linear=use_linear, skip_weight=skip_weight) for _ in range(nb)]
            )

        elif self.block_type =='PSA' :
            if bUseComposition :
                self.branch = B.PSA_s(inplanes= wf, planes =wf) 
            else :
                self.branch = B.PSA_p(inplanes= wf, planes =wf) 

        elif self.block_type =='NFblock-PSA' :
            if bUseComposition :
                self.branch = nn.Sequential(
                    *[B.NFResBlock(in_channels= wf, out_channels =wf, bias=keep_bias, mode=mode, type_init=type_init, 
                                beta = (expected_std**2+(i+1)*alpha**2)**0.5, alpha = alpha, gain=gain) for i in range(nb)],
                    B.PSA_s(inplanes= wf, planes =wf)
                    )
            else :
                self.branch = nn.Sequential(
                    *[B.NFResBlock(in_channels= wf, out_channels =wf, bias=keep_bias, mode=mode, type_init=type_init, 
                                beta = (expected_std**2+(i+1)*alpha**2)**0.5, alpha = alpha, gain=gain) for i in range(nb)],
                    B.PSA_p(inplanes= wf, planes =wf) 
                    )
                
            
        else:
            raise NotImplementedError('block type [{:s}] is not found'.format(self.block_type))
        
      

    def forward(self, x, sigma=None):
        if self.use_sigma or self.block_type == 'RCABlock':
            x = self.upsample(x)
            for _, up in enumerate(self.branch):
                x = up(x, sigma)
            out = x
            return out
        else:
            return self.branch(self.upsample(x))

    
    @torch.no_grad()
    def signal_prop(self, x, sigma=None, dim=(0, -1, -2, -3)): 
        i_in = x
        i_in = self.upsample(i_in)
        statistics = [(
            torch.mean(i_in.mean(dim) ** 2).item(),
            torch.mean(i_in.var(dim)).item(),
            float('nan'),
        )]
        # forward code
        for _, up in enumerate(self.branch):
            if self.use_sigma or self.block_type == 'RCABlock':
                i_in, stats = up.signal_prop(i_in,dim= dim, sigma=sigma)
            else :
                i_in, stats = up.signal_prop(i_in, dim=dim)
            statistics.append(stats)
        # upsample
        sp = tuple(map(list, zip(*statistics)))

        return i_in, sp

###################################################################
class NFUpConcatBlock(nn.Module):


    def __init__(self,
        upsample_mode='strideconv',
        nb=2, 
        wf=16,
        type_init= 'xavier', 
        prev_channels = 64,
        keep_bias = False,
        mode = 'CRC',
        alpha = 1.0, 
        upsample = True, 
        expected_std=1.0,
        block_type = 'resblock',
        skip_weight = None, 
        gain = 1.0
    ):
        super().__init__()

        # upsample
        if upsample_mode == 'upconv':
            upsample_block = B.upsample_upconv
        elif upsample_mode == 'pixelshuffle':
            upsample_block = B.upsample_pixelshuffle
        elif upsample_mode == 'convtranspose':
            upsample_block = B.upsample_convtranspose
        else:
            raise NotImplementedError('upsample mode [{:s}] is not found'.format(upsample_mode))

        self.upsample = upsample_block(prev_channels, wf, bias=keep_bias, mode='2', type_init=type_init) if upsample else nn.Identity()

        self.branch = B.ConvBlock(in_channels= 2*wf, out_channels =wf, bias=keep_bias, mode=mode, type_init=type_init) 


        # if block_type == 'NFblock':
        #     self.branch = nn.Sequential(
        #             *[B.NFResBlock(in_channels= wf, out_channels =wf, bias=keep_bias, mode=mode, type_init=type_init, 
        #                         beta = (expected_std**2+(i+1)*alpha**2)**0.5, alpha = alpha, gain=gain) for i in range(nb)]
        #             )
        # elif block_type == 'Wresblock':
        #     self.branch = nn.Sequential(
        #         *[B.ResBlockWeight(in_channels= wf, out_channels =wf, bias=keep_bias,
        #                             mode=mode, type_init=type_init, skip_weight = skip_weight) for _ in range(nb)]
        #     )
        # elif block_type == 'resblock':
        #     self.branch = nn.Sequential(
        #         *[B.ResBlock(in_channels= wf, out_channels =wf, bias=keep_bias,
        #                             mode=mode, type_init=type_init) for _ in range(nb)]
        #     )
        # else:
        #     raise NotImplementedError('block type [{:s}] is not found'.format(block_type))
        
      

    def forward(self, x, y):

        return self.branch(torch.cat((self.upsample(x),y),dim=1))

    
    @torch.no_grad()
    def signal_prop(self, x, y, dim=(0, -1, -2, -3)): 
        i_in = x
        
        statistics = [(
            torch.mean(i_in.mean(dim) ** 2).item(),
            torch.mean(i_in.var(dim)).item(),
            float('nan')
        )]
        i_in = self.branch(torch.cat((self.upsample(i_in),y),dim=1))
        statistics.append(
            (torch.mean(i_in.mean(dim) ** 2).item(),
            torch.mean(i_in.var(dim)).item(),
            float('nan'))
        )
        # forward code
        # for i, up in enumerate(self.branch):
        #     i_in, stats = up.signal_prop(i_in, dim)
        #     statistics.append(stats)
        # upsample
        sp = tuple(map(list, zip(*statistics)))

        return i_in, sp



###################################################################
class NFUpAttBlock(nn.Module):


    def __init__(self,
        upsample_mode='strideconv',
        nb=2, 
        wf=16,
        type_init= 'xavier', 
        prev_channels = 64,
        keep_bias = False,
        mode = 'CRC',
        alpha = 1.0, 
        upsample = True, 
        expected_std=1.0,
        block_type = 'resblock',
        skip_weight = None, 
        bUseComposition = False
    ):
        super().__init__()

        # upsample
        if upsample_mode == 'upconv':
            upsample_block = B.upsample_upconv
        elif upsample_mode == 'pixelshuffle':
            upsample_block = B.upsample_pixelshuffle
        elif upsample_mode == 'convtranspose':
            upsample_block = B.upsample_convtranspose
        else:
            raise NotImplementedError('upsample mode [{:s}] is not found'.format(upsample_mode))

        self.upsample = upsample_block(prev_channels, wf, bias=keep_bias, mode='2', type_init=type_init) if upsample else nn.Identity()

        # self.branch = B.ConvBlock(in_channels= 2*wf, out_channels =wf, bias=keep_bias, mode=mode, type_init=type_init) 
        if bUseComposition :
            self.branch = B.PSA_s(inplanes= 2*wf, planes =2*wf) 
        else :
            self.branch = B.PSA_p(inplanes= 2*wf, planes =2*wf) 
      

    def forward(self, x, y):
        out = torch.cat((self.upsample(x),y),dim=1)
        out, att_maps = self.branch(out)

        return out, att_maps

    
    @torch.no_grad()
    def signal_prop(self, x, y, dim=(0, -1, -2, -3)): 
        i_in = x
        
        statistics = [(
            torch.mean(i_in.mean(dim) ** 2).item(),
            torch.mean(i_in.var(dim)).item(),
            float('nan')
        )]
        i_in = self.branch(torch.cat((self.upsample(i_in),y),dim=1))
        statistics.append(
            (torch.mean(i_in.mean(dim) ** 2).item(),
            torch.mean(i_in.var(dim)).item(),
            float('nan'))
        )
        # forward code
        # for i, up in enumerate(self.branch):
        #     i_in, stats = up.signal_prop(i_in, dim)
        #     statistics.append(stats)
        # upsample
        sp = tuple(map(list, zip(*statistics)))

        return i_in, sp
   
###################################################################################
class NFUNetRes2Emb(nn.Module):
    def __init__(self, in_nc=2, 
                out_nc=1, 
                nb=2, 
                depth = 2, 
                wf=16,
                act_mode='R', 
                downsample_mode='strideconv', 
                upsample_mode='convtranspose', 
                norm = 'nonorm', 
                type_init= 'xavier', 
                skip_weight = None, 
                keep_bias = False, 
                alpha = 1.0,
                repeat = True
                ) :
        super(NFUNetRes2Emb, self).__init__() #nc=[16, 32, 64, 128],

        self.down_path = nn.ModuleList()
        self.down_path.append(B.conv(in_nc, wf, bias=keep_bias, mode='C'))
        prev_channels = wf
        self.down_scaling = nn.ModuleList()
        self.alpha = alpha
        self.nb = nb

        mode = get_norm_layer(norm, act_mode, repeat)        
        match act_mode:
            case 'R':  
                # with torch.no_grad():
                    # y = F.relu(torch.randn(1024, 256).cuda()) 
                    # gamma = y.var(dim=1, keepdim=True)
                gain = 1.7139588594436646 #1.2716004848480225 
                    #gamma.mean(dim=0, keepdim=True)

            case 'L':
                # with torch.no_grad():
                    # y = F.leaky_relu(torch.randn(1024, 256).cuda()) 
                    # gamma = y.var(dim=1, keepdim=True)
                gain =  1.70590341091156 #gamma.mean(dim=0, keepdim=True)
            case 'E':
                # with torch.no_grad():
                    # y = F.elu(torch.randn(1024, 256).cuda()) 
                    # gamma = y.var(dim=1, keepdim=True)
                gain = 1.2716004848480225 
                    #gamma.mean(dim=0, keepdim=True)

        # expected_std = ((1.0+(2*(depth)+1)*nb*(alpha**2))**0.5)
        expected_std = (((1.0+nb*(alpha**2))**(depth+1))*(1.0+nb*depth*(alpha**2)))**0.5
        self.init_scaling = B.Scaling(expected_std)

        list_expected_std_up = []
        list_expected_std_input = []

        for i in range(depth-1):
                        
            self.down_path.append(NFDownBlock(downsample_mode=downsample_mode, prev_channels= prev_channels, wf = wf*(2 ** (i+1)), alpha = self.alpha, expected_std = expected_std,
                                               nb = nb, keep_bias=keep_bias, mode=mode, type_init=type_init, block_type = 'NFblock', gain = gain)
                                               )                         
            expected_std = (expected_std **2 +  nb*(alpha**2))**0.5
            list_expected_std_input.append(expected_std)
            # list_expected_std_up.append((expected_std**2+(2*(depth-i)+1)*nb*(alpha**2))**0.5 )
            list_expected_std_up.append((((1.0+nb*(alpha**2))**(i+1))*(1.0+nb*depth*(alpha**2)))**0.5)
            # todo: add rescale
            self.down_scaling.append(B.Scaling(list_expected_std_up[-1])) 
            prev_channels = wf*(2 ** (i+1))
            # after 1 downblock
            

        self.down_path.append(NFDownBlock(expected_std= expected_std, alpha = self.alpha, prev_channels= prev_channels, downsample=False, 
                                          nb = nb, keep_bias=keep_bias, 
                                          mode=mode, type_init=type_init, block_type = 'NFblock', gain=gain)
                                          )
        expected_std = (expected_std ** 2 + alpha**2) ** 0.5

        self.up_path = nn.ModuleList()

        self.att_up_path = nn.ModuleList()
    
        for i in reversed(range(depth-1)):
            # beta = 1./ expected_std
            self.up_path.append(NFUpBlock(expected_std= expected_std, alpha = self.alpha, upsample_mode=upsample_mode, 
                                          prev_channels= prev_channels, nb=nb,
                                          wf=wf*(2 ** i), keep_bias=keep_bias, mode=mode,type_init=type_init, block_type = 'NFblock', gain=gain)
                                        )
            self.att_up_path.append(B.CCALayer2(prev_channels, use_linear = True, type_init=type_init))

            prev_channels = wf*(2 ** i)
            expected_std = (expected_std **2 +  nb*(alpha**2))**0.5

        self.final = B.conv(wf, out_nc, bias=keep_bias, mode='C', type_init=type_init)
        # expected_std = (expected_std**2 + 1.0)**0.5
        # self.beta = 1./ expected_std


    def forward(self, x, sigma):
        # sigma = x[:,1,1,1,1]
        blocks = []
        xinit = x
        x_s = self.init_scaling(xinit)
        for i, down in enumerate(self.down_path):

            x_s = down(x_s)

            if i != len(self.down_path) - 1:
                blocks.append(x_s)

            # if scaling common to res and id branches swap 
            
            if i > 0 and i != len(self.down_path) - 1:
                x_s = self.down_scaling[i-1](x_s)
                # expected_std = (self.list_expected_std_input[i-1] **2 +  self.nb*(self.alpha*self.list_expected_std_input[i-1]**2))**0.5
                # x_s = x_s/expected_std
                
        
        for i, up in enumerate(self.up_path):
            x_s = self.alpha*self.att_up_path[i](x_s, sigma)+ blocks[-i - 1]
            
            #x_s = torch.cat((x_s, sigma.view(-1,1,1,1,1).expand(-1,-1,x.size(2),x.size(3),x.size(4))), 1)
            x_s = up(x_s)
        
        x_s = self.final(x_s)   
        x_s = self.alpha*x_s +xinit[:,0,:,:].unsqueeze(1)
        return x_s


    @torch.no_grad()
    def signal_prop(self, x, sigma, dim=(0, -1, -2, -3)):

        blocks = []
        xinit = x
        x_s = self.init_scaling(xinit)
        statistics_down = []
        statistics_up = []
    
        lists_stats = [(
                torch.mean(xinit.mean(dim) ** 2).item(),
                torch.mean(xinit.var(dim)).item(),
                float('nan'),
             )]
        for i, down in enumerate(self.down_path):
            if i == 0:
                x_s = down(x_s)
            else :
                x_s, stats= down.signal_prop(x_s, dim)
                # stats is a list of tuples of 3 elements
                # list_stats is a tuple of 2 elements
                statistics_down.append(stats)
                # lists_stats.append(list_stats)

            if i != len(self.down_path) - 1:
                blocks.append(x_s)

            if i > 0 and i != len(self.down_path) - 1:
                x_s = self.down_scaling[i-1](x_s)
        
            

        for i, up in enumerate(self.up_path):
            out = self.alpha*x_s+ blocks[-i - 1]
            out_mu2 = torch.mean(out.mean(dim) ** 2).item()
            out_var = torch.mean(out.var(dim)).item()
            res_var = torch.mean(x_s.var(dim)).item()
            x_s, stats = up.signal_prop(out, dim)
            statistics_up.append(stats)
            lists_stats.append((out_mu2, out_var, res_var))
           
        x_s = self.final(x_s)   
        res_var = torch.mean(x_s.var(dim)).item()
        x_s = x_s+self.alpha*xinit
        out_mu2 = torch.mean(x_s.mean(dim) ** 2).item()
        out_var = torch.mean(x_s.var(dim)).item()
        lists_stats.append((out_mu2, out_var, res_var))
  
                
        # convert list of tuples to tuple of lists
        lists_stats = tuple(map(list, zip(*lists_stats)))
        return x_s, statistics_down, statistics_up, lists_stats   
###################################################################################


class NFUNetRes2Emb2(nn.Module):
    def __init__(self, in_nc=2, 
                out_nc=1, 
                nb=2, 
                depth = 2, 
                wf=16,
                act_mode='R', 
                downsample_mode='strideconv', 
                upsample_mode='convtranspose', 
                norm = 'nonorm', 
                type_init= 'xavier', 
                skip_weight = None, 
                keep_bias = False, 
                alpha = 1.0,
                repeat = True
                ) :
        super(NFUNetRes2Emb2, self).__init__() #nc=[16, 32, 64, 128],

        self.down_path = nn.ModuleList()
        self.down_path.append(B.conv(in_nc, wf, bias=keep_bias, mode='C'))
        prev_channels = wf
        self.down_scaling = nn.ModuleList()
        self.alpha = alpha
        self.nb = nb

        mode = get_norm_layer(norm, act_mode, repeat)        
        match act_mode:
            case 'R':  
                # with torch.no_grad():
                    # y = F.relu(torch.randn(1024, 256).cuda()) 
                    # gamma = y.var(dim=1, keepdim=True)
                gain = 1.7139588594436646 #1.2716004848480225 
                    #gamma.mean(dim=0, keepdim=True)

            case 'L':
                # with torch.no_grad():
                    # y = F.leaky_relu(torch.randn(1024, 256).cuda()) 
                    # gamma = y.var(dim=1, keepdim=True)
                gain =  1.70590341091156 #gamma.mean(dim=0, keepdim=True)
            case 'E':
                # with torch.no_grad():
                    # y = F.elu(torch.randn(1024, 256).cuda()) 
                    # gamma = y.var(dim=1, keepdim=True)
                gain = 1.2716004848480225 
                    #gamma.mean(dim=0, keepdim=True)

        # expected_std = ((1.0+(2*(depth)+1)*nb*(alpha**2))**0.5)
        expected_std = (((1.0+nb*(alpha**2))**(depth+1))*(1.0+nb*depth*(alpha**2)))**0.5
        self.init_scaling = B.Scaling(expected_std)

        list_expected_std_up = []
        list_expected_std_input = []

        self.res_weight = nn.Parameter(torch.FloatTensor([1.]))
        # self.res_weight_bias = nn.Parameter(torch.FloatTensor([0.]))

        for i in range(depth-1):
                        
            self.down_path.append(NFDownBlock(downsample_mode=downsample_mode, prev_channels= prev_channels, wf = wf*(2 ** (i+1)), alpha = self.alpha, expected_std = expected_std,
                                               nb = nb, keep_bias=keep_bias, mode=mode, type_init=type_init, block_type = 'NFblock', gain = gain)
                                               )                         
            expected_std = (expected_std **2 +  nb*(alpha**2))**0.5
            list_expected_std_input.append(expected_std)
            # list_expected_std_up.append((expected_std**2+(2*(depth-i)+1)*nb*(alpha**2))**0.5 )
            list_expected_std_up.append((((1.0+nb*(alpha**2))**(i+1))*(1.0+nb*depth*(alpha**2)))**0.5)
            # todo: add rescale
            self.down_scaling.append(B.Scaling(list_expected_std_up[-1])) 
            prev_channels = wf*(2 ** (i+1))
            # after 1 downblock
            

        self.down_path.append(NFDownBlock(expected_std= expected_std, alpha = self.alpha, prev_channels= prev_channels, downsample=False, 
                                          nb = nb, keep_bias=keep_bias, 
                                          mode=mode, type_init=type_init, block_type = 'NFblock', gain=gain)
                                          )
        expected_std = (expected_std ** 2 + alpha**2) ** 0.5

        self.up_path = nn.ModuleList()

    
        for i in reversed(range(depth-1)):
            # beta = 1./ expected_std
            self.up_path.append(NFUpBlock(expected_std= expected_std, alpha = self.alpha, upsample_mode=upsample_mode, 
                                          prev_channels= prev_channels, nb=nb,
                                          wf=wf*(2 ** i), keep_bias=keep_bias, mode=mode,type_init=type_init, block_type = 'NFblock', gain=gain)
                                        )

            prev_channels = wf*(2 ** i)
            expected_std = (expected_std **2 +  nb*(alpha**2))**0.5

        self.final = B.conv(wf, out_nc, bias=keep_bias, mode='C', type_init=type_init)
        # expected_std = (expected_std**2 + 1.0)**0.5
        # self.beta = 1./ expected_std


    def forward(self, x, sigma):
        # print("sigma is", sigma)
        # sigma = x[:,1,1,1,1]
        blocks = []
        xinit = x
        x_s = self.init_scaling(xinit)
        for i, down in enumerate(self.down_path):

            x_s = down(x_s)

            if i != len(self.down_path) - 1:
                blocks.append(x_s)

            # if scaling common to res and id branches swap 
            
            if i > 0 and i != len(self.down_path) - 1:
                x_s = self.down_scaling[i-1](x_s)
                # expected_std = (self.list_expected_std_input[i-1] **2 +  self.nb*(self.alpha*self.list_expected_std_input[i-1]**2))**0.5
                # x_s = x_s/expected_std
                
        
        for i, up in enumerate(self.up_path):
            x_s = self.alpha*x_s+ blocks[-i - 1]
            
            #x_s = torch.cat((x_s, sigma.view(-1,1,1,1,1).expand(-1,-1,x.size(2),x.size(3),x.size(4))), 1)
            x_s = up(x_s)
        
        x_s = self.final(x_s)   
        # print((self.alpha*self.res_weight*sigma).detach().squeeze().cpu().numpy())
        # x_s = 0.001*(self.alpha*self.res_weight*sigma).view(-1,1,1,1,1)*x_s +xinit[:,0,:,:].unsqueeze(1)
        # x_s = self.alpha*(self.res_weight*100.0*(1.0/sigma) + 1.0*self.res_weight_bias).view(-1,1,1,1,1)*x_s +xinit[:,0,:,:].unsqueeze(1)
        # x_s = self.alpha*(self.res_weight*10.0*sigma + 10.0*self.res_weight_bias).view(-1,1,1,1,1)*x_s +xinit[:,0,:,:].unsqueeze(1)
        x_s = self.alpha*(self.res_weight*100.0*(1.0/sigma)).view(-1,1,1,1,1)*x_s +xinit[:,0,:,:].unsqueeze(1)

        return x_s


    @torch.no_grad()
    def signal_prop(self, x, sigma, dim=(0, -1, -2, -3)):

        blocks = []
        xinit = x
        x_s = self.init_scaling(xinit)
        statistics_down = []
        statistics_up = []
    
        lists_stats = [(
                torch.mean(xinit.mean(dim) ** 2).item(),
                torch.mean(xinit.var(dim)).item(),
                float('nan'),
             )]
        for i, down in enumerate(self.down_path):
            if i == 0:
                x_s = down(x_s)
            else :
                x_s, stats= down.signal_prop(x_s, dim)
                # stats is a list of tuples of 3 elements
                # list_stats is a tuple of 2 elements
                statistics_down.append(stats)
                # lists_stats.append(list_stats)

            if i != len(self.down_path) - 1:
                blocks.append(x_s)

            if i > 0 and i != len(self.down_path) - 1:
                x_s = self.down_scaling[i-1](x_s)
        
            

        for i, up in enumerate(self.up_path):
            out = self.alpha*x_s+ blocks[-i - 1]
            out_mu2 = torch.mean(out.mean(dim) ** 2).item()
            out_var = torch.mean(out.var(dim)).item()
            res_var = torch.mean(x_s.var(dim)).item()
            x_s, stats = up.signal_prop(out, dim)
            statistics_up.append(stats)
            lists_stats.append((out_mu2, out_var, res_var))
           
        x_s = self.final(x_s)   
        res_var = torch.mean(x_s.var(dim)).item()
        x_s = x_s+self.alpha*xinit
        out_mu2 = torch.mean(x_s.mean(dim) ** 2).item()
        out_var = torch.mean(x_s.var(dim)).item()
        lists_stats.append((out_mu2, out_var, res_var))
  
                
        # convert list of tuples to tuple of lists
        lists_stats = tuple(map(list, zip(*lists_stats)))
        return x_s, statistics_down, statistics_up, lists_stats   


##################################################################################



class NFUNetRes2Emb1Att(nn.Module):
    def __init__(self, in_nc=2, 
                out_nc=1, 
                nb=2, 
                depth = 2, 
                wf=16,
                act_mode='R', 
                downsample_mode='strideconv', 
                upsample_mode='convtranspose', 
                norm = 'nonorm', 
                type_init= 'xavier', 
                skip_weight = None, 
                keep_bias = False, 
                alpha = 1.0,
                repeat = True, 
                nb_channels_noise = 1, 
                kernel_size_noise = 3
                ) :
        super(NFUNetRes2Emb1Att, self).__init__() #nc=[16, 32, 64, 128],

        self.down_path = nn.ModuleList()
        self.down_path.append(B.conv(in_nc, wf, bias=keep_bias, mode='C'))
        prev_channels = wf
        self.down_scaling = nn.ModuleList()
        self.alpha = alpha
        self.nb = nb

        mode = get_norm_layer(norm, act_mode, repeat)        
        match act_mode:
            case 'R':  
                # with torch.no_grad():
                    # y = F.relu(torch.randn(1024, 256).cuda()) 
                    # gamma = y.var(dim=1, keepdim=True)
                gain = 1.7139588594436646 #1.2716004848480225 
                    #gamma.mean(dim=0, keepdim=True)

            case 'L':
                # with torch.no_grad():
                    # y = F.leaky_relu(torch.randn(1024, 256).cuda()) 
                    # gamma = y.var(dim=1, keepdim=True)
                gain =  1.70590341091156 #gamma.mean(dim=0, keepdim=True)
            case 'E':
                # with torch.no_grad():
                    # y = F.elu(torch.randn(1024, 256).cuda()) 
                    # gamma = y.var(dim=1, keepdim=True)
                gain = 1.2716004848480225 
                    #gamma.mean(dim=0, keepdim=True)

        # expected_std = ((1.0+(2*(depth)+1)*nb*(alpha**2))**0.5)
        expected_std = (((1.0+nb*(alpha**2))**(depth+1))*(1.0+nb*depth*(alpha**2)))**0.5
        self.init_scaling = B.Scaling(expected_std)

        list_expected_std_up = []
        list_expected_std_input = []

        self.att = B.CCALayer4(nb_channels_noise, kernel_size_noise, type_init=type_init)



        for i in range(depth-1):
                        
            self.down_path.append(NFDownBlock(downsample_mode=downsample_mode, prev_channels= prev_channels, wf = wf*(2 ** (i+1)), alpha = self.alpha, expected_std = expected_std,
                                               nb = nb, keep_bias=keep_bias, mode=mode, type_init=type_init, block_type = 'NFblock', gain = gain)
                                               )                         
            expected_std = (expected_std **2 +  nb*(alpha**2))**0.5
            list_expected_std_input.append(expected_std)
            # list_expected_std_up.append((expected_std**2+(2*(depth-i)+1)*nb*(alpha**2))**0.5 )
            list_expected_std_up.append((((1.0+nb*(alpha**2))**(i+1))*(1.0+nb*depth*(alpha**2)))**0.5)
            # todo: add rescale
            self.down_scaling.append(B.Scaling(list_expected_std_up[-1])) 
            prev_channels = wf*(2 ** (i+1))
            # after 1 downblock
            

        self.down_path.append(NFDownBlock(expected_std= expected_std, alpha = self.alpha, prev_channels= prev_channels, downsample=False, 
                                          nb = nb, keep_bias=keep_bias, 
                                          mode=mode, type_init=type_init, block_type = 'NFblock', gain=gain)
                                          )
        expected_std = (expected_std ** 2 + alpha**2) ** 0.5

        self.up_path = nn.ModuleList()

    
        for i in reversed(range(depth-1)):
            # beta = 1./ expected_std
            self.up_path.append(NFUpBlock(expected_std= expected_std, alpha = self.alpha, upsample_mode=upsample_mode, 
                                          prev_channels= prev_channels, nb=nb,
                                          wf=wf*(2 ** i), keep_bias=keep_bias, mode=mode,type_init=type_init, block_type = 'NFblock', gain=gain)
                                        )

            prev_channels = wf*(2 ** i)
            expected_std = (expected_std **2 +  nb*(alpha**2))**0.5

        self.final = B.conv(wf, out_nc, bias=keep_bias, mode='C', type_init=type_init)
        # expected_std = (expected_std**2 + 1.0)**0.5
        # self.beta = 1./ expected_std


    def forward(self, x, sigma):
        # sigma = x[:,1,1,1,1]
        blocks = []
        xinit = x
        x_s = self.init_scaling(xinit)
        for i, down in enumerate(self.down_path):

            x_s = down(x_s)

            if i != len(self.down_path) - 1:
                blocks.append(x_s)

            # if scaling common to res and id branches swap 
            
            if i > 0 and i != len(self.down_path) - 1:
                x_s = self.down_scaling[i-1](x_s)
                # expected_std = (self.list_expected_std_input[i-1] **2 +  self.nb*(self.alpha*self.list_expected_std_input[i-1]**2))**0.5
                # x_s = x_s/expected_std
                
        
        for i, up in enumerate(self.up_path):
            x_s = self.alpha*x_s+ blocks[-i - 1]
            
            #x_s = torch.cat((x_s, sigma.view(-1,1,1,1,1).expand(-1,-1,x.size(2),x.size(3),x.size(4))), 1)
            x_s = up(x_s)
        
        x_s = self.final(x_s)   
        # print((self.alpha*self.res_weight*sigma).detach().squeeze().cpu().numpy())
        # x_s = (self.alpha*self.res_weight*sigma).view(-1,1,1,1,1)*x_s +xinit[:,0,:,:].unsqueeze(1)
        x_s = self.alpha*x_s*self.att(xinit[:,0,:,:].unsqueeze(1), sigma) +xinit[:,0,:,:].unsqueeze(1)
        return x_s


    @torch.no_grad()
    def signal_prop(self, x, sigma, dim=(0, -1, -2, -3)):

        blocks = []
        xinit = x
        x_s = self.init_scaling(xinit)
        statistics_down = []
        statistics_up = []
    
        lists_stats = [(
                torch.mean(xinit.mean(dim) ** 2).item(),
                torch.mean(xinit.var(dim)).item(),
                float('nan'),
             )]
        for i, down in enumerate(self.down_path):
            if i == 0:
                x_s = down(x_s)
            else :
                x_s, stats= down.signal_prop(x_s, dim)
                # stats is a list of tuples of 3 elements
                # list_stats is a tuple of 2 elements
                statistics_down.append(stats)
                # lists_stats.append(list_stats)

            if i != len(self.down_path) - 1:
                blocks.append(x_s)

            if i > 0 and i != len(self.down_path) - 1:
                x_s = self.down_scaling[i-1](x_s)
        
            

        for i, up in enumerate(self.up_path):
            out = self.alpha*x_s+ blocks[-i - 1]
            out_mu2 = torch.mean(out.mean(dim) ** 2).item()
            out_var = torch.mean(out.var(dim)).item()
            res_var = torch.mean(x_s.var(dim)).item()
            x_s, stats = up.signal_prop(out, dim)
            statistics_up.append(stats)
            lists_stats.append((out_mu2, out_var, res_var))
           
        x_s = self.final(x_s)   
        res_var = torch.mean(x_s.var(dim)).item()
        x_s = x_s+self.alpha*xinit
        out_mu2 = torch.mean(x_s.mean(dim) ** 2).item()
        out_var = torch.mean(x_s.var(dim)).item()
        lists_stats.append((out_mu2, out_var, res_var))
  
                
        # convert list of tuples to tuple of lists
        lists_stats = tuple(map(list, zip(*lists_stats)))
        return x_s, statistics_down, statistics_up, lists_stats   
    
    

##################################################################################
class NFUNetRes2(nn.Module):
    def __init__(self, in_nc=2, 
                out_nc=1, 
                nb=2, 
                depth = 2, 
                wf=16,
                act_mode='R', 
                downsample_mode='strideconv', 
                upsample_mode='convtranspose', 
                norm = 'nonorm', 
                type_init= 'xavier', 
                skip_weight = None, 
                keep_bias = False, 
                alpha = 1.0,
                repeat = True, 
                bUseClamp = True, 
                bUseAtt = False, 
                bUseComposition = False,
                bUseMask = False,
                use_gamma = False,
                bExtendedConv = False
                ) :
        super(NFUNetRes2, self).__init__() #nc=[16, 32, 64, 128],

        self.down_path = nn.ModuleList()
        # if bExtendedConv :
        #     self.down_path.append(B.conv(in_nc, wf, bias=keep_bias, mode='CRCRCRC'))
        # else :
        self.down_path.append(B.conv(in_nc, wf, bias=keep_bias, mode='C'))
        
        prev_channels = wf
        self.down_scaling = nn.ModuleList()
        self.alpha = alpha
        self.nb = nb
        self.bUseMask = bUseMask
        # self.bUseClamp = bUseClamp
        # self.use_gamma = use_gamma
        # if self.use_gamma :
        #     self.scale_gamma = nn.Parameter(torch.ones(1))

        mode = get_norm_layer(norm, act_mode, repeat)        
        match act_mode:
            case 'R':  
                # with torch.no_grad():
                    # y = F.relu(torch.randn(1024, 256).cuda()) 
                    # gamma = y.var(dim=1, keepdim=True)
                gain = 1.7139588594436646 #1.2716004848480225 
                    #gamma.mean(dim=0, keepdim=True)

            case 'L':
                # with torch.no_grad():
                    # y = F.leaky_relu(torch.randn(1024, 256).cuda()) 
                    # gamma = y.var(dim=1, keepdim=True)
                gain =  1.70590341091156 #gamma.mean(dim=0, keepdim=True)
            case 'E':
                # with torch.no_grad():
                    # y = F.elu(torch.randn(1024, 256).cuda()) 
                    # gamma = y.var(dim=1, keepdim=True)
                gain = 1.2716004848480225 
                    #gamma.mean(dim=0, keepdim=True)

        # expected_std = ((1.0+(2*(depth)+1)*nb*(alpha**2))**0.5)
        expected_std = (((1.0+nb*(alpha**2))**(depth+1))*(1.0+nb*depth*(alpha**2)))**0.5
        self.init_scaling = B.Scaling(expected_std)


        list_expected_std_up = []
        list_expected_std_input = []

        self.bUseAtt = bUseAtt

        for i in range(depth-1):
                        
            self.down_path.append(NFDownBlock(downsample_mode=downsample_mode, prev_channels= prev_channels, wf = wf*(2 ** (i+1)), alpha = self.alpha, expected_std = expected_std,
                                               nb = nb, keep_bias=keep_bias, mode=mode, type_init=type_init, block_type = 'NFblock', gain = gain)
                                               )                         
            expected_std = (expected_std **2 +  nb*(alpha**2))**0.5
            list_expected_std_input.append(expected_std)
            # list_expected_std_up.append((expected_std**2+(2*(depth-i)+1)*nb*(alpha**2))**0.5 )
            list_expected_std_up.append((((1.0+nb*(alpha**2))**(i+1))*(1.0+nb*depth*(alpha**2)))**0.5)
            # todo: add rescale
            self.down_scaling.append(B.Scaling(list_expected_std_up[-1])) 
            prev_channels = wf*(2 ** (i+1))
            # after 1 downblock
            

        self.down_path.append(NFDownBlock(expected_std= expected_std, alpha = self.alpha, prev_channels= prev_channels, downsample=False, 
                                          nb = nb, keep_bias=keep_bias, 
                                          mode=mode, type_init=type_init, block_type = 'NFblock', gain=gain)
                                          )
        expected_std = (expected_std ** 2 + alpha**2) ** 0.5

        self.up_path = nn.ModuleList()
    
        for i in reversed(range(depth-1)):
            # beta = 1./ expected_std
            self.up_path.append(NFUpBlock(expected_std= expected_std, alpha = self.alpha, upsample_mode=upsample_mode, 
                                            prev_channels= prev_channels, nb=nb,
                                            wf=wf*(2 ** i), keep_bias=keep_bias, mode=mode,type_init=type_init, 
                                            block_type = 'NFblock' if (i > 0 or not bUseAtt) else 'NFblock-PSA', gain=gain, bUseComposition=bUseComposition
                                            ))
           


            prev_channels = wf*(2 ** i)
            expected_std = (expected_std **2 +  nb*(alpha**2))**0.5

        if bExtendedConv :
            self.final = B.conv(wf, out_nc, bias=keep_bias, mode='CECECEC')
        else :
            self.final = B.conv(wf, out_nc, bias=keep_bias, mode='C', type_init=type_init)
        # expected_std = (expected_std**2 + 1.0)**0.5
        # self.beta = 1./ expected_std

        if bUseMask :
            self.mask = B.PSA_i(inplanes = 1) 
            # self.mask = B.PSA_o(inplanes = wf, planes= wf) 
           

    def forward(self, x):
        # if self.use_gamma :
        #     gamma = x[:,1,:,:,:].unsqueeze(1)
        #     x = x[:,0,:,:,:].unsqueeze(1)
        # if self.bUseClamp :
        #     x = torch.where(x>10000.0, torch.zeros_like(x), x)
        #     x = torch.where(x<-100, torch.zeros_like(x), x)
        if self.bUseMask: 
            x, my_mask = self.mask(x)
        # sigma = x[:,1,1,1,1]
        blocks = []
        xinit = x
        # print("xinit min max", xinit.min(), xinit.max())
        x_s = self.init_scaling(xinit)
        for i, down in enumerate(self.down_path):

            x_s = down(x_s)

            if i != len(self.down_path) - 1:
                blocks.append(x_s)

            # if scaling common to res and id branches swap 
            if i > 0 and i != len(self.down_path) - 1:
                x_s = self.down_scaling[i-1](x_s)
                # expected_std = (self.list_expected_std_input[i-1] **2 +  self.nb*(self.alpha*self.list_expected_std_input[i-1]**2))**0.5
                # x_s = x_s/expected_std
                
        
        for i, up in enumerate(self.up_path):
            # x_s = self.alpha*x_s+ blocks[-i - 1]
            
            
            # #x_s = torch.cat((x_s, sigma.view(-1,1,1,1,1).expand(-1,-1,x.size(2),x.size(3),x.size(4))), 1)
            # x_s = up(x_s)

                        
            if i == len(self.up_path) - 1 and self.bUseAtt:
                x_s, att_maps = up(self.alpha*x_s+blocks[-i - 1])
            else :
                x_s = up(self.alpha*x_s+ blocks[-i - 1])
            
        # if self.bUseMask: 
        #     x_s, my_mask = self.mask(x_s)
            # att_maps_final = x_s
        x_s = self.final(x_s)   
        # x_s = self.alpha*x_s +xinit[:,0,:,:].unsqueeze(1)
        # if self.use_gamma :                
        #     # x_s = (1.0-(self.scale_gamma*F.sigmoid(gamma)))*self.alpha*x_s+(self.scale_gamma*F.sigmoid(gamma))*xinit[:,0,:,:].unsqueeze(1)
        #     x_s = ((self.scale_gamma*F.sigmoid(gamma)))*self.alpha*x_s+(1.0-self.scale_gamma*F.sigmoid(gamma))*xinit[:,0,:,:].unsqueeze(1)
        # else :
        #     x_s = self.alpha*x_s +xinit[:,0,:,:].unsqueeze(1)

        # x_s = self.alpha*x_s +xinit
        # x_s = (x_s[:,0,:,:]*x_s[:,1,:,:]).unsqueeze(1)
        if self.bUseMask :
            return F.relu(x_s), my_mask #, att_maps
        else :
            return utils.relu_straight_through(x_s) #, None #att_maps


    @torch.no_grad()
    def signal_prop(self, x, dim=(0, -1, -2, -3)):

        blocks = []
        xinit = x
        x_s = self.init_scaling(xinit)
        statistics_down = []
        statistics_up = []
    
        lists_stats = [(
                torch.mean(xinit.mean(dim) ** 2).item(),
                torch.mean(xinit.var(dim)).item(),
                float('nan'),
             )]
        for i, down in enumerate(self.down_path):
            if i == 0:
                x_s = down(x_s)
            else :
                x_s, stats= down.signal_prop(x_s, dim)
                # stats is a list of tuples of 3 elements
                # list_stats is a tuple of 2 elements
                statistics_down.append(stats)
                # lists_stats.append(list_stats)

            if i != len(self.down_path) - 1:
                blocks.append(x_s)

            if i > 0 and i != len(self.down_path) - 1:
                x_s = self.down_scaling[i-1](x_s)
        
            

        for i, up in enumerate(self.up_path):
            out = self.alpha*x_s+ blocks[-i - 1]
            out_mu2 = torch.mean(out.mean(dim) ** 2).item()
            out_var = torch.mean(out.var(dim)).item()
            res_var = torch.mean(x_s.var(dim)).item()
            x_s, stats = up.signal_prop(out, dim)
            statistics_up.append(stats)
            lists_stats.append((out_mu2, out_var, res_var))
           
        x_s = self.final(x_s)   
        res_var = torch.mean(x_s.var(dim)).item()
        x_s = x_s+self.alpha*xinit
        out_mu2 = torch.mean(x_s.mean(dim) ** 2).item()
        out_var = torch.mean(x_s.var(dim)).item()
        lists_stats.append((out_mu2, out_var, res_var))
  
                
        # convert list of tuples to tuple of lists
        lists_stats = tuple(map(list, zip(*lists_stats)))
        return x_s, statistics_down, statistics_up, lists_stats
    
###########################################

class AvgNFUNetRes2(nn.Module):
    def __init__(self, in_nc=2, 
                out_nc=1, 
                nb=2, 
                depth = 2, 
                wf=16,
                act_mode='R', 
                downsample_mode='strideconv', 
                upsample_mode='convtranspose', 
                norm = 'nonorm', 
                type_init= 'xavier', 
                skip_weight = None, 
                keep_bias = False, 
                alpha = 1.0,
                repeat = True, 
                bUseClamp = True, 
                bUseAtt = False, 
                bUseComposition = False,
                bUseMask = False,
                use_gamma = False
                ) :
        super(AvgNFUNetRes2, self).__init__()  

        self.model1 = NFUNetRes2(in_nc, out_nc, nb, depth, wf, act_mode, downsample_mode, upsample_mode, norm, type_init, skip_weight, keep_bias, alpha, repeat, bUseClamp, bUseAtt, bUseComposition, bUseMask, use_gamma)
        self.model2 = NFUNetRes2(in_nc, out_nc, nb, depth, wf, act_mode, downsample_mode, upsample_mode, norm, type_init, skip_weight, keep_bias, alpha, repeat, bUseClamp, bUseAtt, bUseComposition, bUseMask, use_gamma)
        # self.weight = nn.Parameter(torch.zeros(1))      

    def forward(self, x):
        # weight = F.sigmoid(5*self.weight)
        # return (weight*self.model1(x) + (1.0-weight)*self.model2(x))
        return (0.5*self.model1(x) + 0.5*self.model2(x))
       


###########################################
class NFUNetResMultBranch2Decoder(nn.Module):
    def __init__(self, in_nc=2, 
                out_nc=1, 
                nb=2, 
                depth = 2, 
                wf=16,
                act_mode='R', 
                downsample_mode='strideconv', 
                upsample_mode='convtranspose', 
                norm = 'nonorm', 
                type_init= 'xavier', 
                alpha = 1.0,
                repeat = True, 
                bUse_N = True
                ) :
        super(NFUNetResMultBranch2Decoder, self).__init__() 

        self.down_path = nn.ModuleList()
        self.down_path.append(B.conv(in_nc, wf, bias=False, mode='C'))

        self.down_path2 = nn.ModuleList()
        self.down_path2.append(B.conv(in_nc, wf, bias=False, mode='C'))

        prev_channels = wf
        self.down_scaling = nn.ModuleList()
        self.alpha = alpha
        self.nb = nb


        mode = get_norm_layer(norm, act_mode, repeat)        
        match act_mode:
            case 'R':  
                gain = 1.7139588594436646 
            case 'L':
                gain =  1.70590341091156 
            case 'E':
                gain = 1.2716004848480225 
                   
        expected_std = (((1.0+nb*(alpha**2))**(depth+1))*(1.0+nb*depth*(alpha**2)))**0.5
        self.init_scaling = B.Scaling(expected_std)

        list_expected_std_up = []
        list_expected_std_input = []

        self.res_weights = nn.ParameterList([nn.Parameter(torch.FloatTensor([0.])) for i in range(depth-1)])


        for i in range(depth-1):
                        
            self.down_path.append(NFDownBlock(downsample_mode=downsample_mode, prev_channels= prev_channels, wf = wf*(2 ** (i+1)), alpha = self.alpha, expected_std = expected_std,
                                               nb = nb, keep_bias=False, mode=mode, type_init=type_init, block_type = 'NFblock', gain = gain)
                                               )
            self.down_path2.append(NFDownBlock(downsample_mode=downsample_mode, prev_channels= prev_channels, wf = wf*(2 ** (i+1)), alpha = self.alpha, expected_std = expected_std,
                                                  nb = nb, keep_bias=False, mode=mode, type_init=type_init, block_type = 'NFblock', gain = gain)
                                                  )
            expected_std = (expected_std **2 +  nb*(alpha**2))**0.5
            list_expected_std_input.append(expected_std)
            list_expected_std_up.append((((1.0+nb*(alpha**2))**(i+1))*(1.0+nb*depth*(alpha**2)))**0.5)
            self.down_scaling.append(B.Scaling(list_expected_std_up[-1])) 
            prev_channels = wf*(2 ** (i+1))
            

        self.down_path.append(NFDownBlock(expected_std= expected_std, alpha = self.alpha, prev_channels= prev_channels, downsample=False, 
                                          nb = nb, keep_bias=False, mode=mode, type_init=type_init, block_type = 'NFblock', gain=gain)
                                          )
        self.down_path2.append(NFDownBlock(expected_std= expected_std, alpha = self.alpha, prev_channels= prev_channels, downsample=False,
                                           nb=nb, keep_bias=False, mode=mode, type_init=type_init, block_type = 'NFblock', gain=gain)
        
                                  )
        self.fusion = B.conv(2*prev_channels,prev_channels, bias=False, mode='CE', type_init=type_init)
        if bUse_N :
            self.normalization = B.conv(out_channels=[2*prev_channels, int(104/(2 ** (depth-1))),  int(128/(2 ** (depth-1))),  int(128/(2 ** (depth-1)))], mode="G")
        else :
            self.normalization = nn.Identity()
        expected_std = (expected_std ** 2 + alpha**2) ** 0.5

        self.up_path = nn.ModuleList()
    
        for i in reversed(range(depth-1)):
            self.up_path.append(NFUpBlock(expected_std= expected_std, alpha = self.alpha, upsample_mode=upsample_mode, 
                                            prev_channels= prev_channels, nb=nb,
                                            wf=wf*(2 ** i), keep_bias=False, mode=mode,type_init=type_init, 
                                            block_type = 'NFblock', gain=gain))
           


            prev_channels = wf*(2 ** i)
            expected_std = (expected_std **2 +  nb*(alpha**2))**0.5

        self.final = B.conv(wf, out_nc, bias=False, mode='C', type_init=type_init)


    def forward(self, x, xcond):
        
       
        blocks = []
        blocks2 = []
        xinit = x
        x_s = self.init_scaling(xinit)
        for i, down in enumerate(self.down_path):

            x_s = down(x_s)

            if i != len(self.down_path) - 1:
                blocks.append(x_s)

            # if scaling common to res and id branches swap 
            if i > 0 and i != len(self.down_path) - 1:
                x_s = self.down_scaling[i-1](x_s)

        xcond_s = self.init_scaling(xcond)
        for i, down in enumerate(self.down_path2):

            xcond_s = down(xcond_s)
            if i != len(self.down_path2) - 1:
                blocks2.append(xcond_s)

            # if scaling common to res and id branches swap 
            if i > 0 and i != len(self.down_path) - 1:
                xcond_s = self.down_scaling[i-1](xcond_s)

        x_s = self.normalization(torch.cat((x_s, xcond_s), 1))
        x_s = self.fusion(x_s)

        for i, up in enumerate(self.up_path):          
            x_s = up(self.alpha*x_s+ blocks[-i - 1] + self.res_weights[i]*blocks2[-i - 1])
            
      
        x_s = self.final(x_s)   
       
        return utils.relu_straight_through(x_s)  

##################################################################################
class NFUNetResMultBranch(nn.Module):
    def __init__(self, in_nc=2, 
                out_nc=1, 
                nb=2, 
                depth = 2, 
                wf=16,
                act_mode='R', 
                downsample_mode='strideconv', 
                upsample_mode='convtranspose', 
                norm = 'nonorm', 
                type_init= 'xavier', 
                alpha = 1.0,
                repeat = True, 
                bUse_N = True
                ) :
        super(NFUNetResMultBranch, self).__init__() 

        self.down_path = nn.ModuleList()
        self.down_path.append(B.conv(in_nc, wf, bias=False, mode='C'))

        self.down_path2 = nn.ModuleList()
        self.down_path2.append(B.conv(in_nc, wf, bias=False, mode='C'))

        prev_channels = wf
        self.down_scaling = nn.ModuleList()
        self.alpha = alpha
        self.nb = nb


        mode = get_norm_layer(norm, act_mode, repeat)        
        match act_mode:
            case 'R':  
                gain = 1.7139588594436646 
            case 'L':
                gain =  1.70590341091156 
            case 'E':
                gain = 1.2716004848480225 
                   
        expected_std = (((1.0+nb*(alpha**2))**(depth+1))*(1.0+nb*depth*(alpha**2)))**0.5
        self.init_scaling = B.Scaling(expected_std)

        list_expected_std_up = []
        list_expected_std_input = []


        for i in range(depth-1):
                        
            self.down_path.append(NFDownBlock(downsample_mode=downsample_mode, prev_channels= prev_channels, wf = wf*(2 ** (i+1)), alpha = self.alpha, expected_std = expected_std,
                                               nb = nb, keep_bias=False, mode=mode, type_init=type_init, block_type = 'NFblock', gain = gain)
                                               )
            self.down_path2.append(NFDownBlock(downsample_mode=downsample_mode, prev_channels= prev_channels, wf = wf*(2 ** (i+1)), alpha = self.alpha, expected_std = expected_std,
                                                  nb = nb, keep_bias=False, mode=mode, type_init=type_init, block_type = 'NFblock', gain = gain)
                                                  )
            expected_std = (expected_std **2 +  nb*(alpha**2))**0.5
            list_expected_std_input.append(expected_std)
            list_expected_std_up.append((((1.0+nb*(alpha**2))**(i+1))*(1.0+nb*depth*(alpha**2)))**0.5)
            self.down_scaling.append(B.Scaling(list_expected_std_up[-1])) 
            prev_channels = wf*(2 ** (i+1))
            

        self.down_path.append(NFDownBlock(expected_std= expected_std, alpha = self.alpha, prev_channels= prev_channels, downsample=False, 
                                          nb = nb, keep_bias=False, mode=mode, type_init=type_init, block_type = 'NFblock', gain=gain)
                                          )
        self.down_path2.append(NFDownBlock(expected_std= expected_std, alpha = self.alpha, prev_channels= prev_channels, downsample=False,
                                           nb=nb, keep_bias=False, mode=mode, type_init=type_init, block_type = 'NFblock', gain=gain)
        
                                  )
        self.fusion = B.conv(2*prev_channels,prev_channels, bias=False, mode='CE', type_init=type_init)
        if bUse_N :
            self.normalization = B.conv(out_channels=[2*prev_channels, int(104/(2 ** (depth-1))),  int(128/(2 ** (depth-1))),  int(128/(2 ** (depth-1)))], mode="G")
        else :
            self.normalization = nn.Identity()
        expected_std = (expected_std ** 2 + alpha**2) ** 0.5

        self.up_path = nn.ModuleList()
    
        for i in reversed(range(depth-1)):
            self.up_path.append(NFUpBlock(expected_std= expected_std, alpha = self.alpha, upsample_mode=upsample_mode, 
                                            prev_channels= prev_channels, nb=nb,
                                            wf=wf*(2 ** i), keep_bias=False, mode=mode,type_init=type_init, 
                                            block_type = 'NFblock', gain=gain))
           


            prev_channels = wf*(2 ** i)
            expected_std = (expected_std **2 +  nb*(alpha**2))**0.5

        self.final = B.conv(wf, out_nc, bias=False, mode='C', type_init=type_init)


    def forward(self, x, xcond):
        
       
        blocks = []
        xinit = x
        x_s = self.init_scaling(xinit)
        for i, down in enumerate(self.down_path):

            x_s = down(x_s)

            if i != len(self.down_path) - 1:
                blocks.append(x_s)

            # if scaling common to res and id branches swap 
            if i > 0 and i != len(self.down_path) - 1:
                x_s = self.down_scaling[i-1](x_s)

        xcond_s = self.init_scaling(xcond)
        for i, down in enumerate(self.down_path2):

            xcond_s = down(xcond_s)

            # if scaling common to res and id branches swap 
            if i > 0 and i != len(self.down_path) - 1:
                xcond_s = self.down_scaling[i-1](xcond_s)

        x_s = self.normalization(torch.cat((x_s, xcond_s), 1))
        x_s = self.fusion(x_s)

        for i, up in enumerate(self.up_path):          
            x_s = up(self.alpha*x_s+ blocks[-i - 1])
            
      
        x_s = self.final(x_s)   
       
        return utils.relu_straight_through(x_s)  


class NFUNetResMultChan(nn.Module):
    def __init__(self, in_nc=2, 
                out_nc=1, 
                nb=2, 
                depth = 2, 
                wf=16,
                act_mode='R', 
                downsample_mode='strideconv', 
                upsample_mode='convtranspose', 
                norm = 'nonorm', 
                type_init= 'xavier', 
                alpha = 1.0,
                repeat = True,
                bUse_N = True
                ) :
        super(NFUNetResMultChan, self).__init__() 
        if bUse_N :
            self.normalization = B.conv(out_channels=[2, 104, 128, 128], mode='G')
        else :
            self.normalization = nn.Identity()

        self.down_path = nn.ModuleList()
        self.down_path.append(B.conv(2*in_nc, wf, bias=False, mode='C'))


        prev_channels = wf
        self.down_scaling = nn.ModuleList()
        self.alpha = alpha
        self.nb = nb


        mode = get_norm_layer(norm, act_mode, repeat)        
        match act_mode:
            case 'R':  
                gain = 1.7139588594436646 
            case 'L':
                gain =  1.70590341091156 
            case 'E':
                gain = 1.2716004848480225 
                   
        expected_std = (((1.0+nb*(alpha**2))**(depth+1))*(1.0+nb*depth*(alpha**2)))**0.5
        self.init_scaling = B.Scaling(expected_std)

        list_expected_std_up = []
        list_expected_std_input = []


        for i in range(depth-1):
                        
            self.down_path.append(NFDownBlock(downsample_mode=downsample_mode, prev_channels= prev_channels, wf = wf*(2 ** (i+1)), alpha = self.alpha, expected_std = expected_std,
                                               nb = nb, keep_bias=False, mode=mode, type_init=type_init, block_type = 'NFblock', gain = gain)
                                               )
         
            expected_std = (expected_std **2 +  nb*(alpha**2))**0.5
            list_expected_std_input.append(expected_std)
            list_expected_std_up.append((((1.0+nb*(alpha**2))**(i+1))*(1.0+nb*depth*(alpha**2)))**0.5)
            self.down_scaling.append(B.Scaling(list_expected_std_up[-1])) 
            prev_channels = wf*(2 ** (i+1))
            

        self.down_path.append(NFDownBlock(expected_std= expected_std, alpha = self.alpha, prev_channels= prev_channels, downsample=False, 
                                          nb = nb, keep_bias=False, mode=mode, type_init=type_init, block_type = 'NFblock', gain=gain)
                                          )
      
        expected_std = (expected_std ** 2 + alpha**2) ** 0.5

        self.up_path = nn.ModuleList()
    
        for i in reversed(range(depth-1)):
            self.up_path.append(NFUpBlock(expected_std= expected_std, alpha = self.alpha, upsample_mode=upsample_mode, 
                                            prev_channels= prev_channels, nb=nb,
                                            wf=wf*(2 ** i), keep_bias=False, mode=mode,type_init=type_init, 
                                            block_type = 'NFblock', gain=gain))
           


            prev_channels = wf*(2 ** i)
            expected_std = (expected_std **2 +  nb*(alpha**2))**0.5

        self.final = B.conv(wf, out_nc, bias=False, mode='C', type_init=type_init)
        self.res_weight = nn.Parameter(torch.FloatTensor([1.]))


    def forward(self, x, xcond):
        
       
        blocks = []
        x_s = self.init_scaling(torch.cat((x, self.res_weight*xcond), 1))
        x_s = self.normalization(x_s)
        for i, down in enumerate(self.down_path):

            x_s = down(x_s)

            if i != len(self.down_path) - 1:
                blocks.append(x_s)

            # if scaling common to res and id branches swap 
            if i > 0 and i != len(self.down_path) - 1:
                x_s = self.down_scaling[i-1](x_s)

        

        for i, up in enumerate(self.up_path):          
            x_s = up(self.alpha*x_s+ blocks[-i - 1])
            
      
        x_s = self.final(x_s)   
       
        return utils.relu_straight_through(x_s)  
   
    

###########################################

class NFDRUNet(nn.Module):
    def __init__(self, in_nc=2, 
                out_nc=1, 
                nb=2, 
                depth = 2, 
                wf=16,
                act_mode='R', 
                downsample_mode='strideconv', 
                upsample_mode='convtranspose', 
                norm = 'nonorm', 
                type_init= 'xavier', 
                skip_weight = None, 
                keep_bias = False, 
                alpha = 1.0,
                repeat = True, 
                bUseClamp = True, 
                bUseAtt = False, 
                bUseComposition = False,
                bUseMask = False,
                use_gamma = False
                ) :
        super(NFDRUNet, self).__init__() #nc=[16, 32, 64, 128],

        self.down_path = nn.ModuleList()
        self.down_path.append(B.conv(in_nc, wf, bias=keep_bias, mode='C'))
        prev_channels = wf
        self.down_scaling = nn.ModuleList()
        self.alpha = alpha
        self.nb = nb
        self.bUseMask = bUseMask
        # self.bUseClamp = bUseClamp
        # self.use_gamma = use_gamma
        # if self.use_gamma :
        #     self.scale_gamma = nn.Parameter(torch.ones(1))

        mode = get_norm_layer(norm, act_mode, repeat)        
        match act_mode:
            case 'R':  
                # with torch.no_grad():
                    # y = F.relu(torch.randn(1024, 256).cuda()) 
                    # gamma = y.var(dim=1, keepdim=True)
                gain = 1.7139588594436646 #1.2716004848480225 
                    #gamma.mean(dim=0, keepdim=True)

            case 'L':
                # with torch.no_grad():
                    # y = F.leaky_relu(torch.randn(1024, 256).cuda()) 
                    # gamma = y.var(dim=1, keepdim=True)
                gain =  1.70590341091156 #gamma.mean(dim=0, keepdim=True)
            case 'E':
                # with torch.no_grad():
                    # y = F.elu(torch.randn(1024, 256).cuda()) 
                    # gamma = y.var(dim=1, keepdim=True)
                gain = 1.2716004848480225 
                    #gamma.mean(dim=0, keepdim=True)

        # expected_std = ((1.0+(2*(depth)+1)*nb*(alpha**2))**0.5)
        expected_std = (((1.0+nb*(alpha**2))**(depth+1))*(1.0+nb*depth*(alpha**2)))**0.5
        self.init_scaling = B.Scaling(expected_std)

        list_expected_std_up = []
        list_expected_std_input = []

        self.bUseAtt = bUseAtt

        for i in range(depth-1):
                        
            self.down_path.append(NFDownBlock(downsample_mode=downsample_mode, prev_channels= prev_channels, wf = wf*(2 ** (i+1)), alpha = self.alpha, expected_std = expected_std,
                                               nb = nb, keep_bias=keep_bias, mode=mode, type_init=type_init, block_type = 'NFblock', gain = gain)
                                               )                         
            expected_std = (expected_std **2 +  nb*(alpha**2))**0.5
            list_expected_std_input.append(expected_std)
            # list_expected_std_up.append((expected_std**2+(2*(depth-i)+1)*nb*(alpha**2))**0.5 )
            list_expected_std_up.append((((1.0+nb*(alpha**2))**(i+1))*(1.0+nb*depth*(alpha**2)))**0.5)
            # todo: add rescale
            self.down_scaling.append(B.Scaling(list_expected_std_up[-1])) 
            prev_channels = wf*(2 ** (i+1))
            # after 1 downblock
            

        self.down_path.append(NFDownBlock(expected_std= expected_std, alpha = self.alpha, prev_channels= prev_channels, downsample=False, 
                                          nb = nb, keep_bias=keep_bias, 
                                          mode=mode, type_init=type_init, block_type = 'NFblock', gain=gain)
                                          )
        expected_std = (expected_std ** 2 + alpha**2) ** 0.5

        self.up_path = nn.ModuleList()
    
        for i in reversed(range(depth-1)):
            # beta = 1./ expected_std
            self.up_path.append(NFUpBlock(expected_std= expected_std, alpha = self.alpha, upsample_mode=upsample_mode, 
                                            prev_channels= prev_channels, nb=nb,
                                            wf=wf*(2 ** i), keep_bias=keep_bias, mode=mode,type_init=type_init, 
                                            block_type = 'NFblock' if (i > 0 or not bUseAtt) else 'NFblock-PSA', gain=gain, bUseComposition=bUseComposition
                                            ))
           


            prev_channels = wf*(2 ** i)
            expected_std = (expected_std **2 +  nb*(alpha**2))**0.5

        self.final = B.conv(wf, out_nc, bias=keep_bias, mode='C', type_init=type_init)
        # expected_std = (expected_std**2 + 1.0)**0.5
        # self.beta = 1./ expected_std

        if bUseMask :
            self.mask = B.PSA_i(inplanes = 1) 
            # self.mask = B.PSA_o(inplanes = wf, planes= wf) 
           

    def forward(self, x):
        # if self.use_gamma :
        #     gamma = x[:,1,:,:,:].unsqueeze(1)
        #     x = x[:,0,:,:,:].unsqueeze(1)
        # if self.bUseClamp :
        #     x = torch.where(x>10000.0, torch.zeros_like(x), x)
        #     x = torch.where(x<-100, torch.zeros_like(x), x)
        if self.bUseMask: 
            x, my_mask = self.mask(x)
        # sigma = x[:,1,1,1,1]
        blocks = []
        xinit = x
        # print("xinit min max", xinit.min(), xinit.max())
        x_s = self.init_scaling(xinit)
        for i, down in enumerate(self.down_path):

            x_s = down(x_s)

            if i != len(self.down_path) - 1:
                blocks.append(x_s)

            # if scaling common to res and id branches swap 
            if i > 0 and i != len(self.down_path) - 1:
                x_s = self.down_scaling[i-1](x_s)
                # expected_std = (self.list_expected_std_input[i-1] **2 +  self.nb*(self.alpha*self.list_expected_std_input[i-1]**2))**0.5
                # x_s = x_s/expected_std
                
        
        for i, up in enumerate(self.up_path):
            # x_s = self.alpha*x_s+ blocks[-i - 1]
            
            
            # #x_s = torch.cat((x_s, sigma.view(-1,1,1,1,1).expand(-1,-1,x.size(2),x.size(3),x.size(4))), 1)
            # x_s = up(x_s)

                        
            if i == len(self.up_path) - 1 and self.bUseAtt:
                x_s, att_maps = up(self.alpha*x_s+blocks[-i - 1])
            else :
                x_s = up(self.alpha*x_s+ blocks[-i - 1])
            
        # if self.bUseMask: 
        #     x_s, my_mask = self.mask(x_s)
            # att_maps_final = x_s
        x_s = self.final(x_s)   
        x_s = self.alpha*x_s +xinit[:,0,:,:].unsqueeze(1)
        # if self.use_gamma :                
        #     # x_s = (1.0-(self.scale_gamma*F.sigmoid(gamma)))*self.alpha*x_s+(self.scale_gamma*F.sigmoid(gamma))*xinit[:,0,:,:].unsqueeze(1)
        #     x_s = ((self.scale_gamma*F.sigmoid(gamma)))*self.alpha*x_s+(1.0-self.scale_gamma*F.sigmoid(gamma))*xinit[:,0,:,:].unsqueeze(1)
        # else :
        #     x_s = self.alpha*x_s +xinit[:,0,:,:].unsqueeze(1)

        # x_s = self.alpha*x_s +xinit
        # x_s = (x_s[:,0,:,:]*x_s[:,1,:,:]).unsqueeze(1)
        if self.bUseMask :
            return F.relu(x_s), my_mask #, att_maps
        else :
            return utils.relu_straight_through(x_s) #, None #att_maps


    @torch.no_grad()
    def signal_prop(self, x, dim=(0, -1, -2, -3)):

        blocks = []
        xinit = x
        x_s = self.init_scaling(xinit)
        statistics_down = []
        statistics_up = []
    
        lists_stats = [(
                torch.mean(xinit.mean(dim) ** 2).item(),
                torch.mean(xinit.var(dim)).item(),
                float('nan'),
             )]
        for i, down in enumerate(self.down_path):
            if i == 0:
                x_s = down(x_s)
            else :
                x_s, stats= down.signal_prop(x_s, dim)
                # stats is a list of tuples of 3 elements
                # list_stats is a tuple of 2 elements
                statistics_down.append(stats)
                # lists_stats.append(list_stats)

            if i != len(self.down_path) - 1:
                blocks.append(x_s)

            if i > 0 and i != len(self.down_path) - 1:
                x_s = self.down_scaling[i-1](x_s)
        
            

        for i, up in enumerate(self.up_path):
            out = self.alpha*x_s+ blocks[-i - 1]
            out_mu2 = torch.mean(out.mean(dim) ** 2).item()
            out_var = torch.mean(out.var(dim)).item()
            res_var = torch.mean(x_s.var(dim)).item()
            x_s, stats = up.signal_prop(out, dim)
            statistics_up.append(stats)
            lists_stats.append((out_mu2, out_var, res_var))
           
        x_s = self.final(x_s)   
        res_var = torch.mean(x_s.var(dim)).item()
        x_s = x_s+self.alpha*xinit
        out_mu2 = torch.mean(x_s.mean(dim) ** 2).item()
        out_var = torch.mean(x_s.var(dim)).item()
        lists_stats.append((out_mu2, out_var, res_var))
  
                
        # convert list of tuples to tuple of lists
        lists_stats = tuple(map(list, zip(*lists_stats)))
        return x_s, statistics_down, statistics_up, lists_stats
##################################################################################
class NFUNetRes_withmask(nn.Module):
    def __init__(self, in_nc=2, 
                out_nc=1, 
                nb=2, 
                depth = 2, 
                wf=16,
                act_mode='R', 
                downsample_mode='strideconv', 
                upsample_mode='convtranspose', 
                norm = 'nonorm', 
                type_init= 'xavier', 
                skip_weight = None, 
                keep_bias = False, 
                alpha = 1.0,
                repeat = True, 
                bUseClamp = True, 
                bUseAtt = False, 
                bUseComposition = False,
                bUseMask = False
                ) :
        super(NFUNetRes_withmask, self).__init__() #nc=[16, 32, 64, 128],

        self.down_path = nn.ModuleList()
        self.down_path.append(B.conv(in_nc, wf, bias=keep_bias, mode='C'))
        prev_channels = wf
        self.down_scaling = nn.ModuleList()
        self.alpha = alpha
        self.nb = nb
        self.bUseMask = bUseMask
        self.bUseClamp = bUseClamp

        mode = get_norm_layer(norm, act_mode, repeat)        
        match act_mode:
            case 'R':  
                # with torch.no_grad():
                    # y = F.relu(torch.randn(1024, 256).cuda()) 
                    # gamma = y.var(dim=1, keepdim=True)
                gain = 1.7139588594436646 #1.2716004848480225 
                    #gamma.mean(dim=0, keepdim=True)

            case 'L':
                # with torch.no_grad():
                    # y = F.leaky_relu(torch.randn(1024, 256).cuda()) 
                    # gamma = y.var(dim=1, keepdim=True)
                gain =  1.70590341091156 #gamma.mean(dim=0, keepdim=True)
            case 'E':
                # with torch.no_grad():
                    # y = F.elu(torch.randn(1024, 256).cuda()) 
                    # gamma = y.var(dim=1, keepdim=True)
                gain = 1.2716004848480225 
                    #gamma.mean(dim=0, keepdim=True)

        # expected_std = ((1.0+(2*(depth)+1)*nb*(alpha**2))**0.5)
        expected_std = (((1.0+nb*(alpha**2))**(depth+1))*(1.0+nb*depth*(alpha**2)))**0.5
        self.init_scaling = B.Scaling(expected_std)

        list_expected_std_up = []
        list_expected_std_input = []

        self.bUseAtt = bUseAtt

        self.NN_mask = NFUNetRes_mask(in_nc=in_nc, 
                out_nc=out_nc, 
                nb=nb, 
                depth = depth, 
                wf=wf,
                act_mode=act_mode, 
                downsample_mode=downsample_mode, 
                upsample_mode=upsample_mode, 
                norm = norm, 
                type_init= type_init, 
                skip_weight = skip_weight, 
                keep_bias = keep_bias, 
                alpha = alpha,
                repeat = repeat, 
                bUseAtt = bUseAtt, 
                bUseComposition = bUseComposition)

        for i in range(depth-1):
                        
            self.down_path.append(NFDownBlock(downsample_mode=downsample_mode, prev_channels= prev_channels, wf = wf*(2 ** (i+1)), alpha = self.alpha, expected_std = expected_std,
                                               nb = nb, keep_bias=keep_bias, mode=mode, type_init=type_init, block_type = 'NFblock', gain = gain)
                                               )                         
            expected_std = (expected_std **2 +  nb*(alpha**2))**0.5
            list_expected_std_input.append(expected_std)
            # list_expected_std_up.append((expected_std**2+(2*(depth-i)+1)*nb*(alpha**2))**0.5 )
            list_expected_std_up.append((((1.0+nb*(alpha**2))**(i+1))*(1.0+nb*depth*(alpha**2)))**0.5)
            # todo: add rescale
            self.down_scaling.append(B.Scaling(list_expected_std_up[-1])) 
            prev_channels = wf*(2 ** (i+1))
            # after 1 downblock
            

        self.down_path.append(NFDownBlock(expected_std= expected_std, alpha = self.alpha, prev_channels= prev_channels, downsample=False, 
                                          nb = nb, keep_bias=keep_bias, 
                                          mode=mode, type_init=type_init, block_type = 'NFblock', gain=gain)
                                          )
        expected_std = (expected_std ** 2 + alpha**2) ** 0.5

        self.up_path = nn.ModuleList()
    
        for i in reversed(range(depth-1)):
            # beta = 1./ expected_std
            self.up_path.append(NFUpBlock(expected_std= expected_std, alpha = self.alpha, upsample_mode=upsample_mode, 
                                            prev_channels= prev_channels, nb=nb,
                                            wf=wf*(2 ** i), keep_bias=keep_bias, mode=mode,type_init=type_init, 
                                            block_type = 'NFblock' if (i > 0 or not bUseAtt) else 'NFblock-PSA', gain=gain, bUseComposition=bUseComposition
                                            ))
           


            prev_channels = wf*(2 ** i)
            expected_std = (expected_std **2 +  nb*(alpha**2))**0.5

        self.final = B.conv(wf, out_nc, bias=keep_bias, mode='C', type_init=type_init)
        # expected_std = (expected_std**2 + 1.0)**0.5
        # self.beta = 1./ expected_std

        if bUseMask :
            self.mask = B.PSA_i(inplanes = 1) 
            # self.mask = B.PSA_o(inplanes = wf, planes= wf) 
           

    def forward(self, x):
       
        blocks = []
        xinit = x
        my_mask = self.NN_mask(x)
        x_s = self.init_scaling(xinit)
        for i, down in enumerate(self.down_path):

            x_s = down(x_s)

            if i != len(self.down_path) - 1:
                blocks.append(x_s)

            # if scaling common to res and id branches swap 
            if i > 0 and i != len(self.down_path) - 1:
                x_s = self.down_scaling[i-1](x_s)
                # expected_std = (self.list_expected_std_input[i-1] **2 +  self.nb*(self.alpha*self.list_expected_std_input[i-1]**2))**0.5
                # x_s = x_s/expected_std
                
        
        for i, up in enumerate(self.up_path):
            # x_s = self.alpha*x_s+ blocks[-i - 1]
            
            
            # #x_s = torch.cat((x_s, sigma.view(-1,1,1,1,1).expand(-1,-1,x.size(2),x.size(3),x.size(4))), 1)
            # x_s = up(x_s)

                        
            if i == len(self.up_path) - 1 and self.bUseAtt:
                x_s, att_maps = up(self.alpha*x_s+blocks[-i - 1])
            else :
                x_s = up(self.alpha*x_s+ blocks[-i - 1])
            
        x_s = self.final(x_s)   
        x_s = self.alpha*x_s +xinit[:,0,:,:].unsqueeze(1)


        return F.relu(x_s)*my_mask, None #, my_mask 
        

    @torch.no_grad()
    def signal_prop(self, x, dim=(0, -1, -2, -3)):

        blocks = []
        xinit = x
        x_s = self.init_scaling(xinit)
        statistics_down = []
        statistics_up = []
    
        lists_stats = [(
                torch.mean(xinit.mean(dim) ** 2).item(),
                torch.mean(xinit.var(dim)).item(),
                float('nan'),
             )]
        for i, down in enumerate(self.down_path):
            if i == 0:
                x_s = down(x_s)
            else :
                x_s, stats= down.signal_prop(x_s, dim)
                # stats is a list of tuples of 3 elements
                # list_stats is a tuple of 2 elements
                statistics_down.append(stats)
                # lists_stats.append(list_stats)

            if i != len(self.down_path) - 1:
                blocks.append(x_s)

            if i > 0 and i != len(self.down_path) - 1:
                x_s = self.down_scaling[i-1](x_s)
        
            

        for i, up in enumerate(self.up_path):
            out = self.alpha*x_s+ blocks[-i - 1]
            out_mu2 = torch.mean(out.mean(dim) ** 2).item()
            out_var = torch.mean(out.var(dim)).item()
            res_var = torch.mean(x_s.var(dim)).item()
            x_s, stats = up.signal_prop(out, dim)
            statistics_up.append(stats)
            lists_stats.append((out_mu2, out_var, res_var))
           
        x_s = self.final(x_s)   
        res_var = torch.mean(x_s.var(dim)).item()
        x_s = x_s+self.alpha*xinit
        out_mu2 = torch.mean(x_s.mean(dim) ** 2).item()
        out_var = torch.mean(x_s.var(dim)).item()
        lists_stats.append((out_mu2, out_var, res_var))
  
                
        # convert list of tuples to tuple of lists
        lists_stats = tuple(map(list, zip(*lists_stats)))
        return x_s, statistics_down, statistics_up, lists_stats
##################################################################################
class NFUNetRes_mask(nn.Module):
    def __init__(self, in_nc=2, 
                out_nc=1, 
                nb=2, 
                depth = 2, 
                wf=16,
                act_mode='R', 
                downsample_mode='strideconv', 
                upsample_mode='convtranspose', 
                norm = 'nonorm', 
                type_init= 'xavier', 
                skip_weight = None, 
                keep_bias = False, 
                alpha = 1.0,
                repeat = True, 
                bUseClamp = True, 
                bUseAtt = False, 
                bUseComposition = False,
                bUseMask = False
                ) :
        super(NFUNetRes_mask, self).__init__() #nc=[16, 32, 64, 128],

        self.down_path = nn.ModuleList()
        self.down_path.append(B.conv(in_nc, wf, bias=keep_bias, mode='C'))
        prev_channels = wf
        self.down_scaling = nn.ModuleList()
        self.alpha = alpha
        self.nb = nb
        self.bUseClamp = bUseClamp

        mode = get_norm_layer(norm, act_mode, repeat)        
        match act_mode:
            case 'R':  
                # with torch.no_grad():
                    # y = F.relu(torch.randn(1024, 256).cuda()) 
                    # gamma = y.var(dim=1, keepdim=True)
                gain = 1.7139588594436646 #1.2716004848480225 
                    #gamma.mean(dim=0, keepdim=True)

            case 'L':
                # with torch.no_grad():
                    # y = F.leaky_relu(torch.randn(1024, 256).cuda()) 
                    # gamma = y.var(dim=1, keepdim=True)
                gain =  1.70590341091156 #gamma.mean(dim=0, keepdim=True)
            case 'E':
                # with torch.no_grad():
                    # y = F.elu(torch.randn(1024, 256).cuda()) 
                    # gamma = y.var(dim=1, keepdim=True)
                gain = 1.2716004848480225 
                    #gamma.mean(dim=0, keepdim=True)

        # expected_std = ((1.0+(2*(depth)+1)*nb*(alpha**2))**0.5)
        expected_std = (((1.0+nb*(alpha**2))**(depth+1))*(1.0+nb*depth*(alpha**2)))**0.5
        self.init_scaling = B.Scaling(expected_std)

        list_expected_std_up = []
        list_expected_std_input = []

        self.bUseAtt = bUseAtt

        for i in range(depth-1):
                        
            self.down_path.append(NFDownBlock(downsample_mode=downsample_mode, prev_channels= prev_channels, wf = wf*(2 ** (i+1)), alpha = self.alpha, expected_std = expected_std,
                                               nb = nb, keep_bias=keep_bias, mode=mode, type_init=type_init, block_type = 'NFblock', gain = gain)
                                               )                         
            expected_std = (expected_std **2 +  nb*(alpha**2))**0.5
            list_expected_std_input.append(expected_std)
            # list_expected_std_up.append((expected_std**2+(2*(depth-i)+1)*nb*(alpha**2))**0.5 )
            list_expected_std_up.append((((1.0+nb*(alpha**2))**(i+1))*(1.0+nb*depth*(alpha**2)))**0.5)
            # todo: add rescale
            self.down_scaling.append(B.Scaling(list_expected_std_up[-1])) 
            prev_channels = wf*(2 ** (i+1))
            # after 1 downblock
            

        self.down_path.append(NFDownBlock(expected_std= expected_std, alpha = self.alpha, prev_channels= prev_channels, downsample=False, 
                                          nb = nb, keep_bias=keep_bias, 
                                          mode=mode, type_init=type_init, block_type = 'NFblock', gain=gain)
                                          )
        expected_std = (expected_std ** 2 + alpha**2) ** 0.5

        self.up_path = nn.ModuleList()
    
        for i in reversed(range(depth-1)):
            # beta = 1./ expected_std
            self.up_path.append(NFUpBlock(expected_std= expected_std, alpha = self.alpha, upsample_mode=upsample_mode, 
                                            prev_channels= prev_channels, nb=nb,
                                            wf=wf*(2 ** i), keep_bias=keep_bias, mode=mode,type_init=type_init, 
                                            block_type = 'NFblock' if (i > 0 or not bUseAtt) else 'NFblock-PSA', gain=gain, bUseComposition=bUseComposition
                                            ))
           


            prev_channels = wf*(2 ** i)
            expected_std = (expected_std **2 +  nb*(alpha**2))**0.5

        self.final = B.conv(wf, out_nc, bias=keep_bias, mode='C', type_init=type_init)
           
           

    def forward(self, x):
        
        blocks = []
        xinit = x
        x_s = self.init_scaling(xinit)
        for i, down in enumerate(self.down_path):

            x_s = down(x_s)

            if i != len(self.down_path) - 1:
                blocks.append(x_s)

            # if scaling common to res and id branches swap 
            if i > 0 and i != len(self.down_path) - 1:
                x_s = self.down_scaling[i-1](x_s)
                        
        
        for i, up in enumerate(self.up_path):
                           
            if i == len(self.up_path) - 1 and self.bUseAtt:
                x_s, att_maps = up(self.alpha*x_s+blocks[-i - 1])
            else :
                x_s = up(self.alpha*x_s+ blocks[-i - 1])
            

        x_s = self.final(x_s)   
        x_s = self.alpha*x_s +xinit[:,0,:,:].unsqueeze(1)
    
        return utils.binarize_straight_through(x_s)


    @torch.no_grad()
    def signal_prop(self, x, dim=(0, -1, -2, -3)):

        blocks = []
        xinit = x
        x_s = self.init_scaling(xinit)
        statistics_down = []
        statistics_up = []
    
        lists_stats = [(
                torch.mean(xinit.mean(dim) ** 2).item(),
                torch.mean(xinit.var(dim)).item(),
                float('nan'),
             )]
        for i, down in enumerate(self.down_path):
            if i == 0:
                x_s = down(x_s)
            else :
                x_s, stats= down.signal_prop(x_s, dim)
                # stats is a list of tuples of 3 elements
                # list_stats is a tuple of 2 elements
                statistics_down.append(stats)
                # lists_stats.append(list_stats)

            if i != len(self.down_path) - 1:
                blocks.append(x_s)

            if i > 0 and i != len(self.down_path) - 1:
                x_s = self.down_scaling[i-1](x_s)
        
            

        for i, up in enumerate(self.up_path):
            out = self.alpha*x_s+ blocks[-i - 1]
            out_mu2 = torch.mean(out.mean(dim) ** 2).item()
            out_var = torch.mean(out.var(dim)).item()
            res_var = torch.mean(x_s.var(dim)).item()
            x_s, stats = up.signal_prop(out, dim)
            statistics_up.append(stats)
            lists_stats.append((out_mu2, out_var, res_var))
           
        x_s = self.final(x_s)   
        res_var = torch.mean(x_s.var(dim)).item()
        x_s = x_s+self.alpha*xinit
        out_mu2 = torch.mean(x_s.mean(dim) ** 2).item()
        out_var = torch.mean(x_s.var(dim)).item()
        lists_stats.append((out_mu2, out_var, res_var))
  
                
        # convert list of tuples to tuple of lists
        lists_stats = tuple(map(list, zip(*lists_stats)))
        return x_s, statistics_down, statistics_up, lists_stats

class NFUNetRes(nn.Module):
    def __init__(self, in_nc=2, 
                out_nc=1, 
                nb=2, 
                depth = 2, 
                wf=16,
                act_mode='R', 
                downsample_mode='strideconv', 
                upsample_mode='convtranspose', 
                norm = 'nonorm', 
                type_init= 'xavier', 
                skip_weight = None, 
                keep_bias = False, 
                alpha = 1.0,
                repeat = True
                ) :
        super(NFUNetRes, self).__init__() #nc=[16, 32, 64, 128],

        self.down_path = nn.ModuleList()
        self.down_path.append(B.conv(in_nc, wf, bias=keep_bias, mode='C'))
        prev_channels = wf
        self.down_scaling = nn.ModuleList()
        self.alpha = alpha
        self.nb = nb

        mode = get_norm_layer(norm, act_mode, repeat)        
        match act_mode:
            case 'R':  
                # with torch.no_grad():
                    # y = F.relu(torch.randn(1024, 256).cuda()) 
                    # gamma = y.var(dim=1, keepdim=True)
                gain = 1.7139588594436646 #1.2716004848480225 
                    #gamma.mean(dim=0, keepdim=True)

            case 'L':
                # with torch.no_grad():
                    # y = F.leaky_relu(torch.randn(1024, 256).cuda()) 
                    # gamma = y.var(dim=1, keepdim=True)
                gain =  1.70590341091156 #gamma.mean(dim=0, keepdim=True)
            case 'E':
                # with torch.no_grad():
                    # y = F.elu(torch.randn(1024, 256).cuda()) 
                    # gamma = y.var(dim=1, keepdim=True)
                gain = 1.2716004848480225 
                    #gamma.mean(dim=0, keepdim=True)

        expected_std = 1.0
        self.init_scaling = B.Scaling((1.0+alpha**2)**0.5)

        list_expected_std = []
        list_expected_std_input = []

        
        for i in range(depth-1):
            expected_std = (1.0+alpha**2)**0.5 
            list_expected_std.append(expected_std)        
            self.down_path.append(NFDownBlock(downsample_mode=downsample_mode, prev_channels= prev_channels, wf = wf*(2 ** (i+1)), alpha = self.alpha, expected_std = expected_std,
                                               nb = nb, keep_bias=keep_bias, mode=mode, type_init=type_init, block_type = 'NFblock', gain = gain)
                                               )                         
            prev_channels = wf*(2 ** (i+1))
            

        self.down_path.append(NFDownBlock(expected_std= expected_std, alpha = self.alpha, prev_channels= prev_channels, downsample=False, 
                                          nb = nb, keep_bias=keep_bias, 
                                          mode=mode, type_init=type_init, block_type = 'NFblock', gain=gain)
                                          )

        self.up_path = nn.ModuleList()
    
        for i in reversed(range(depth-1)):
            expected_std =list_expected_std[i]
            self.up_path.append(NFUpBlock(expected_std= expected_std, alpha = self.alpha, upsample_mode=upsample_mode, 
                                          prev_channels= prev_channels, nb=nb,
                                          wf=wf*(2 ** i), keep_bias=keep_bias, mode=mode,type_init=type_init, block_type = 'NFblock', gain=gain)
                                        )
            prev_channels = wf*(2 ** i)

        self.up_path.append(B.conv(wf, out_nc, bias=keep_bias, mode='C', type_init=type_init))
        # expected_std = (expected_std**2 + 1.0)**0.5
        # self.beta = 1./ expected_std


    def forward(self, x):
        blocks = []
        xinit = self.init_scaling(x)
        x_s = xinit
        for i, down in enumerate(self.down_path):
            x_s = down(x_s)            
            if i > 0 and i != len(self.down_path) - 1:
                x_s = self.init_scaling(x_s)
       
            if i != len(self.down_path) - 1:
                blocks.append(x_s)
                
        
        for i, up in enumerate(self.up_path):
            x_s = up(self.alpha*x_s+ blocks[-i - 1])
            
        x_s = self.alpha*x_s+xinit
        return x_s


    @torch.no_grad()
    def signal_prop(self, x, dim=(0, -1, -2, -3)):

        blocks = []
        xinit = self.init_scaling(x)
        x_s = xinit
        statistics_down = []
        statistics_up = []
    
        lists_stats = [(
                torch.mean(xinit.mean(dim) ** 2).item(),
                torch.mean(xinit.var(dim)).item(),
                float('nan'),
             )]
        for i, down in enumerate(self.down_path):
            if i == 0:
                x_s = down(x_s)
            else :
                x_s, stats= down.signal_prop(x_s, dim)
                # stats is a list of tuples of 3 elements
                # list_stats is a tuple of 2 elements
                statistics_down.append(stats)
                # lists_stats.append(list_stats)

            

            if i > 0 and i != len(self.down_path) - 1:
                # out_mu2 = torch.mean(x_s.mean(dim) ** 2).item()
                # out_var = torch.mean(x_s.var(dim)).item()
                # res_var = 0
                # lists_stats.append((out_mu2, out_var, res_var))
                x_s = self.init_scaling(x_s)

            if i != len(self.down_path) - 1:
                blocks.append(x_s)
                
            

        for i, up in enumerate(self.up_path):
            if i != len(self.up_path) - 1:
                out = self.alpha*x_s+ blocks[-i - 1]
                out_mu2 = torch.mean(out.mean(dim) ** 2).item()
                out_var = torch.mean(out.var(dim)).item()
                res_var = torch.mean(x_s.var(dim)).item()
                x_s, stats = up.signal_prop(out, dim)
                statistics_up.append(stats)
                lists_stats.append((out_mu2, out_var, res_var))
            else :
                x_s = up(self.alpha*x_s+ blocks[-i - 1])
            
        res_var = torch.mean(x_s.var(dim)).item()
        x_s = x_s+self.alpha*xinit
        out_mu2 = torch.mean(x_s.mean(dim) ** 2).item()
        out_var = torch.mean(x_s.var(dim)).item()
        lists_stats.append((out_mu2, out_var, res_var))
  
                
        # convert list of tuples to tuple of lists
        lists_stats = tuple(map(list, zip(*lists_stats)))
        return x_s, statistics_down, statistics_up, lists_stats


###################################################################################
class HalfUNetRes(nn.Module):
    def __init__(self, in_nc=2, 
                out_nc=1, 
                nb=2, 
                depth = 2, 
                wf=16,
                act_mode='R', 
                downsample_mode='strideconv', 
                upsample_mode='convtranspose', 
                norm = 'nonorm', 
                type_init= 'xavier', 
                skip_weight = None, 
                keep_bias = False, 
                repeat = True
                ) :
        super(HalfUNetRes, self).__init__() #nc=[16, 32, 64, 128],

        self.down_path = nn.ModuleList()
        self.down_path.append(B.conv(in_nc, wf, bias=keep_bias, mode='C'))
        prev_channels = wf
        self.down_scaling = nn.ModuleList()
        self.nb = nb
        self.skip_weight = skip_weight
        self.scaling = torch.tensor(depth*np.sqrt(2))
        if self.skip_weight == 'sigmoid' or self.skip_weight == 'softplus':
            self.res_weights = nn.ParameterList([nn.Parameter(torch.cuda.FloatTensor([-6.0])) for i in range(depth)])
        elif self.skip_weight == 'relu':
            self.res_weights = nn.ParameterList([nn.Parameter(torch.cuda.FloatTensor([1e-6])) for i in range(depth)])
        else :
            self.res_weights = nn.ParameterList([nn.Parameter(torch.cuda.FloatTensor([0.0])) for i in range(depth)]) #[0 for i in range(depth+1)]#


        mode = get_norm_layer(norm, act_mode, repeat) 
              


        for i in range(depth-1):
                        
            self.down_path.append(NFDownBlock(downsample_mode=downsample_mode, prev_channels= prev_channels, wf = wf*(2 ** (i+1)), alpha = self.scaling,
                                               nb = nb, keep_bias=keep_bias, mode=mode, type_init=type_init, block_type = 'Halfresblock')
                                               )                         
           
            prev_channels = wf*(2 ** (i+1))
            

        self.down_path.append(NFDownBlock(prev_channels= prev_channels, downsample=False, alpha = self.scaling,
                                          nb = nb, keep_bias=keep_bias, 
                                          mode=mode, type_init=type_init, block_type = 'Halfresblock')
                                          )

        self.up_path = nn.ModuleList()
    
        for i in reversed(range(depth-1)):
            self.up_path.append(NFUpBlock(upsample_mode=upsample_mode, alpha = self.scaling,
                                          prev_channels= prev_channels, nb=nb,
                                          wf=wf*(2 ** i), keep_bias=keep_bias, mode=mode,type_init=type_init, block_type = 'Halfresblock')
                                        )
            prev_channels = wf*(2 ** i)

        self.final = B.conv(wf, out_nc, bias=keep_bias, mode='C', type_init=type_init)
    


    def forward(self, x_s):
        blocks = []
       
        x_s = x_s/self.scaling
        xinit = x_s
        for i, down in enumerate(self.down_path):

            x_s = down(x_s)

            if i > 0 and i != len(self.down_path) - 1:
                x_s = x_s/self.scaling

            if i != len(self.down_path) - 1:
                blocks.append(x_s)
                
        
        for i, up in enumerate(self.up_path):
            

            if self.skip_weight is None:
                x_s = up(self.res_weights[i]*x_s+ blocks[-i - 1])
            elif self.skip_weight == 'softplus':
                x_s = up(F.softplus(self.res_weights[i])*x_s+ blocks[-i - 1])
            elif self.skip_weight == 'sigmoid':
                x_s = up(F.sigmoid(self.res_weights[i])*x_s+ blocks[-i - 1])
            elif self.skip_weight == 'relu':
                x_s = up(utils.relu_straight_through(self.res_weights[i])*x_s+ blocks[-i - 1])
            else:
                raise NotImplementedError('skip_weight mode [{:s}] is not found'.format(self.skip_weight))

            # x_s = up(self.res_weights[i]*x_s+ blocks[-i - 1])
            # x_s = up(x_s+ blocks[-i - 1])

        x_s = self.final(x_s)    
        # x_s = self.res_weights[-1]*x_s+xinit
        if self.skip_weight is None:
            x_s = self.res_weights[-1]*x_s+xinit
        elif self.skip_weight == 'softplus':
            x_sx = F.softplus(self.res_weights[-1])*x_s+xinit
        elif self.skip_weight == 'sigmoid':
            x_s = F.sigmoid(self.res_weights[-1])*x_s+xinit
        elif self.skip_weight == 'relu':
            x_s = utils.relu_straight_through(self.res_weights[-1])*x_s+xinit
        else:
            raise NotImplementedError('skip_weight mode [{:s}] is not found'.format(self.skip_weight))

        return x_s


    @torch.no_grad()
    def signal_prop(self, x_s, dim=(0, -1, -2, -3)):

        blocks = []
        lists_stats = [(
                torch.mean(x_s.mean(dim) ** 2).item(),
                torch.mean(x_s.var(dim)).item(),
                float('nan'),
             )]
        x_s = x_s/(self.scaling)
        # x_s = x_s/(2*len(self.down_path)*self.scaling)
        xinit = x_s
        statistics_down = []
        statistics_up = []
    

        for i, down in enumerate(self.down_path):
            if i == 0:
                x_s = down(x_s)
            else :
                x_s, stats= down.signal_prop(x_s, dim)
                statistics_down.append(stats)

            if i > 0 and i != len(self.down_path) - 1:
                # x_s = x_s/((2*len(self.down_path)-i)*self.scaling)
                x_s = x_s/ self.scaling
                
            if i != len(self.down_path) - 1:
                blocks.append(x_s)
            

        for i, up in enumerate(self.up_path):
            if self.skip_weight is None:
                out = self.res_weights[i]*x_s+ blocks[-i - 1]
            elif self.skip_weight == 'softplus':
                out = F.softplus(self.res_weights[i])*x_s+ blocks[-i - 1]
            elif self.skip_weight == 'sigmoid':
                out = F.sigmoid(self.res_weights[i])*x_s+ blocks[-i - 1]
            elif self.skip_weight == 'relu':
                out = utils.relu_straight_through(self.res_weights[i])*x_s+ blocks[-i - 1]
            else:
                raise NotImplementedError('skip_weight mode [{:s}] is not found'.format(self.skip_weight))
    
            # out = x_s+ blocks[-i - 1]
            out_mu2 = torch.mean(out.mean(dim) ** 2).item()
            out_var = torch.mean(out.var(dim)).item()
            res_var = torch.mean(x_s.var(dim)).item()
            x_s, stats = up.signal_prop(out, dim)
            statistics_up.append(stats)
            lists_stats.append((out_mu2, out_var, res_var))
            
        
        lists_stats.append((torch.mean(x_s.mean(dim) ** 2).item(), torch.mean(x_s.var(dim)).item(), float('nan')))
        # self.final.apply(lambda x: B.standardize_weight(x, None))
        x_s = self.final(x_s)    
        lists_stats.append((torch.mean(x_s.mean(dim) ** 2).item(), torch.mean(x_s.var(dim)).item(), float('nan')))
        res_var = torch.mean(x_s.var(dim)).item()

        if self.skip_weight is None:
            x_s = self.res_weights[-1]*x_s+xinit
        elif self.skip_weight == 'softplus':
            x_sx = F.softplus(self.res_weights[-1])*x_s+xinit
        elif self.skip_weight == 'sigmoid':
            x_s = F.sigmoid(self.res_weights[-1])*x_s+xinit
        elif self.skip_weight == 'relu':
            x_s = utils.relu_straight_through(self.res_weights[-1])*x_s+xinit
        else:
            raise NotImplementedError('skip_weight mode [{:s}] is not found'.format(self.skip_weight))
    
        # x_s = x_s+xinit
        out_mu2 = torch.mean(x_s.mean(dim) ** 2).item()
        out_var = torch.mean(x_s.var(dim)).item()
        lists_stats.append((out_mu2, out_var, res_var))
  
                
        # convert list of tuples to tuple of lists
        lists_stats = tuple(map(list, zip(*lists_stats)))
        return x_s, statistics_down, statistics_up, lists_stats



#####################################################
#                   UNetResWeight                   #
#####################################################

class UNetResWeight(nn.Module):
    def __init__(self, 
                 in_nc=2, 
                 out_nc=1,  
                 nb=2, 
                 depth = 2, 
                 wf=16,
                 act_mode='R', 
                 downsample_mode='strideconv', 
                 upsample_mode='convtranspose', 
                 norm = 'nonorm', 
                 type_init= 'xavier', 
                 skip_weight = None, 
                 keep_bias = False,
                 repeat = True) :
        super(UNetResWeight, self).__init__() #nc=[16, 32, 64, 128],

        self.skip_weight = skip_weight

        # downsample
        if downsample_mode == 'avgpool':
            downsample_block = B.downsample_avgpool
        elif downsample_mode == 'maxpool':
            downsample_block = B.downsample_maxpool
        elif downsample_mode == 'strideconv':
            downsample_block = B.downsample_strideconv
        else:
            raise NotImplementedError('downsample mode [{:s}] is not found'.format(downsample_mode))


        # upsample
        if upsample_mode == 'upconv':
            upsample_block = B.upsample_upconv
        elif upsample_mode == 'pixelshuffle':
            upsample_block = B.upsample_pixelshuffle
        elif upsample_mode == 'convtranspose':
            upsample_block = B.upsample_convtranspose
        else:
            raise NotImplementedError('upsample mode [{:s}] is not found'.format(upsample_mode))


        self.down_path = nn.ModuleList()
        self.down_path.append(B.conv(in_nc, wf, bias=keep_bias, mode='C'))
        prev_channels = wf

        mode = get_norm_layer(norm, act_mode, repeat)



        for i in range(depth-1):
            self.down_path.append(B.sequential(*[B.ResBlockWeight(prev_channels, prev_channels, bias=keep_bias, mode=mode, type_init=type_init, skip_weight = skip_weight) for _ in range(nb)], 
                                            downsample_block(prev_channels, wf*(2 ** (i+1)), bias=keep_bias, mode='2', type_init=type_init)))
            
            
            prev_channels = wf*(2 ** (i+1))
        self.down_path.append(B.sequential(*[B.ResBlockWeight(prev_channels, prev_channels, bias=keep_bias, mode=mode, type_init=type_init, skip_weight = skip_weight) for _ in range(nb)]))
      

        self.up_path = nn.ModuleList()
        if self.skip_weight == 'sigmoid' or self.skip_weight == 'softplus':
            self.res_weights = nn.ParameterList([nn.Parameter(torch.FloatTensor([-6.0])) for i in range(depth)])
        else :
            self.res_weights = nn.ParameterList([nn.Parameter(torch.FloatTensor([0.])) for i in range(depth)])
        for i in reversed(range(depth-1)):
            self.up_path.append(
                B.sequential(upsample_block(prev_channels, wf*(2 ** i), bias=keep_bias, mode='2',type_init=type_init), *[B.ResBlockWeight(wf*(2 ** i), wf*(2 ** i), bias=keep_bias, mode=mode, type_init=type_init, skip_weight = skip_weight) for _ in range(nb)])
            )
            prev_channels = wf*(2 ** i)

        self.up_path.append(B.conv(wf, out_nc, bias=keep_bias, mode='C', type_init=type_init))



    def forward(self, x):

        blocks = []
        xinit = x
        for i, down in enumerate(self.down_path):
            x = down(x)
            if i != len(self.down_path) - 1:
                blocks.append(x)
        for i, up in enumerate(self.up_path):
            if self.skip_weight is None:
                x = up(self.res_weights[i]*x+ blocks[-i - 1])
            elif self.skip_weight == 'softplus':
                x = up(F.softplus(self.res_weights[i])*x+ blocks[-i - 1])
            elif self.skip_weight == 'sigmoid':
                x = up(F.sigmoid(self.res_weights[i])*x+ blocks[-i - 1])
            else:
                raise NotImplementedError('skip_weight mode [{:s}] is not found'.format(self.skip_weight))
            
        if self.skip_weight is None:
            x = x+self.res_weights[-1]*xinit
        elif self.skip_weight == 'softplus':
            x = x+F.softplus(self.res_weights[-1])*xinit
        elif self.skip_weight == 'sigmoid':
            x = x+F.sigmoid(self.res_weights[-1])*xinit
        else:
            raise NotImplementedError('skip_weight mode [{:s}] is not found'.format(self.skip_weight))      
        return x    
    


class UNetResWeight2(nn.Module):
    def __init__(self, 
                 in_nc=2, 
                 out_nc=1,  
                 nb=2, 
                 depth = 2, 
                 wf=16,
                 act_mode='R', 
                 downsample_mode='strideconv', 
                 upsample_mode='convtranspose', 
                 norm = 'nonorm', 
                 type_init= 'xavier', 
                 skip_weight = None, 
                 keep_bias = False,
                 repeat = True) :
        super(UNetResWeight2, self).__init__() #nc=[16, 32, 64, 128],

        self.skip_weight = skip_weight


        self.down_path = nn.ModuleList()
        self.down_path.append(B.conv(in_nc, wf, bias=keep_bias, mode='C'))
        prev_channels = wf

        mode = get_norm_layer(norm, act_mode, repeat)



        for i in range(depth-1):
            self.down_path.append(NFDownBlock(downsample_mode=downsample_mode, prev_channels= prev_channels, wf = wf*(2 ** (i+1)), skip_weight=skip_weight,
                                               nb = nb, keep_bias=keep_bias, mode=mode, type_init=type_init, block_type='Wresblock')
            )
             
            
            prev_channels = wf*(2 ** (i+1))
        self.down_path.append(NFDownBlock(prev_channels= prev_channels, downsample=False, nb = nb, keep_bias=keep_bias, skip_weight=skip_weight,
                                         mode=mode, type_init=type_init, block_type='Wresblock')
                                         )
        
        # self.down_path.append(B.sequential(*[B.ResBlockWeight(prev_channels, prev_channels, bias=keep_bias, mode=mode, type_init=type_init, skip_weight = skip_weight) for _ in range(nb)]))

        self.up_path = nn.ModuleList()
        if self.skip_weight == 'sigmoid' or self.skip_weight == 'softplus':
            self.res_weights = nn.ParameterList([nn.Parameter(torch.FloatTensor([-6.0])) for i in range(depth)])
        elif self.skip_weight == 'relu':
             self.res_weights = nn.ParameterList([nn.Parameter(torch.FloatTensor([1e-6])) for i in range(depth)])
        else :
            self.res_weights = nn.ParameterList([nn.Parameter(torch.FloatTensor([0.])) for i in range(depth)]) #[0 for i in range(depth+1)]#
        for i in reversed(range(depth-1)):
            self.up_path.append(NFUpBlock(upsample_mode=upsample_mode, prev_channels= prev_channels, nb=nb, skip_weight = skip_weight,
                                          wf=wf*(2 ** i), keep_bias=keep_bias, mode=mode,type_init=type_init, block_type='Wresblock')
                                        )
            
       
            prev_channels = wf*(2 ** i)

        self.final = B.conv(wf, out_nc, bias=keep_bias, mode='C', type_init=type_init)



    def forward(self, x):
        blocks = []
        xinit = x
        for i, down in enumerate(self.down_path):
            x = down(x)
            if i != len(self.down_path) - 1:
                blocks.append(x)
        for i, up in enumerate(self.up_path):
            
            if self.skip_weight is None:
                x = up(self.res_weights[i]*x+ blocks[-i - 1])
            elif self.skip_weight == 'softplus':
                x = up(F.softplus(self.res_weights[i])*x+ blocks[-i - 1])
            elif self.skip_weight == 'sigmoid':
                x = 0.0100*up(F.sigmoid(self.res_weights[i])*x+ blocks[-i - 1])
            elif self.skip_weight == 'relu':
                x = up(utils.relu_straight_through(self.res_weights[i])*x+ blocks[-i - 1])
            else:
                raise NotImplementedError('skip_weight mode [{:s}] is not found'.format(self.skip_weight))
        x = self.final(x)        
        
        if self.skip_weight is None:
            x = self.res_weights[-1]*x+xinit[:,0,:,:].unsqueeze(1)
        elif self.skip_weight == 'softplus':
            x = F.softplus(self.res_weights[-1])*x+xinit[:,0,:,:].unsqueeze(1)
        elif self.skip_weight == 'sigmoid':
            x = 0.00100*F.sigmoid(self.res_weights[-1])*x+xinit[:,0,:,:].unsqueeze(1)
        elif self.skip_weight == 'relu':
            x = utils.relu_straight_through(self.res_weights[-1])*x+xinit[:,0,:,:].unsqueeze(1)
        else:
            raise NotImplementedError('skip_weight mode [{:s}] is not found'.format(self.skip_weight))
          
           
        # if self.skip_weight is None:
        #     x = self.res_weights[-1]*xinit+x
        # elif self.skip_weight == 'softplus':
        #     x = F.softplus(self.res_weights[-1])*xinit+x
        # elif self.skip_weight == 'sigmoid':
        #     x = F.sigmoid(self.res_weights[-1])*xinit+x
        # else:
        #     raise NotImplementedError('skip_weight mode [{:s}] is not found'.format(self.skip_weight))    
            
        return F.relu(x)

    @torch.no_grad()
    def signal_prop(self, x, dim=(0, -1, -2, -3)):

        blocks = []
        xinit = x
        x_s = xinit

        statistics_down = [] 
        statistics_up = []
    
        lists_stats = [(
                torch.mean(xinit.mean(dim) ** 2).item(),
                torch.mean(xinit.var(dim)).item(),
                float('nan'),
             )]
        for i, down in enumerate(self.down_path):
            if i == 0:
                x_s = down(x_s)
            else :
                x_s, stats = down.signal_prop(x_s, dim)
                # stats is a list of tuples of 3 elements
                # list_stats is a tuple of 2 elements
                statistics_down.append(stats)

            if i != len(self.down_path) - 1:
                blocks.append(x_s)

        
            

        for i, up in enumerate(self.up_path):
        
            if self.skip_weight is None:
                out= self.res_weights[i]*x_s+ blocks[-i - 1]
            elif self.skip_weight == 'softplus':
                out = F.softplus(self.res_weights[i])*x_s+ blocks[-i - 1]
            elif self.skip_weight == 'sigmoid':
                out = F.sigmoid(self.res_weights[i])*x_s+ blocks[-i - 1]
            elif self.skip_weight == 'relu':
                out = utils.relu_straight_through(self.res_weights[i])*x_s+ blocks[-i - 1]
            else:
                raise NotImplementedError('skip_weight mode [{:s}] is not found'.format(self.skip_weight))
        

            out_mu2 = torch.mean(out.mean(dim) ** 2).item()
            out_var = torch.mean(out.var(dim)).item()
            res_var = torch.mean(x_s.var(dim)).item()
            x_s, stats = up.signal_prop(out, dim)
            statistics_up.append(stats)
            lists_stats.append((out_mu2, out_var, res_var))
           
        x_s = self.final(x_s)
        res_var = torch.mean(x_s.var(dim)).item()

        if self.skip_weight is None:
            x_s = self.res_weights[-1]*x_s+xinit
        elif self.skip_weight == 'softplus':
            x_s = F.softplus(self.res_weights[-1])*x_s+xinit
        elif self.skip_weight == 'sigmoid':
            x_s = F.sigmoid(self.res_weights[-1])*x_s+xinit
        elif self.skip_weight == 'relu':
            x_s = utils.relu_straight_through(self.res_weights[-1])*x_s+xinit
        else:
            raise NotImplementedError('skip_weight mode [{:s}] is not found'.format(self.skip_weight))      

        out_mu2 = torch.mean(x_s.mean(dim) ** 2).item()
        out_var = torch.mean(x_s.var(dim)).item()
        lists_stats.append((out_mu2, out_var, res_var))
  
                
        # convert list of tuples to tuple of lists
        lists_stats = tuple(map(list, zip(*lists_stats)))
        return x_s, statistics_down, statistics_up, lists_stats
    
###########################################################################


class UNetResConcatWeight(nn.Module):
    def __init__(self, 
                 in_nc=2, 
                 out_nc=1,  
                 nb=2, 
                 depth = 2, 
                 wf=16,
                 act_mode='R', 
                 downsample_mode='strideconv', 
                 upsample_mode='convtranspose', 
                 norm = 'nonorm', 
                 type_init= 'xavier', 
                 skip_weight = None, 
                 keep_bias = False,
                 repeat = True,
                 bUseComposition = False) :
        super(UNetResConcatWeight, self).__init__() #nc=[16, 32, 64, 128],

        self.skip_weight = skip_weight

        self.down_path = nn.ModuleList()
        self.down_path.append(B.conv(in_nc, wf, bias=keep_bias, mode='C'))
        prev_channels = wf

        mode = get_norm_layer(norm, act_mode, repeat)
        block_type = 'Halfresblock' if self.skip_weight == 'half' else 'Wresblock'


        for i in range(depth-1):
            self.down_path.append(NFDownBlock(downsample_mode=downsample_mode, prev_channels= prev_channels, wf = wf*(2 ** (i+1)), skip_weight=skip_weight,
                                               nb = nb, keep_bias=keep_bias, mode=mode, type_init=type_init, block_type=block_type)
            )
             
            
            prev_channels = wf*(2 ** (i+1))
        self.down_path.append(NFDownBlock(prev_channels= prev_channels, downsample=False, nb = nb, keep_bias=keep_bias, skip_weight=skip_weight,
                                         mode=mode, type_init=type_init, block_type=block_type)
                                         )
        

        self.up_path = nn.ModuleList()
        if self.skip_weight == 'sigmoid' or self.skip_weight == 'softplus':
            self.res_weights = nn.ParameterList([nn.Parameter(torch.FloatTensor([-6.0])) ])
        elif self.skip_weight == 'relu':
            self.res_weights = nn.ParameterList([nn.Parameter(torch.FloatTensor([1e-6])) ])
        elif self.skip_weight == 'half':
            self.res_weights =1.0/np.sqrt(2)
        else :
            self.res_weights = nn.ParameterList([nn.Parameter(torch.FloatTensor([0])) ])
        for i in reversed(range(depth-1)):
            if i > 0:
                self.up_path.append(NFUpConcatBlock(upsample_mode=upsample_mode, prev_channels= prev_channels, nb=nb, skip_weight = skip_weight,
                                            wf=wf*(2 ** i), keep_bias=keep_bias, mode=mode,type_init=type_init, block_type=block_type)
                                            )
            else :
                self.up_path.append(NFUpAttBlock(upsample_mode=upsample_mode, prev_channels= prev_channels, nb=nb, skip_weight = skip_weight,
                                            wf=wf*(2 ** i), keep_bias=keep_bias, mode=mode,
                                            type_init=type_init, block_type=block_type, bUseComposition=bUseComposition)
                                            )
            
       
            prev_channels = wf*(2 ** i)

        self.final = B.conv(2*wf, out_nc, bias=keep_bias, mode='C', type_init=type_init)


    def forward(self, x):
        blocks = []
        # if self.bUseClamp :
        # x = torch.where(x>10000.0, torch.zeros_like(x), x)
        # x = torch.where(x<-100, torch.zeros_like(x), x)
        # x = x.clamp(-100, 10000.0)
        
        if self.skip_weight == 'half':
            x = x * self.res_weights
        xinit = x.clone() #[:,0,:,:,:].clone()
        # print(xinit.shape)
        for i, down in enumerate(self.down_path):
            x = down(x)
            if i < len(self.down_path) - 2:
                blocks.append(x)
        for i, up in enumerate(self.up_path):
            if i == len(self.up_path) - 1:
                x, att_maps = up(x,blocks[-i - 1])
            else :
                x = up(x,blocks[-i - 1])
            

        x1 = self.final(x)               
        if self.skip_weight is None :
            x2 = self.res_weights[-1]*x1+xinit
        elif self.skip_weight == 'softplus':
            x2 = F.softplus(self.res_weights[-1])*x1+xinit
        elif self.skip_weight == 'sigmoid':
            x2 = F.sigmoid(self.res_weights[-1])*x1+xinit
        elif self.skip_weight == 'relu':
            x2 = utils.relu_straight_through(self.res_weights[-1])*x1+xinit
        elif self.skip_weight == 'half':
            x2 = x1 + xinit
        else:
            raise NotImplementedError('skip_weight mode [{:s}] is not found'.format(self.skip_weight))
        # out = utils.relu_straight_through(x2) 
        out = F.relu(x2)
        return out #, att_maps

    @torch.no_grad()
    def signal_prop(self, x_s, dim=(0, -1, -2, -3)):

        blocks = []
        if self.skip_weight == 'half':
            x_s = x_s * self.res_weights
        xinit = x_s #[:,0,:,:,:].clone()

        statistics_down = [] 
        statistics_up = []
    
        lists_stats = [(
                torch.mean(xinit.mean(dim) ** 2).item(),
                torch.mean(xinit.var(dim)).item(),
                float('nan'),
             )]
        for i, down in enumerate(self.down_path):
            if i == 0:
                x_s = down(x_s)
            else :
                x_s, stats = down.signal_prop(x_s, dim)
                # stats is a list of tuples of 3 elements
                # list_stats is a tuple of 2 elements
                statistics_down.append(stats)

            if i < len(self.down_path) - 2:
                blocks.append(x_s)

        
            

        for i, up in enumerate(self.up_path):
            out = x_s
           
           
            out_mu2 = torch.mean(out.mean(dim) ** 2).item()
            out_var = torch.mean(out.var(dim)).item()
            res_var = torch.mean(x_s.var(dim)).item()
            x_s, stats = up.signal_prop(out, blocks[-i - 1], dim)
            statistics_up.append(stats)
            lists_stats.append((out_mu2, out_var, res_var))
            
        x_s = self.final(x_s)    
        res_var = torch.mean(x_s.var(dim)).item()

        if self.skip_weight is None:
            x_s = self.res_weights[-1]*x_s+xinit
        elif self.skip_weight == 'softplus':
            x_s = F.softplus(self.res_weights[-1])*x_s+xinit
        elif self.skip_weight == 'sigmoid':
            x_s = F.sigmoid(self.res_weights[-1])*x_s+xinit
        elif self.skip_weight == 'relu':
            x_s = utils.relu_straight_through(self.res_weights[-1])*x_s+xinit
        elif self.skip_weight == 'half':
            x_s = x_s + xinit
        else:
            raise NotImplementedError('skip_weight mode [{:s}] is not found'.format(self.skip_weight))      

        out_mu2 = torch.mean(x_s.mean(dim) ** 2).item()
        out_var = torch.mean(x_s.var(dim)).item()
        lists_stats.append((out_mu2, out_var, res_var))
  
                
        # convert list of tuples to tuple of lists
        lists_stats = tuple(map(list, zip(*lists_stats)))
        return x_s, statistics_down, statistics_up, lists_stats

###########################################################################


class UNetResConcatWeight2(nn.Module):
    def __init__(self, 
                 in_nc=2, 
                 out_nc=1,  
                 nb=2, 
                 depth = 2, 
                 wf=16,
                 act_mode='R', 
                 downsample_mode='strideconv', 
                 upsample_mode='convtranspose', 
                 norm = 'nonorm', 
                 type_init= 'xavier', 
                 skip_weight = None, 
                 keep_bias = False,
                 repeat = True,
                 bUseComposition = False) :
        super(UNetResConcatWeight2, self).__init__() #nc=[16, 32, 64, 128],

        self.skip_weight = skip_weight

        self.down_path = nn.ModuleList()
        self.down_path.append(B.conv(in_nc, wf, bias=keep_bias, mode='C'))
        prev_channels = wf

        mode = get_norm_layer(norm, act_mode, repeat)
        block_type = 'Halfresblock' if self.skip_weight == 'half' else 'Wresblock'


        for i in range(depth-1):
            self.down_path.append(NFDownBlock(downsample_mode=downsample_mode, prev_channels= prev_channels, wf = wf*(2 ** (i+1)), skip_weight=skip_weight,
                                               nb = nb, keep_bias=keep_bias, mode=mode, type_init=type_init, block_type=block_type)
            )
             
            
            prev_channels = wf*(2 ** (i+1))
        self.down_path.append(NFDownBlock(prev_channels= prev_channels, downsample=False, nb = nb, keep_bias=keep_bias, skip_weight=skip_weight,
                                         mode=mode, type_init=type_init, block_type=block_type)
                                         )
        

        self.up_path = nn.ModuleList()
        if self.skip_weight == 'sigmoid' or self.skip_weight == 'softplus':
            self.res_weights = nn.ParameterList([nn.Parameter(torch.FloatTensor([-6.0])) ])
        elif self.skip_weight == 'relu':
            self.res_weights = nn.ParameterList([nn.Parameter(torch.FloatTensor([1e-6])) ])
        elif self.skip_weight == 'half':
            self.res_weights =1.0/np.sqrt(2)
        else :
            self.res_weights = nn.ParameterList([nn.Parameter(torch.FloatTensor([0])) ])
        for i in reversed(range(depth-1)):
            self.up_path.append(NFUpConcatBlock(upsample_mode=upsample_mode, prev_channels= prev_channels, nb=nb, skip_weight = skip_weight,
                                            wf=wf*(2 ** i), keep_bias=keep_bias, mode=mode,type_init=type_init, block_type=block_type)
                                            )
           
            
       
            prev_channels = wf*(2 ** i)

        self.final = B.conv(wf, out_nc, bias=keep_bias, mode='C', type_init=type_init)


    def forward(self, x):
        blocks = []

        
        if self.skip_weight == 'half':
            x = x * self.res_weights
        xinit = x.clone() 
        for i, down in enumerate(self.down_path):
            x = down(x)
            if i < len(self.down_path) - 2:
                blocks.append(x)
        for i, up in enumerate(self.up_path):
            x = up(x,blocks[-i - 1])
            

        x1 = self.final(x)               
        if self.skip_weight is None :
            x2 = self.res_weights[-1]*x1+xinit
        elif self.skip_weight == 'softplus':
            x2 = F.softplus(self.res_weights[-1])*x1+xinit
        elif self.skip_weight == 'sigmoid':
            x2 = F.sigmoid(self.res_weights[-1])*x1+xinit
        elif self.skip_weight == 'relu':
            x2 = utils.relu_straight_through(self.res_weights[-1])*x1+xinit
        elif self.skip_weight == 'half':
            x2 = x1 + xinit
        else:
            raise NotImplementedError('skip_weight mode [{:s}] is not found'.format(self.skip_weight))
        out = utils.relu_straight_through(x2) 
        # out = F.relu(x2)
        return out #, att_maps

    @torch.no_grad()
    def signal_prop(self, x_s, dim=(0, -1, -2, -3)):

        blocks = []
        if self.skip_weight == 'half':
            x_s = x_s * self.res_weights
        xinit = x_s #[:,0,:,:,:].clone()

        statistics_down = [] 
        statistics_up = []
    
        lists_stats = [(
                torch.mean(xinit.mean(dim) ** 2).item(),
                torch.mean(xinit.var(dim)).item(),
                float('nan'),
             )]
        for i, down in enumerate(self.down_path):
            if i == 0:
                x_s = down(x_s)
            else :
                x_s, stats = down.signal_prop(x_s, dim)
                # stats is a list of tuples of 3 elements
                # list_stats is a tuple of 2 elements
                statistics_down.append(stats)

            if i < len(self.down_path) - 2:
                blocks.append(x_s)

        
            

        for i, up in enumerate(self.up_path):
            out = x_s
           
           
            out_mu2 = torch.mean(out.mean(dim) ** 2).item()
            out_var = torch.mean(out.var(dim)).item()
            res_var = torch.mean(x_s.var(dim)).item()
            x_s, stats = up.signal_prop(out, blocks[-i - 1], dim)
            statistics_up.append(stats)
            lists_stats.append((out_mu2, out_var, res_var))
            
        x_s = self.final(x_s)    
        res_var = torch.mean(x_s.var(dim)).item()

        if self.skip_weight is None:
            x_s = self.res_weights[-1]*x_s+xinit
        elif self.skip_weight == 'softplus':
            x_s = F.softplus(self.res_weights[-1])*x_s+xinit
        elif self.skip_weight == 'sigmoid':
            x_s = F.sigmoid(self.res_weights[-1])*x_s+xinit
        elif self.skip_weight == 'relu':
            x_s = utils.relu_straight_through(self.res_weights[-1])*x_s+xinit
        elif self.skip_weight == 'half':
            x_s = x_s + xinit
        else:
            raise NotImplementedError('skip_weight mode [{:s}] is not found'.format(self.skip_weight))      

        out_mu2 = torch.mean(x_s.mean(dim) ** 2).item()
        out_var = torch.mean(x_s.var(dim)).item()
        lists_stats.append((out_mu2, out_var, res_var))
  
                
        # convert list of tuples to tuple of lists
        lists_stats = tuple(map(list, zip(*lists_stats)))
        return x_s, statistics_down, statistics_up, lists_stats

###########################################################################
# define the network class
class MyNetwork(nn.Module):
    def __init__(self, in_c):
        # call constructor from superclass
        super().__init__()
        
        # define network layers
        self.fc1 = nn.Linear(in_c, in_c//2)
        self.fc2 = nn.Linear(in_c//2, in_c//4)
        self.fc3 = nn.Linear(in_c//4, 1)
        
    def forward(self, x):
        # define forward pass
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = torch.sigmoid(self.fc3(x))
        return x
    

class UNetResWeightAtt(nn.Module):
    def __init__(self, 
                 in_nc=2, 
                 out_nc=1,  
                 nb=2, 
                 depth = 2, 
                 wf=16,
                 act_mode='R', 
                 downsample_mode='strideconv', 
                 upsample_mode='convtranspose', 
                 norm = 'nonorm', 
                 type_init= 'xavier', 
                 conditioned = False, 
                 use_linear = False, 
                 skip_weight = None,
                 keep_bias = False,
                 repeat = True
                 ) :
        super(UNetResWeightAtt, self).__init__() #nc=[16, 32, 64, 128],

        
        self.skip_weight = skip_weight
        
        self.down_path = nn.ModuleList()
        self.down_path.append(B.conv(in_nc, wf, bias=False, mode='C'))
        prev_channels = wf

        mode = get_norm_layer(norm, act_mode, repeat)

        for i in range(depth-1):
            self.down_path.append(NFDownBlock(downsample_mode=downsample_mode, prev_channels= prev_channels, wf = wf*(2 ** (i+1)), skip_weight=skip_weight,
                                               nb = nb, keep_bias=keep_bias, mode=mode, type_init=type_init, block_type='Wresblock')
            )
            # self.down_path.append(B.sequential(*[B.ResBlockWeight(prev_channels, prev_channels, bias=False, mode=mode, type_init=type_init, skip_weight=skip_weight) for _ in range(nb)], 
            #                                 downsample_block(prev_channels, wf*(2 ** (i+1)), bias=False, mode='2', type_init=type_init)))
            
            
            prev_channels = wf*(2 ** (i+1))
        # self.down_path.append(B.sequential(*[B.RCABlock(prev_channels, prev_channels, bias=False, mode=mode, type_init=type_init,conditioned=conditioned, use_linear=use_linear, skip_weight=skip_weight) for _ in range(nb)]))
      
        self.down_path.append(NFDownBlock(prev_channels= prev_channels, downsample=False, nb = nb, keep_bias=keep_bias, skip_weight=skip_weight,
                                         mode=mode, type_init=type_init, block_type='RCABlock',conditioned=conditioned, use_linear=use_linear)
                                         )
        #self.att = B.RCABlock(in_channels=prev_channels, out_channels=prev_channels, bias=False, reduction=16):
      


        self.up_path = nn.ModuleList()
        if self.skip_weight == 'sigmoid' or self.skip_weight == 'softplus':
            self.res_weights = nn.ParameterList([nn.Parameter(torch.FloatTensor([-6.0])) for i in range(depth)])
        elif self.skip_weight == 'relu':
             self.res_weights = nn.ParameterList([nn.Parameter(torch.FloatTensor([1e-6])) for i in range(depth)])
        else :
            self.res_weights = nn.ParameterList([nn.Parameter(torch.FloatTensor([0.])) for i in range(depth)])  

        for i in reversed(range(depth-1)):
            self.up_path.append(NFUpBlock(upsample_mode=upsample_mode, prev_channels= prev_channels, nb=nb, skip_weight = skip_weight,
                                          wf=wf*(2 ** i), keep_bias=keep_bias, mode=mode,type_init=type_init, block_type='Wresblock')
                                        )
            # self.up_path.append(
            #     B.sequential(upsample_block(prev_channels, wf*(2 ** i), bias=False, mode='2',type_init=type_init), *[B.ResBlockWeight(wf*(2 ** i), wf*(2 ** i), bias=False, mode=mode, type_init=type_init, skip_weight=skip_weight) for _ in range(nb)])
            # )
            prev_channels = wf*(2 ** i)

        self.final = B.conv(wf, out_nc, bias=False, mode='C', type_init=type_init)
        



    def forward(self, x, sigma):
        blocks = []
        xinit = x
        for i, down in enumerate(self.down_path):
            
            if i < len(self.down_path) - 1:
                x = down(x)
                blocks.append(x)
            else :
                x = down(x,sigma=sigma)
            

        for i, up in enumerate(self.up_path):
            if self.skip_weight is None:
                x = up(self.res_weights[i]*x+ blocks[-i - 1])
            elif self.skip_weight == 'softplus':
                x = up(F.softplus(self.res_weights[i])*x+ blocks[-i - 1])
            elif self.skip_weight == 'sigmoid':
                x = up(F.sigmoid(self.res_weights[i])*x+ blocks[-i - 1])
            elif self.skip_weight == 'relu':
                
                x = up(utils.relu_straight_through(self.res_weights[i])*x+ blocks[-i - 1])
            else :
                raise NotImplementedError('skip weight mode [{:s}] is not found'.format(self.skip_weight))
            
        x = self.final(x)
        if self.skip_weight is None:
            x = xinit+self.res_weights[-1]*x
        elif self.skip_weight == 'softplus':
            x = xinit+F.softplus(self.res_weights[-1])*x
        elif self.skip_weight == 'sigmoid':
            x = xinit+F.sigmoid(self.res_weights[-1])*x
        elif self.skip_weight == 'relu':
            x = xinit+utils.relu_straight_through(self.res_weights[-1])*x
        else:
            raise NotImplementedError('skip_weight mode [{:s}] is not found'.format(self.skip_weight)) 
        
        # out = F.relu(x)
        return x
    

    @torch.no_grad()
    def signal_prop(self, x, sigma=None, dim=(0, -1, -2, -3)):

        blocks = []
        xinit = x
        x_s = xinit

        statistics_down = [] 
        statistics_up = []
    
        lists_stats = [(
                torch.mean(xinit.mean(dim) ** 2).item(),
                torch.mean(xinit.var(dim)).item(),
                float('nan'),
             )]
        for i, down in enumerate(self.down_path):
            if i == 0:
                x_s = down(x_s)
            elif  i < len(self.down_path) - 1 :
                x_s, stats = down.signal_prop(x_s, dim=dim)
                statistics_down.append(stats)
            else :
                x_s, stats = down.signal_prop(x_s, sigma=sigma, dim=dim)
                statistics_down.append(stats)


            if i != len(self.down_path) - 1:
                blocks.append(x_s)

        

        for i, up in enumerate(self.up_path):
            if self.skip_weight is None:
                out= self.res_weights[i]*x_s+ blocks[-i - 1]
            elif self.skip_weight == 'softplus':
                out = F.softplus(self.res_weights[i])*x_s+ blocks[-i - 1]
            elif self.skip_weight == 'sigmoid':
                out = F.sigmoid(self.res_weights[i])*x_s+ blocks[-i - 1]
            elif self.skip_weight == 'relu':
                out = utils.relu_straight_through(self.res_weights[i])*x_s+ blocks[-i - 1]
            else:
                raise NotImplementedError('skip_weight mode [{:s}] is not found'.format(self.skip_weight))
    

            out_mu2 = torch.mean(out.mean(dim) ** 2).item()
            out_var = torch.mean(out.var(dim)).item()
            res_var = torch.mean(x_s.var(dim)).item()
            x_s, stats = up.signal_prop(out, dim)
            statistics_up.append(stats)
            lists_stats.append((out_mu2, out_var, res_var))
        
        x_s = self.final(x_s)   
        res_var = torch.mean(x_s.var(dim)).item()

        if self.skip_weight is None:
            x_s = self.res_weights[-1]*x_s+xinit
        elif self.skip_weight == 'softplus':
            x_s = F.softplus(self.res_weights[-1])*x_s+xinit
        elif self.skip_weight == 'sigmoid':
            x_s = F.sigmoid(self.res_weights[-1])*x_s+xinit
        elif self.skip_weight == 'relu':
            x_s = utils.relu_straight_through(self.res_weights[-1])*x_s+xinit
        else:
            raise NotImplementedError('skip_weight mode [{:s}] is not found'.format(self.skip_weight))      

        out_mu2 = torch.mean(x_s.mean(dim) ** 2).item()
        out_var = torch.mean(x_s.var(dim)).item()
        lists_stats.append((out_mu2, out_var, res_var))
  
                
        # convert list of tuples to tuple of lists
        lists_stats = tuple(map(list, zip(*lists_stats)))
        return x_s, statistics_down, statistics_up, lists_stats
###############################################################################################################


class UNetResWeightAttFull(nn.Module):
    def __init__(self, 
                 in_nc=2, 
                 out_nc=1,  
                 nb=2, 
                 depth = 2, 
                 wf=16,
                 act_mode='R', 
                 downsample_mode='strideconv', 
                 upsample_mode='convtranspose', 
                 norm = 'nonorm', 
                 type_init= 'xavier', 
                 conditioned = False, 
                 use_linear = False, 
                 skip_weight = None,
                 keep_bias = False,
                 repeat = True
                 ) :
        super(UNetResWeightAttFull, self).__init__() #nc=[16, 32, 64, 128],

        
        self.skip_weight = skip_weight
        
        self.down_path = nn.ModuleList()
        self.down_path.append(B.conv(in_nc, wf, bias=False, mode='C'))
        prev_channels = wf

        mode = get_norm_layer(norm, act_mode, repeat)

        for i in range(depth-1):
            self.down_path.append(NFDownBlock(downsample_mode=downsample_mode, prev_channels= prev_channels, wf = wf*(2 ** (i+1)), skip_weight=skip_weight,
                                               nb = nb, keep_bias=keep_bias, mode=mode, type_init=type_init, block_type='RCABlock',conditioned=False, use_linear=use_linear)
            )
            
            
            prev_channels = wf*(2 ** (i+1))
      
        self.down_path.append(NFDownBlock(prev_channels= prev_channels, downsample=False, nb = nb, keep_bias=keep_bias, skip_weight=skip_weight,
                                         mode=mode, type_init=type_init, block_type='RCABlock',conditioned=False, use_linear=use_linear)
                                         )     


        self.up_path = nn.ModuleList()
        if self.skip_weight == 'sigmoid' or self.skip_weight == 'softplus':
            self.res_weights = nn.ParameterList([nn.Parameter(torch.FloatTensor([-6.0])) for i in range(depth)])
        elif self.skip_weight == 'relu':
             self.res_weights = nn.ParameterList([nn.Parameter(torch.FloatTensor([1e-6])) for i in range(depth)])
        else :
            self.res_weights = nn.ParameterList([nn.Parameter(torch.FloatTensor([0.])) for i in range(depth)])  

        for i in reversed(range(depth-1)):
            self.up_path.append(NFUpBlock(upsample_mode=upsample_mode, prev_channels= prev_channels, nb=nb, skip_weight = skip_weight,
                                          wf=wf*(2 ** i), keep_bias=keep_bias, mode=mode,type_init=type_init, block_type='RCABlock',conditioned=False, use_linear=use_linear)
                                        )
     
            prev_channels = wf*(2 ** i)

        self.final = B.conv(wf, out_nc, bias=False, mode='C', type_init=type_init)
        



    def forward(self, x):
        blocks = []
        sigma = None
        xinit = x
        for i, down in enumerate(self.down_path):
            
            if i < len(self.down_path) - 1:
                if i == 0:
                    x = down(x)
                else :
                    x = down(x,sigma=sigma)

                blocks.append(x)
            else :
                x = down(x,sigma=sigma)
            

        for i, up in enumerate(self.up_path):
            if self.skip_weight is None:
                x = up(self.res_weights[i]*x+ blocks[-i - 1], sigma=sigma)
            elif self.skip_weight == 'softplus':
                x = up(F.softplus(self.res_weights[i])*x+ blocks[-i - 1], sigma=sigma)
            elif self.skip_weight == 'sigmoid':
                x = up(F.sigmoid(self.res_weights[i])*x+ blocks[-i - 1], sigma=sigma)
            elif self.skip_weight == 'relu':
                
                x = up(utils.relu_straight_through(self.res_weights[i])*x+ blocks[-i - 1], sigma=sigma)
            else :
                raise NotImplementedError('skip weight mode [{:s}] is not found'.format(self.skip_weight))
            
        x = self.final(x)
        if self.skip_weight is None:
            x = xinit+self.res_weights[-1]*x
        elif self.skip_weight == 'softplus':
            x = xinit+F.softplus(self.res_weights[-1])*x
        elif self.skip_weight == 'sigmoid':
            x = xinit+F.sigmoid(self.res_weights[-1])*x
        elif self.skip_weight == 'relu':
            x = xinit+utils.relu_straight_through(self.res_weights[-1])*x
        else:
            raise NotImplementedError('skip_weight mode [{:s}] is not found'.format(self.skip_weight)) 
        
        # out = F.relu(x)
        return x
    

    @torch.no_grad()
    def signal_prop(self, x, dim=(0, -1, -2, -3)):

        blocks = []
        xinit = x
        x_s = xinit
        sigma=None
        statistics_down = [] 
        statistics_up = []
    
        lists_stats = [(
                torch.mean(xinit.mean(dim) ** 2).item(),
                torch.mean(xinit.var(dim)).item(),
                float('nan'),
             )]
        for i, down in enumerate(self.down_path):
            if i == 0:
                x_s = down(x_s)
            elif  i < len(self.down_path) - 1 :
                x_s, stats = down.signal_prop(x_s, dim=dim)
                statistics_down.append(stats)
            else :
                x_s, stats = down.signal_prop(x_s, sigma=sigma, dim=dim)
                statistics_down.append(stats)


            if i != len(self.down_path) - 1:
                blocks.append(x_s)

        

        for i, up in enumerate(self.up_path):
            if self.skip_weight is None:
                out= self.res_weights[i]*x_s+ blocks[-i - 1]
            elif self.skip_weight == 'softplus':
                out = F.softplus(self.res_weights[i])*x_s+ blocks[-i - 1]
            elif self.skip_weight == 'sigmoid':
                out = F.sigmoid(self.res_weights[i])*x_s+ blocks[-i - 1]
            elif self.skip_weight == 'relu':
                out = utils.relu_straight_through(self.res_weights[i])*x_s+ blocks[-i - 1]
            else:
                raise NotImplementedError('skip_weight mode [{:s}] is not found'.format(self.skip_weight))
    

            out_mu2 = torch.mean(out.mean(dim) ** 2).item()
            out_var = torch.mean(out.var(dim)).item()
            res_var = torch.mean(x_s.var(dim)).item()
            x_s, stats = up.signal_prop(out, dim)
            statistics_up.append(stats)
            lists_stats.append((out_mu2, out_var, res_var))
        
        x_s = self.final(x_s)   
        res_var = torch.mean(x_s.var(dim)).item()

        if self.skip_weight is None:
            x_s = self.res_weights[-1]*x_s+xinit
        elif self.skip_weight == 'softplus':
            x_s = F.softplus(self.res_weights[-1])*x_s+xinit
        elif self.skip_weight == 'sigmoid':
            x_s = F.sigmoid(self.res_weights[-1])*x_s+xinit
        elif self.skip_weight == 'relu':
            x_s = utils.relu_straight_through(self.res_weights[-1])*x_s+xinit
        else:
            raise NotImplementedError('skip_weight mode [{:s}] is not found'.format(self.skip_weight))      

        out_mu2 = torch.mean(x_s.mean(dim) ** 2).item()
        out_var = torch.mean(x_s.var(dim)).item()
        lists_stats.append((out_mu2, out_var, res_var))
  
                
        # convert list of tuples to tuple of lists
        lists_stats = tuple(map(list, zip(*lists_stats)))
        return x_s, statistics_down, statistics_up, lists_stats



###############################################################################################################
class UNetRes(nn.Module):
    def __init__(self, 
                 in_nc=2, 
                 out_nc=1,  
                 nb=2, 
                 depth = 2, 
                 wf=16,
                 act_mode='R', 
                 downsample_mode='strideconv', 
                 upsample_mode='convtranspose', 
                 norm = 'nonorm', 
                 type_init= 'xavier', 
                 keep_bias = False,
                 repeat = True
                 ) :
        super(UNetRes, self).__init__() #nc=[16, 32, 64, 128],
        self.down_path = nn.ModuleList()
        self.down_path.append(B.conv(in_nc, wf, bias=False, mode='C'))
        prev_channels = wf

        mode = get_norm_layer(norm, act_mode, repeat)


        for i in range(depth-1):

            self.down_path.append(NFDownBlock(downsample_mode=downsample_mode, prev_channels= prev_channels, wf = wf*(2 ** (i+1)), 
                                               nb = nb, keep_bias=keep_bias, mode=mode, type_init=type_init, block_type='resblock')
                                               ) 
            
            prev_channels = wf*(2 ** (i+1))
        self.down_path.append(NFDownBlock(prev_channels= prev_channels, downsample=False, nb = nb, keep_bias=keep_bias, 
                                          mode=mode, type_init=type_init, block_type='resblock')
                                          )

        self.up_path = nn.ModuleList()
        for i in reversed(range(depth-1)):

            self.up_path.append(NFUpBlock(upsample_mode=upsample_mode, prev_channels= prev_channels, nb=nb,
                                          wf=wf*(2 ** i), keep_bias=keep_bias, mode=mode,type_init=type_init, block_type='resblock')
                                        )
            prev_channels = wf*(2 ** i)

        self.final = B.conv(wf, out_nc, bias=False, mode='C', type_init=type_init)



    def forward(self, x):
        blocks = []
        x_init=x
        for i, down in enumerate(self.down_path):
            x = down(x)
            if i != len(self.down_path) - 1:
                blocks.append(x)

        for i, up in enumerate(self.up_path):
            x = up(x+ blocks[-i - 1])

        x = self.final(x)
        return (x+x_init)
    
    @torch.no_grad()
    def signal_prop(self, x, dim=(0, -1, -2, -3)):

        blocks = []
        xinit = x
        x_s = xinit

        statistics_down = []
        statistics_up = []
    
        lists_stats = [(
                torch.mean(xinit.mean(dim) ** 2).item(),
                torch.mean(xinit.var(dim)).item(),
                float('nan'),
             )]
        for i, down in enumerate(self.down_path):
            if i == 0:
                x_s = down(x_s)
            else :
                x_s, stats = down.signal_prop(x_s, dim)
                # stats is a list of tuples of 3 elements
                # list_stats is a tuple of 2 elements
                statistics_down.append(stats)

            if i != len(self.down_path) - 1:
                blocks.append(x_s)

        
            

        for i, up in enumerate(self.up_path):

            out = x_s+ blocks[-i - 1]
            out_mu2 = torch.mean(out.mean(dim) ** 2).item()
            out_var = torch.mean(out.var(dim)).item()
            res_var = torch.mean(x_s.var(dim)).item()
            x_s, stats = up.signal_prop(out, dim)
            statistics_up.append(stats)
            lists_stats.append((out_mu2, out_var, res_var))
           
        x_s = self.final(x_s)
        res_var = torch.mean(x_s.var(dim)).item()
        x_s = x_s+xinit
        out_mu2 = torch.mean(x_s.mean(dim) ** 2).item()
        out_var = torch.mean(x_s.var(dim)).item()
        lists_stats.append((out_mu2, out_var, res_var))        
  
            
        # convert list of tuples to tuple of lists
        lists_stats = tuple(map(list, zip(*lists_stats)))
        return x_s, statistics_down, statistics_up, lists_stats
    

# class ResUNet(nn.Module):
#     def __init__(self, in_nc=1, out_nc=1, nc=[64, 128, 256, 512], nb=4, act_mode='L', downsample_mode='strideconv', upsample_mode='convtranspose'):
#         super(ResUNet, self).__init__()

#         self.m_head = B.conv(in_nc, nc[0], bias=False, mode='C')

#         # downsample
#         if downsample_mode == 'avgpool':
#             downsample_block = B.downsample_avgpool
#         elif downsample_mode == 'maxpool':
#             downsample_block = B.downsample_maxpool
#         elif downsample_mode == 'strideconv':
#             downsample_block = B.downsample_strideconv
#         else:
#             raise NotImplementedError('downsample mode [{:s}] is not found'.format(downsample_mode))

#         self.m_down1 = B.sequential(*[B.IMDBlock(nc[0], nc[0], bias=False, mode='C'+act_mode) for _ in range(nb)], downsample_block(nc[0], nc[1], bias=False, mode='2'))
#         self.m_down2 = B.sequential(*[B.IMDBlock(nc[1], nc[1], bias=False, mode='C'+act_mode) for _ in range(nb)], downsample_block(nc[1], nc[2], bias=False, mode='2'))
#         self.m_down3 = B.sequential(*[B.IMDBlock(nc[2], nc[2], bias=False, mode='C'+act_mode) for _ in range(nb)], downsample_block(nc[2], nc[3], bias=False, mode='2'))

#         self.m_body  = B.sequential(*[B.IMDBlock(nc[3], nc[3], bias=False, mode='C'+act_mode) for _ in range(nb)])

#         # upsample
#         if upsample_mode == 'upconv':
#             upsample_block = B.upsample_upconv
#         elif upsample_mode == 'pixelshuffle':
#             upsample_block = B.upsample_pixelshuffle
#         elif upsample_mode == 'convtranspose':
#             upsample_block = B.upsample_convtranspose
#         else:
#             raise NotImplementedError('upsample mode [{:s}] is not found'.format(upsample_mode))

#         self.m_up3 = B.sequential(upsample_block(nc[3], nc[2], bias=False, mode='2'), *[B.IMDBlock(nc[2], nc[2], bias=False, mode='C'+act_mode) for _ in range(nb)])
#         self.m_up2 = B.sequential(upsample_block(nc[2], nc[1], bias=False, mode='2'), *[B.IMDBlock(nc[1], nc[1], bias=False, mode='C'+act_mode) for _ in range(nb)])
#         self.m_up1 = B.sequential(upsample_block(nc[1], nc[0], bias=False, mode='2'), *[B.IMDBlock(nc[0], nc[0], bias=False, mode='C'+act_mode) for _ in range(nb)])

#         self.m_tail = B.conv(nc[0], out_nc, bias=False, mode='C')

#     def forward(self, x):
        
#         h, w = x.size()[-2:]
#         paddingBottom = int(np.ceil(h/8)*8-h)
#         paddingRight = int(np.ceil(w/8)*8-w)
#         x = nn.ReplicationPad2d((0, paddingRight, 0, paddingBottom))(x)

#         x1 = self.m_head(x)
#         x2 = self.m_down1(x1)
#         x3 = self.m_down2(x2)
#         x4 = self.m_down3(x3)
#         x = self.m_body(x4)
#         x = self.m_up3(x+x4)
#         x = self.m_up2(x+x3)
#         x = self.m_up1(x+x2)
#         x = self.m_tail(x+x1)
#         x = x[..., :h, :w]

#         return x


class UNetResSubP(nn.Module):
    def __init__(self, in_nc=1, out_nc=1, nc=[64, 128, 256, 512], nb=2, act_mode='R', downsample_mode='strideconv', upsample_mode='convtranspose'):
        super(UNetResSubP, self).__init__()
        sf = 2
        self.m_ps_down = B.PixelUnShuffle(sf)
        self.m_ps_up = nn.PixelShuffle(sf)
        self.m_head = B.conv(in_nc*sf*sf, nc[0], mode='C'+act_mode[-1])

        # downsample
        if downsample_mode == 'avgpool':
            downsample_block = B.downsample_avgpool
        elif downsample_mode == 'maxpool':
            downsample_block = B.downsample_maxpool
        elif downsample_mode == 'strideconv':
            downsample_block = B.downsample_strideconv
        else:
            raise NotImplementedError('downsample mode [{:s}] is not found'.format(downsample_mode))

        self.m_down1 = B.sequential(*[B.ResBlock(nc[0], nc[0], mode='C'+act_mode+'C') for _ in range(nb)], downsample_block(nc[0], nc[1], mode='2'+act_mode))
        self.m_down2 = B.sequential(*[B.ResBlock(nc[1], nc[1], mode='C'+act_mode+'C') for _ in range(nb)], downsample_block(nc[1], nc[2], mode='2'+act_mode))
        self.m_down3 = B.sequential(*[B.ResBlock(nc[2], nc[2], mode='C'+act_mode+'C') for _ in range(nb)], downsample_block(nc[2], nc[3], mode='2'+act_mode))

        self.m_body  = B.sequential(*[B.ResBlock(nc[3], nc[3], mode='C'+act_mode+'C') for _ in range(nb+1)])

        # upsample
        if upsample_mode == 'upconv':
            upsample_block = B.upsample_upconv
        elif upsample_mode == 'pixelshuffle':
            upsample_block = B.upsample_pixelshuffle
        elif upsample_mode == 'convtranspose':
            upsample_block = B.upsample_convtranspose
        else:
            raise NotImplementedError('upsample mode [{:s}] is not found'.format(upsample_mode))

        self.m_up3 = B.sequential(upsample_block(nc[3], nc[2], mode='2'+act_mode), *[B.ResBlock(nc[2], nc[2], mode='C'+act_mode+'C') for _ in range(nb)])
        self.m_up2 = B.sequential(upsample_block(nc[2], nc[1], mode='2'+act_mode), *[B.ResBlock(nc[1], nc[1], mode='C'+act_mode+'C') for _ in range(nb)])
        self.m_up1 = B.sequential(upsample_block(nc[1], nc[0], mode='2'+act_mode), *[B.ResBlock(nc[0], nc[0], mode='C'+act_mode+'C') for _ in range(nb)])

        self.m_tail = B.conv(nc[0], out_nc*sf*sf, bias=False, mode='C')

    def forward(self, x0):
        x0_d = self.m_ps_down(x0)
        x1 = self.m_head(x0_d)
        x2 = self.m_down1(x1)
        x3 = self.m_down2(x2)
        x4 = self.m_down3(x3)
        x = self.m_body(x4)
        x = self.m_up3(x+x4)
        x = self.m_up2(x+x3)
        x = self.m_up1(x+x2)
        x = self.m_tail(x+x1)
        x = self.m_ps_up(x) + x0

        return x


class UNetPlus(nn.Module):
    def __init__(self, in_nc=3, out_nc=3, nc=[64, 128, 256, 512], nb=1, act_mode='R', downsample_mode='strideconv', upsample_mode='convtranspose'):
        super(UNetPlus, self).__init__()

        self.m_head = B.conv(in_nc, nc[0], mode='C')

        # downsample
        if downsample_mode == 'avgpool':
            downsample_block = B.downsample_avgpool
        elif downsample_mode == 'maxpool':
            downsample_block = B.downsample_maxpool
        elif downsample_mode == 'strideconv':
            downsample_block = B.downsample_strideconv
        else:
            raise NotImplementedError('downsample mode [{:s}] is not found'.format(downsample_mode))

        self.m_down1 = B.sequential(*[B.conv(nc[0], nc[0], mode='C'+act_mode) for _ in range(nb)], downsample_block(nc[0], nc[1], mode='2'+act_mode[1]))
        self.m_down2 = B.sequential(*[B.conv(nc[1], nc[1], mode='C'+act_mode) for _ in range(nb)], downsample_block(nc[1], nc[2], mode='2'+act_mode[1]))
        self.m_down3 = B.sequential(*[B.conv(nc[2], nc[2], mode='C'+act_mode) for _ in range(nb)], downsample_block(nc[2], nc[3], mode='2'+act_mode[1]))

        self.m_body  = B.sequential(*[B.conv(nc[3], nc[3], mode='C'+act_mode) for _ in range(nb+1)])

        # upsample
        if upsample_mode == 'upconv':
            upsample_block = B.upsample_upconv
        elif upsample_mode == 'pixelshuffle':
            upsample_block = B.upsample_pixelshuffle
        elif upsample_mode == 'convtranspose':
            upsample_block = B.upsample_convtranspose
        else:
            raise NotImplementedError('upsample mode [{:s}] is not found'.format(upsample_mode))

        self.m_up3 = B.sequential(upsample_block(nc[3], nc[2], mode='2'+act_mode), *[B.conv(nc[2], nc[2], mode='C'+act_mode) for _ in range(nb-1)], B.conv(nc[2], nc[2], mode='C'+act_mode[1]))
        self.m_up2 = B.sequential(upsample_block(nc[2], nc[1], mode='2'+act_mode), *[B.conv(nc[1], nc[1], mode='C'+act_mode) for _ in range(nb-1)], B.conv(nc[1], nc[1], mode='C'+act_mode[1]))
        self.m_up1 = B.sequential(upsample_block(nc[1], nc[0], mode='2'+act_mode), *[B.conv(nc[0], nc[0], mode='C'+act_mode) for _ in range(nb-1)], B.conv(nc[0], nc[0], mode='C'+act_mode[1]))

        self.m_tail = B.conv(nc[0], out_nc, mode='C')

    def forward(self, x0):
        x1 = self.m_head(x0)
        x2 = self.m_down1(x1)
        x3 = self.m_down2(x2)
        x4 = self.m_down3(x3)
        x = self.m_body(x4)
        x = self.m_up3(x+x4)
        x = self.m_up2(x+x3)
        x = self.m_up1(x+x2)
        x = self.m_tail(x+x1) + x0
        return x

'''
# ====================
# nonlocalunet
# ====================
'''

class NonLocalUNet(nn.Module):
    def __init__(self, in_nc=3, out_nc=3, nc=[64,128,256,512], nb=1, act_mode='R', downsample_mode='strideconv', upsample_mode='convtranspose'):
        super(NonLocalUNet, self).__init__()

        down_nonlocal = B.NonLocalBlock2D(nc[2], kernel_size=1, stride=1, padding=0, bias=True, act_mode='B', downsample=False, downsample_mode='strideconv')
        up_nonlocal = B.NonLocalBlock2D(nc[2], kernel_size=1, stride=1, padding=0, bias=True, act_mode='B', downsample=False, downsample_mode='strideconv')

        self.m_head = B.conv(in_nc, nc[0], mode='C'+act_mode[-1])

        # downsample
        if downsample_mode == 'avgpool':
            downsample_block = B.downsample_avgpool
        elif downsample_mode == 'maxpool':
            downsample_block = B.downsample_maxpool
        elif downsample_mode == 'strideconv':
            downsample_block = B.downsample_strideconv
        else:
            raise NotImplementedError('downsample mode [{:s}] is not found'.format(downsample_mode))


        self.m_down1 = B.sequential(*[B.conv(nc[0], nc[0], mode='C'+act_mode) for _ in range(nb)], downsample_block(nc[0], nc[1], mode='2'+act_mode))
        self.m_down2 = B.sequential(*[B.conv(nc[1], nc[1], mode='C'+act_mode) for _ in range(nb)], downsample_block(nc[1], nc[2], mode='2'+act_mode))
        self.m_down3 = B.sequential(down_nonlocal, *[B.conv(nc[2], nc[2], mode='C'+act_mode) for _ in range(nb)], downsample_block(nc[2], nc[3], mode='2'+act_mode))

        self.m_body  = B.sequential(*[B.conv(nc[3], nc[3], mode='C'+act_mode) for _ in range(nb+1)])

        # upsample
        if upsample_mode == 'upconv':
            upsample_block = B.upsample_upconv
        elif upsample_mode == 'pixelshuffle':
            upsample_block = B.upsample_pixelshuffle
        elif upsample_mode == 'convtranspose':
            upsample_block = B.upsample_convtranspose
        else:
            raise NotImplementedError('upsample mode [{:s}] is not found'.format(upsample_mode))


        self.m_up3 = B.sequential(upsample_block(nc[3], nc[2], mode='2'+act_mode), *[B.conv(nc[2], nc[2], mode='C'+act_mode) for _ in range(nb)], up_nonlocal)
        self.m_up2 = B.sequential(upsample_block(nc[2], nc[1], mode='2'+act_mode), *[B.conv(nc[1], nc[1], mode='C'+act_mode) for _ in range(nb)])
        self.m_up1 = B.sequential(upsample_block(nc[1], nc[0], mode='2'+act_mode), *[B.conv(nc[0], nc[0], mode='C'+act_mode) for _ in range(nb)])

        self.m_tail = B.conv(nc[0], out_nc, mode='C')

    def forward(self, x0):
        x1 = self.m_head(x0)
        x2 = self.m_down1(x1)
        x3 = self.m_down2(x2)
        x4 = self.m_down3(x3)
        x = self.m_body(x4)
        x = self.m_up3(x+x4)
        x = self.m_up2(x+x3)
        x = self.m_up1(x+x2)
        x = self.m_tail(x+x1) + x0
        return x

class NFDownBlockFix(nn.Module):

    expansion = 4

    def __init__(self,
        downsample_mode='strideconv',
        nb=2, 
        wf=16,
        type_init= 'xavier', 
        prev_channels = 64,
        keep_bias = False,
        mode = 'CRC',
        alpha = 1.0, 
        downsample = True, 
        expected_std=1.0, 
        block_type = 'resblock',
        skip_weight = None, 
        gain = 1.0,
        conditioned = None,
        use_linear=None, 
        use_sigma=False

    ):
        super().__init__()
        self.block_type = block_type

        self.use_sigma = use_sigma
    
        # downsample
        if downsample_mode == 'avgpool':
            downsample_block = B.downsample_avgpool
        elif downsample_mode == 'maxpool':
            downsample_block = B.downsample_maxpool
        elif downsample_mode == 'strideconv':
            downsample_block = B.downsample_strideconv
        else:
            raise NotImplementedError('downsample mode [{:s}] is not found'.format(downsample_mode))


        if block_type == 'NFblock':#(expected_std**2+(i+1)*alpha**2)**0.5
            self.branch = nn.Sequential(
                    *[B.NFResBlock(wf, wf, bias=keep_bias, mode=mode, type_init=type_init, 
                                beta = expected_std, alpha = alpha, gain=gain) for i in range(nb)]
                    )
        elif block_type == 'Halfresblock':
            self.branch = nn.Sequential(
                    *[B.HalfResBlock(prev_channels, prev_channels, bias=keep_bias, mode=mode, type_init=type_init, 
                                alpha = alpha) for _ in range(nb)]
                    )
        elif block_type == 'Wresblock':
            self.branch = nn.Sequential(
                *[B.ResBlockWeight(prev_channels, prev_channels, bias=keep_bias,
                                    mode=mode, type_init=type_init, skip_weight = skip_weight) for _ in range(nb)]
            )
        elif block_type == 'WresblockEmb':
            self.branch = nn.Sequential(
                *[B.ResBlockWeightEmb(prev_channels, prev_channels, bias=keep_bias,
                                    mode=mode, type_init=type_init, skip_weight = skip_weight) for _ in range(nb)]
            )
        elif block_type == 'resblock':
            self.branch = nn.Sequential(
                *[B.ResBlock(prev_channels, prev_channels, bias=keep_bias,
                                    mode=mode, type_init=type_init) for _ in range(nb)]
            )
        elif block_type == 'RCABlock':
            self.branch = nn.Sequential(
                *[B.RCABlock(prev_channels, prev_channels, bias=keep_bias,
                                    mode=mode, type_init=type_init,conditioned=conditioned, use_linear=use_linear, skip_weight=skip_weight) for _ in range(nb)]
            )



        else:
            raise NotImplementedError('block type [{:s}] is not found'.format(block_type))
            



        self.downsample = downsample_block(prev_channels, wf, bias=keep_bias, mode='2', type_init=type_init) if downsample else nn.Identity()

    def forward(self, x, sigma=None):
        dx = self.downsample(x) 
        if self.block_type == 'RCABlock' or self.use_sigma:
            for _, down in enumerate(self.branch):
                dx = down(dx, sigma=sigma)
            out = dx
        else:
           out = self.branch(dx)
        return out


    @torch.no_grad()
    def signal_prop(self, x, dim=(0, -1, -2), sigma = None):
        statistics = [(
            torch.mean(x.mean(dim) ** 2).item(),
            torch.mean(x.var(dim)).item(),
            float('nan'),
        )]
        # forward code
        for i, down in enumerate(self.branch):
            if self.block_type == 'RCABlock' or self.use_sigma:
                x, stats = down.signal_prop(x, dim=dim, sigma=sigma)
            else :
                x, stats = down.signal_prop(x,dim= dim)
            statistics.append(stats)
        # downsample
        out = self.downsample(x)
        # print("current statistics", statistics)
        sp = tuple(map(list, zip(*statistics)))

        return out, sp
class NFUNetResFix(nn.Module):
    def __init__(self, in_nc=2, 
                out_nc=1, 
                nb=2, 
                depth = 2, 
                wf=16,
                act_mode='R', 
                downsample_mode='strideconv', 
                upsample_mode='convtranspose', 
                norm = 'nonorm', 
                type_init= 'xavier', 
                skip_weight = None, 
                keep_bias = False, 
                alpha = 1.0,
                repeat = True, 
                bUseClamp = True, 
                bUseAtt = False, 
                bUseComposition = False,
                bUseMask = False,
                use_gamma = False,
                bExtendedConv = False
                ) :
        super(NFUNetResFix, self).__init__() #nc=[16, 32, 64, 128],

        self.down_path = nn.ModuleList()
        # if bExtendedConv :
        #     self.down_path.append(B.conv(in_nc, wf, bias=keep_bias, mode='CRCRCRC'))
        # else :
        self.down_path.append(B.conv(in_nc, wf, bias=keep_bias, mode='C'))
        
        prev_channels = wf
        self.down_scaling = nn.ModuleList()
        self.alpha = alpha
        self.nb = nb
        self.bUseMask = bUseMask
        # self.bUseClamp = bUseClamp
        # self.use_gamma = use_gamma
        # if self.use_gamma :
        #     self.scale_gamma = nn.Parameter(torch.ones(1))

        mode = get_norm_layer(norm, act_mode, repeat)        
        match act_mode:
            case 'R':  
                # with torch.no_grad():
                    # y = F.relu(torch.randn(1024, 256).cuda()) 
                    # gamma = y.var(dim=1, keepdim=True)
                gain = 1.7139588594436646 #1.2716004848480225 
                    #gamma.mean(dim=0, keepdim=True)

            case 'L':
                # with torch.no_grad():
                    # y = F.leaky_relu(torch.randn(1024, 256).cuda()) 
                    # gamma = y.var(dim=1, keepdim=True)
                gain =  1.70590341091156 #gamma.mean(dim=0, keepdim=True)
            case 'E':
                # with torch.no_grad():
                    # y = F.elu(torch.randn(1024, 256).cuda()) 
                    # gamma = y.var(dim=1, keepdim=True)
                gain = 1.2716004848480225 
                    #gamma.mean(dim=0, keepdim=True)

        # expected_std = ((1.0+(2*(depth)+1)*nb*(alpha**2))**0.5)
        expected_std = (((1.0+nb*(alpha**2))**(depth+1))*(1.0+nb*depth*(alpha**2)))**0.5
        self.init_scaling = B.Scaling(expected_std)
        self.down_path.append(NFDownBlockFix(expected_std= expected_std, alpha = self.alpha, prev_channels= wf , wf = wf, downsample=False, 
                                          nb = nb, keep_bias=keep_bias, 
                                          mode=mode, type_init=type_init, block_type = 'NFblock', gain=gain)
                                          )


        list_expected_std_up = []
        list_expected_std_input = []

        self.bUseAtt = bUseAtt

        for i in range(depth-1):
                        
            self.down_path.append(NFDownBlockFix(downsample_mode=downsample_mode, prev_channels= prev_channels, wf = wf*(2 ** (i+1)), alpha = self.alpha, expected_std = expected_std,
                                               nb = nb, keep_bias=keep_bias, mode=mode, type_init=type_init, block_type = 'NFblock', gain = gain)
                                               )                         
            expected_std = (expected_std **2 +  nb*(alpha**2))**0.5
            list_expected_std_input.append(expected_std)
            # list_expected_std_up.append((expected_std**2+(2*(depth-i)+1)*nb*(alpha**2))**0.5 )
            list_expected_std_up.append((((1.0+nb*(alpha**2))**(i+1))*(1.0+nb*depth*(alpha**2)))**0.5)
            # todo: add rescale
            self.down_scaling.append(B.Scaling(list_expected_std_up[-1])) 
            prev_channels = wf*(2 ** (i+1))
            # after 1 downblock
            

        expected_std = (expected_std ** 2 + alpha**2) ** 0.5

        self.up_path = nn.ModuleList()
    
        for i in reversed(range(depth-1)):
            # beta = 1./ expected_std
            self.up_path.append(NFUpBlock(expected_std= expected_std, alpha = self.alpha, upsample_mode=upsample_mode, 
                                            prev_channels= prev_channels, nb=nb,
                                            wf=wf*(2 ** i), keep_bias=keep_bias, mode=mode,type_init=type_init, 
                                            block_type = 'NFblock' if (i > 0 or not bUseAtt) else 'NFblock-PSA', gain=gain, bUseComposition=bUseComposition
                                            ))
        
           


            prev_channels = wf*(2 ** i)
            expected_std = (expected_std **2 +  nb*(alpha**2))**0.5
        self.up_path.append(NFUpBlock(expected_std= expected_std, alpha = self.alpha, upsample = False, 
                                            prev_channels= wf, nb=nb,
                                            wf=wf, keep_bias=keep_bias, mode=mode,type_init=type_init, 
                                            block_type = 'NFblock' if (i > 0 or not bUseAtt) else 'NFblock-PSA', gain=gain, bUseComposition=bUseComposition
                                            ))

        if bExtendedConv :
            self.final = B.conv(wf, out_nc, bias=keep_bias, mode='CECECEC')
        else :
            self.final = B.conv(wf, out_nc, bias=keep_bias, mode='C', type_init=type_init)
        # expected_std = (expected_std**2 + 1.0)**0.5
        # self.beta = 1./ expected_std

        if bUseMask :
            self.mask = B.PSA_i(inplanes = 1) 
            # self.mask = B.PSA_o(inplanes = wf, planes= wf) 
           

    def forward(self, x):
        if self.bUseMask: 
            x, my_mask = self.mask(x)
        blocks = []
        xinit = x
        x_s = self.init_scaling(xinit)
        for i, down in enumerate(self.down_path):
            x_s = down(x_s)

            if i < len(self.down_path) - 1 and i > 0:
                blocks.append(x_s)

            if i > 0 and i < len(self.down_path) - 1:
                x_s = self.down_scaling[i-1](x_s)
     
                
        for i, up in enumerate(self.up_path):
                             
            if i == len(self.up_path) - 1 and self.bUseAtt:
                x_s, att_maps = up(self.alpha*x_s+blocks[-i - 1])
            else :
                if i == 0 : 
                    x_s = up(x_s)
                else :
                    x_s = up(self.alpha*x_s+ blocks[-i ])


        x_s = self.final(x_s)   

        if self.bUseMask :
            return F.relu(x_s), my_mask #, att_maps
        else :
            return utils.relu_straight_through(x_s) #, None #att_maps


    @torch.no_grad()
    def signal_prop(self, x, dim=(0, -1, -2, -3)):

        blocks = []
        xinit = x
        x_s = self.init_scaling(xinit)
        statistics_down = []
        statistics_up = []
    
        lists_stats = [(
                torch.mean(xinit.mean(dim) ** 2).item(),
                torch.mean(xinit.var(dim)).item(),
                float('nan'),
             )]
        for i, down in enumerate(self.down_path):
            if i == 0:
                x_s = down(x_s)
            else :
                x_s, stats= down.signal_prop(x_s, dim)
                # stats is a list of tuples of 3 elements
                # list_stats is a tuple of 2 elements
                statistics_down.append(stats)
                # lists_stats.append(list_stats)

            if i != len(self.down_path) - 1:
                blocks.append(x_s)

            if i > 0 and i != len(self.down_path) - 1:
                x_s = self.down_scaling[i-1](x_s)
        
            

        for i, up in enumerate(self.up_path):
            out = self.alpha*x_s+ blocks[-i - 1]
            out_mu2 = torch.mean(out.mean(dim) ** 2).item()
            out_var = torch.mean(out.var(dim)).item()
            res_var = torch.mean(x_s.var(dim)).item()
            x_s, stats = up.signal_prop(out, dim)
            statistics_up.append(stats)
            lists_stats.append((out_mu2, out_var, res_var))
           
        x_s = self.final(x_s)   
        res_var = torch.mean(x_s.var(dim)).item()
        x_s = x_s+self.alpha*xinit
        out_mu2 = torch.mean(x_s.mean(dim) ** 2).item()
        out_var = torch.mean(x_s.var(dim)).item()
        lists_stats.append((out_mu2, out_var, res_var))
  
                
        # convert list of tuples to tuple of lists
        lists_stats = tuple(map(list, zip(*lists_stats)))
        return x_s, statistics_down, statistics_up, lists_stats
    

class NFUNetResMultBranch2DecoderFix(nn.Module):
    def __init__(self, in_nc=2, 
                out_nc=1, 
                nb=2, 
                depth = 2, 
                wf=16,
                act_mode='R', 
                downsample_mode='strideconv', 
                upsample_mode='convtranspose', 
                norm = 'nonorm', 
                type_init= 'xavier', 
                alpha = 1.0,
                repeat = True, 
                bUse_N = True
                ) :
        super(NFUNetResMultBranch2DecoderFix, self).__init__() 

        self.down_path = nn.ModuleList()
        self.down_path.append(B.conv(in_nc, wf, bias=False, mode='C'))

        self.down_path2 = nn.ModuleList()
        self.down_path2.append(B.conv(in_nc, wf, bias=False, mode='C'))

        prev_channels = wf
        self.down_scaling = nn.ModuleList()
        self.alpha = alpha
        self.nb = nb


        mode = get_norm_layer(norm, act_mode, repeat)        
        match act_mode:
            case 'R':  
                gain = 1.7139588594436646 
            case 'L':
                gain =  1.70590341091156 
            case 'E':
                gain = 1.2716004848480225 
                   
        expected_std = (((1.0+nb*(alpha**2))**(depth+1))*(1.0+nb*depth*(alpha**2)))**0.5
        self.init_scaling = B.Scaling(expected_std)

        list_expected_std_up = []
        list_expected_std_input = []

        self.res_weights = nn.ParameterList([nn.Parameter(torch.FloatTensor([0.])) for i in range(depth-1)])
        self.down_path.append(NFDownBlockFix(expected_std= expected_std, alpha = self.alpha, prev_channels= wf, wf=wf, downsample=False, 
                                          nb = nb, keep_bias=False, mode=mode, type_init=type_init, block_type = 'NFblock', gain=gain)
                                          )
        self.down_path2.append(NFDownBlockFix(expected_std= expected_std, alpha = self.alpha, prev_channels= wf, wf=wf, downsample=False,
                                           nb=nb, keep_bias=False, mode=mode, type_init=type_init, block_type = 'NFblock', gain=gain)
        
                                  )

        for i in range(depth-1):
                        
            self.down_path.append(NFDownBlockFix(downsample_mode=downsample_mode, prev_channels= prev_channels, wf = wf*(2 ** (i+1)), alpha = self.alpha, expected_std = expected_std,
                                               nb = nb, keep_bias=False, mode=mode, type_init=type_init, block_type = 'NFblock', gain = gain)
                                               )
            self.down_path2.append(NFDownBlockFix(downsample_mode=downsample_mode, prev_channels= prev_channels, wf = wf*(2 ** (i+1)), alpha = self.alpha, expected_std = expected_std,
                                                  nb = nb, keep_bias=False, mode=mode, type_init=type_init, block_type = 'NFblock', gain = gain)
                                                  )
            expected_std = (expected_std **2 +  nb*(alpha**2))**0.5
            list_expected_std_input.append(expected_std)
            list_expected_std_up.append((((1.0+nb*(alpha**2))**(i+1))*(1.0+nb*depth*(alpha**2)))**0.5)
            self.down_scaling.append(B.Scaling(list_expected_std_up[-1])) 
            prev_channels = wf*(2 ** (i+1))
            

        
        self.fusion = B.conv(2*prev_channels,prev_channels, bias=False, mode='CE', type_init=type_init)
        if bUse_N :
            self.normalization = B.conv(out_channels=[2*prev_channels, int(104/(2 ** (depth-1))),  int(128/(2 ** (depth-1))),  int(128/(2 ** (depth-1)))], mode="G")
        else :
            self.normalization = nn.Identity()
        expected_std = (expected_std ** 2 + alpha**2) ** 0.5

        self.up_path = nn.ModuleList()
    
        for i in reversed(range(depth-1)):
            self.up_path.append(NFUpBlock(expected_std= expected_std, alpha = self.alpha, upsample_mode=upsample_mode, 
                                            prev_channels= prev_channels, nb=nb,
                                            wf=wf*(2 ** i), keep_bias=False, mode=mode,type_init=type_init, 
                                            block_type = 'NFblock', gain=gain))
           


            prev_channels = wf*(2 ** i)
            expected_std = (expected_std **2 +  nb*(alpha**2))**0.5
        self.up_path.append(NFUpBlock(expected_std= expected_std, alpha = self.alpha, upsample = False, 
                                            prev_channels= wf, nb=nb,
                                            wf=wf, keep_bias=False, mode=mode,type_init=type_init, 
                                            block_type = 'NFblock', gain=gain))
                                            
        self.final = B.conv(wf, out_nc, bias=False, mode='C', type_init=type_init)


    def forward(self, x, xcond):
        
       
        blocks = []
        blocks2 = []
        xinit = x
        x_s = self.init_scaling(xinit)
        for i, down in enumerate(self.down_path):

            x_s = down(x_s)

            if i < len(self.down_path) - 1 and i > 0:
                blocks.append(x_s)

            # if scaling common to res and id branches swap 
            if i > 0 and i < len(self.down_path) - 1:
                x_s = self.down_scaling[i-1](x_s)

        xcond_s = self.init_scaling(xcond)
        for i, down in enumerate(self.down_path2):

            xcond_s = down(xcond_s)
            if i < len(self.down_path2) - 1 and i > 0:
                blocks2.append(xcond_s)

            # if scaling common to res and id branches swap 
            if i > 0 and i != len(self.down_path) - 1:
                xcond_s = self.down_scaling[i-1](xcond_s)

        x_s = self.normalization(torch.cat((x_s, xcond_s), 1))
        x_s = self.fusion(x_s)

        for i, up in enumerate(self.up_path):
            if i == 0 :
                x_s = up(x_s)
            else :
                x_s = up(self.alpha*x_s+ blocks[-i ] + self.res_weights[i-1]*blocks2[-i ])
            
      
        x_s = self.final(x_s)   
       
        return utils.relu_straight_through(x_s)  

class NFUNetResMultBranchFix(nn.Module):
    def __init__(self, in_nc=2, 
                out_nc=1, 
                nb=2, 
                depth = 2, 
                wf=16,
                act_mode='R', 
                downsample_mode='strideconv', 
                upsample_mode='convtranspose', 
                norm = 'nonorm', 
                type_init= 'xavier', 
                alpha = 1.0,
                repeat = True, 
                bUse_N = True
                ) :
        super(NFUNetResMultBranchFix, self).__init__() 

        self.down_path = nn.ModuleList()
        self.down_path.append(B.conv(in_nc, wf, bias=False, mode='C'))

        self.down_path2 = nn.ModuleList()
        self.down_path2.append(B.conv(in_nc, wf, bias=False, mode='C'))

        prev_channels = wf
        self.down_scaling = nn.ModuleList()
        self.alpha = alpha
        self.nb = nb


        mode = get_norm_layer(norm, act_mode, repeat)        
        match act_mode:
            case 'R':  
                gain = 1.7139588594436646 
            case 'L':
                gain =  1.70590341091156 
            case 'E':
                gain = 1.2716004848480225 
                   
        expected_std = (((1.0+nb*(alpha**2))**(depth+1))*(1.0+nb*depth*(alpha**2)))**0.5
        self.init_scaling = B.Scaling(expected_std)

        list_expected_std_up = []
        list_expected_std_input = []

        self.down_path.append(NFDownBlockFix(expected_std= expected_std, alpha = self.alpha, prev_channels= wf, wf=wf, downsample=False, 
                                          nb = nb, keep_bias=False, mode=mode, type_init=type_init, block_type = 'NFblock', gain=gain)
                                          )
        self.down_path2.append(NFDownBlockFix(expected_std= expected_std, alpha = self.alpha, prev_channels= wf, wf=wf, downsample=False,
                                           nb=nb, keep_bias=False, mode=mode, type_init=type_init, block_type = 'NFblock', gain=gain)
        
                                  )


        for i in range(depth-1):
                        
            self.down_path.append(NFDownBlockFix(downsample_mode=downsample_mode, prev_channels= prev_channels, wf = wf*(2 ** (i+1)), alpha = self.alpha, expected_std = expected_std,
                                               nb = nb, keep_bias=False, mode=mode, type_init=type_init, block_type = 'NFblock', gain = gain)
                                               )
            self.down_path2.append(NFDownBlockFix(downsample_mode=downsample_mode, prev_channels= prev_channels, wf = wf*(2 ** (i+1)), alpha = self.alpha, expected_std = expected_std,
                                                  nb = nb, keep_bias=False, mode=mode, type_init=type_init, block_type = 'NFblock', gain = gain)
                                                  )
            expected_std = (expected_std **2 +  nb*(alpha**2))**0.5
            list_expected_std_input.append(expected_std)
            list_expected_std_up.append((((1.0+nb*(alpha**2))**(i+1))*(1.0+nb*depth*(alpha**2)))**0.5)
            self.down_scaling.append(B.Scaling(list_expected_std_up[-1])) 
            prev_channels = wf*(2 ** (i+1))
            

      
        self.fusion = B.conv(2*prev_channels,prev_channels, bias=False, mode='CE', type_init=type_init)
        if bUse_N :
            self.normalization = B.conv(out_channels=[2*prev_channels, int(104/(2 ** (depth-1))),  int(128/(2 ** (depth-1))),  int(128/(2 ** (depth-1)))], mode="G")
        else :
            self.normalization = nn.Identity()
        expected_std = (expected_std ** 2 + alpha**2) ** 0.5

        self.up_path = nn.ModuleList()
    
        for i in reversed(range(depth-1)):
            self.up_path.append(NFUpBlock(expected_std= expected_std, alpha = self.alpha, upsample_mode=upsample_mode, 
                                            prev_channels= prev_channels, nb=nb,
                                            wf=wf*(2 ** i), keep_bias=False, mode=mode,type_init=type_init, 
                                            block_type = 'NFblock', gain=gain))
           


            prev_channels = wf*(2 ** i)
            expected_std = (expected_std **2 +  nb*(alpha**2))**0.5

        self.up_path.append(NFUpBlock(expected_std= expected_std, alpha = self.alpha, upsample = False, 
                                            prev_channels= wf, nb=nb,
                                            wf=wf, keep_bias=False, mode=mode,type_init=type_init, 
                                            block_type = 'NFblock', gain=gain))
        self.final = B.conv(wf, out_nc, bias=False, mode='C', type_init=type_init)


    def forward(self, x, xcond):
        
       
        blocks = []
        xinit = x
        x_s = self.init_scaling(xinit)
        for i, down in enumerate(self.down_path):

            x_s = down(x_s)

            if i < len(self.down_path) - 1 and i > 0:
                blocks.append(x_s)

            # if scaling common to res and id branches swap 
            if i > 0 and i < len(self.down_path) - 1:
                x_s = self.down_scaling[i-1](x_s)

        xcond_s = self.init_scaling(xcond)
        for i, down in enumerate(self.down_path2):

            xcond_s = down(xcond_s)
           
            # if scaling common to res and id branches swap 
            if i > 0 and i != len(self.down_path) - 1:
                xcond_s = self.down_scaling[i-1](xcond_s)

        x_s = self.normalization(torch.cat((x_s, xcond_s), 1))
        x_s = self.fusion(x_s)

        for i, up in enumerate(self.up_path):          
            if i == 0 :
                x_s = up(x_s)
            else :
                x_s = up(self.alpha*x_s+ blocks[-i ])
            
      
        x_s = self.final(x_s)   
       
        return utils.relu_straight_through(x_s)  


class NFUNetResMultChanFix(nn.Module):
    def __init__(self, in_nc=2, 
                out_nc=1, 
                nb=2, 
                depth = 2, 
                wf=16,
                act_mode='R', 
                downsample_mode='strideconv', 
                upsample_mode='convtranspose', 
                norm = 'nonorm', 
                type_init= 'xavier', 
                alpha = 1.0,
                repeat = True,
                bUse_N = True
                ) :
        super(NFUNetResMultChanFix, self).__init__() 
        if bUse_N :
            self.normalization = B.conv(out_channels=[2, 104, 128, 128], mode='G')
        else :
            self.normalization = nn.Identity()

        self.down_path = nn.ModuleList()
        self.down_path.append(B.conv(2*in_nc, wf, bias=False, mode='C'))


        prev_channels = wf
        self.down_scaling = nn.ModuleList()
        self.alpha = alpha
        self.nb = nb


        mode = get_norm_layer(norm, act_mode, repeat)        
        match act_mode:
            case 'R':  
                gain = 1.7139588594436646 
            case 'L':
                gain =  1.70590341091156 
            case 'E':
                gain = 1.2716004848480225 
                   
        expected_std = (((1.0+nb*(alpha**2))**(depth+1))*(1.0+nb*depth*(alpha**2)))**0.5
        self.init_scaling = B.Scaling(expected_std)

        list_expected_std_up = []
        list_expected_std_input = []

        self.down_path.append(NFDownBlockFix(expected_std= expected_std, alpha = self.alpha, prev_channels= wf, wf=wf, downsample=False, 
                                          nb = nb, keep_bias=False, mode=mode, type_init=type_init, block_type = 'NFblock', gain=gain)
                                          )
        for i in range(depth-1):
                        
            self.down_path.append(NFDownBlockFix(downsample_mode=downsample_mode, prev_channels= prev_channels, wf = wf*(2 ** (i+1)), alpha = self.alpha, expected_std = expected_std,
                                               nb = nb, keep_bias=False, mode=mode, type_init=type_init, block_type = 'NFblock', gain = gain)
                                               )
         
            expected_std = (expected_std **2 +  nb*(alpha**2))**0.5
            list_expected_std_input.append(expected_std)
            list_expected_std_up.append((((1.0+nb*(alpha**2))**(i+1))*(1.0+nb*depth*(alpha**2)))**0.5)
            self.down_scaling.append(B.Scaling(list_expected_std_up[-1])) 
            prev_channels = wf*(2 ** (i+1))
            

    
      
        expected_std = (expected_std ** 2 + alpha**2) ** 0.5

        self.up_path = nn.ModuleList()
    
        for i in reversed(range(depth-1)):
            self.up_path.append(NFUpBlock(expected_std= expected_std, alpha = self.alpha, upsample_mode=upsample_mode, 
                                            prev_channels= prev_channels, nb=nb,
                                            wf=wf*(2 ** i), keep_bias=False, mode=mode,type_init=type_init, 
                                            block_type = 'NFblock', gain=gain))
           


            prev_channels = wf*(2 ** i)
            expected_std = (expected_std **2 +  nb*(alpha**2))**0.5
        self.up_path.append(NFUpBlock(expected_std= expected_std, alpha = self.alpha, upsample = False, 
                                            prev_channels= wf, nb=nb,
                                            wf=wf, keep_bias=False, mode=mode,type_init=type_init, 
                                            block_type = 'NFblock', gain=gain))
        self.final = B.conv(wf, out_nc, bias=False, mode='C', type_init=type_init)
        self.res_weight = nn.Parameter(torch.FloatTensor([1.]))


    def forward(self, x, xcond):
        
       
        blocks = []
        x_s = self.init_scaling(torch.cat((x, self.res_weight*xcond), 1))
        x_s = self.normalization(x_s)
        for i, down in enumerate(self.down_path):

            x_s = down(x_s)

            if i < len(self.down_path) - 1 and i > 0:
                blocks.append(x_s)

            # if scaling common to res and id branches swap 
            if i > 0 and i < len(self.down_path) - 1:
                x_s = self.down_scaling[i-1](x_s)

        

        for i, up in enumerate(self.up_path):          
            if i == 0 :
                x_s = up(x_s)
            else :
                x_s = up(self.alpha*x_s+ blocks[-i ])
            
      
        x_s = self.final(x_s)   
       
        return utils.relu_straight_through(x_s)  