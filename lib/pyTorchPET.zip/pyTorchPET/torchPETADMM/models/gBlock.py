"""
Created on March 2023

@author: florent.sureau
"""

import os
import numpy as np
import torch

def init_weights(m, type_init='xavier'):
    if type(m) == torch.nn.Conv3d or type(m) == torch.nn.ConvTranspose3d:
        match type_init:
            case 'xavier':  
                torch.nn.init.xavier_normal_(m.weight.data, gain=1.3)
                
            case 'kaiming': 
                torch.nn.init.kaiming_normal_(m.weight.data) #, nonlinearity='relu')

            case _:
                raise NotImplementedError(f'init_weights: type_init={type_init} not implemented')           

    
        if m.bias is not None:
            m.bias.data.fill_(0)
    if type(m) == torch.nn.BatchNorm3d:
        torch.nn.init.normal_(m.weight.data, 1.0, 0.02)
        #constant(m.weight.data, 0.10)

        if m.bias is not None:
            m.bias.data.fill_(0)

# class BFBatchNorm3d(nn.BatchNorm3d):
#     r"""
#     From Mohan et al.
#     "Robust And Interpretable Blind Image Denoising Via Bias-Free Convolutional Neural Networks"
#     S. Mohan, Z. Kadkhodaie, E. P. Simoncelli, C. Fernandez-Granda
#     Int'l. Conf. on Learning Representations (ICLR), Apr 2020.

#     """

#     def __init__(
#         self, num_features, eps=1e-5, momentum=0.1, use_bias=False, affine=True
#     ):
#         super(BFBatchNorm3d, self).__init__(num_features, eps, momentum)
#         self.use_bias = use_bias
#         self.affine = affine

#     def forward(self, x):
#         self._check_input_dim(x)
#         y = x.transpose(0, 1)
#         return_shape = y.shape
#         y = y.contiguous().view(x.size(1), -1)
#         if self.use_bias:
#             mu = y.mean(dim=1)
#         sigma2 = y.var(dim=1)
#         if self.training is not True:
#             if self.use_bias:
#                 y = y - self.running_mean.view(-1, 1)
#             y = y / (self.running_var.view(-1, 1) ** 0.5 + self.eps)
#         else:
#             if self.track_running_stats is True:
#                 with torch.no_grad():
#                     if self.use_bias:
#                         self.running_mean = (
#                             1 - self.momentum
#                         ) * self.running_mean + self.momentum * mu
#                     self.running_var = (
#                         1 - self.momentum
#                     ) * self.running_var + self.momentum * sigma2
#             if self.use_bias:
#                 y = y - mu.view(-1, 1)
#             y = y / (sigma2.view(-1, 1) ** 0.5 + self.eps)
#         if self.affine:
#             y = self.weight.view(-1, 1) * y
#             if self.use_bias:
#                 y += self.bias.view(-1, 1)

#         return y.view(return_shape).transpose(0, 1)


class ConvBNR3D(torch.nn.Module):
    def __init__(self, in_channels, out_channels, filter_size, out = False, track = False, elu=False,InstanceNorm=False):
        '''
        Initialize a Conv3d/BatchNorm3d/ReLU (out=False) or Conv3d/ReLU/Conv3d Block (out=True) block.
        Arguments:
            - in_channels: number of input channels (int).
            - out_channels: number of output channels (int).
            - filter_size: 3D filter radius (int).
            - out: specify if output block (boolean, if True [conv3D,ReLU,conv3D] else [conv3D, BatchNorm3D,ReLU], default: False)
            - track: boolean to track running stats (see see BatchNorm3D,boolean, if False then batch statistic used in evaluation,
             if True running mean/var estimated in training and applied in evaluation, default: False).
            - elu: use ELU instead of ReLU (differentiable, default: False).
            - InstanceNorm: use InstanceNorm instead of BatchNorm (allows accumulate grad, default: False).
        '''

        super().__init__()
        if InstanceNorm:
            NormMod=torch.nn.InstanceNorm3d
        else:
            NormMod=torch.nn.BatchNorm3d
        if out:
            if elu:
                self.convbnr = torch.nn.Sequential(
                    torch.nn.Conv3d(in_channels, in_channels, kernel_size = filter_size, padding = filter_size//2),
                    torch.nn.ELU(),
                    torch.nn.Conv3d(in_channels, out_channels, kernel_size = 1),
                )
            else:
                self.convbnr = torch.nn.Sequential(
                    torch.nn.Conv3d(in_channels, in_channels, kernel_size = filter_size, padding = filter_size//2),
                    torch.nn.ReLU(),
                    torch.nn.Conv3d(in_channels, out_channels, kernel_size = 1),
                )

        else:
            if elu:
                self.convbnr = torch.nn.Sequential(
                    torch.nn.Conv3d(in_channels, out_channels, kernel_size = filter_size, padding = filter_size//2),
                    NormMod(out_channels, track_running_stats = track),
                    torch.nn.ELU(),
                )
            else:
                self.convbnr = torch.nn.Sequential(
                    torch.nn.Conv3d(in_channels, out_channels, kernel_size = filter_size, padding = filter_size//2),
                    NormMod(out_channels, track_running_stats = track),
                    torch.nn.ReLU(),
                )

    def forward(self, x):
        '''
        Apply the initialized ConvBNR3D block

        Arguments:
            - x: input tensor (torch Tensor).

        Returns:
            - output of ConvBNR3D(x) (torch Tensor).
        '''
        return self.convbnr(x)

#3D Convolution + 3D Convolution 1x1x1
class ConvBNR3D_out(torch.nn.Module):
    def __init__(self, in_channels, out_channels, filter_size, custom_init = True, type_init='xavier'):
        '''
        Initialize a Conv3d/Conv3d Block (out=True) block.

        Arguments:
            - in_channels: number of input channels (int).
            - out_channels: number of output channels (int).
            - filter_size: 3D filter radius (int).
        '''
        super().__init__()

        self.convbnr = torch.nn.Sequential(
                torch.nn.Conv3d(in_channels, in_channels, kernel_size = filter_size, padding = filter_size//2),
                torch.nn.Conv3d(in_channels, out_channels, kernel_size = 1),
        )
        if custom_init : 
            self.convbnr.apply(lambda x: init_weights(x, type_init=type_init))

    def forward(self, x):
        '''
        Apply the initialized ConvBNR3D_out block

        Arguments:
            - x: input tensor (torch Tensor).

        Returns:
            - output of ConvBNR3D_out(x) (torch Tensor).
        '''
        return self.convbnr(x)
    
#3D Convolution + 3D Convolution 1x1x1
class ConvBNR3D_out2(torch.nn.Module):
    def __init__(self, in_channels, out_channels, custom_init = True, type_init='xavier', batch_norm = True):
        '''
        Initialize a Conv3d/Conv3d Block (out=True) block.

        Arguments:
            - in_channels: number of input channels (int).
            - out_channels: number of output channels (int).
            - filter_size: 3D filter radius (int).
        '''
        super().__init__()

        self.convbnr = torch.nn.Sequential(
                torch.nn.Conv3d(in_channels, out_channels, kernel_size = 1, bias = batch_norm),
        )
        if custom_init : 
            self.convbnr.apply(lambda x: init_weights(x, type_init=type_init))

    def forward(self, x):
        '''
        Apply the initialized ConvBNR3D_out block

        Arguments:
            - x: input tensor (torch Tensor).

        Returns:
            - output of ConvBNR3D_out(x) (torch Tensor).
        '''
        return self.convbnr(x)


#3D Convolution + 3D Convolution 1x1x1
class ConvBNR3D_in(torch.nn.Module):
    def __init__(self, in_channels, out_channels, filter_size, custom_init = True, type_init='xavier', batch_norm = True):
        '''
        Initialize a Conv3d/Conv3d Block (out=True) block.

        Arguments:
            - in_channels: number of input channels (int).
            - out_channels: number of output channels (int).
            - filter_size: 3D filter radius (int).
        '''
        super().__init__()

        self.convbnr = torch.nn.Sequential(
                torch.nn.Conv3d(in_channels, out_channels, kernel_size = filter_size, padding = filter_size//2, bias = batch_norm),
        )
        if custom_init : 
            self.convbnr.apply(lambda x: init_weights(x, type_init=type_init))

    def forward(self, x):
        '''
        Apply the initialized ConvBNR3D_out block

        Arguments:
            - x: input tensor (torch Tensor).

        Returns:
            - output of ConvBNR3D_out(x) (torch Tensor).
        '''
        return self.convbnr(x)
    
#3D Convolution for Downsampling + 3D Batch Normalization + ReLU Activation Function
class Down3D(torch.nn.Module):

    def __init__(self, in_channels, out_channels, filter_size, track = False, elu=False,InstanceNorm=False):
        '''
        Initialize a AvgPool3d (kernel size/stride 2)/Conv3d/BatchNorm3d/ReLU block.

        Arguments:
            - in_channels: number of input channels (int).
            - out_channels: number of output channels (int).
            - filter_size: 3D filter radius (int).
            - track: boolean to track running stats (see see BatchNorm3D,boolean, if False then batch statistic used in evaluation,
             if True running mean/var estimated in training and applied in evaluation, default=False).
            - elu: use ELU instead of ReLU (differentiable).
            - InstanceNorm: use InstanceNorm instead of BatchNorm (allows accumulate grad, default: False).
        '''
        super().__init__()
        if InstanceNorm:
            NormMod=torch.nn.InstanceNorm3d
        else:
            NormMod=torch.nn.BatchNorm3d
        if elu:
            self.down = torch.nn.Sequential(
                torch.nn.AvgPool3d(kernel_size=2, stride = 2,padding=0),
                torch.nn.Conv3d(in_channels, out_channels, kernel_size = filter_size, padding = filter_size//2),
                NormMod(out_channels, track_running_stats = track),
                torch.nn.ELU(),
            )
        else:
            self.down = torch.nn.Sequential(
                torch.nn.AvgPool3d(kernel_size=2, stride = 2,padding=0),
                torch.nn.Conv3d(in_channels, out_channels, kernel_size = filter_size, padding = filter_size//2),
                NormMod(out_channels, track_running_stats = track),
                torch.nn.ReLU(),
            )

    def forward(self, x):
        '''
        Apply the initialized Down3D block

        Arguments:
            - x: input tensor (torch Tensor).

        Returns:
            - output of Down3D(x) (torch Tensor).
        '''
        return self.down(x)

#Trilinear Upsampling + 3D Convolution + 3D Batch Normalization + ReLU Activation Function
class Up3D_add(torch.nn.Module):

    def __init__(self, in_channels, out_channels, filter_size, track = False, elu=False,InstanceNorm=False):
        '''
        Initialize a Upsample (scale factor 2)/Conv3d/BatchNorm3d/ReLU block followed by addition.

        Arguments:
            - in_channels: number of input channels (int).
            - out_channels: number of output channels (int).
            - filter_size: 3D filter radius (int).
            - track: boolean to track running stats (see see BatchNorm3D,boolean, if False then batch statistic used in evaluation,
             if True running mean/var estimated in training and applied in evaluation, default=False).
            - elu: use ELU instead of ReLU (differentiable).
            - InstanceNorm: use InstanceNorm instead of BatchNorm (allows accumulate grad, default: False).
        '''
        super().__init__()

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.filter_size = filter_size
        if InstanceNorm:
            NormMod=torch.nn.InstanceNorm3d
        else:
            NormMod=torch.nn.BatchNorm3d


        self.up = torch.nn.Upsample(scale_factor = 2, mode = 'trilinear', align_corners = False)
        if elu:
            self.convbnr = torch.nn.Sequential(
                torch.nn.Conv3d(in_channels, out_channels, kernel_size = filter_size, padding = filter_size//2),
                NormMod(out_channels, track_running_stats = track),
                torch.nn.ELU(),
            )
        else:
            self.convbnr = torch.nn.Sequential(
                torch.nn.Conv3d(in_channels, out_channels, kernel_size = filter_size, padding = filter_size//2),
                NormMod(out_channels, track_running_stats = track),
                torch.nn.ReLU(),
            )

    def forward(self, x1,y):
        '''
        Apply the initialized Up3D_add block

        Arguments:
            - x: input tensor (torch Tensor).
            - y: added tensor (torch Tensor).

        Returns:
            - output of Up3D_add(x,y) (torch Tensor).
        '''
        x2 = self.up(x1)
        x3 = self.convbnr(x2)
        x4 = torch.add(x3,y)
        return x4

#Trilinear Upsampling + 3D Convolution + 3D Batch Normalization + ReLU Activation Function
class Up3D_cat(torch.nn.Module):

    def __init__(self, in_channels, out_channels, filter_size, track = False, elu=False,InstanceNorm=False):
        '''
        Initialize a Upsample (scale factor 2) followed by concatenation/Conv3d/BatchNorm3d/ReLU block.

        Arguments:
            - in_channels: number of input channels (int).
            - out_channels: number of output channels (int).
            - filter_size: 3D filter radius (int).
            - track: boolean to track running stats (see see BatchNorm3D,boolean, if False then batch statistic used in evaluation,
             if True running mean/var estimated in training and applied in evaluation, default=False).
            - elu: use ELU instead of ReLU (differentiable).
            - InstanceNorm: use InstanceNorm instead of BatchNorm (allows accumulate grad, default: False).
        '''
        super().__init__()

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.filter_size = filter_size
        if InstanceNorm:
            NormMod=torch.nn.InstanceNorm3d
        else:
            NormMod=torch.nn.BatchNorm3d

        self.up = torch.nn.Upsample(scale_factor = 2, mode = 'trilinear', align_corners = False)
        if elu:
            self.convbnr = torch.nn.Sequential(
                torch.nn.Conv3d(in_channels, out_channels, kernel_size = filter_size, padding = filter_size//2),
                NormMod(out_channels, track_running_stats = track),
                torch.nn.ELU(),
            )
        else:
            self.convbnr = torch.nn.Sequential(
                torch.nn.Conv3d(in_channels, out_channels, kernel_size = filter_size, padding = filter_size//2),
                NormMod(out_channels, track_running_stats = track),
                torch.nn.ReLU(),
            )

    def forward(self, x1,y):
        '''
        Apply the initialized Up3D_cat block

        Arguments:
            - x: input tensor (torch Tensor).
            - y: tensor for concatenation after upsampling of x (torch Tensor).

        Returns:
            - output of Up3D_cat(x) (torch Tensor).
        '''
        x2 = self.up(x1)
        x3 = torch.cat((x2,y),dim=1) #batch,
        x4 = self.convbnr(x3)
        return x4

#3D Transport Convolution + 3D Convolution + 3D Batch Normalization + ReLU Activation Function
class Up3D_convt(torch.nn.Module):

    def __init__(self, in_channels, out_channels, filter_size, track = False, elu=False,InstanceNorm=False):
        '''
        Initialize a ConvTranspose3d followed by concatenation/Conv3d/BatchNorm3d/ReLU block.

        Arguments:
            - in_channels: number of input channels (int).
            - out_channels: number of output channels (int).
            - filter_size: 3D filter radius (int).
            - track: boolean to track running stats (see see BatchNorm3D,boolean, if False then batch statistic used in evaluation,
             if True running mean/var estimated in training and applied in evaluation, default=False).
            - elu: use ELU instead of ReLU (differentiable).
            - InstanceNorm: use InstanceNorm instead of BatchNorm (allows accumulate grad, default: False).
        '''
        super().__init__()

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.filter_size = filter_size
        if InstanceNorm:
            NormMod=torch.nn.InstanceNorm3d
        else:
            NormMod=torch.nn.BatchNorm3d

        self.up = torch.nn.ConvTranspose3d(in_channels, out_channels,
                                     kernel_size=2, padding=1, stride = 2)
        if elu:
            self.convbnr = torch.nn.Sequential(
                torch.nn.Conv3d(out_channels, out_channels, kernel_size=filter_size, padding=1),
                NormMod(out_channels, track_running_stats = track),
                torch.nn.ELU(),
            )
        else:
            self.convbnr = torch.nn.Sequential(
                torch.nn.Conv3d(out_channels, out_channels, kernel_size=filter_size, padding=1),
                NormMod(out_channels, track_running_stats = track),
                torch.nn.ReLU(),
            )

    def forward(self, x1, y):
        '''
        Apply the initialized Up3D_convt block

        Arguments:
            - x: input tensor (torch Tensor).
            - y: tensor for concatenation after ConvTranspose3d of x (torch Tensor).

        Returns:
            - output of Up3D_convt(x) (torch Tensor).
        '''
        x1 = self.up(x1)
        dX = y.size()[3] - x1.size()[3]
        dY = y.size()[4] - x1.size()[4]
        dZ = y.size()[2] - x1.size()[2]
        a = torch.nn.functional.pad(x1,(0,dZ,0,dX,0,dY))
        a = self.convbnr(a)
        return torch.add(a,y)
    #check before use
