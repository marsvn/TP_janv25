import torch.nn as nn
import torch
from torch.nn.functional import conv3d
from torch.nn.parameter import Parameter

"""
Spectral Normalization borrowed from https://arxiv.org/abs/1802.05957
SN for convolutional layers to be of Lipschtz constant sigma (deault=1.0).
"""

def init_weights_conv(m, type_init='xavier'):
    if type(m) == torch.nn.Conv3d or type(m) == torch.nn.ConvTranspose3d:
        match type_init:
            case 'xavier':  
                torch.nn.init.xavier_normal_(m.weight.data, gain=1.3)
                
            case 'kaiming': 
                torch.nn.init.kaiming_normal_(m.weight.data) #, nonlinearity='relu')

            case 'zero': 
                m.weight.data.zero_()

            case _:
                raise NotImplementedError(f'init_weights: type_init={type_init} not implemented')           

        
        #torch.nn.init.kaiming_normal_(m.weight.data, nonlinearity='relu') #, gain=0.1)

        if m.bias is not None:
            m.bias.data.fill_(0)
    if type(m) == torch.nn.BatchNorm3d or type(m) == torch.nn.InstanceNorm3d:
        #torch.nn.init.constant(m.weight.data, 0.10)
        if m.weight is not None:

            torch.nn.init.normal_(m.weight.data, 1.0, 0.02)
        if m.bias is not None:
            m.bias.data.fill_(0)

    if type(m) == nn.Linear:
        if type_init == 'zero':
            m.weight.data.zero_()
        else :
            torch.nn.init.xavier_normal_(m.weight.data)
        if m.bias is not None:
            m.bias.data.fill_(0)
    return m


class MultiConv3d(nn.Module):
    def __init__(self, num_channels=[1, 64], size_kernels=[3], zero_mean=True, sn_size=256):
        '''

        '''

        super().__init__()
        # parameters and options
        self.size_kernels = size_kernels
        self.num_channels = num_channels
        self.sn_size = sn_size
        self.zero_mean = zero_mean

        
        # list of convolutionnal layers
        self.conv_layers = nn.ModuleList()
        
        for j in range(len(num_channels) - 1):
            self.conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[j], out_channels=num_channels[j+1], kernel_size=size_kernels[j], padding=size_kernels[j]//2, stride=1, bias=False, padding_mode='circular'), 'kaiming')) #, padding_mode='circular'
            # # enforce zero mean filter for first conv
            # if zero_mean and j == 0:
            #      P.register_parametrization(self.conv_layers[-1], "weight", ZeroMean())
           


        # cache the estimation of the spectral norm
        self.L = torch.tensor(1., requires_grad=True)
        # cache dirac impulse used to estimate the spectral norm
        self.padding_total = sum([kernel_size//2 for kernel_size in size_kernels])
        self.dirac = torch.zeros((1, 1) + (4 * self.padding_total + 1, 4 * self.padding_total + 1, 4 * self.padding_total + 1))
        self.dirac[0, 0, 2 * self.padding_total, 2 * self.padding_total, 2 * self.padding_total] = 1


    def forward(self, x):
        # self.spectral_norm(u0 = x)
        self.spectral_norm(u0 = x, mode="power_method", n_steps=10)
        # print("spectral norm: ", self.L)
        return(self.convolution(x))

    def convolution(self, x):
        # normalized convolution, so that the spectral norm of the convolutional kernel is 1
        # nb the spectral norm of the convolution has to be upated before
        x = x / torch.sqrt(self.L)

        for conv in self.conv_layers:
            weight = conv.weight
            x = nn.functional.conv3d(x, weight, bias=None, dilation=conv.dilation, padding=conv.padding, groups=conv.groups, stride=conv.stride)


        return(x)

    def transpose(self, x):
        # normalized transpose convolution, so that the spectral norm of the convolutional kernel is 1
        # nb the spectral norm of the convolution has to be upated before
        x = x / torch.sqrt(self.L)

        for conv in reversed(self.conv_layers):
            weight = conv.weight
            x = nn.functional.conv_transpose3d(x, weight, bias = None, padding=conv.padding, groups=conv.groups, dilation=conv.dilation, stride=conv.stride)

        return(x)
    
    def spectral_norm(self, u0, mode="Fourier", n_steps=1000):
        """ Compute the spectral norm of the convolutional layer
                Args:
                    mode: "Fourier" or "power_method"
                        - "Fourier" computes the spectral norm by computing the DFT of the equivalent convolutional kernel. This is only an estimate (boundary effects are not taken into account) but it is differentiable and fast
                        - "power_method" computes the spectral norm by power iteration. This is more accurate and used before testing
                    n_steps: number of steps for the power method
        """

        if mode =="Fourier":
            # temporary set L to 1 to get the spectral norm of the unnormalized filter
            self.L = torch.tensor([1.], device=self.conv_layers[0].weight.device)
            # get the convolutional kernel corresponding to WtW
            kernel = self.get_kernel_WtW()
            # pad the kernel and compute its DFT. The spectral norm of WtW is the maximum of the absolute value of the DFT
            padding = (self.sn_size - 1) // 2 - self.padding_total
            self.L = torch.fft.fftn(torch.nn.functional.pad(kernel, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()
            return(self.L)
        
        elif mode == "power_method":
            self.L = torch.tensor([1.], device=self.conv_layers[0].weight.device)
            u = torch.empty(u0.size(), device= self.conv_layers[0].weight.device).normal_()
            with torch.no_grad():
                for _ in range(n_steps):
                    u = self.transpose(self.convolution(u))
                    u = u / torch.linalg.norm(u)

                
                # The largest eigen value can now be estimated in a differentiable way
                sn = torch.linalg.norm(self.transpose(self.convolution(u)))
                self.L = sn
                return sn




    def spectrum(self):
        kernel = self.get_kernel_WtW()
        padding = (self.sn_size - 1) // 2 - self.padding_total
        return(torch.fft.fftn(torch.nn.functional.pad(kernel, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)))
    
    def get_filters(self):
        # we collapse the convolutions to get one kernel per channel
        # this done by computing the response of a dirac impulse
        self.dirac = self.dirac.to(self.conv_layers[0].weight.device)
        kernel = self.convolution(self.dirac)[:,:,self.padding_total:3*self.padding_total+1, self.padding_total:3*self.padding_total+1, self.padding_total:3*self.padding_total+1]
        return(kernel)


    def get_kernel_WtW(self):
        self.dirac = self.dirac.to(self.conv_layers[0].weight.device)
        return(self.transpose(self.convolution(self.dirac)))
       



# enforce zero mean kernels for each output channel
class ZeroMean(nn.Module):
    def forward(self, X):
        Y = X - torch.mean(X, dim=(1,2,3)).unsqueeze(1).unsqueeze(2).unsqueeze(3)
        return(Y)


def l2normalize(v, eps=1e-12):
    return v / (v.norm() + eps)


class SpectralNorm(nn.Module):
    def __init__(self, module, name='weight', power_iterations=1):
        super(SpectralNorm, self).__init__()
        self.module = module
        self.name = name
        self.power_iterations = power_iterations
        if not self._made_params():
            self._make_params()

    def _update_u_v(self):
        u = getattr(self.module, self.name + "_u")
        v = getattr(self.module, self.name + "_v")
        w = getattr(self.module, self.name + "_bar")

        height = w.data.shape[0]
        print("height", height)
        for _ in range(self.power_iterations):
            v.data = l2normalize(torch.mv(torch.t(w.view(height,-1).data), u.data))
            u.data = l2normalize(torch.mv(w.view(height,-1).data, v.data))

            sigma = torch.dot(u.data, torch.mv(w.view(height,-1).data, v.data))
            # sigma = u.dot(w.view(height, -1).mv(v))
        print("sigma", sigma)
        setattr(self.module, self.name, w / sigma.expand_as(w))

    def _made_params(self):
        try:
            u = getattr(self.module, self.name + "_u")
            v = getattr(self.module, self.name + "_v")
            w = getattr(self.module, self.name + "_bar")
            return True
        except AttributeError:
            return False


    def _make_params(self):
        w = getattr(self.module, self.name)

        height = w.data.shape[0]
        width = w.view(height, -1).data.shape[1]

        u = Parameter(w.data.new(height).normal_(0, 1), requires_grad=False)
        v = Parameter(w.data.new(width).normal_(0, 1), requires_grad=False)
        u.data = l2normalize(u.data)
        v.data = l2normalize(v.data)
        w_bar = Parameter(w.data)

        del self.module._parameters[self.name]

        self.module.register_parameter(self.name + "_u", u)
        self.module.register_parameter(self.name + "_v", v)
        self.module.register_parameter(self.name + "_bar", w_bar)


    def forward(self, *args):
        self._update_u_v()
        return self.module.forward(*args)
    

#################################################################################

class BatchNormSpectralNorm(object):

    def __init__(self, name='weight', sigma=1.0, eps=1e-12):
        self.name = name
        self.sigma = sigma
        self.eps = eps

    def compute_weight(self, module):
        weight = getattr(module, self.name + '_orig')
        bias = getattr(module, "bias_orig")
        running_var = getattr(module, "running_var")

        with torch.no_grad():
            cur_sigma = torch.max(torch.abs(weight / torch.sqrt(running_var)))
            # print(cur_sigma)
            cur_sigma = max(float(cur_sigma.cpu().detach().numpy()), self.sigma)
            # print(cur_sigma)

        weight = weight / cur_sigma
        bias = bias / cur_sigma
        return weight, bias

    def remove(self, module):
        weight = getattr(module, self.name)
        bias = getattr(module, "bias")
        delattr(module, self.name)
        delattr(module, self.name + '_orig')
        delattr(module, "bias")
        delattr(module, "bias_orig")
        module.register_parameter(self.name, torch.nn.Parameter(weight.detach()))
        module.register_parameter("bias", torch.nn.Parameter(bias.detach()))

    def __call__(self, module, inputs):
        if module.training:
            weight, bias = self.compute_weight(module)
            setattr(module, self.name, weight)
            setattr(module, "bias", bias)
        else:
            weight_r_g = getattr(module, self.name + '_orig').requires_grad
            bias_r_g = getattr(module, "bias_orig").requires_grad
            getattr(module, self.name).detach_().requires_grad_(weight_r_g)
            getattr(module, "bias").detach_().requires_grad_(bias_r_g)

    @staticmethod
    def apply(module, name, sigma, eps):
        fn = BatchNormSpectralNorm(name, sigma, eps)
        weight = module._parameters[name]
        bias = module._parameters["bias"]

        delattr(module, fn.name)
        delattr(module, "bias")
        module.register_parameter(fn.name + "_orig", weight)
        module.register_parameter("bias_orig", bias)
        # We still need to assign weight back as fn.name because all sorts of
        # things may assume that it exists, e.g., when initializing weights.
        # However, we can't directly assign as it could be an nn.Parameter and
        # gets added as a parameter. Instead, we register weight.data as a
        # buffer, which will cause weight to be included in the state dict
        # and also supports nn.init due to shared storage.
        module.register_buffer(fn.name, weight.data)
        module.register_buffer("bias", bias.data)

        module.register_forward_pre_hook(fn)
        return fn


def bn_spectral_norm(module, name='weight', sigma=1.0, eps=1e-12):
    r"""Applies spectral normalization to a parameter in the given module.

    .. math::
         \mathbf{W} &= \dfrac{\mathbf{W}}{\sigma(\mathbf{W})} \\
         \sigma(\mathbf{W}) &= \max_{\mathbf{h}: \mathbf{h} \ne 0} \dfrac{\|\mathbf{W} \mathbf{h}\|_2}{\|\mathbf{h}\|_2}

    Spectral normalization stabilizes the training of discriminators (critics)
    in Generaive Adversarial Networks (GANs) by rescaling the weight tensor
    with spectral norm :math:`\sigma` of the weight matrix calculated using
    power iteration method. If the dimension of the weight tensor is greater
    than 2, it is reshaped to 2D in power iteration method to get spectral
    norm. This is implemented via a hook that calculates spectral norm and
    rescales weight before every :meth:`~Module.forward` call.

    See `Spectral Normalization for Generative Adversarial Networks`_ .

    .. _`Spectral Normalization for Generative Adversarial Networks`: https://arxiv.org/abs/1802.05957

    Args:
        module (nn.Module): containing module
        name (str, optional): name of weight parameter
        eps (float, optional): epsilon for numerical stability in
            calculating norms

    Returns:
        The original module with the spectal norm hook

    Example::

        >>> m = batchnorm_spectral_norm(nn.BatchNorm2d(10))
        BatchNorm2d(10, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        >>> m.weight_orig.size()
        torch.Size([10])

    """
    BatchNormSpectralNorm.apply(module, name, sigma, eps)
    return module


def remove_bn_spectral_norm(module, name='weight'):
    r"""Removes the spectral normalization reparameterization from a module.

    Args:
        module (nn.Module): containing module
        name (str, optional): name of weight parameter

    Example:
        >>> m = spectral_norm(nn.Linear(40, 10))
        >>> remove_spectral_norm(m)
    """
    for k, hook in module._forward_pre_hooks.items():
        if isinstance(hook, BatchNormSpectralNorm) and hook.name == name:
            hook.remove(module)
            del module._forward_pre_hooks[k]
            return module

    raise ValueError("spectral_norm of '{}' not found in {}".format(
        name, module))


def normalize(tensor, eps=1e-12):
    norm = float(torch.sqrt(torch.sum(tensor * tensor)))
    norm = max(norm, eps)
    ans = tensor / norm
    return ans


class ConvSpectralNorm(object):

    def __init__(self, name='weight', sigma=1.0, n_power_iterations=1,
                 dim=0, eps=1e-12):
        self.name = name
        self.sigma = sigma
        self.dim = dim
        if n_power_iterations <= 0:
            raise ValueError('Expected n_power_iterations to be positive, but '
                             'got n_power_iterations={}'.format(n_power_iterations))
        self.n_power_iterations = n_power_iterations
        self.eps = eps

    def compute_weight(self, module):

        weight = getattr(module, self.name + '_orig')
        u = getattr(module, self.name + '_u')
        weight_mat = weight
        print("u shape: ", u.shape)
        print("weight_mat shape: ", weight_mat.shape)

        height = weight_mat.data.shape[0]
        for _ in range(self.n_power_iterations):
            v = normalize(torch.mv(torch.t(weight_mat.view(height,-1).data), u.data))
            u.data = normalize(torch.mv(weight_mat.view(height,-1).data, v))

        # sigma = torch.dot(u.data, torch.mv(w.view(height,-1).data, v.data))
        cur_sigma = u.dot(weight_mat.view(height, -1).mv(v))
        return weight_mat / cur_sigma.expand_as(weight_mat), u, cur_sigma

    # def compute_weight(self, module):
    #     weight = getattr(module, self.name + '_orig')
    #     u = getattr(module, self.name + '_u')
    #     weight_mat = weight

    #     with torch.no_grad():
    #         for _ in range(self.n_power_iterations):
    #             # Spectral norm of weight equals to `u^T W v`, where `u` and `v`
    #             # are the first left and right singular vectors.
    #             # This power iteration produces approximations of `u` and `v`.
    #             v = normalize(
    #                     conv3d(u.flip(2,3), weight_mat.permute(1, 0, 2, 3), padding=1),
    #                     eps=self.eps).flip(2, 3)
    #             u = normalize(conv3d(v, weight_mat, padding=1), eps=self.eps)
    #             if self.n_power_iterations > 0:
    #                 # See above on why we need to clone
    #                 u = u.clone()
    #                 v = v.clone()

    #     cur_sigma = torch.sum(u * conv3d(v, weight_mat, padding=1))
    #     weight = weight / cur_sigma * self.sigma
    #     return weight, u, cur_sigma

    def remove(self, module):
        weight = getattr(module, self.name)
        delattr(module, self.name)
        delattr(module, self.name + '_u')
        # delattr(module, self.name + '_v')
        delattr(module, self.name + '_orig')
        module.register_parameter(self.name, torch.nn.Parameter(weight.detach()))

    def __call__(self, module, inputs):
        if module.training:
            weight, u, cur_sigma = self.compute_weight(module)
            setattr(module, self.name, weight)
            setattr(module, self.name + '_u', u)
        else:
            r_g = getattr(module, self.name + '_orig').requires_grad
            getattr(module, self.name).detach_().requires_grad_(r_g)

    @staticmethod
    def apply(module, name, sigma, n_power_iterations, dim, eps):
        fn = ConvSpectralNorm(name, sigma, n_power_iterations, dim, eps)
        weight = module._parameters[name]
        height = weight.size(dim)

        if module.weight.shape[0] == 1:
            C_out = 1
        else:
            C_out = 64

        u = normalize(weight.new_empty(1, C_out, 104, 128, 128).normal_(0, 1), eps=fn.eps)# input size
        delattr(module, fn.name)
        module.register_parameter(fn.name + "_orig", weight)
        # We still need to assign weight back as fn.name because all sorts of
        # things may assume that it exists, e.g., when initializing weights.
        # However, we can't directly assign as it could be an nn.Parameter and
        # gets added as a parameter. Instead, we register weight.data as a
        # buffer, which will cause weight to be included in the state dict
        # and also supports nn.init due to shared storage.
        module.register_buffer(fn.name, weight.data)
        module.register_buffer(fn.name + "_u", u)

        module.register_forward_pre_hook(fn)
        return fn


def conv_spectral_norm(module, name='weight', sigma=1.0, n_power_iterations=1,
                       eps=1e-12, dim=None):
    r"""Applies spectral normalization to a parameter in the given module.

    .. math::
         \mathbf{W} &= \dfrac{\mathbf{W}}{\sigma(\mathbf{W})} \\
         \sigma(\mathbf{W}) &= \max_{\mathbf{h}: \mathbf{h} \ne 0} \dfrac{\|\mathbf{W} \mathbf{h}\|_2}{\|\mathbf{h}\|_2}

    Spectral normalization stabilizes the training of discriminators (critics)
    in Generaive Adversarial Networks (GANs) by rescaling the weight tensor
    with spectral norm :math:`\sigma` of the weight matrix calculated using
    power iteration method. If the dimension of the weight tensor is greater
    than 2, it is reshaped to 2D in power iteration method to get spectral
    norm. This is implemented via a hook that calculates spectral norm and
    rescales weight before every :meth:`~Module.forward` call.

    See `Spectral Normalization for Generative Adversarial Networks`_ .

    .. _`Spectral Normalization for Generative Adversarial Networks`: https://arxiv.org/abs/1802.05957

    Args:
        module (nn.Module): containing module
        name (str, optional): name of weight parameter
        n_power_iterations (int, optional): number of power iterations to
            calculate spectal norm
        eps (float, optional): epsilon for numerical stability in
            calculating norms
        dim (int, optional): dimension corresponding to number of outputs,
            the default is 0, except for modules that are instances of
            ConvTranspose1/2/3d, when it is 1

    Returns:
        The original module with the spectal norm hook

    Example::

        >>> m = spectral_norm(nn.Linear(20, 40))
        Linear (20 -> 40)
        >>> m.weight_u.size()
        torch.Size([20])

    """
    if dim is None:
        if isinstance(module, (torch.nn.ConvTranspose1d,
                               torch.nn.ConvTranspose2d,
                               torch.nn.ConvTranspose3d)):
            dim = 1
        else:
            dim = 0
    ConvSpectralNorm.apply(module, name, sigma, n_power_iterations, dim, eps)
    return module


# def remove_conv_spectral_norm(module, name='weight'):
#     r"""Removes the spectral normalization reparameterization from a module.

#     Args:
#         module (nn.Module): containing module
#         name (str, optional): name of weight parameter

#     Example:
#         >>> m = spectral_norm(nn.Linear(40, 10))
#         >>> remove_spectral_norm(m)
#     """
#     for k, hook in module._forward_pre_hooks.items():
#         if isinstance(hook, ConvSpectralNorm) and hook.name == name:
#             hook.remove(module)
#             del module._forward_pre_hooks[k]
#             return module

#     raise ValueError("spectral_norm of '{}' not found in {}".format(
#         name, module))



class DnCNN(nn.Module):
    def __init__(self, channels, num_of_layers=17, lip=1.0, no_bn=False,
                 adaptive=False):
        super(DnCNN, self).__init__()
        kernel_size = 3
        padding = 1
        features = 2*16
        if lip > 0.0:
            sigmas = [pow(lip, 1.0/num_of_layers) for _ in range(num_of_layers)]
        else:
            sigmas = [0.0 for _ in range(num_of_layers)]

        if adaptive:
            # sigmas = [5.0, 2.0, 0.68, 0.46, 0.31]
            # sigmas = [5.0, 1.0, 0.584, 0.342]
            sigmas = [5.0, 2.0, 1.0, 0.681, 0.464, 0.316]
            assert len(sigmas) == num_of_layers, "Length of SN list uncompatible with num of layers."

        def conv_layer(cin, cout, sigma):
            # conv = nn.Conv3d(in_channels=cin,
            #                  out_channels=cout,
            #                  kernel_size=kernel_size,
            #                  padding=padding,
            #                  bias=False)
            conv = MultiConv3d(num_channels=[cin, cout], size_kernels=[kernel_size], sn_size=128)
            return conv
            # if sigma > 0.0:
            #     return SpectralNorm(conv, power_iterations=20) #conv_spectral_norm(conv, sigma=sigma)
            # else:
            #     return conv

        def bn_layer(n_features, sigma=1.0):
            bn = nn.BatchNorm3d(n_features)
            if sigma > 0.0:
                return bn_spectral_norm(bn, sigma=sigma)
            else:
                return bn

        layers = []
        layers.append(conv_layer(channels, features, sigmas[0]))
        layers.append(nn.ReLU(inplace=True))
        print("conv_1 with SN {}".format(sigmas[0]))

        for i in range(1, num_of_layers-1):
            layers.append(conv_layer(features, features, sigmas[i])) # conv layer
            print("conv_{} with SN {}".format(i+1, sigmas[i]))
            if not no_bn:
                print("using BN")
                layers.append(bn_layer(features, 0.0)) # bn layer
            layers.append(nn.ReLU(inplace=True))

        layers.append(conv_layer(features, channels, sigmas[-1]))
        print("conv_{} with SN {}".format(num_of_layers, sigmas[-1]))
        self.dncnn = nn.Sequential(*layers)

    def forward(self, x):
        out = self.dncnn(x)
        return torch.nn.functional.relu(0.5*x+0.5*out)