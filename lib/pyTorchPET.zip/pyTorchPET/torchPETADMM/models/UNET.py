"""
Created on March 2023

@author: florent.sureau
"""

import os
import numpy as np
import torch
from . import gBlock as gBlock

class UNET3D_simple(torch.nn.Module):
    def __init__(self, n_in = 1, n_out = 1, filter_size = 3,track=False,elu=False,pos_out=True,InstanceNorm=False):
        '''
        Initialize a UNET with 2 levels, 3D Trilinear Upsampling with addition, 3D Downsampling, residual skip connection.

        Arguments:
            - n_in: number of input channels (int, default: 1).
            - n_out: number of output channels (int, default: 1).
            - filter_size: 3D filter radius (int, default: 3).
            - out: specify if output block (boolean, if True [conv3D,ReLU,conv3D] else [conv3D, BatchNorm3D,ReLU], default: False)
            - track: boolean to track running stats (see see BatchNorm3D,boolean, if False then batch statistic used in evaluation,
             if True running mean/var estimated in training and applied in evaluation, default: False).
            - elu: use ELU instead of ReLU (differentiable, default: False).
            - pos_out: enfoce positivity of output via ReLU (non differentiable, default:True).
            - InstanceNorm: use InstanceNorm instead of BatchNorm (allows accumulate grad, default: False).
        '''
        super(UNET3D_simple, self).__init__()

        self.n_in = n_in
        self.n_out = n_out
        self.filter_size = filter_size
        self.track=track
        self.elu=elu
        self.pos_out=pos_out
        self.InstanceNorm=InstanceNorm

        self.conv1 = gBlock.ConvBNR3D(n_in, 16, filter_size,track=track,elu=elu,InstanceNorm=InstanceNorm)
        self.down1 = gBlock.Down3D(16, 32, filter_size,track=track,elu=elu,InstanceNorm=InstanceNorm)
        self.up1 = gBlock.Up3D_add(32, 16, filter_size, track = track,elu=elu,InstanceNorm=InstanceNorm)
        self.outc = gBlock.ConvBNR3D(16, n_out, filter_size, out = True,elu=elu,InstanceNorm=InstanceNorm)
        self.outrelu = torch.nn.ReLU()

    def get_name(self):
        return self._get_name()+f"_track{self.track}_elu{self.elu}_posout{self.pos_out}_INorm{self.InstanceNorm}"

    def forward(self, x):
        x1 = self.conv1(x)
        x2 = self.down1(x1)
        x3 = self.up1(x2, x1)
        x4 = self.outc(x3)
        if self.pos_out:
            x5 = self.outrelu(torch.add(x4,x))#Positivity constraint
        else:
            x5 = torch.add(x4,x)# No Positivity constraint
        return x5


#UNet: 3D Trilinear Upsampling with concatenation, 3D Downsampling, residual skip connection
class UNet3D(torch.nn.Module):
    def __init__(self, n_in = 1, n_out = 1, filter_size = 3, track = False, elu=False,pos_out=True,InstanceNorm=False):
        '''
        Initialize a UNET with 3D Trilinear Upsampling with concatenation, 3D Downsampling, residual skip connection.

        Arguments:
            - n_in: number of input channels (int, default: 1).
            - n_out: number of output channels (int, default: 1).
            - filter_size: 3D filter radius (int, default: 3).
            - out: specify if output block (boolean, if True [conv3D,ReLU,conv3D] else [conv3D, BatchNorm3D,ReLU], default: False)
            - track: boolean to track running stats (see see BatchNorm3D,boolean, if False then batch statistic used in evaluation,
             if True running mean/var estimated in training and applied in evaluation, default=False).
            - elu: use ELU instead of ReLU (differentiable).
            - pos_out: enfoce positivity of output via ReLU (non differentiable, default:True).
            - InstanceNorm: use InstanceNorm instead of BatchNorm (allows accumulate grad, default: False).
        '''
        super(UNet3D, self).__init__()

        self.n_in = n_in
        self.n_out = n_out
        self.filter_size = filter_size
        self.track=track
        self.elu=elu
        self.pos_out=pos_out
        self.InstanceNorm=InstanceNorm

        self.conv1 = gBlock.ConvBNR3D(n_in, 32, filter_size, track = track,elu=elu,InstanceNorm=InstanceNorm)
        self.down1 = gBlock.Down3D(32, 32, filter_size, track = track,elu=elu,InstanceNorm=InstanceNorm)
        self.conv2 = gBlock.ConvBNR3D(32, 32, filter_size, track = track,elu=elu,InstanceNorm=InstanceNorm)
        self.down2 = gBlock.Down3D(32, 64, filter_size, track = track,elu=elu,InstanceNorm=InstanceNorm)
        self.conv3 = gBlock.ConvBNR3D(64, 64, filter_size, track = track,elu=elu,InstanceNorm=InstanceNorm)
        self.up1 = gBlock.Up3D_cat(96, 32, filter_size, track = track,elu=elu,InstanceNorm=InstanceNorm)
        self.conv4 = gBlock.ConvBNR3D(32, 32, filter_size, track = track,elu=elu,InstanceNorm=InstanceNorm)
        self.up2 = gBlock.Up3D_cat(64, 32, filter_size, track = track,elu=elu,InstanceNorm=InstanceNorm)
        self.conv5 = gBlock.ConvBNR3D(32, 32, filter_size, track = track,elu=elu,InstanceNorm=InstanceNorm)
        self.outconv = gBlock.ConvBNR3D(32, n_out, filter_size, out = True,elu=elu,InstanceNorm=InstanceNorm)
        self.outrelu = torch.nn.ReLU()#Positivity constraint

    def get_name(self):
        return self._get_name()+f"_track{self.track}_elu{self.elu}_posout{self.pos_out}_INorm{self.InstanceNorm}"

    def forward(self, x, sigma=None):
        x_og = x
        x1 = self.conv1(x)
        x2 = self.down1(x1)
        x3 = self.conv2(x2)
        x4 = self.down2(x3)
        x5 = self.conv3(x4)
        x6 = self.up1(x5, x3)
        x7 = self.conv4(x6)
        x8 = self.up2(x7, x1)
        x9 = self.conv5(x8)
        x10 = self.outconv(x9)
        if self.pos_out:
            x11 = self.outrelu(torch.add(x10,x_og))
        else:
            x11 = torch.add(x10,x_og)

        return x11

#UNet: 3D Trilinear Upsampling with concatenation, 3D Downsampling, ConvBNR3D_out with residual skip connection
class u3D1(torch.nn.Module):
    def __init__(self, n_in = 1, n_out = 1, filter_size = 3, track = False,elu=False,pos_out=True,InstanceNorm=False):
        '''
        Initialize a UNET with 3D Trilinear Upsampling with concatenation, 3D Downsampling, ConvBNR3D_out block with residual skip connection.

        Arguments:
            - n_in: number of input channels (int, default: 1).
            - n_out: number of output channels (int, default: 1).
            - filter_size: 3D filter radius (int, default: 3).
            - out: specify if output block (boolean, if True [conv3D,ReLU,conv3D] else [conv3D, BatchNorm3D,ReLU], default: False)
            - track: boolean to track running stats (see see BatchNorm3D,boolean, if False then batch statistic used in evaluation,
             if True running mean/var estimated in training and applied in evaluation, default=False).
            - elu: use ELU instead of ReLU (differentiable).
            - pos_out: enfoce positivity of output via ReLU (non differentiable, default:True).
            - InstanceNorm: use InstanceNorm instead of BatchNorm (allows accumulate grad, default: False).
        '''
        super(u3D1, self).__init__()

        self.n_in = n_in
        self.n_out = n_out
        self.filter_size = filter_size
        self.track=track
        self.elu=elu
        self.pos_out=pos_out
        self.InstanceNorm=InstanceNorm

        self.conv1 = gBlock.ConvBNR3D(n_in, 32, filter_size, track = track,elu=elu,InstanceNorm=InstanceNorm)
        self.down1 = gBlock.Down3D(32, 32, filter_size, track = track,elu=elu,InstanceNorm=InstanceNorm)
        self.conv2 = gBlock.ConvBNR3D(32, 32, filter_size, track = track,elu=elu,InstanceNorm=InstanceNorm)
        self.down2 = gBlock.Down3D(32, 64, filter_size, track = track,elu=elu,InstanceNorm=InstanceNorm)
        self.conv3 = gBlock.ConvBNR3D(64, 64, filter_size, track = track,elu=elu,InstanceNorm=InstanceNorm)
        self.up1 = gBlock.Up3D_cat(96, 32, filter_size, track = track,elu=elu,InstanceNorm=InstanceNorm)
        self.conv4 = gBlock.ConvBNR3D(32, 32, filter_size, track = track,elu=elu,InstanceNorm=InstanceNorm)
        self.up2 = gBlock.Up3D_cat(64, 32, filter_size, track = track,elu=elu,InstanceNorm=InstanceNorm)
        self.conv5 = gBlock.ConvBNR3D(32, 32, filter_size, track = track,elu=elu,InstanceNorm=InstanceNorm)
        self.outconv = gBlock.ConvBNR3D_out(32, n_out, filter_size)
        self.outrelu = torch.nn.ReLU()

    def get_name(self):
        return self._get_name()+f"_track{self.track}_elu{self.elu}_posout{self.pos_out}_INorm{self.InstanceNorm}"

    def forward(self, x):
        x_og = x
        x1 = self.conv1(x)
        x2 = self.down1(x1)
        x3 = self.conv2(x2)
        x4 = self.down2(x3)
        x5 = self.conv3(x4)
        x6 = self.up1(x5, x3)
        x7 = self.conv4(x6)
        x8 = self.up2(x7, x1)
        x9 = self.conv5(x8)
        x10 = self.outconv(x9)
        if self.pos_out:
            x11 = self.outrelu(torch.add(x10,x_og))
        else:
            x11 = torch.add(x10,x_og)
        return x11

#UNet: 3D Trilinear Upsampling with addition, 3D Downsampling, residual skip connection
class u3D2(torch.nn.Module):
    def __init__(self, n_in = 1, n_out = 1, filter_size = 3, track = False,elu=False,pos_out=True,InstanceNorm=False):
        '''
        Initialize a UNET with 3D Trilinear Upsampling with addition, 3D Downsampling, residual skip connection.

        Arguments:
            - n_in: number of input channels (int, default: 1).
            - n_out: number of output channels (int, default: 1).
            - filter_size: 3D filter radius (int, default: 3).
            - out: specify if output block (boolean, if True [conv3D,ReLU,conv3D] else [conv3D, BatchNorm3D,ReLU], default: False)
            - track: boolean to track running stats (see see BatchNorm3D,boolean, if False then batch statistic used in evaluation,
             if True running mean/var estimated in training and applied in evaluation, default=False).
            - pos_out: enfoce positivity of output via ReLU (non differentiable, default:True).
            - InstanceNorm: use InstanceNorm instead of BatchNorm (allows accumulate grad, default: False).
        '''
        super(u3D2, self).__init__()

        self.n_in = n_in
        self.n_out = n_out
        self.filter_size = filter_size
        self.track=track
        self.elu=elu
        self.pos_out=pos_out
        self.InstanceNorm=InstanceNorm

        self.conv1 = gBlock.ConvBNR3D(n_in, 32, filter_size, track = track,elu=elu,InstanceNorm=InstanceNorm)
        self.down1 = gBlock.Down3D(32, 32, filter_size, track = track,elu=elu,InstanceNorm=InstanceNorm)
        self.conv2 = gBlock.ConvBNR3D(32, 32, filter_size, track = track,elu=elu,InstanceNorm=InstanceNorm)
        self.down2 = gBlock.Down3D(32, 64, filter_size, track = track,elu=elu,InstanceNorm=InstanceNorm)
        self.conv3 = gBlock.ConvBNR3D(64, 64, filter_size, track = track,elu=elu,InstanceNorm=InstanceNorm)
        self.up1 = gBlock.Up3D_add(64, 32, filter_size, track = track,elu=elu,InstanceNorm=InstanceNorm)
        self.conv4 = gBlock.ConvBNR3D(32, 32, filter_size, track = track,elu=elu,InstanceNorm=InstanceNorm)
        self.up2 = gBlock.Up3D_add(32, 32, filter_size, track = track,elu=elu,InstanceNorm=InstanceNorm)
        self.conv5 = gBlock.ConvBNR3D(32, 32, filter_size, track = track,elu=elu,InstanceNorm=InstanceNorm)
        self.outconv = gBlock.ConvBNR3D(32, n_out, filter_size, out = True,elu=elu,InstanceNorm=InstanceNorm)
        self.outrelu = torch.nn.ReLU()

    def get_name(self):
        return self._get_name()+f"_track{self.track}_elu{self.elu}_posout{self.pos_out}_INorm{self.InstanceNorm}"


    def forward(self, x):
        x_og = x
        x1 = self.conv1(x)
        x2 = self.down1(x1)
        x3 = self.conv2(x2)
        x4 = self.down2(x3)
        x5 = self.conv3(x4)
        x6 = self.up1(x5, x3)
        x7 = self.conv4(x6)
        x8 = self.up2(x7, x1)
        x9 = self.conv5(x8)
        x10 = self.outconv(x9)
        if self.pos_out:
            x11 = self.outrelu(torch.add(x10,x_og))
        else:
            x11 = torch.add(x10,x_og)
        return x11