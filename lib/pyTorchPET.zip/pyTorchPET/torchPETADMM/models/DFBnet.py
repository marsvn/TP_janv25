import torch
import torch.nn as nn
import torch.nn.functional as F
from . import basicblock as B



class DiFB_block(torch.nn.Module):
    def __init__(self, 
                 N_rho, 
                 N_nu,
                 i_channels, 
                 i_kernel_size, 
                 b_inertia = True, 
                 b_transpose = False
                 ):
        super(DiFB_block, self).__init__()
        
        self.b_inertia = b_inertia

        self.N_nu = N_nu

        # self.nu = nn.Parameter(torch.ones(1))
        self.b_transpose = b_transpose  

        if self.b_inertia:
            self.rho = nn.Parameter(torch.ones(1))      
            self.N_rho = N_rho
        

        self.convD = B.MultiConv3d(num_channels=[1, i_channels], size_kernels=[i_kernel_size], zero_mean = False, sn_size=128)
        if not b_transpose:
            self.convDt = B.MultiConv3d(num_channels=[1, i_channels], size_kernels=[i_kernel_size], zero_mean = False, sn_size=128)   

        

    def forward(self, vk, uk, zref, nu, b_training = True, alpha = None, b_compute_x = False):
        vk_1 = vk.clone()
        
        if self.b_transpose:
            tmp = torch.clamp(zref- self.convD.transpose(vk), min=0, max = None)
            sn = self.convD.spectral_norm(mode="Fourier", n_steps=100)
            # print("spectral norm 1:", sn)
            # sn2 = self.convD.spectral_norm(mode="power_method", n_steps=100)
            # print("spectral norm 2:", sn2)
            if alpha is None:
                tau = 1.99/sn
            else :
                tau = 0.99/sn
            uk_1 = self.N_nu*nu*F.hardtanh((vk+ self.convD(tmp)*tau)/(self.N_nu*nu+1e-6))
        else:
            tmp = torch.clamp(zref- self.convDt.transpose(vk), min=0, max = None)
            # print((vk+ self.convD(tmp)).max()/(self.N_nu*F.softplus(self.nu)), (vk+ self.convD(tmp)).min()/(self.N_nu*F.softplus(self.nu)))
            # print(self.N_nu, (self.N_nu*nu + 1e-6))
            uk_1 = self.N_nu*nu*F.hardtanh((vk+ self.convD(tmp))/(self.N_nu*nu +1e-6))

        if self.b_inertia:
            vk_1 = (1+ self.N_rho*F.softplus(self.rho))*uk_1 - self.N_rho*F.softplus(self.rho)*uk
        elif alpha is not None:
            vk_1 = (1+ alpha)*uk_1 - alpha*uk
        else :
            vk_1 = uk_1
        if b_compute_x:
            if self.b_transpose:
                x = torch.clamp(zref- self.convD.transpose(vk_1), min=0, max = None)
            else :
                x = torch.clamp(zref- self.convDt.transpose(vk_1), min=0, max = None)
        else :
            x = None

        return vk_1, uk_1, x




class DiFB_blockUnmatched(torch.nn.Module):
    def __init__(self, 
                 N_rho, 
                 N_nu,
                 i_channels, 
                 i_kernel_size, 
                 b_inertia = True, 
                 b_transpose = False
                 ):
        super(DiFB_blockUnmatched, self).__init__()
        
        self.b_inertia = b_inertia

        self.N_nu = N_nu

        # self.nu = nn.Parameter(torch.ones(1))
        self.b_transpose = b_transpose  

        if self.b_inertia:
            self.rho = nn.Parameter(torch.ones(1))      
            self.N_rho = N_rho
        

        self.convD = B.UnmatchedMultiConv3d(num_channels=[1, i_channels], size_kernels=[i_kernel_size], zero_mean = False, sn_size=128)
        
        

    def forward(self, vk, uk, zref, nu, b_training = True, alpha = None, b_compute_x = False):
        vk_1 = vk.clone()
        
        tmp = torch.clamp(zref- self.convD.transpose(vk), min=0, max = None)
        sn = self.convD.spectral_norm(mode="Fourier", n_steps=100)
        # print("spectral norm 1:", sn)
        # sn2 = self.convD.spectral_norm(mode="power_method", n_steps=100)
        # print("spectral norm 2:", sn2)
        if alpha is None:
            tau = 1.99/sn
        else :
            tau = 0.99/sn
        uk_1 = self.N_nu*nu*F.hardtanh((vk+ self.convD(tmp)*tau)/(self.N_nu*nu+1e-6))
    
        if self.b_inertia:
            vk_1 = (1+ self.N_rho*F.softplus(self.rho))*uk_1 - self.N_rho*F.softplus(self.rho)*uk
        elif alpha is not None:
            vk_1 = (1+ alpha)*uk_1 - alpha*uk
        else :
            vk_1 = uk_1
        if b_compute_x:
            x = torch.clamp(zref- self.convD.transpose(vk_1), min=0, max = None)
            
        else :
            x = None

        return vk_1, uk_1, x    

class DiFB_block_shareD(torch.nn.Module):
    def __init__(self, 
                 N_rho, 
                 N_nu,
                 i_kernel_size, 
                 b_inertia = True,
                 ):
        super(DiFB_block_shareD, self).__init__()
        
        self.b_inertia = b_inertia
        # self.nu = nn.Parameter(torch.ones(1))
        self.N_nu = N_nu

        if self.b_inertia:
            self.rho = nn.Parameter(torch.ones(1))      
            self.N_rho = N_rho
            

        self.size_pad = i_kernel_size//2
        

    def forward(self, vk, uk, zref, nu, convD, convDt, b_training = True, alpha = None, b_compute_x = False):
        vk_1 = vk.clone()

        if convDt is None:
            tmp = torch.clamp(zref- convD.transpose(vk), min=0, max = None)
            # sn = convD.spectral_norm(mode="Fourier", n_steps=100)
            # print("spectral norm 1:", sn)
            # sn2 = convD.spectral_norm(mode="power_method", n_steps=1000)
            # print("spectral norm 2:", sn2)
            if alpha is None:
                tau = 1.99/convD.L
            else :
                tau = 0.99/convD.L
            uk_1 = self.N_nu*nu*F.hardtanh((vk+ convD(tmp)*tau)/(self.N_nu*nu+1e-6))
        else:
            tmp = torch.clamp(zref- convDt.transpose(vk), min=0, max = None)
            # print((vk+ convD(tmp)).max()/(self.N_nu*F.softplus(self.nu)), (vk+ convD(tmp)).min()/(self.N_nu*F.softplus(self.nu)))

            uk_1 = self.N_nu*nu*F.hardtanh((vk+ convD(tmp))/(self.N_nu*nu+1e-6))


        if self.b_inertia:
            vk_1 = (1+ self.N_rho*F.softplus(self.rho))*uk_1 - self.N_rho*F.softplus(self.rho)*uk
        elif alpha is not None:
            vk_1 = (1+ alpha)*uk_1 - alpha*uk
        else:
            vk_1 = uk_1

        if b_compute_x:
            if convDt is None:
                x = torch.clamp(zref- convD.transpose(vk_1), min=0, max = None)
            else :
                x = torch.clamp(zref- convDt.transpose(vk_1), min=0, max = None)
        else :
            x = None

        return vk_1, uk_1, x


#################################################

class DFBnet(torch.nn.Module):
    def __init__(self, 
                 N_rho, 
                 N_nu,
                 i_channels, 
                 i_kernel_size, 
                 i_num_iter, 
                 b_shareD = False, 
                 b_inertia = True, 
                 b_fista = False,
                 b_transpose = False
                 ):
        super(DFBnet, self).__init__()
        
        self.N_rho = N_rho
        self.N_nu = N_nu
        self.i_channels = i_channels
        self.i_kernel_size = i_kernel_size
        self.i_num_iter = i_num_iter
        self.b_shareD = b_shareD
        self.b_transpose = b_transpose
        self.b_fista = b_fista
        assert( not (b_fista and b_inertia))

        self.Layers   = nn.ModuleList()
        self.nu = nn.Parameter(torch.ones(1))

        if self.b_shareD:
            self.convD = B.MultiConv3d(num_channels=[1, i_channels], size_kernels=[i_kernel_size], zero_mean = False, sn_size=128)
            if not self.b_transpose:
                self.convDt = B.MultiConv3d(num_channels=[1, i_channels], size_kernels=[i_kernel_size], zero_mean = False, sn_size=128)
            else:
                self.convDt = None
        for _ in range(self.i_num_iter):        
            if self.b_shareD:
                self.Layers.append(DiFB_block_shareD(N_rho, N_nu, i_kernel_size, b_inertia))
            else :
                if b_transpose:
                    self.Layers.append(DiFB_block(N_rho, N_nu, i_channels, i_kernel_size, b_inertia, b_transpose))
                else :
                    self.Layers.append(DiFB_blockUnmatched(N_rho, N_nu, i_channels, i_kernel_size, b_inertia, b_transpose))
            
    def forward(self, zref, mask, nu, b_training = False):
        vk = torch.zeros(zref.shape[0], self.i_channels, zref.shape[2], zref.shape[3], zref.shape[4], device=zref.device)
        uk = torch.zeros(zref.shape[0], 1, zref.shape[2], zref.shape[3], zref.shape[4], device=zref.device)
        vec_x = torch.zeros(zref.shape[0], self.i_num_iter, zref.shape[2], zref.shape[3], zref.shape[4], device=zref.device)
        a = 2.1
        if self.b_shareD and self.b_transpose:
            _ = self.convD.spectral_norm(mode="Fourier", n_steps=100)

        tk = (a+1.0)/a
        for k in range(self.i_num_iter):
            if self.b_fista:
                tk_1 = (k + 1 + a + 1.0)/a
                alpha = (tk - 1.0)/tk_1
                tk = tk_1
            else :
                alpha = None
            if self.b_shareD:
                vk, uk, x = self.Layers[k](vk, uk, zref, nu*F.softplus(self.nu), self.convD, self.convDt, b_training, alpha, b_compute_x = True)#(k == self.i_num_iter-1))
            else :
                vk, uk, x = self.Layers[k](vk, uk, zref, nu*F.softplus(self.nu), b_training, alpha, b_compute_x = True) #(k == self.i_num_iter-1))
            if mask is not None:
                x = x*mask
            vec_x[:,k,:,:,:] = x.squeeze()
      
        return x, vec_x