"""
Created on March 2023

@author: florent.sureau
"""

import os
import torch
import pickle
from  torchPETADMM.learning.training import learningParams as learningParams

def get_save_model_name(model,ParamsLearn,date):
    '''
    Get a string identifying the model (all inputs are strings).

    Arguments:
        - model: Neural Network model (class derived from torch.nn.Module).
        - ParamsLearn: parameters for training (learningParams).
        - date: date for saving (string, format: mm-dd-yyyy).
    Returns:
        - filename for model (string).
    '''
    model_type=model.get_name()
    init_model_name=ParamsLearn.init_model_name.rsplit('.')[0]

    epochs=ParamsLearn.epochs
    batch_size=ParamsLearn.train_batch_size
    nsubj=ParamsLearn.paramsTensorDataSet.n_subjects
    n_sim=ParamsLearn.paramsTensorDataSet.n_sim
    patience=ParamsLearn.patience
    learning_rate=ParamsLearn.learning_rate
    Acc=ParamsLearn.accumulate_grad
    name = f'model_{date}_{model_type}-{epochs}ep-{batch_size}bs-{nsubj}p-{n_sim}r-{patience}p-lr{learning_rate}-Acc{Acc}'
    if ParamsLearn.normalize:
        name = name + '-norm'
    if ParamsLearn.norm_train:
        name = name + '-g1g2norm'
    if not ParamsLearn.paramsTensorDataSet.shuffle_train:
        name = name + '-ord'
    if ParamsLearn.jacobian_reg:
        sj_eps_str=str(ParamsLearn.sj_eps).replace('.','p')
        sj_iter_str=str(ParamsLearn.sj_iter).replace('.','p')
        noisy_jac_str=str(ParamsLearn.noisy_jac)
        diff_sj=str(ParamsLearn.diff_sj)
        beta_sj=str(ParamsLearn.beta_sj)
        name = name + '-sj'
        name = name + f'_sjeps{sj_eps_str}_sjiter{sj_iter_str}_noisyjac{noisy_jac_str}_diff{diff_sj}_beta{beta_sj}'
    #if not init_model_name is '':
    #    name= name+ f'_init_{init_model_name}'
    name = name + '.pth'
    return name

def save_model(model,ParamsLearn,date,root_save_dir="/home/sureau/Projects/Mahdi/MahdiDev/Code/UNet Models"):
    '''
    Save NN model using torch.save.

    Arguments:
        - model: Neural Network model (class derived from torch.nn.Module).
        - ParamsLearn: parameters for training (learningParams).
        - date: date for saving (string, format: mm-dd-yyyy).
        - root_save_dir: rootname where models are saved (string,
          default:'/home/sureau/Projects/Mahdi/MahdiDev/Code/UNet Models') ;
          models are saved in subdirectory givent by the database.
    Returns:
        - filename for model (string).
    '''
    name = get_save_model_name(model,ParamsLearn,date)

    save_dir =os.path.join(root_save_dir, ParamsLearn.paramsTensorDataSet.database_name)
    if not os.path.exists(save_dir):
            os.makedirs(save_dir)

    torch.save(model, os.path.join(save_dir, name))
    return name

def load_model(name,save_dir,device="cuda"):
    '''
    Load NN model using torch.load.

    Arguments:
        - name: filename of saved NN file (string).
        - save_dir: dirpath where models are saved, including database (string)
        - device: device where the model will be saved (string, "cuda","cuda:1","cpu"...)
    Returns:
        - model: Neural Network model (class derived from torch.nn.Module).
    '''

    print(os.path.join(save_dir, name))
    model = torch.load(os.path.join(save_dir, name),map_location=device)

    return model

def save_model_Params(model_name,ParamsLearn,root_save_dir="/home/sureau/Projects/Mahdi/MahdiDev/Code/UNet Models"):
    '''
    Save NN model parameters.

    Arguments:
        - model_name: name of Neural Network model (string).
        - ParamsLearn: parameters for training (learningParams).
        - root_save_dir: rootname where models are saved (string,
          default:'/home/sureau/Projects/Mahdi/MahdiDev/Code/UNet Models') ;
          models are saved in subdirectory givent by the database.
    Returns:
        - filename for model parameters (string).
    '''
    save_dir =os.path.join(root_save_dir, ParamsLearn.paramsTensorDataSet.database_name)
    if not os.path.exists(save_dir):
            os.makedirs(save_dir)
    param_name=model_name.replace('.pth','_paramLearn.pickle')
    fname=os.path.join(save_dir,param_name)
    ParamsLearn.save(fname)
    return param_name


def save_learning_metrics(model_name,ParamsLearn,output_learning_dico,storage_dir):
    '''
    Save the output of the training step.

    Arguments:
        - model_name: name of NN model (string).
        - ParamsLearn: parameters for training (learningParams).
        - output_learning_dico: dictionary of learning metrics.
        - storage_dir: root path for saved file (string).

    Returns:
        - path to saved file (string)
    '''
    save_dir =os.path.join(storage_dir, ParamsLearn.paramsTensorDataSet.database_name)
    metrics_name_save=f"{model_name.replace('.pth','_results.pickle')}"
    fname=os.path.join(save_dir,metrics_name_save)
    with open(fname,"wb") as handle:
         pickle.dump(output_learning_dico,handle,protocol=pickle.HIGHEST_PROTOCOL)
    return metrics_name_save

def load_model_Params(model_name,save_dir):
    '''
    Load NN model parameters.

    Arguments:
        - model_name: filename of saved NN file (string).
        - save_dir: dirpath where models are saved, including database (string)
    Returns:
        - ParamsLearn: parameters used for training (learningParams).
    '''
    ParamsLearn=learningParams()
    ParamsLearn.load(os.path.join(save_dir, model_name.replace('.pth','_paramLearn.pickle')))

    return ParamsLearn

def load_learning_metrics(model_name,save_dir):
    '''
    Load the dictionary of the training step metrics.

    Arguments:
        - model_name: name of NN model (string).
        - ParamsLearn: parameters for training (learningParams).
        - save_dir: root path for saved file (string).

    Returns:
        - dictionary of learning metrics. (dictionary)
    '''

    test_name_save=f"{model_name.replace('.pth','_results.pickle')}"
    fname=os.path.join(save_dir,test_name_save)
    with open(fname, 'rb') as pickle_file:
        dico_results=pickle.load(pickle_file)
    return dico_results


def memory():

    '''
    Displays the reserved, GPU memory for cuda, memory allocated, and free memory.
    '''

    t = torch.cuda.get_device_properties(0).total_memory
    r = torch.cuda.memory_reserved(0)
    a = torch.cuda.memory_allocated(0)
    f = r-a

    print('Reserved Memory:', int(r//1e9), 'Gb',
          int((r-r//1e9*1e9)//1e6), 'Mb',
          int((r-r//1e9*1e9-(r-r//1e9*1e9)//1e6*1e6)//1e3), 'Kb (Total Memory: ', int(t//1e9), 'Gb',
          int((t-t//1e9*1e9)//1e6), 'Mb',
          int((t-t//1e9*1e9-(t-t//1e9*1e9)//1e6*1e6)//1e3), 'Kb)')
    print('Allocated Memory:', int(a//1e9), 'Gb',
          int((a-a//1e9*1e9)//1e6), 'Mb',
          int((a-a//1e9*1e9-(a-a//1e9*1e9)//1e6*1e6)//1e3), 'Kb')
    print('Free Memory:', int(f//1e9), 'Gb',
          int((f-f//1e9*1e9)//1e6), 'Mb',
          int((f-f//1e9*1e9-(f-f//1e9*1e9)//1e6*1e6)//1e3), 'Kb')
