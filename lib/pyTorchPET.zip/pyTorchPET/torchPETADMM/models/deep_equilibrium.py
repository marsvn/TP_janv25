import torch
from torch import nn
import sys
sys.path.append("..")
from . import utils
from . import CVnet

class DEQFixedPoint(nn.Module):
    def __init__(self, model, params_fw, params_bw, num_chan):
        super().__init__()
        self.model = model
        self.solver = safe_anderson_acceleration
        self.params_fw = params_fw
        self.params_bw = params_bw
        self.f = None
        self.fjvp = None
        self.backward_res = None
        self.backward_iter = None
        self.lamb_bck = None
        self.lamb_fwd = None
        self.moving_avg_res_bck = None
        self.moving_avg_res_fwd = None
        self.forward_res = None
        self.NN = CVnet.RFDN(in_nc=1, nf=8, num_modules=1, out_nc=num_chan, upscale=1, bias=False)

    def reg_weight(self, x) :
        return(self.NN(x))
        
    def forward(self, x_noisy, sigma=None, bTrain = False, xem = None, **kwargs):
        nonlocal_lbd = self.NN(xem)
        # update spectral norm of the convolutional layer
        if bTrain:
            self.model.conv_layer.spectral_norm()
            
        # fixed point iteration
        def f(x, x_noisy):
             return(x - self.model.grad_denoising(x, x_noisy, sigma=sigma, nonlocal_lbd=nonlocal_lbd))

        # jacobian vector product of the fixed point iteration
        def fjvp(x, y):
            with torch.no_grad():
                return(y - self.model.hvp_denoising(x, y, sigma=sigma, nonlocal_lbd=nonlocal_lbd))

        self.f = f
        self.fjvp = fjvp


        # compute the fixed point
        with torch.no_grad():
            z, self.forward_niter_max, self.forward_niter_mean = utils.accelerated_gd_batch(x_noisy, self.model, sigma=sigma, ada_restart=True, **self.params_fw)
      
        z = self.f(z, x_noisy)
  
        z0 = z.clone().detach()

        def backward_hook(grad):
            g, self.backward_iter, self.backward_res, self.lamb_bck, self.moving_avg_res_bck = self.solver(lambda y : self.fjvp(z0, y) + grad,
                                           grad, **self.params_bw)
            return g

        if bTrain:
            z.register_hook(backward_hook)
       
        return z



def anderson(f, x0, m=5, lam=1e-4, max_iter=50, tol=1e-5, beta = 1.0):
    """ Anderson acceleration for fixed point iteration. """
    bsz, d, D, H, W = x0.shape
    X = torch.zeros(bsz, m, d*D*H*W, dtype=x0.dtype, device=x0.device)
    F = torch.zeros(bsz, m, d*D*H*W, dtype=x0.dtype, device=x0.device)
    X[:,0], F[:,0] = x0.view(bsz, -1), f(x0).view(bsz, -1)
    X[:,1], F[:,1] = F[:,0], f(F[:,0].view_as(x0)).view(bsz, -1)
    
    H = torch.zeros(bsz, m+1, m+1, dtype=x0.dtype, device=x0.device)
    H[:,0,1:] = H[:,1:,0] = 1
    y = torch.zeros(bsz, m+1, 1, dtype=x0.dtype, device=x0.device)
    y[:,0] = 1
    
    res = []
    for k in range(2, max_iter):
        n = min(k, m)
        G = F[:,:n]-X[:,:n]
        H[:,1:n+1,1:n+1] = torch.bmm(G,G.transpose(1,2)) + lam*torch.eye(n, dtype=x0.dtype,device=x0.device)[None]
  
        alpha = torch.linalg.solve(H[:, :n + 1, :n + 1], y[:, :n + 1])[:,1:n+1,0]
   
        X[:,k%m] = beta * (alpha[:,None] @ F[:,:n])[:,0] + (1-beta)*(alpha[:,None] @ X[:,:n])[:,0]
        F[:,k%m] = f(X[:,k%m].view_as(x0)).view(bsz, -1)
        res.append((F[:,k%m] - X[:,k%m]).norm().item()/(1e-5 + F[:,k%m].norm().item()))
        if (res[-1] < tol):
            break
       
        
    return X[:,k%m].view_as(x0), k





def safe_anderson_acceleration(f, x0, m=5, lam=1e-4, max_iter=50, tol=1e-5, beta=1.0, average_iter=20, deb_average=50, plateau_iter=20, verbose = True):
    """Safe version of Anderson acceleration for fixed point iteration.
    Ensures that the Hessian is invertible by adding a small value to the diagonal depending on the conditioning of G.
    If the moving average of residual is increasing, the method is restarted with a larger value of lam (fac 1.1).
    
    Args:
    - f (callable): The function for fixed point iteration.
    - x0 (torch.Tensor): The initial guess tensor.
    - m (int): Number of previous iterates to store.
    - lam (float): Regularization parameter.
    - max_iter (int): Maximum number of iterations.
    - tol (float): Tolerance for convergence.
    - beta (float): Mixing coefficient for the accelerated iterate.
    - average_iter (int): Number of iterations to compute the movign average of residuals.
    - deb_average (int): Number of iterations before starting to compute the moving average of residuals.
    
    Returns:
    - x (torch.Tensor): The final iterate.
    - f_x (torch.Tensor): The value of f at the final iterate.
    - res (list): List of residuals for each iteration.
    """
    bsz, d, D, H, W = x0.shape
    X = torch.zeros(bsz, m, d * D * H * W, dtype=x0.dtype, device=x0.device)
    F = torch.zeros(bsz, m, d * D * H * W, dtype=x0.dtype, device=x0.device)
    X[:, 0], F[:, 0] = x0.view(bsz, -1), f(x0).view(bsz, -1)
    X[:, 1], F[:, 1] = F[:, 0], f(F[:, 0].view_as(x0)).view(bsz, -1)

    H_mat = torch.zeros(bsz, m + 1, m + 1, dtype=x0.dtype, device=x0.device)
    H_mat[:, 0, 1:] = H_mat[:, 1:, 0] = 1
    y = torch.zeros(bsz, m + 1, 1, dtype=x0.dtype, device=x0.device)
    y[:, 0] = 1
    
    plateau_count = 0  # Count for plateau iterations
    # prev_res_norm = float('inf')  # Initial previous residual norm
    res = []
    
    moving_avg_res = []

    k = 2
    while k < max_iter:
        n = min(k, m)
        G = F[:, :n] - X[:, :n]

        # Compute the conditioning of G
        g_norm = G.norm(dim=(1, 2))
        cond_G = g_norm.max() / g_norm.min()

        # Update the diagonal of H_mat with a small value based on the conditioning of G
        H_mat[:, 1:n + 1, 1:n + 1] = torch.bmm(G, G.transpose(1, 2)) + lam * cond_G * torch.eye(n, dtype=x0.dtype, device=x0.device)[None]

        # Solve for alpha
        alpha = torch.linalg.solve(H_mat[:, :n + 1, :n + 1], y[:, :n + 1])[:, 1:n + 1, 0]

        # Update X and F
        X[:, k % m] = beta * (alpha[:, None] @ F[:, :n])[:, 0] + (1 - beta) * (alpha[:, None] @ X[:, :n])[:, 0]
        F[:, k % m] = f(X[:, k % m].view_as(x0)).view(bsz, -1)

        # Compute residual and check for convergence
        res_norm = (F[:, k % m] - X[:, k % m]).norm() / (1e-5 + F[:, k % m].norm())
        res.append(res_norm.item())

        if res_norm < tol:
            if verbose:
                print("Converged in", k, "iterations.")
            break
        
        # compute the moving average of residuals
        if k >= deb_average + average_iter: #and k % average_iter == 0:
            if k == (average_iter + deb_average) : #first one
                moving_avg_res = res[-average_iter:]
                current_sum = sum(moving_avg_res) 
            else:
                moving_avg_res.append(res_norm.item())
                moving_avg_res = moving_avg_res[1:]
                prec_sum = current_sum
                current_sum = sum(moving_avg_res)


        # check if the moving average of residuals is increasing
        if k > (deb_average+average_iter) :
            if verbose :
                print("prec_sum", prec_sum, "current_sum", current_sum, "res_norm", res_norm.item(), "cond_G", cond_G)
            if current_sum > prec_sum:
                if verbose:
                    print("Increasing plateau.")
                plateau_count += 1
            else:
                plateau_count = 0
            if plateau_count == plateau_iter :
                plateau_count = 0
                deb_average = k
                if verbose:
                    print("####################################")
                    print("Iteration", k, ": Restarting Anderson acceleration with larger regularization parameter.")
                    print("prec_sum", prec_sum, "current_sum", current_sum)
                k = 1
                res = []
                moving_avg_res = []
                X[:, 0], F[:, 0] = x0.view(bsz, -1), f(x0).view(bsz, -1)
                X[:, 1], F[:, 1] = F[:, 0], f(F[:, 0].view_as(x0)).view(bsz, -1)

                H_mat = torch.zeros(bsz, m + 1, m + 1, dtype=x0.dtype, device=x0.device)
                H_mat[:, 0, 1:] = H_mat[:, 1:, 0] = 1

                y = torch.zeros(bsz, m + 1, 1, dtype=x0.dtype, device=x0.device)
                y[:, 0] = 1
                
                # Restart with a larger value of lam
                lam *= 1.5 #1.1
                if verbose :
                    print("lam", lam)
                    print("####################################")

        k += 1

    if verbose :
        print("Anderson acceleration done.")
    del H_mat, y, F, G
    return X[:, k % m].view_as(x0), k, res, lam, moving_avg_res