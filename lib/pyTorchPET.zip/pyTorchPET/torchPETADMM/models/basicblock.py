from collections import OrderedDict
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from . import utils
import torch.nn.utils.parametrize as P


def repeat_lam(func, times):
    def wrapper(arg):
        for i in range(times):
            arg = func(arg)
        return arg
    return wrapper
'''
Copyright (c) 2020 Kai Zhang (cskaizhang@gmail.com)
'''

'''
# --------------------------------------------
# Advanced nn.Sequential
# https://github.com/xinntao/BasicSR
# --------------------------------------------
'''
def init_weights(m, type_init='xavier'):
    if type(m) == torch.nn.Conv3d or type(m) == torch.nn.ConvTranspose3d:
        match type_init:
            case 'xavier':  
                torch.nn.init.xavier_normal_(m.weight.data, gain=1.3)
                
            case 'kaiming': 
                torch.nn.init.kaiming_normal_(m.weight.data) #, nonlinearity='relu')

            case 'zero': 
                m.weight.data.zero_()

            case _:
                raise NotImplementedError(f'init_weights: type_init={type_init} not implemented')           

        
        #torch.nn.init.kaiming_normal_(m.weight.data, nonlinearity='relu') #, gain=0.1)

        if m.bias is not None:
            m.bias.data.fill_(0)
    if type(m) == torch.nn.BatchNorm3d or type(m) == torch.nn.InstanceNorm3d:
        #torch.nn.init.constant(m.weight.data, 0.10)
        if m.weight is not None:

            torch.nn.init.normal_(m.weight.data, 1.0, 0.02)
        if m.bias is not None:
            m.bias.data.fill_(0)

    if type(m) == nn.Linear:
        if type_init == 'zero':
            m.weight.data.zero_()
        else :
            torch.nn.init.xavier_normal_(m.weight.data)
        if m.bias is not None:
            m.bias.data.fill_(0)

def init_weights_conv(m, type_init='xavier'):
    if type(m) == torch.nn.Conv3d or type(m) == torch.nn.ConvTranspose3d:
        match type_init:
            case 'xavier':  
                torch.nn.init.xavier_normal_(m.weight.data, gain=1.3)
                
            case 'kaiming': 
                torch.nn.init.kaiming_normal_(m.weight.data) #, nonlinearity='relu')

            case 'zero': 
                m.weight.data.zero_()

            case _:
                raise NotImplementedError(f'init_weights: type_init={type_init} not implemented')           

        
        #torch.nn.init.kaiming_normal_(m.weight.data, nonlinearity='relu') #, gain=0.1)

        if m.bias is not None:
            m.bias.data.fill_(0)
    if type(m) == torch.nn.BatchNorm3d or type(m) == torch.nn.InstanceNorm3d:
        #torch.nn.init.constant(m.weight.data, 0.10)
        if m.weight is not None:

            torch.nn.init.normal_(m.weight.data, 1.0, 0.02)
        if m.bias is not None:
            m.bias.data.fill_(0)

    if type(m) == nn.Linear:
        if type_init == 'zero':
            m.weight.data.zero_()
        else :
            torch.nn.init.xavier_normal_(m.weight.data)
        if m.bias is not None:
            m.bias.data.fill_(0)
    return m



def standardize_weight(m, gamma):
    if type(m) == torch.nn.Conv3d or type(m) == torch.nn.ConvTranspose3d:
        weight_ = m.weight.data.view(m.weight.data.size(0), -1)
        weight_mean = weight_.mean(dim=1, keepdim=True)
        weight_var = weight_.var(dim=1, keepdim=True)
        # weight_mean = weight_.mean(dim=(0,2,3,4), keepdim=True)
        # weight_var = weight_.var(dim=(0,2,3,4), keepdim=True)
        weight_ = weight_ - weight_mean
        #print('w=',weight_)
        # gamma = 1.2716004848480225 #1.7139588594436646


        # norm = weight_.norm(dim=1, keepdim=True) + 1e-6
        # weight_CWN = weight_ / norm
        # m.weight.data = weight_CWN.view(m.weight.data.size())
    
        fan_in = np.prod(m.weight.data.shape[1:])
        # with torch.no_grad():
        #     y = F.relu(torch.randn(1024, 256).cuda()) # Take the average variance of many random batches 
        #     gamma = y.var(dim=1, keepdim=True)
        #     gamma = gamma.mean(dim=0, keepdim=True)
            # print('gamma',gamma) #0.62 elu 0.34 relu
        # weight_ =weight_*gamma/((weight_var*fan_in)**0.5)
        #print('norm=',weight_.norm(dim=1, keepdim=True))
        #weight_ =gamma*weight_/(weight_.norm(dim=1, keepdim=True) + 1e-5)
        if gamma is None :
            weight_ =weight_/((weight_var*fan_in)**0.5)
        else :
            weight_ =weight_*gamma/((weight_var*fan_in)**0.5)

        m.weight.data = weight_.view(m.weight.data.size())

        weight_ = m.weight.data.view(m.weight.data.size(0), -1)
        weight_mean = weight_.mean(dim=1, keepdim=True)
        weight_var = weight_.var(dim=1, keepdim=True)

        # print('check mean',weight_mean)
        # print('check var',weight_var)

        # """Apply scaled WS with affine gain."""
        # mean = torch.mean(m.weight.data, axis=(0, 1, 2, 3, 4), keepdims=True)
        # print('m.weight.data',m.weight.data.shape)
        # scale =  m.weight.data-mean
        # scale = scale.norm(2)**0.5
        # print('scale',scale)
        # # Manually fused normalization, eq. to (w - mean) * gain / sqrt(N * var)
        # shift = mean * scale
        # new_weight = m.weight.data * scale - shift
        # m.weight.data = new_weight
    return 

def sequential(*args):
    """Advanced nn.Sequential.
    Args:
        nn.Sequential, nn.Module
    Returns:
        nn.Sequential
    """
    if len(args) == 1:
        if isinstance(args[0], OrderedDict):
            raise NotImplementedError('sequential does not support OrderedDict input.')
        return args[0]  # No sequential is needed.
    modules = []
    for module in args:
        if isinstance(module, nn.Sequential):
            for submodule in module.children():
                modules.append(submodule)
        elif isinstance(module, nn.Module):
            modules.append(module)
    return nn.Sequential(*modules)


'''
# --------------------------------------------
# Useful blocks
# https://github.com/xinntao/BasicSR
# --------------------------------
# conv + normaliation + relu (conv)
# (PixelUnShuffle)
# (ConditionalBatchNorm2d)
# concat (ConcatBlock)
# sum (ShortcutBlock)
# resblock (ResBlock)
# Channel Attention (CA) Layer (CALayer)
# Residual Channel Attention Block (RCABlock)
# Residual Channel Attention Group (RCAGroup)
# Residual Dense Block (ResidualDenseBlock_5C)
# Residual in Residual Dense Block (RRDB)
# --------------------------------------------
'''


class Scaling(nn.Module):

    def __init__(self, scale: float):
        self.scale = scale
        super().__init__()
    
    def __repr__(self):
        return f"{self.__class__.__name__}({self.scale})"
    
    def forward(self, x):
        return x/self.scale



class PixelShuffle3d(nn.Module):
    '''
    This class is a 3d version of pixelshuffle.
    '''
    def __init__(self, upscale_factor):
        '''
        :param scale: upsample scale
        '''
        super().__init__()
        self.scale = upscale_factor

    def forward(self, input):
        batch_size, channels, in_depth, in_height, in_width = input.size()
        nOut = channels // self.scale ** 3

        out_depth = in_depth * self.scale
        out_height = in_height * self.scale
        out_width = in_width * self.scale

        input_view = input.contiguous().view(batch_size, nOut, self.scale, self.scale, self.scale, in_depth, in_height, in_width)

        output = input_view.permute(0, 1, 5, 2, 6, 3, 7, 4).contiguous()

        return output.view(batch_size, nOut, out_depth, out_height, out_width)
# --------------------------------------------
# return nn.Sequantial of (Conv + BN + ReLU)
# --------------------------------------------
def conv(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1, bias=True, mode='CBR', negative_slope=0.2, emb_dim=64, type_init='xavier'):
    L = []
    for t in mode:
        if t == 'C':
            L.append(nn.Conv3d(in_channels=in_channels, out_channels=out_channels, kernel_size=kernel_size, stride=stride, padding=padding, bias=bias))
        elif t == 'c':
            L.append(nn.Conv1d(in_channels=in_channels, out_channels=out_channels, kernel_size=kernel_size, stride=stride, padding=padding, bias=bias))
        elif t == 'S':
            L.append(nn.utils.spectral_norm(nn.Conv3d(in_channels=in_channels, out_channels=out_channels, kernel_size=kernel_size, stride=stride, padding=padding, bias=bias)))
        elif t == 'T':
            L.append(nn.ConvTranspose3d(in_channels=in_channels, out_channels=out_channels, kernel_size=kernel_size, stride=stride, padding=padding, bias=bias))
        elif t == 'B':
            L.append(nn.BatchNorm3d(out_channels, momentum=0.9, eps=1e-04))
            #L.append(nn.BatchNorm2d(out_channels))
        elif t == 'I':
            L.append(nn.InstanceNorm3d(out_channels, affine=True))
        elif t == 'i':
            L.append(nn.InstanceNorm3d(out_channels, affine=False))
        elif t == 'D':
            L.append(nn.Sequential(
            nn.SiLU(),
            nn.Linear(
                emb_dim,
                out_channels
            ),
        ))
        elif t =='F':
            L.append(nn.Dropout3d(p=0.5, inplace=False))
        elif t == 'G':
            L.append(nn.LayerNorm(out_channels, elementwise_affine=True))
            
        elif t == 'p':
            L.append(nn.Linear(emb_dim,out_channels, bias = False))
        elif t == 'R':
        #     L.append(nn.ReLU(inplace=True))
        # elif t == 'r':
            L.append(nn.ReLU(inplace=False))
        # elif t == 'E':
        #     L.append(nn.ELU(inplace=True))
        elif t == 'E':
            L.append(nn.ELU(inplace=False))
        elif t == 'L':
        #     L.append(nn.LeakyReLU(negative_slope=negative_slope, inplace=True))
        # elif t == 'l':
            L.append(nn.LeakyReLU(negative_slope=negative_slope, inplace=False))
        elif t == 's':
            L.append(nn.Softplus())
        elif t == 'z':
            L.append(nn.Sigmoid())
        elif t == '2':
            L.append(PixelShuffle3d(upscale_factor=2))
        elif t == '3':
            L.append(PixelShuffle3d(upscale_factor=3))
        elif t == '4':
            L.append(PixelShuffle3d(upscale_factor=4))
        elif t == 'U':
            L.append(nn.Upsample(scale_factor=2)) #, mode = 'trilinear', align_corners = False))
        elif t == 'u':
            L.append(nn.Upsample(scale_factor=3, mode = 'trilinear', align_corners = False))
        elif t == 'v':
            L.append(nn.Upsample(scale_factor=4, mode = 'trilinear', align_corners = False))
        elif t == 'M':
            L.append(nn.MaxPool3d(kernel_size=kernel_size, stride=stride, padding=0))
        elif t == 'A':
            L.append(nn.AvgPool3d(kernel_size=kernel_size, stride=stride, padding=0))
        else:
            raise NotImplementedError('Undefined type: '.format(t))
        L[-1].apply(lambda x: init_weights(x, type_init=type_init))
    return sequential(*L)


# --------------------------------------------
# inverse of pixel_shuffle
# --------------------------------------------
def pixel_unshuffle(input, upscale_factor):
    r"""Rearranges elements in a Tensor of shape :math:`(C, rH, rW)` to a
    tensor of shape :math:`(*, r^2C, H, W)`.
    Authors:
        Zhaoyi Yan, https://github.com/Zhaoyi-Yan
        Kai Zhang, https://github.com/cszn/FFDNet
    Date:
        01/Jan/2019
    """
    batch_size, channels, in_height, in_width = input.size()

    out_height = in_height // upscale_factor
    out_width = in_width // upscale_factor

    input_view = input.contiguous().view(
        batch_size, channels, out_height, upscale_factor,
        out_width, upscale_factor)

    channels *= upscale_factor ** 2
    unshuffle_out = input_view.permute(0, 1, 3, 5, 2, 4).contiguous()
    return unshuffle_out.view(batch_size, channels, out_height, out_width)




# class AttentionBlock(nn.Module):
#     """
#     ### Attention block

#     This is similar to [transformer multi-head attention](../../transformers/mha.html).
#     """

#     def __init__(self, n_channels: int, n_heads: int = 1, d_k: int = None, n_groups: int = 32):
#         """
#         * `n_channels` is the number of channels in the input
#         * `n_heads` is the number of heads in multi-head attention
#         * `d_k` is the number of dimensions in each head
#         * `n_groups` is the number of groups for [group normalization](../../normalization/group_norm/index.html)
#         """
#         super().__init__()

#         # Default `d_k`
#         if d_k is None:
#             d_k = n_channels
#         # Normalization layer
#         self.norm = nn.GroupNorm(n_groups, n_channels)
#         # Projections for query, key and values
#         self.projection = nn.Linear(n_channels, n_heads * d_k * 3)
#         # Linear layer for final transformation
#         self.output = nn.Linear(n_heads * d_k, n_channels)
#         # Scale for dot-product attention
#         self.scale = d_k ** -0.5
#         #
#         self.n_heads = n_heads
#         self.d_k = d_k

#     def forward(self, x: torch.Tensor, t: Optional[torch.Tensor] = None):
#         """
#         * `x` has shape `[batch_size, in_channels, height, width]`
#         * `t` has shape `[batch_size, time_channels]`
#         """
#         # `t` is not used, but it's kept in the arguments because for the attention layer function signature
#         # to match with `ResidualBlock`.
#         _ = t
#         # Get shape
#         batch_size, n_channels, height, width = x.shape
#         # Change `x` to shape `[batch_size, seq, n_channels]`
#         x = x.view(batch_size, n_channels, -1).permute(0, 2, 1)
#         # Get query, key, and values (concatenated) and shape it to `[batch_size, seq, n_heads, 3 * d_k]`
#         qkv = self.projection(x).view(batch_size, -1, self.n_heads, 3 * self.d_k)
#         # Split query, key, and values. Each of them will have shape `[batch_size, seq, n_heads, d_k]`
#         q, k, v = torch.chunk(qkv, 3, dim=-1)
#         # Calculate scaled dot-product $\frac{Q K^\top}{\sqrt{d_k}}$
#         attn = torch.einsum('bihd,bjhd->bijh', q, k) * self.scale
#         # Softmax along the sequence dimension $\underset{seq}{softmax}\Bigg(\frac{Q K^\top}{\sqrt{d_k}}\Bigg)$
#         attn = attn.softmax(dim=2)
#         # Multiply by values
#         res = torch.einsum('bijh,bjhd->bihd', attn, v)
#         # Reshape to `[batch_size, seq, n_heads * d_k]`
#         res = res.view(batch_size, -1, self.n_heads * self.d_k)
#         # Transform to `[batch_size, seq, n_channels]`
#         res = self.output(res)

#         # Add skip connection
#         res += x

#         # Change to shape `[batch_size, in_channels, height, width]`
#         res = res.permute(0, 2, 1).view(batch_size, n_channels, height, width)

#         #
#         return res

class SelfAttention(nn.Module):
    def __init__(self, channels, size, num_heads=4):
        super(SelfAttention, self).__init__()
        self.channels = channels
        self.size = size
        self.num_heads = num_heads
        self.mha = nn.MultiheadAttention(channels, self.num_heads, batch_first=True)
        self.ln = nn.LayerNorm([channels])
        self.ff_self = nn.Sequential(
            nn.LayerNorm([channels]),
            nn.Linear(channels, channels),
            nn.GELU(),
            nn.Linear(channels, channels),
        )

    def forward(self, x, t=None):
        x = x.view(-1, self.channels, self.size * self.size).swapaxes(1, 2)
        x_ln = self.ln(x)
        attention_value, _ = self.mha(x_ln, x_ln, x_ln)
        attention_value = attention_value + x
        attention_value = self.ff_self(attention_value) + attention_value
        return attention_value.swapaxes(2, 1).view(-1, self.channels, self.size, self.size)

class PixelUnShuffle(nn.Module):
    r"""Rearranges elements in a Tensor of shape :math:`(C, rH, rW)` to a
    tensor of shape :math:`(*, r^2C, H, W)`.
    Authors:
        Zhaoyi Yan, https://github.com/Zhaoyi-Yan
        Kai Zhang, https://github.com/cszn/FFDNet
    Date:
        01/Jan/2019
    """

    def __init__(self, upscale_factor):
        super(PixelUnShuffle, self).__init__()
        self.upscale_factor = upscale_factor

    def forward(self, input):
        return pixel_unshuffle(input, self.upscale_factor)

    def extra_repr(self):
        return 'upscale_factor={}'.format(self.upscale_factor)


# --------------------------------------------
# conditional batch norm
# https://github.com/pytorch/pytorch/issues/8985#issuecomment-405080775
# --------------------------------------------
class ConditionalBatchNorm2d(nn.Module):
    def __init__(self, num_features, num_classes):
        super().__init__()
        self.num_features = num_features
        self.bn = nn.BatchNorm2d(num_features, affine=False)
        self.embed = nn.Embedding(num_classes, num_features * 2)
        self.embed.weight.data[:, :num_features].normal_(1, 0.02)  # Initialise scale at N(1, 0.02)
        self.embed.weight.data[:, num_features:].zero_()  # Initialise bias at 0

    def forward(self, x, y):
        out = self.bn(x)
        gamma, beta = self.embed(y).chunk(2, 1)
        out = gamma.view(-1, self.num_features, 1, 1) * out + beta.view(-1, self.num_features, 1, 1)
        return out


# --------------------------------------------
# Concat the output of a submodule to its input
# --------------------------------------------
class ConcatBlock(nn.Module):
    def __init__(self, submodule):
        super(ConcatBlock, self).__init__()
        self.sub = submodule

    def forward(self, x):
        output = torch.cat((x, self.sub(x)), dim=1)
        return output

    def __repr__(self):
        return self.sub.__repr__() + 'concat'


# --------------------------------------------
# sum the output of a submodule to its input
# --------------------------------------------
class ShortcutBlock(nn.Module):
    def __init__(self, submodule):
        super(ShortcutBlock, self).__init__()

        self.sub = submodule

    def forward(self, x):
        output = x + self.sub(x)
        return output

    def __repr__(self):
        tmpstr = 'Identity + \n|'
        modstr = self.sub.__repr__().replace('\n', '\n|')
        tmpstr = tmpstr + modstr
        return tmpstr


# --------------------------------------------
# Res Block: x + conv(relu(conv(x)))
# --------------------------------------------
class ResBlock(nn.Module):
    def __init__(self, in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1, bias=True, mode='CRC', negative_slope=0.2, type_init='xavier'):
        super(ResBlock, self).__init__()

        assert in_channels == out_channels, 'Only support in_channels==out_channels.'
        # if mode[0] in ['R', 'L']:
        #     mode = mode[0].lower() + mode[1:]

        self.res = conv(in_channels, out_channels, kernel_size, stride, padding, bias, mode, negative_slope, type_init=type_init)

    def forward(self, x):
        res = self.res(x)
        return x + res
    
    @torch.no_grad()
    def signal_prop(self, x, dim=(0, -1, -2, -3)):
        # forward code
        skip = x
        residual = self.res(x)
        out = residual + skip

        # compute necessary statistics
        out_mu2 = torch.mean(out.mean(dim) ** 2).item()
        out_var = torch.mean(out.var(dim)).item()
        res_var = torch.mean(residual.var(dim)).item()
        print((out_mu2, out_var, res_var))

        return out, (out_mu2, out_var, res_var)
    
# --------------------------------------------
# --------------------------------------------
class NFResBlock(nn.Module):
    def __init__(self, in_channels=64, 
                 out_channels=64, 
                 kernel_size=3, 
                 stride=1, 
                 padding=1, 
                 bias=True, 
                 mode='CRC', 
                 negative_slope=0.2, 
                 type_init='xavier', 
                 beta = 1.0,
                 alpha = 1.0, 
                 gain = 1.0
                 ):
        super(NFResBlock, self).__init__()

        self.alpha = alpha
        self.gain = gain
        self.beta = (1.0+alpha**2)**0.5

        ### pre-activations ###
        self.residual_preact = nn.Sequential(
            Scaling(self.beta)
        )
        

        assert in_channels == out_channels, 'Only support in_channels==out_channels.'

   
        # if mode[0] in ['R', 'L']:
        #     mode = mode[0].lower() + mode[1:]

        self.in_channels = in_channels
        self.out_channels = out_channels
        #self.residual_branch = nn.Identity()
        self.residual_branch = conv(in_channels, out_channels, kernel_size, stride, padding, bias, mode, negative_slope, type_init=type_init)
        

    def forward(self, x):
        residual = self.residual_preact(x)
        skip = residual
        #self.residual_branch.apply(lambda x: standardize_weight(x, self.gain))
        for i,conv in enumerate(self.residual_branch): conv.apply(lambda x: standardize_weight(x, self.gain))
        residual = self.residual_branch(residual)

        return self.alpha * residual + skip
    
    @torch.no_grad()
    def signal_prop(self, x, dim=(0, -1, -2, -3)): 
        # print("beta=",self.beta)
        # print("alpha=",self.alpha)

        # x = (x - torch.mean(x.mean(dim)))/torch.mean(x.var(dim)).sqrt()
        # print("var i=", torch.mean(x.var(dim)).item())
        # print("mean i=", torch.mean(x.mean(dim)).item())

        # forward code
        residual = self.residual_preact(x)
        skip = residual
        # print("var skip=", torch.mean(skip.var(dim)).item())
        # print("mean skip=", torch.mean(skip.mean(dim)).item())

        t = self.residual_branch(residual)
        # print("var conv=", torch.mean(t.var(dim)).item())
        # print("mean conv=", torch.mean(t.mean(dim)).item())
        # print("var a*conv=", torch.mean((self.alpha * t).var(dim)).item())
        out = (self.alpha * t + skip)
        # out =out1/(self.alpha*self.alpha)
        # print("var o1=", torch.mean(out1.var(dim)).item())
        # print("var o=", torch.mean(out.var(dim)).item())
        # print("mean o=", torch.mean(out.mean(dim)).item())
        # compute necessary statistics
        out_mu2 = torch.mean(out.mean(dim) ** 2).item()
        out_var = torch.mean(out.var(dim)).item()
        res_var = torch.mean(residual.var(dim)).item()

        return out, (out_mu2, out_var, res_var)
    

################################################################



class HalfResBlock(nn.Module):
    def __init__(self, in_channels=64, 
                 out_channels=64, 
                 kernel_size=3, 
                 stride=1, 
                 padding=1, 
                 bias=True, 
                 mode='CRC', 
                 negative_slope=0.2, 
                 type_init='xavier', 
                 alpha = 1.0, 
                 ):
        super(HalfResBlock, self).__init__()


        ### pre-activations ###
        self.residual_preact = nn.Sequential(
            Scaling(alpha),
            #nn.ReLU(),
        )
    
        assert in_channels == out_channels, 'Only support in_channels==out_channels.'

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.residual_branch = conv(in_channels, out_channels, kernel_size, stride, padding, bias, mode, negative_slope, type_init=type_init)
        

    def forward(self, x):
        residual = self.residual_preact(x)
        skip = residual
        #for _,conv in enumerate(self.residual_branch): conv.apply(lambda x: standardize_weight(x, None))
        residual = self.residual_branch(residual)

        return residual + skip
    
    @torch.no_grad()
    def signal_prop(self, x, dim=(0, -1, -2, -3)): 
        
        # forward code
        residual = self.residual_preact(x)
        skip = residual
        # for _,conv in enumerate(self.residual_branch): conv.apply(lambda x: standardize_weight(x, None))

        out = self.residual_branch(residual) + skip
        
        out_mu2 = torch.mean(out.mean(dim) ** 2).item()
        out_var = torch.mean(out.var(dim)).item()
        res_var = torch.mean(residual.var(dim)).item()

        return out, (out_mu2, out_var, res_var)
        
# --------------------------------------------
# Res Block weight: x + weight*conv(relu(conv(x)))
# --------------------------------------------
class ResBlockWeight(nn.Module):
    def __init__(self, in_channels=64, 
                 out_channels=64, 
                 kernel_size=3, 
                 stride=1, 
                 padding=1, 
                 bias=True, 
                 mode='CRC', 
                 negative_slope=0.2, 
                 type_init='xavier', 
                 skip_weight = None):
        super(ResBlockWeight, self).__init__()

        self.skip_weight = skip_weight

        assert in_channels == out_channels, 'Only support in_channels==out_channels.'
        # if mode[0] in ['R', 'L']:
        #     mode = mode[0].lower() + mode[1:]


        self.res = conv(in_channels, out_channels, kernel_size, stride, padding, bias, mode, negative_slope, type_init=type_init)
        if self.skip_weight == 'sigmoid' or self.skip_weight == 'softplus':
            self.res_weight = nn.Parameter(torch.cuda.FloatTensor([-6.0]))
        elif self.skip_weight == 'relu':
            self.res_weight = nn.Parameter(torch.cuda.FloatTensor([1e-6]))
        else :
            self.res_weight = nn.Parameter(torch.cuda.FloatTensor([0.]))

    def forward(self, x, sigma = None):
        res = self.res(x)
        if sigma is not None:
            res_weight = (self.res_weight*sigma).view(-1, 1, 1, 1, 1)
        else:
            res_weight = self.res_weight

        if self.skip_weight is None:
            return x + res_weight*res
        elif self.skip_weight == 'softplus':
            return x + F.softplus(res_weight)*res
        elif self.skip_weight == 'sigmoid':
            return x + F.sigmoid(res_weight)*res
        elif self.skip_weight == 'relu':
            return x +utils.relu_straight_through(res_weight)*res
    
        else :
            raise NotImplementedError
        
    @torch.no_grad()
    def signal_prop(self, x, sigma = None, dim=(0, -1, -2, -3)):
        # forward code
        residual = self.res(x)

        if sigma is not None:
            res_weight = self.res_weight*sigma
        else:
            res_weight = self.res_weight

        if self.skip_weight is None:
            out=  x + res_weight*residual
        elif self.skip_weight == 'softplus':
            out= x + F.softplus(res_weight)*residual
        elif self.skip_weight == 'sigmoid':
            out= x + F.sigmoid(res_weight)*residual
        elif self.skip_weight == 'relu':
            out= x +utils.relu_straight_through(res_weight)*residual
        else :
            raise NotImplementedError

        # compute necessary statistics
        out_mu2 = torch.mean(out.mean(dim) ** 2).item()
        out_var = torch.mean(out.var(dim)).item()
        res_var = torch.mean(residual.var(dim)).item()

        return out, (out_mu2, out_var, res_var)

##############################################
class Swish(nn.Module):
    def forward(self, x):
        return x * torch.sigmoid(x)

class TimeEmbedding(nn.Module):

    def __init__(self, n_channels: int):
        super().__init__()
        self.n_channels = n_channels
        self.lin1 = nn.Linear(self.n_channels // 4, self.n_channels)
        self.act = Swish()
        self.lin2 = nn.Linear(self.n_channels, self.n_channels)

#

    def forward(self, t: torch.Tensor):
        half_dim = self.n_channels // 8
        emb = math.log(10_000) / (half_dim - 1)
        emb = torch.exp(torch.arange(half_dim, device=t.device) * -emb)
        emb = t[:, None] * emb[None, :]
        emb = torch.cat((emb.sin(), emb.cos()), dim=1)
        print("emb shape=", emb.shape)
        emb = self.act(self.lin1(emb))
        print("emb shape2=", emb.shape)
        emb = self.lin2(emb)
        print("emb shape3=", emb.shape)
        
        return emb



class ResBlockWeightEmb(nn.Module):
    def __init__(self, in_channels=64, 
                 out_channels=64, 
                 kernel_size=3, 
                 stride=1, 
                 padding=1, 
                 bias=True, 
                 mode='CRC', 
                 negative_slope=0.2, 
                 type_init='xavier', 
                 skip_weight = None, 
                 time_channels = 64 ):
        super(ResBlockWeightEmb, self).__init__()

        self.skip_weight = skip_weight

        # # Add sinusoidal positional embeddings as extra channels
        # self.positional_embeddings = self.generate_positional_embeddings(img_size, emb_dim)


        assert in_channels == out_channels, 'Only support in_channels==out_channels.'
        # if mode[0] in ['R', 'L']:
        #     mode = mode[0].lower() + mode[1:]


        self.conv1 = conv(in_channels, out_channels, kernel_size, stride, padding, bias, mode, negative_slope, type_init=type_init)
        self.conv2 = conv(in_channels, out_channels, kernel_size, stride, padding, bias, mode, negative_slope, type_init=type_init)

        self.time_emb = nn.Linear(time_channels, out_channels)
        self.time_act = Swish()

        if self.skip_weight == 'sigmoid' or self.skip_weight == 'softplus':
            self.res_weight = nn.Parameter(torch.cuda.FloatTensor([-6.0]))
        elif self.skip_weight == 'relu':
            self.res_weight = nn.Parameter(torch.cuda.FloatTensor([1e-6]))
        else :
            self.res_weight = nn.Parameter(torch.cuda.FloatTensor([0.]))

    def forward(self, x, sigma ):
        res = self.conv1(x)
        print("res shape=", res.shape)
        print("time emb shape=", self.time_emb(self.time_act(sigma)).shape)
        res += self.time_emb(self.time_act(sigma))[:, :, None, None]

        h = self.conv2(res)

        res_weight = self.res_weight

        if self.skip_weight is None:
            return x + res_weight*h
        elif self.skip_weight == 'softplus':
            return x + F.softplus(res_weight)*h
        elif self.skip_weight == 'sigmoid':
            return x + F.sigmoid(res_weight)*h
        elif self.skip_weight == 'relu':
            return x +utils.relu_straight_through(res_weight)*h
    
        else :
            raise NotImplementedError
        
    @torch.no_grad()
    def signal_prop(self, x, sigma, dim=(0, -1, -2, -3)):
        # forward code
        residual = self.res(x)

        res_weight = self.res_weight

        if self.skip_weight is None:
            out=  x + res_weight*residual
        elif self.skip_weight == 'softplus':
            out= x + F.softplus(res_weight)*residual
        elif self.skip_weight == 'sigmoid':
            out= x + F.sigmoid(res_weight)*residual
        elif self.skip_weight == 'relu':
            out= x +utils.relu_straight_through(res_weight)*residual
        else :
            raise NotImplementedError

        # compute necessary statistics
        out_mu2 = torch.mean(out.mean(dim) ** 2).item()
        out_var = torch.mean(out.var(dim)).item()
        res_var = torch.mean(residual.var(dim)).item()

        return out, (out_mu2, out_var, res_var)


##############################################
# --------------------------------------------
# Conv Block : conv(relu(conv(x)))
# --------------------------------------------
class ConvBlock(nn.Module):
    def __init__(self, in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1, bias=True, mode='CRC', negative_slope=0.2, type_init='xavier'):
        super(ConvBlock, self).__init__()

        # if mode[0] in ['R', 'L']:
        #     mode = mode[0].lower() + mode[1:]

        self.res = conv(in_channels, out_channels, kernel_size, stride, padding, bias, mode, negative_slope, type_init=type_init)

    def forward(self, x):
        res = self.res(x)
        return res



class ResEmbBlock(nn.Module):
    def __init__(self, in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1, bias=True, mode='CRC', negative_slope=0.2, type_init='xavier'):
        super(ResEmbBlock, self).__init__()

        assert in_channels == out_channels, 'Only support in_channels==out_channels.'
        # if mode[0] in ['R', 'L']:
        #     mode = mode[0].lower() + mode[1:]

        self.res = conv(in_channels, out_channels, kernel_size, stride, padding, bias, mode, negative_slope, type_init=type_init)
        self.emb_layer = conv(in_channels, out_channels, kernel_size, stride, padding, bias, 'D', negative_slope, emb_dim=64, type_init=type_init)

    def forward(self, x, t):
        res = self.res(x)
        emb = self.emb_layer(t)[:, :, None, None].repeat(1, 1, x.shape[-2], x.shape[-1])
        return x + res + emb


# --------------------------------------------
# simplified information multi-distillation block (IMDB)
# x + conv1(concat(split(relu(conv(x)))x3))
# --------------------------------------------
class IMDBlock(nn.Module):
    """
    @inproceedings{hui2019lightweight,
      title={Lightweight Image Super-Resolution with Information Multi-distillation Network},
      author={Hui, Zheng and Gao, Xinbo and Yang, Yunchu and Wang, Xiumei},
      booktitle={Proceedings of the 27th ACM International Conference on Multimedia (ACM MM)},
      pages={2024--2032},
      year={2019}
    }
    @inproceedings{zhang2019aim,
      title={AIM 2019 Challenge on Constrained Super-Resolution: Methods and Results},
      author={Kai Zhang and Shuhang Gu and Radu Timofte and others},
      booktitle={IEEE International Conference on Computer Vision Workshops},
      year={2019}
    }
    """
    def __init__(self, in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1, bias=True, mode='CL', d_rate=0.25, negative_slope=0.05):
        super(IMDBlock, self).__init__()
        self.d_nc = int(in_channels * d_rate)
        self.r_nc = int(in_channels - self.d_nc)

        assert mode[0] == 'C', 'convolutional layer first'

        self.conv1 = conv(in_channels, in_channels, kernel_size, stride, padding, bias, mode, negative_slope)
        self.conv2 = conv(self.r_nc, in_channels, kernel_size, stride, padding, bias, mode, negative_slope)
        self.conv3 = conv(self.r_nc, in_channels, kernel_size, stride, padding, bias, mode, negative_slope)
        self.conv4 = conv(self.r_nc, self.d_nc, kernel_size, stride, padding, bias, mode[0], negative_slope)
        self.conv1x1 = conv(self.d_nc*4, out_channels, kernel_size=1, stride=1, padding=0, bias=bias, mode=mode[0], negative_slope=negative_slope)

    def forward(self, x):
        d1, r1 = torch.split(self.conv1(x), (self.d_nc, self.r_nc), dim=1)
        d2, r2 = torch.split(self.conv2(r1), (self.d_nc, self.r_nc), dim=1)
        d3, r3 = torch.split(self.conv3(r2), (self.d_nc, self.r_nc), dim=1)
        d4 = self.conv4(r3)
        res = self.conv1x1(torch.cat((d1, d2, d3, d4), dim=1))
        return x + res


# --------------------------------------------
# Enhanced Spatial Attention (ESA)
# --------------------------------------------
class ESA(nn.Module):
    def __init__(self, channel=64, reduction=4, bias=True):
        super(ESA, self).__init__()
        #               -->conv3x3(conv21)-----------------------------------------------------------------------------------------+
        # conv1x1(conv1)-->conv3x3-2(conv2)-->maxpool7-3-->conv3x3(conv3)(relu)-->conv3x3(conv4)(relu)-->conv3x3(conv5)-->bilinear--->conv1x1(conv6)-->sigmoid
        self.r_nc = channel // reduction
        self.conv1 = nn.Conv2d(channel, self.r_nc, kernel_size=1)
        self.conv21 = nn.Conv2d(self.r_nc, self.r_nc, kernel_size=1)
        self.conv2 = nn.Conv2d(self.r_nc, self.r_nc, kernel_size=3, stride=2, padding=0)
        self.conv3 = nn.Conv2d(self.r_nc, self.r_nc, kernel_size=3, padding=1)
        self.conv4 = nn.Conv2d(self.r_nc, self.r_nc, kernel_size=3, padding=1)
        self.conv5 = nn.Conv2d(self.r_nc, self.r_nc, kernel_size=3, padding=1)
        self.conv6 = nn.Conv2d(self.r_nc, channel, kernel_size=1)
        self.sigmoid = nn.Sigmoid()
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x1 = self.conv1(x)
        x2 = F.max_pool2d(self.conv2(x1), kernel_size=7, stride=3)  # 1/6
        x2 = self.relu(self.conv3(x2))
        x2 = self.relu(self.conv4(x2))
        x2 = F.interpolate(self.conv5(x2), (x.size(2), x.size(3)), mode='bilinear', align_corners=False)
        x2 = self.conv6(x2 + self.conv21(x1))
        return x.mul(self.sigmoid(x2))
        # return x.mul_(self.sigmoid(x2))


class CFRB(nn.Module):
    def __init__(self, in_channels=50, out_channels=50, kernel_size=3, stride=1, padding=1, bias=True, mode='CL', d_rate=0.5, negative_slope=0.05):
        super(CFRB, self).__init__()
        self.d_nc = int(in_channels * d_rate)
        self.r_nc = in_channels  # int(in_channels - self.d_nc)

        assert mode[0] == 'C', 'convolutional layer first'

        self.conv1_d = conv(in_channels, self.d_nc, kernel_size=1, stride=1, padding=0, bias=bias, mode=mode[0])
        self.conv1_r = conv(in_channels, self.r_nc, kernel_size, stride, padding, bias=bias, mode=mode[0])
        self.conv2_d = conv(self.r_nc, self.d_nc, kernel_size=1, stride=1, padding=0, bias=bias, mode=mode[0])
        self.conv2_r = conv(self.r_nc, self.r_nc, kernel_size, stride, padding, bias=bias, mode=mode[0])
        self.conv3_d = conv(self.r_nc, self.d_nc, kernel_size=1, stride=1, padding=0, bias=bias, mode=mode[0])
        self.conv3_r = conv(self.r_nc, self.r_nc, kernel_size, stride, padding, bias=bias, mode=mode[0])
        self.conv4_d = conv(self.r_nc, self.d_nc, kernel_size, stride, padding, bias=bias, mode=mode[0])
        self.conv1x1 = conv(self.d_nc*4, out_channels, kernel_size=1, stride=1, padding=0, bias=bias, mode=mode[0])
        self.act = conv(mode=mode[-1], negative_slope=negative_slope)
        self.esa = ESA(in_channels, reduction=4, bias=True)

    def forward(self, x):
        d1 = self.conv1_d(x)
        x = self.act(self.conv1_r(x)+x)
        d2 = self.conv2_d(x)
        x = self.act(self.conv2_r(x)+x)
        d3 = self.conv3_d(x)
        x = self.act(self.conv3_r(x)+x)
        x = self.conv4_d(x)
        x = self.act(torch.cat([d1, d2, d3, x], dim=1))
        x = self.esa(self.conv1x1(x))
        return x

          
# --------------------------------------------
# Channel Attention (CA) Layer
# --------------------------------------------
class CALayer(nn.Module):
    def __init__(self, channel=64, reduction=16, use_linear = False, type_init = 'xavier'):
        super(CALayer, self).__init__()

        self.avg_pool = nn.AdaptiveAvgPool3d((1,1,1))
   
        if use_linear:
            self.conv_fc = nn.Sequential(
                # nn.Linear(channel, channel // reduction),
                # nn.ReLU(inplace=True),
                # nn.Linear(channel // reduction, channel),
                # torch.sigmoid()
                conv(emb_dim= channel, out_channels=channel // reduction,  mode='pR',type_init=type_init),
                conv(emb_dim= channel // reduction, out_channels=channel , mode='Cz', type_init=type_init)
            )
            
        else :

            self.conv_fc = nn.Sequential(
                conv(in_channels= channel, out_channels=channel // reduction, kernel_size=3, padding=1, bias=False, mode='CR', type_init=type_init),
                conv(in_channels= channel // reduction, out_channels=channel , kernel_size=3, padding=1, bias=False, mode='Cz', type_init=type_init)
            )
                        

            # self.conv_fc = nn.Sequential(
            #     nn.Conv3d(channel, channel // reduction, 1, padding=0, bias=True),
            #     nn.ReLU(inplace=True),
            #     nn.Conv3d(channel // reduction, channel, 1, padding=0, bias=True),
            #     torch.sigmoid()
            # )

    def forward(self, x, sigma=None):
        y = self.avg_pool(x)
        y = self.conv_fc(y)
        
        return x * y

# --------------------------------------------
# Conditioned Channel Attention (CA) Layer
# --------------------------------------------
class CCALayer(nn.Module):
    def __init__(self, channel=64, reduction=16, use_linear = False, type_init = 'xavier'):
        super(CCALayer, self).__init__()

        self.avg_pool = nn.AdaptiveAvgPool3d((1,1,1))
  
        if use_linear:
            self.conv_fc = nn.Sequential(
                conv(emb_dim= channel+1, out_channels=channel // reduction,  mode='pR', type_init = type_init),
                conv(emb_dim= channel // reduction, out_channels=channel, mode='Cz', type_init = type_init)
                # nn.Linear(channel, channel // reduction),
                # nn.ReLU(inplace=True),
                # nn.Linear(channel // reduction, channel-1),
                # torch.sigmoid()
            )
        else :
            self.conv_fc = nn.Sequential(
                conv(in_channels= channel+1, out_channels=channel // reduction, kernel_size=1, padding=0, bias=False, mode='CR', type_init = type_init),
                #nn.Conv3d(channel, channel // reduction, 1, padding=0, bias=True),
                #nn.ReLU(inplace=True),
                conv(in_channels= channel // reduction, out_channels=channel, kernel_size=1, padding=0, bias=False, mode='Cz', type_init = type_init)
                #nn.Conv3d(channel // reduction, channel-1, 1, padding=0, bias=True),
                #torch.sigmoid()
            )

    def forward(self, x, sigma=None):

       
        y = self.avg_pool(x)


        y = torch.cat((y, sigma.view(-1,1,1,1,1).expand(-1,-1,y.size(2),y.size(3),y.size(4))), 1)
        

        y = self.conv_fc(y)

        return x * y
    


# --------------------------------------------
# Conditioned Channel Attention (CA) Layer
# --------------------------------------------
class CCALayer2(nn.Module):
    def __init__(self, channel=64, reduction=8, use_linear = False, type_init = 'xavier'):
        super(CCALayer2, self).__init__()

        self.init = nn.Identity() # conv(in_channels= channel+1, out_channels=channel, kernel_size=3, padding=0, bias=False, mode='C', type_init = type_init)

        self.avg_pool = nn.AdaptiveAvgPool3d((1,1,1))

        self.channel = channel
  
        if use_linear:
            self.conv_fc = nn.Sequential(
                conv(emb_dim= channel+1, out_channels=channel // reduction,  mode='pR', type_init = type_init),
                # nn.Linear(channel, channel // reduction),
                # nn.ReLU(inplace=True),
                # nn.Linear(channel // reduction, channel-1),
                # torch.sigmoid()
            )
        else :
            self.conv_fc = nn.Sequential(
                conv(in_channels= channel+1, out_channels=channel // reduction, kernel_size=1, padding=0, bias=False, mode='CR', type_init = type_init),
                #nn.Conv3d(channel, channel // reduction, 1, padding=0, bias=True),
                #nn.ReLU(inplace=True),
                # conv(in_channels= channel // reduction, out_channels=channel-1, kernel_size=1, padding=0, bias=False, mode='Cz', type_init = type_init)
                #nn.Conv3d(channel // reduction, channel-1, 1, padding=0, bias=True),
                # torch.sigmoid()
            )

        self.conv_fc2 = nn.Sequential(
            # conv(in_channels= channel // reduction, out_channels=channel-1, kernel_size=1, padding=0, bias=False, mode='Cz', type_init = type_init)
            conv(emb_dim= channel // reduction, out_channels=channel, mode='pz', type_init = type_init)

        )

    def forward(self, x, sigma=None):

       
        y = self.avg_pool(self.init(x))

        t = 2.39*sigma-torch.full(sigma.shape, 1.4, device="cuda") #test4
        sigma = torch.arctanh(t) + 2*torch.full(sigma.shape, 1.0, device="cuda")

        y = torch.cat((y, sigma.view(-1,1,1,1,1).expand(-1,-1,y.size(2),y.size(3),y.size(4))), 1).squeeze(dim=-1).squeeze(dim=-1).squeeze(dim=-1)
        
        y = self.conv_fc(y)

        # print( "weight", self.conv_fc2(y))


        # print("sigma", sigma.detach().squeeze().cpu().numpy(), "weight", self.conv_fc2(y).detach().squeeze().cpu().numpy())

        y = self.conv_fc2(y).view(-1, self.channel, 1, 1, 1)

        return x * y

class NoiseEstimator(nn.Module):
    def __init__(self) :
        super(NoiseEstimator, self).__init__()
        self.conv1 = nn.Sequential( 
            conv(in_channels= 1, out_channels=32, kernel_size=3, padding=1, bias=False, mode='C', type_init = 'xavier'),
                                   )
        self.conv26 = nn.Sequential(
            # conv(in_channels= 32, out_channels=32, kernel_size=3, padding=1, bias=False, mode='RCiRCiRCiRCiRCiR', type_init = 'xavier'),
            conv(in_channels= 32, out_channels=32, kernel_size=3, padding=1, bias=False, mode='ECECECECECE', type_init = 'xavier'),
        )
        self.conv7 = nn.Sequential( 
            conv(in_channels= 32, out_channels=1, kernel_size=3, padding=1, bias=False, mode='C', type_init = 'xavier'),
                                   )

    def forward(self, x):
        # x = self.conv1(0.0001*x) #0.0001* gard + grand
        x = self.conv1(x) 
        x = self.conv26(x)
        x = self.conv7(x)
        # x = torch.tanh(self.conv7(x))
        return x

class CCALayer3(nn.Module):
    def __init__(self, channel=64, other_channel = 64, reduction=8, use_linear = False, type_init = 'xavier'):
        super(CCALayer3, self).__init__()


        # self.avg_pool = nn.AdaptiveAvgPool3d((26,32,32))
        self.avg_pool = nn.MaxPool3d(4)
        self.init = nn.InstanceNorm3d(channel, affine=True)
        # self.res_weight = nn.Parameter(torch.cuda.FloatTensor([0.]))

        self.channel = channel
        self.other_channel = other_channel
  
        if use_linear:
            self.conv_fc = nn.Sequential(
                conv(emb_dim= 32*32*26 , out_channels=32*32*26 // reduction,  mode='p', type_init = 'zero'),
                # nn.InstanceNorm1d(32*32*26 // reduction , affine=False),
                # conv(emb_dim= 32*32*26 // reduction, out_channels=32*32*26 // reduction,  mode='E', type_init = type_init),
            )
            self.conv_fc2 = nn.Sequential(
                # conv(emb_dim= 32*32*26 // reduction, out_channels=1, mode='pz', type_init = type_init)
                # nn.InstanceNorm1d(32*32*26 // reduction, affine=True),
                conv(emb_dim= 32*32*26 // reduction, out_channels=1, mode='p', type_init = 'zero')

            )
            #  self.conv_fc = nn.Sequential(
            #     conv(emb_dim= 32*32*26 , out_channels=1,  mode='p', type_init = type_init),
            # )
            #  self.conv_fc2 = nn.Identity()
        else :
            self.conv_fc = nn.Sequential(
                conv(in_channels= other_channel, out_channels=channel // reduction, kernel_size=3, padding=1, bias=False, mode='CE', type_init = type_init),
     
            )

            self.conv_fc2 = nn.Sequential(
            #
                conv(in_channels= channel // reduction, out_channels=1, kernel_size=3, padding=1, bias=False, mode='Cz', type_init = type_init)

            )

    def forward(self, x, sigma=None):

        
        # x = x/3000
        # print("step0: ymin=", x.shape)
        y = self.init(x)
        print("step1: ymin=", y.min(), "ymax=", y.max())
        y = self.avg_pool(y)  
        print("step2: ymin=", y.min(), "ymax=", y.max())     
        
        y = y.view(x.shape[0], -1)
        # y = torch.cat((y, (1.0/sigma).view(-1,1)), 1)
        y = self.conv_fc(y)
        # y = torch.tanh(y)
        print("step3: ymin=", y.min(), "ymax=", y.max())
        y = torch.tanh(self.conv_fc2(y).view(-1, self.channel, 1, 1, 1)) + torch.ones(x.shape[0], self.channel, 1, 1, 1).cuda()
        #self.res_weight*
        print("poids=", y.squeeze().detach().cpu().numpy())

        return y


#################################################################

class CCALayer4(nn.Module):
    def __init__(self, channel=64, kernel_size = 3, type_init = 'xavier'):
        super(CCALayer4, self).__init__()


        # self.avg_pool = nn.AdaptiveAvgPool3d((26,32,32))
        self.avg_pool = nn.MaxPool3d(2)
        # self.init = nn.InstanceNorm3d(channel, affine=True)
        # self.res_weight = nn.Parameter(torch.cuda.FloatTensor([0.]))

     
        self.conv1 = nn.Sequential(
            conv(in_channels= 1, out_channels=channel, kernel_size=kernel_size, padding=kernel_size//2, bias=False, mode='CEi', type_init = type_init),
        )

        self.conv2 = nn.Sequential(
            conv(in_channels= channel, out_channels=channel, kernel_size=kernel_size, padding=kernel_size//2, bias=False, mode='CEi', type_init = type_init),
        )

        self.conv3 = nn.Sequential(
            conv(in_channels= channel, out_channels=1, kernel_size=kernel_size, padding=kernel_size//2, bias=False, mode='CEi', type_init = type_init),
        )

        self.conv4 = nn.Sequential(
                conv(emb_dim= 16*16*13 , out_channels=1,  mode='p', type_init = 'zero'),
            )

        # self.conv_fc2 = nn.Sequential(
        # #
        #     conv(in_channels= channel // reduction, out_channels=1, kernel_size=3, padding=1, bias=False, mode='Cz', type_init = type_init)

        # )

    def forward(self, x, sigma=None):

        y = self.conv1(x)
        y = self.avg_pool(y)
        y = self.conv2(y)
        y = self.avg_pool(y)
        y = self.conv3(y)
        # print("(0)y.shape=", y.shape)
        y = self.avg_pool(y)
        # print("y.shape=", y.shape)
        y = y.view(x.shape[0], -1)
        # print("y.shape=", y.shape)
        y = self.conv4(y)
        # # y = torch.cat((y, (1.0/sigma).view(-1,1)), 1)
        # print("y.shape=", y.shape)
        # y = self.conv_fc(y)
        # # y = torch.tanh(y)
        # print("step3: ymin=", y.min(), "ymax=", y.max())
        y = 0.001*y.view(-1, 1, 1, 1, 1) + torch.ones(x.shape[0], 1, 1, 1, 1).cuda()
        #self.res_weight*
        # print("poids=", y.squeeze().detach().cpu().numpy())

        return y
# --------------------------------------------
# Residual Channel Attention Block (RCAB)
# --------------------------------------------
class RCABlock(nn.Module):
    def __init__(self, in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1, bias=True, mode='CRC', reduction=16, negative_slope=0.2, 
                 conditioned=False, use_linear = False, type_init='xavier', skip_weight = None):
        super(RCABlock, self).__init__()
        assert in_channels == out_channels, 'Only support in_channels==out_channels.'
        if mode[0] in ['R','L']:
            mode = mode[0].lower() + mode[1:]

        self.skip_weight = skip_weight

        self.res = conv(in_channels, out_channels, kernel_size, stride, padding, bias, mode, negative_slope, type_init=type_init)
        if conditioned:
            self.ca = CCALayer(out_channels, reduction, use_linear = use_linear, type_init=type_init)
        else:
            self.ca = CALayer(out_channels, reduction, use_linear = use_linear, type_init=type_init)

        if self.skip_weight == 'sigmoid' or self.skip_weight == 'softplus':
            self.res_weight = nn.Parameter(torch.cuda.FloatTensor([-6.0]))
        else :
            self.res_weight = nn.Parameter(torch.cuda.FloatTensor([0.]))

    def forward(self, x, sigma):
        
        res = self.res(x)
        res = self.ca(res, sigma)
        if self.skip_weight is None:
            return self.res_weight*res + x
        elif self.skip_weight == 'sigmoid':
            return F.sigmoid(self.res_weight)*res + x
        elif self.skip_weight == 'softplus':
            return F.softplus(self.res_weight)*res + x
        else :
            raise NotImplementedError('Not implemented skip weight type')
        
    @torch.no_grad()
    def signal_prop(self, x, sigma, dim=(0, -1, -2, -3)):
        # forward code
        residual = self.res(x)
        residual = self.ca(residual, sigma)
        out = residual + x
        if self.skip_weight is None:
            out=  x + self.res_weight*residual
        elif self.skip_weight == 'softplus':
            out= x + F.softplus(self.res_weight)*residual
        elif self.skip_weight == 'sigmoid':
            out= x + F.sigmoid(self.res_weight)*residual
        else :
            raise NotImplementedError

        # compute necessary statistics
        out_mu2 = torch.mean(out.mean(dim) ** 2).item()
        out_var = torch.mean(out.var(dim)).item()
        res_var = torch.mean(residual.var(dim)).item()

        return out, (out_mu2, out_var, res_var)



# --------------------------------------------
# Residual Channel Attention Group (RG)
# --------------------------------------------
class RCAGroup(nn.Module):
    def __init__(self, in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1, bias=True, mode='CRC', reduction=16, nb=12, negative_slope=0.2):
        super(RCAGroup, self).__init__()
        assert in_channels == out_channels, 'Only support in_channels==out_channels.'
        if mode[0] in ['R','L']:
            mode = mode[0].lower() + mode[1:]

        RG = [RCABlock(in_channels, out_channels, kernel_size, stride, padding, bias, mode, reduction, negative_slope)  for _ in range(nb)]
        RG.append(conv(out_channels, out_channels, mode='C'))
        self.rg = nn.Sequential(*RG)  # self.rg = ShortcutBlock(nn.Sequential(*RG))

    def forward(self, x):
        res = self.rg(x)
        return res + x


# --------------------------------------------
# Residual Dense Block
# style: 5 convs
# --------------------------------------------
class ResidualDenseBlock_5C(nn.Module):
    def __init__(self, nc=64, gc=32, kernel_size=3, stride=1, padding=1, bias=True, mode='CR', negative_slope=0.2):
        super(ResidualDenseBlock_5C, self).__init__()
        # gc: growth channel
        self.conv1 = conv(nc, gc, kernel_size, stride, padding, bias, mode, negative_slope)
        self.conv2 = conv(nc+gc, gc, kernel_size, stride, padding, bias, mode, negative_slope)
        self.conv3 = conv(nc+2*gc, gc, kernel_size, stride, padding, bias, mode, negative_slope)
        self.conv4 = conv(nc+3*gc, gc, kernel_size, stride, padding, bias, mode, negative_slope)
        self.conv5 = conv(nc+4*gc, nc, kernel_size, stride, padding, bias, mode[:-1], negative_slope)

    def forward(self, x):
        x1 = self.conv1(x)
        x2 = self.conv2(torch.cat((x, x1), 1))
        x3 = self.conv3(torch.cat((x, x1, x2), 1))
        x4 = self.conv4(torch.cat((x, x1, x2, x3), 1))
        x5 = self.conv5(torch.cat((x, x1, x2, x3, x4), 1))
        return x5.mul_(0.2) + x


# --------------------------------------------
# Residual in Residual Dense Block
# 3x5c
# --------------------------------------------
class RRDB(nn.Module):
    def __init__(self, nc=64, gc=32, kernel_size=3, stride=1, padding=1, bias=True, mode='CR', negative_slope=0.2):
        super(RRDB, self).__init__()

        self.RDB1 = ResidualDenseBlock_5C(nc, gc, kernel_size, stride, padding, bias, mode, negative_slope)
        self.RDB2 = ResidualDenseBlock_5C(nc, gc, kernel_size, stride, padding, bias, mode, negative_slope)
        self.RDB3 = ResidualDenseBlock_5C(nc, gc, kernel_size, stride, padding, bias, mode, negative_slope)

    def forward(self, x):
        out = self.RDB1(x)
        out = self.RDB2(out)
        out = self.RDB3(out)
        return out.mul_(0.2) + x


"""
# --------------------------------------------
# Upsampler
# Kai Zhang, https://github.com/cszn/KAIR
# --------------------------------------------
# upsample_pixelshuffle
# upsample_upconv
# upsample_convtranspose
# --------------------------------------------
"""


# --------------------------------------------
# conv + subp (+ relu)
# --------------------------------------------
def upsample_pixelshuffle(in_channels=64, out_channels=3, kernel_size=3, stride=1, padding=1, bias=True, mode='2R', negative_slope=0.2, type_init='xavier'):
    assert len(mode)<4 and mode[0] in ['2', '3', '4'], 'mode examples: 2, 2R, 2BR, 3, ..., 4BR.'
    up1 = conv(in_channels, out_channels * (int(mode[0]) ** 2), kernel_size, stride, padding, bias, mode='C'+mode, negative_slope=negative_slope, type_init=type_init)
    return up1


# --------------------------------------------
# nearest_upsample + conv (+ R)
# --------------------------------------------
def upsample_upconv(in_channels=64, out_channels=3, kernel_size=3, stride=1, padding=1, bias=True, mode='2R', negative_slope=0.2, type_init='xavier'):
    assert len(mode)<4 and mode[0] in ['2', '3', '4'], 'mode examples: 2, 2R, 2BR, 3, ..., 4BR'
    if mode[0] == '2':
        uc = 'UC'
    elif mode[0] == '3':
        uc = 'uC'
    elif mode[0] == '4':
        uc = 'vC'
    mode = mode.replace(mode[0], uc)
    up1 = conv(in_channels, out_channels, kernel_size, stride, padding, bias, mode=mode, negative_slope=negative_slope, type_init=type_init)
    return up1


# --------------------------------------------
# convTranspose (+ relu)
# --------------------------------------------
def upsample_convtranspose(in_channels=64, out_channels=3, kernel_size=2, stride=2, padding=0, bias=True, mode='2R', negative_slope=0.2, type_init='xavier'):
    assert len(mode)<4 and mode[0] in ['2', '3', '4'], 'mode examples: 2, 2R, 2BR, 3, ..., 4BR.'
    kernel_size = int(mode[0])
    stride = int(mode[0])
    mode = mode.replace(mode[0], 'T')
    up1 = conv(in_channels, out_channels, kernel_size, stride, padding, bias, mode, negative_slope, type_init=type_init)
    return up1


'''
# --------------------------------------------
# Downsampler
# Kai Zhang, https://github.com/cszn/KAIR
# --------------------------------------------
# downsample_strideconv
# downsample_maxpool
# downsample_avgpool
# --------------------------------------------
'''


# --------------------------------------------
# strideconv (+ relu)
# --------------------------------------------
def downsample_strideconv(in_channels=64, out_channels=64, kernel_size=2, stride=2, padding=0, bias=True, mode='2R', negative_slope=0.2, type_init='xavier'):
    assert len(mode)<4 and mode[0] in ['2', '3', '4'], 'mode examples: 2, 2R, 2BR, 3, ..., 4BR.'
    kernel_size = int(mode[0])
    stride = int(mode[0])
    mode = mode.replace(mode[0], 'C')
    down1 = conv(in_channels, out_channels, kernel_size, stride, padding, bias, mode, negative_slope, type_init=type_init)
    return down1


# --------------------------------------------
# maxpooling + conv (+ relu)
# --------------------------------------------
def downsample_maxpool(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1, bias=True, mode='2R', negative_slope=0.2, type_init='xavier'):
    assert len(mode)<4 and mode[0] in ['2', '3'], 'mode examples: 2, 2R, 2BR, 3, ..., 3BR.'
    kernel_size_pool = int(mode[0])
    stride_pool = int(mode[0])
    mode = mode.replace(mode[0], 'MC')
    pool = conv(kernel_size=kernel_size_pool, stride=stride_pool, mode=mode[0], negative_slope=negative_slope, type_init=type_init)
    pool_tail = conv(in_channels, out_channels, kernel_size, stride, padding, bias, mode=mode[1:], negative_slope=negative_slope, type_init=type_init)
    return sequential(pool, pool_tail)


# --------------------------------------------
# averagepooling + conv (+ relu)
# --------------------------------------------
def downsample_avgpool(in_channels=64, out_channels=64, kernel_size=3, stride=1, padding=1, bias=True, mode='2R', negative_slope=0.2, type_init='xavier'):
    assert len(mode)<4 and mode[0] in ['2', '3'], 'mode examples: 2, 2R, 2BR, 3, ..., 3BR.'
    kernel_size_pool = int(mode[0])
    stride_pool = int(mode[0])
    mode = mode.replace(mode[0], 'AC')
    pool = conv(kernel_size=kernel_size_pool, stride=stride_pool, mode=mode[0], negative_slope=negative_slope, type_init=type_init)
    pool_tail = conv(in_channels, out_channels, kernel_size, stride, padding, bias, mode=mode[1:], negative_slope=negative_slope, type_init=type_init)
    return sequential(pool, pool_tail)


'''
# --------------------------------------------
# NonLocalBlock2D:
# embedded_gaussian
# +W(softmax(thetaXphi)Xg)
# --------------------------------------------
'''


# --------------------------------------------
# non-local block with embedded_gaussian
# https://github.com/AlexHex7/Non-local_pytorch
# --------------------------------------------
class NonLocalBlock2D(nn.Module):
    def __init__(self, nc=64, kernel_size=1, stride=1, padding=0, bias=True, act_mode='B', downsample=False, downsample_mode='maxpool', negative_slope=0.2):

        super(NonLocalBlock2D, self).__init__()

        inter_nc = nc // 2
        self.inter_nc = inter_nc
        self.W = conv(inter_nc, nc, kernel_size, stride, padding, bias, mode='C'+act_mode)
        self.theta = conv(nc, inter_nc, kernel_size, stride, padding, bias, mode='C')

        if downsample:
            if downsample_mode == 'avgpool':
                downsample_block = downsample_avgpool
            elif downsample_mode == 'maxpool':
                downsample_block = downsample_maxpool
            elif downsample_mode == 'strideconv':
                downsample_block = downsample_strideconv
            else:
                raise NotImplementedError('downsample mode [{:s}] is not found'.format(downsample_mode))
            self.phi = downsample_block(nc, inter_nc, kernel_size, stride, padding, bias, mode='2')
            self.g = downsample_block(nc, inter_nc, kernel_size, stride, padding, bias, mode='2')
        else:
            self.phi = conv(nc, inter_nc, kernel_size, stride, padding, bias, mode='C')
            self.g = conv(nc, inter_nc, kernel_size, stride, padding, bias, mode='C')

    def forward(self, x):
        '''
        :param x: (b, c, t, h, w)
        :return:
        '''

        batch_size = x.size(0)

        g_x = self.g(x).view(batch_size, self.inter_nc, -1)
        g_x = g_x.permute(0, 2, 1)

        theta_x = self.theta(x).view(batch_size, self.inter_nc, -1)
        theta_x = theta_x.permute(0, 2, 1)
        phi_x = self.phi(x).view(batch_size, self.inter_nc, -1)
        f = torch.matmul(theta_x, phi_x)
        f_div_C = F.softmax(f, dim=-1)

        y = torch.matmul(f_div_C, g_x)
        y = y.permute(0, 2, 1).contiguous()
        y = y.view(batch_size, self.inter_nc, *x.size()[2:])
        W_y = self.W(y)
        z = W_y + x

        return 
    

# --------------------------------------------
def constant_init(module, val, bias=0):
    if hasattr(module, 'weight') and module.weight is not None:
        nn.init.constant_(module.weight, val)
    if hasattr(module, 'bias') and module.bias is not None:
        nn.init.constant_(module.bias, bias)

def identity_init(module, bias=0):
    if hasattr(module, 'weight') and module.weight is not None:
        nn.init.dirac_(module.weight)
    if hasattr(module, 'bias') and module.bias is not None:
        nn.init.constant_(module.bias, bias)


def kaiming_init(module,
                 a=0,
                 mode='fan_out',
                 nonlinearity='relu',
                 bias=0,
                 distribution='normal'):
    assert distribution in ['uniform', 'normal']
    if distribution == 'uniform':
        nn.init.kaiming_uniform_(
            module.weight, a=a, mode=mode, nonlinearity=nonlinearity)
    else:
        nn.init.kaiming_normal_(
            module.weight, a=a, mode=mode, nonlinearity=nonlinearity)
    if hasattr(module, 'bias') and module.bias is not None:
        nn.init.constant_(module.bias, bias)

class PSA_p(nn.Module):
    def __init__(self, inplanes, planes, kernel_size=1, stride=1):
        super(PSA_p, self).__init__()

        self.inplanes = inplanes
        self.rescale = nn.InstanceNorm3d(inplanes, affine=False)
        self.inter_planes = planes // 2
        self.planes = planes
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = (kernel_size-1)//2

        self.conv_q_right = nn.Conv3d(self.inplanes, 1, kernel_size=1, stride=stride, padding=0, bias=False)
        self.conv_v_right = nn.Conv3d(self.inplanes, self.inter_planes, kernel_size=1, stride=stride, padding=0, bias=False)
        self.conv_up = nn.Conv3d(self.inter_planes, self.planes, kernel_size=1, stride=1, padding=0, bias=False)
        self.softmax_right = nn.Softmax(dim=2)
        self.sigmoid = nn.Sigmoid()

        self.conv_q_left = nn.Conv3d(self.inplanes, self.inter_planes, kernel_size=1, stride=stride, padding=0, bias=False)   #g
        self.avg_pool = nn.AdaptiveAvgPool3d(1)
        self.conv_v_left = nn.Conv3d(self.inplanes, self.inter_planes, kernel_size=1, stride=stride, padding=0, bias=False)   #theta
        self.softmax_left = nn.Softmax(dim=2)

        self.reset_parameters()

    def reset_parameters(self):
        kaiming_init(self.conv_q_right, mode='fan_in')
        kaiming_init(self.conv_v_right, mode='fan_in')
        kaiming_init(self.conv_q_left, mode='fan_in')
        kaiming_init(self.conv_v_left, mode='fan_in')

        self.conv_q_right.inited = True
        self.conv_v_right.inited = True
        self.conv_q_left.inited = True
        self.conv_v_left.inited = True

    def spatial_pool(self, x):
        
        input_x = self.conv_v_right(x)

        batch, channel, depth, height, width = input_x.size()

        # [N, IC, H*W*D]
        input_x = input_x.view(batch, channel, height * width* depth)

        # [N, 1, D, H, W]
        context_mask = self.conv_q_right(x)

        # [N, 1, H*W*D]
        context_mask = context_mask.view(batch, 1, height * width*depth)

        # [N, 1, H*W*D]
        context_mask = self.softmax_right(context_mask)

        # [N, IC, 1]
        # context = torch.einsum('ndw,new->nde', input_x, context_mask)
        context = torch.matmul(input_x, context_mask.transpose(1,2))
        # [N, IC, 1, 1, 1]
        context = context.unsqueeze(-1).unsqueeze(-1)

        # [N, OC, 1, 1, 1]
        context = self.conv_up(context)

        # [N, OC, 1, 1, 1]
        mask_ch = self.sigmoid(context)

        out = x * mask_ch

        return out

    def channel_pool(self, x):
        # [N, IC, D, H, W]
        g_x = self.conv_q_left(x)

        batch, channel, depth, height, width = g_x.size()

        # [N, IC, 1, 1, 1]
        avg_x = self.avg_pool(g_x)

        batch, channel, avg_x_d, avg_x_h, avg_x_w = avg_x.size()

        # [N, 1, IC]
        avg_x = avg_x.view(batch, channel, avg_x_d* avg_x_h * avg_x_w).permute(0, 2, 1)

        # [N, IC, H*W*D]
        theta_x = self.conv_v_left(x).view(batch, self.inter_planes, height * width* depth)

        # [N, 1, H*W]
        # context = torch.einsum('nde,new->ndw', avg_x, theta_x)
        context = torch.matmul(avg_x, theta_x)
        # [N, 1, H*W]
        context = self.softmax_left(context)

        # [N, 1, H, W]
        context = context.view(batch, 1, depth, height, width)

        # [N, 1, H, W]
        mask_sp = self.sigmoid(context)

        out = x * mask_sp

        return out

    def forward(self, x):
        x = self.rescale(x)
        # [N, C, H, W]
        context_channel = self.channel_pool(x)
        # [N, C, H, W]
        context_spatial = self.spatial_pool(x)
        # [N, C, H, W]
        out = context_spatial + context_channel
        return out, [context_spatial, context_channel]

class PSA_s(nn.Module):
    def __init__(self, inplanes, planes, kernel_size=1, stride=1):
        super(PSA_s, self).__init__()

        self.inplanes = inplanes
        self.inter_planes = planes // 2
        self.planes = planes
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = (kernel_size - 1) // 2
        ratio = 4
        # self.rescale = nn.InstanceNorm3d(inplanes, affine=False)

        self.conv_q_right = nn.Conv3d(self.inplanes, 1, kernel_size=1, stride=stride, padding=0, bias=False)
        self.conv_v_right = nn.Conv3d(self.inplanes, self.inter_planes, kernel_size=1, stride=stride, padding=0,
                                      bias=False)
        # self.conv_up = nn.Conv2d(self.inter_planes, self.planes, kernel_size=1, stride=1, padding=0, bias=False)
        self.conv_up = nn.Sequential(
            nn.Conv3d(self.inter_planes, self.inter_planes // ratio, kernel_size=1),
            nn.LayerNorm([self.inter_planes // ratio, 1, 1, 1]),
            nn.ReLU(inplace=True),
            nn.Conv3d(self.inter_planes // ratio, self.planes, kernel_size=1)
        )
        self.softmax_right = nn.Softmax(dim=2)
        self.sigmoid = nn.Sigmoid()

        self.conv_q_left = nn.Conv3d(self.inplanes, self.inter_planes, kernel_size=1, stride=stride, padding=0,
                                     bias=False)  # g
        self.avg_pool = nn.AdaptiveAvgPool3d(1)
        self.conv_v_left = nn.Conv3d(self.inplanes, self.inter_planes, kernel_size=1, stride=stride, padding=0,
                                     bias=False)  # theta
        self.softmax_left = nn.Softmax(dim=2)

        self.reset_parameters()

    def reset_parameters(self):
        kaiming_init(self.conv_q_right, mode='fan_in')
        kaiming_init(self.conv_v_right, mode='fan_in')
        kaiming_init(self.conv_q_left, mode='fan_in')
        kaiming_init(self.conv_v_left, mode='fan_in')

        self.conv_q_right.inited = True
        self.conv_v_right.inited = True
        self.conv_q_left.inited = True
        self.conv_v_left.inited = True

    def spatial_pool(self, x):
        input_x = self.conv_v_right(x)

        batch, channel, depth, height, width = input_x.size()

        # [N, IC, D*H*W]
        input_x = input_x.view(batch, channel, depth * height * width)

        # [N, 1, D, H, W]
        context_mask = self.conv_q_right(x)

        # [N, 1, D*H*W]
        context_mask = context_mask.view(batch, 1, depth * height * width)

        # [N, 1, D*H*W]
        context_mask = self.softmax_right(context_mask)

        # [N, IC, 1]
        # context = torch.einsum('ndw,new->nde', input_x, context_mask)
        context = torch.matmul(input_x, context_mask.transpose(1, 2))

        # [N, IC, 1, 1, 1]
        context = context.unsqueeze(-1).unsqueeze(-1)

        # [N, OC, 1, 1, 1]
        context = self.conv_up(context)

        # [N, OC, 1, 1, 1]
        mask_ch = self.sigmoid(context)

        out = x * mask_ch

        return out

    def channel_pool(self, x):
        # [N, IC, D, H, W]
        g_x = self.conv_q_left(x)

        batch, channel, depth, height, width = g_x.size()

        # [N, IC, 1, 1, 1]
        avg_x = self.avg_pool(g_x)

        batch, channel, avg_x_d, avg_x_h, avg_x_w = avg_x.size()

        # [N, 1, IC]
        avg_x = avg_x.view(batch, channel, avg_x_d * avg_x_h * avg_x_w).permute(0, 2, 1)

        # [N, IC, D*H*W]
        theta_x = self.conv_v_left(x).view(batch, self.inter_planes, depth * height * width)

        # [N, IC, D*H*W]
        theta_x = self.softmax_left(theta_x)

        # [N, 1, D*H*W]
        # context = torch.einsum('nde,new->ndw', avg_x, theta_x)
        context = torch.matmul(avg_x, theta_x)

        # [N, 1, D, H, W]
        context = context.view(batch, 1, depth, height, width)

        # [N, 1, D, H, W]
        mask_sp = self.sigmoid(context)

        out = x * mask_sp

        return out

    def forward(self, x):
        # x = self.rescale(x)
        # [N, C, H, W]
        context_spatial = self.spatial_pool(x)

        # [N, C, H, W]
        context_channel = self.channel_pool(context_spatial)

        # [N, C, H, W]
        # out = context_spatial + context_channel

        return context_channel, [context_spatial, context_channel]
    

class PSA_i(nn.Module):
    def __init__(self, inplanes, kernel_size=1, stride=1):
        super(PSA_i, self).__init__()

        self.init = nn.InstanceNorm3d(1, affine=False)
        self.pre_act = nn.InstanceNorm3d(1, affine=False)

        self.inplanes = inplanes
        self.inter_planes = 16
        # self.planes = planes
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = (kernel_size - 1) // 2


        self.conv_q_left = nn.Conv3d(self.inplanes, self.inter_planes, kernel_size=1, stride=stride, padding=0,
                                     bias=False)  # g
        self.avg_pool = nn.AdaptiveAvgPool3d(1)
        self.conv_v_left = nn.Conv3d(self.inplanes, self.inter_planes, kernel_size=1, stride=stride, padding=0,
                                     bias=False)  # theta
        # self.softmax_left = nn.Softmax(dim=2)
        self.softmax_left = nn.Sigmoid()
        self.reset_parameters()

    def reset_parameters(self):
        kaiming_init(self.conv_q_left, mode='fan_in')
        kaiming_init(self.conv_v_left, mode='fan_in')

        # identity_init(self.conv_q_left)
        # identity_init(self.conv_v_left)

        # constant_init(self.conv_q_left, 0)
        # constant_init(self.conv_v_left, 0)

        self.conv_q_left.inited = True
        self.conv_v_left.inited = True


    def channel_pool(self, x):
        xinit = x
        x = self.init(x)
        # [N, IC, D, H, W]
        g_x = self.conv_q_left(x)

        batch, channel, depth, height, width = g_x.size()

        # [N, IC, 1, 1, 1]
        avg_x = self.avg_pool(g_x)

        batch, channel, avg_x_d, avg_x_h, avg_x_w = avg_x.size()

        # [N, 1, IC]
        avg_x = avg_x.view(batch, channel, avg_x_d * avg_x_h * avg_x_w).permute(0, 2, 1)

        # [N, IC, D*H*W]
        theta_x = self.conv_v_left(x).view(batch, self.inter_planes, depth * height * width)

        # [N, IC, D*H*W]
        theta_x = self.softmax_left(theta_x)

        # [N, 1, D*H*W]
        # context = torch.einsum('nde,new->ndw', avg_x, theta_x)
        context = torch.matmul(avg_x, theta_x)

        # [N, 1, D, H, W]
        context = context.view(batch, 1, depth, height, width)

        context = self.pre_act(context)
        # [N, 1, D, H, W]
        # mask_sp = utils.binarize_straight_through(context)
        mask_sp = torch.sigmoid(context)

        # print("context min max", context.min(), context.max())
        # print("avg_x min max", avg_x.min(), avg_x.max())
        # print("theta_x min max", theta_x.min(), theta_x.max())
        # print("mask_sp min max", mask_sp.min(), mask_sp.max())
        # print("sum mask_sp==1", (mask_sp==1).sum())
        # print("sum mask_sp==0", (mask_sp==0).sum())

        out =  xinit * mask_sp #+ xinit
        
        # out =  xinit *( torch.ones_like(mask_sp) - mask_sp )

        # return out, torch.ones_like(mask_sp) - mask_sp
        return out, mask_sp

    def forward(self, x):
        # [N, C, H, W]

        # [N, C, H, W]
        context_channel, mask = self.channel_pool(x)

        # [N, C, H, W]
        # out = context_spatial + context_channel

        return context_channel, mask
    

class PSA_o(nn.Module):
    def __init__(self, inplanes, planes, kernel_size=1, stride=1):
        super(PSA_o, self).__init__()

        self.inplanes = inplanes
        self.inter_planes = planes // 2
        self.planes = planes
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = (kernel_size - 1) // 2

        self.conv_q_left = nn.Conv3d(self.inplanes, self.inter_planes, kernel_size=1, stride=stride, padding=0,
                                     bias=False)  # g
        self.avg_pool = nn.AdaptiveAvgPool3d(1)
        self.conv_v_left = nn.Conv3d(self.inplanes, self.inter_planes, kernel_size=1, stride=stride, padding=0,
                                     bias=False)  # theta
        self.softmax_left = nn.Softmax(dim=2)
        # self.sigmoid = nn.Sigmoid()

        self.reset_parameters()

    def reset_parameters(self):
        kaiming_init(self.conv_q_left, mode='fan_in')
        kaiming_init(self.conv_v_left, mode='fan_in')

        self.conv_q_left.inited = True
        self.conv_v_left.inited = True


    def channel_pool(self, x):
        # [N, IC, D, H, W]
        g_x = self.conv_q_left(x)

        batch, channel, depth, height, width = g_x.size()

        # [N, IC, 1, 1, 1]
        avg_x = self.avg_pool(g_x)

        batch, channel, avg_x_d, avg_x_h, avg_x_w = avg_x.size()

        # [N, 1, IC]
        avg_x = avg_x.view(batch, channel, avg_x_d * avg_x_h * avg_x_w).permute(0, 2, 1)

        # [N, IC, D*H*W]
        theta_x = self.conv_v_left(x).view(batch, self.inter_planes, depth * height * width)

        # [N, IC, D*H*W]
        theta_x = self.softmax_left(theta_x)

        # [N, 1, D*H*W]
        # context = torch.einsum('nde,new->ndw', avg_x, theta_x)
        context = torch.matmul(avg_x, theta_x)

        # [N, 1, D, H, W]
        context = context.view(batch, 1, depth, height, width)

        # [N, 1, D, H, W]
        # mask_sp = self.sigmoid(context)
        mask_sp = utils.binarize_straight_through(context)

        out = x * mask_sp

        return out, mask_sp

    def forward(self, x):
        # [N, C, H, W]
        context_channel, mask_sp = self.channel_pool(x)
        # print("mask_sp min max", mask_sp.min(), mask_sp.max())

        # [N, C, H, W]
        # out = context_spatial + context_channel

        return context_channel, mask_sp
    

class MultiConv3d(nn.Module):
    def __init__(self, num_channels=[1, 64], size_kernels=[3], zero_mean=False, half_zero_mean = False, sn_size=256):
        '''

        '''

        super().__init__()
        # parameters and options
        self.size_kernels = size_kernels
        self.num_channels = num_channels
        self.sn_size = sn_size
        self.zero_mean = zero_mean

        
        # list of convolutionnal layers
        self.conv_layers = nn.ModuleList()
        
        for j in range(len(num_channels) - 1):# padding_mode='circular'
            self.conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[j], out_channels=num_channels[j+1], kernel_size=size_kernels[j], padding=size_kernels[j]//2, stride=1, bias=False), 'kaiming')) #, padding_mode='circular'
            # # enforce zero mean filter for first conv
            if zero_mean and j == 0:
                P.register_parametrization(self.conv_layers[-1], "weight", ZeroMean())
            if half_zero_mean and j == 0:
                P.register_parametrization(self.conv_layers[-1], "weight", HalfZeroMean())
           


        # cache the estimation of the spectral norm
        self.L = torch.tensor(1., requires_grad=True)
        # cache dirac impulse used to estimate the spectral norm
        self.padding_total = sum([kernel_size//2 for kernel_size in size_kernels])
        self.dirac = torch.zeros((1, 1) + (4 * self.padding_total + 1, 4 * self.padding_total + 1, 4 * self.padding_total + 1))
        self.dirac[0, 0, 2 * self.padding_total, 2 * self.padding_total, 2 * self.padding_total] = 1


    def forward(self, x):
        return(self.convolution(x))


    
    def convolution(self, x):
        # normalized convolution, so that the spectral norm of the convolutional kernel is 1
        # nb the spectral norm of the convolution has to be upated before
        # x = x / torch.sqrt(self.L)

        for conv in self.conv_layers:
            weight = conv.weight
            # x = conv(x)
            x = nn.functional.conv3d(x, weight, bias=None, dilation=conv.dilation, padding=conv.padding, groups=conv.groups, stride=conv.stride)


        return(x)

    def transpose(self, x):
        # normalized transpose convolution, so that the spectral norm of the convolutional kernel is 1
        # nb the spectral norm of the convolution has to be upated before
        # x = x / torch.sqrt(self.L)

        for conv in reversed(self.conv_layers):
            
            # tmp_conv = nn.ConvTranspose3d(in_channels=conv.weight[0], out_channels=conv.weight[1], kernel_size=conv.weight[-1], padding=conv.weight[-1]//2, stride=1, bias=False) #, padding_mode='circular')
            weight = conv.weight
            # x = tmp_conv(x) 
            x = nn.functional.conv_transpose3d(x, weight, bias = None, padding=conv.padding, groups=conv.groups, dilation=conv.dilation, stride=conv.stride)

        return(x)
    
    def check_tranpose(self):
        """
            Check that the convolutional layer is indeed the transpose of the convolutional layer
        """
        device = self.conv_layers[0].weight.device
        ratio_sum = 0

        for i in range(100):
            x1 = torch.empty((1, 1, 104, 128, 128), device=device).normal_()
            x2 = torch.empty((1, self.num_channels[-1], 104, 128, 128), device=device).normal_()

            ps_1 = (self(x1)*x2).sum()
            ps_2 = (self.transpose(x2)*x1).sum()
            ratio_sum += ps_1.item()/ps_2.item()
            # print(f"ps_1: {ps_1.item()}")
            # print(f"ps_2: {ps_2.item()}")
        print(f"ratio: {ratio_sum/100}")

    
    def spectral_norm(self, mode="Fourier", n_steps=1000):
        """ Compute the spectral norm of the convolutional layer
                Args:
                    mode: "Fourier" or "power_method"
                        - "Fourier" computes the spectral norm by computing the DFT of the equivalent convolutional kernel. This is only an estimate (boundary effects are not taken into account) but it is differentiable and fast
                        - "power_method" computes the spectral norm by power iteration. This is more accurate and used before testing
                    n_steps: number of steps for the power method
        """

        if mode =="Fourier":
            # temporary set L to 1 to get the spectral norm of the unnormalized filter
            self.L = torch.tensor([1.], device=self.conv_layers[0].weight.device)
            # get the convolutional kernel corresponding to WtW
            kernel = self.get_kernel_WtW()
            # pad the kernel and compute its DFT. The spectral norm of WtW is the maximum of the absolute value of the DFT
            padding = (self.sn_size - 1) // 2 - self.padding_total
            sn = torch.fft.fftn(torch.nn.functional.pad(kernel, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()
            sn = torch.ceil(sn)
            self.L = sn
            return(self.L)
        
        elif mode == "power_method":
            self.L = torch.tensor([1.], device=self.conv_layers[0].weight.device)
            u = torch.empty((1, 1, self.sn_size, self.sn_size, self.sn_size), device= self.conv_layers[0].weight.device).normal_()
            with torch.no_grad():
                for _ in range(n_steps):
                    u = self.transpose(self.convolution(u))
                    u = u / torch.linalg.norm(u)

                
                # The largest eigen value can now be estimated in a differentiable way
                sn = torch.linalg.norm(self.transpose(self.convolution(u)))
                sn = torch.ceil(sn)
                self.L = sn
                return sn


    def shifted_spectral_norm(self, scale, shift, mode="Fourier", n_steps=1000):
        """ Compute the spectral norm of the convolutional layer
                Args:
                    mode: "Fourier" or "power_method"
                        - "Fourier" computes the spectral norm by computing the DFT of the equivalent convolutional kernel. This is only an estimate (boundary effects are not taken into account) but it is differentiable and fast
                        - "power_method" computes the spectral norm by power iteration. This is more accurate and used before testing
                    n_steps: number of steps for the power method
        """

        if mode =="Fourier":
            # temporary set L to 1 to get the spectral norm of the unnormalized filter
            self.L = torch.tensor([1.], device=self.conv_layers[0].weight.device)
            # get the convolutional kernel corresponding to WtW
            kernel = scale*self.get_kernel_WtW() + shift*self.dirac
            # pad the kernel and compute its DFT. The spectral norm of WtW is the maximum of the absolute value of the DFT
            padding = (self.sn_size - 1) // 2 - self.padding_total
            sn = torch.fft.fftn(torch.nn.functional.pad(kernel, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()
        
        elif mode == "power_method":
            self.L = torch.tensor([1.], device=self.conv_layers[0].weight.device)
            u = torch.empty((1, 1, self.sn_size, self.sn_size, self.sn_size), device= self.conv_layers[0].weight.device).normal_()
            with torch.no_grad():
                for _ in range(n_steps):
                    u = scale*self.transpose(self.convolution(u)) + shift*u
                    u = u / torch.linalg.norm(u)

                
                # The largest eigen value can now be estimated in a differentiable way
                sn = torch.linalg.norm(self.transpose(self.convolution(u)))
                # self.L = sn
        return torch.ceil(sn)


    # def check_tranpose(self):
    #     """
    #         Check that the convolutional layer is indeed the transpose of the convolutional layer
    #     """
    #     device = self.conv_layers[0].weight.device

    #     for i in range(1):
    #         x1 = torch.empty((1, 1, 40, 40), device=device).normal_()
    #         x2 = torch.empty((1, self.num_channels[-1], 40, 40), device=device).normal_()

    #         ps_1 = (self(x1)*x2).sum()
    #         ps_2 = (self.transpose(x2)*x1).sum()
    #         print(f"ps_1: {ps_1.item()}")
    #         print(f"ps_2: {ps_2.item()}")
    #         print(f"ratio: {ps_1.item()/ps_2.item()}")

    def spectrum(self):
        kernel = self.get_kernel_WtW()
        padding = (self.sn_size - 1) // 2 - self.padding_total
        return(torch.fft.fftn(torch.nn.functional.pad(kernel, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)))
    
    def get_filters(self):
        # we collapse the convolutions to get one kernel per channel
        # this done by computing the response of a dirac impulse
        self.dirac = self.dirac.to(self.conv_layers[0].weight.device)
        kernel = self.convolution(self.dirac)[:,:,self.padding_total:3*self.padding_total+1, self.padding_total:3*self.padding_total+1, self.padding_total:3*self.padding_total+1]
        return(kernel)


    def get_kernel_WtW(self):
        self.dirac = self.dirac.to(self.conv_layers[0].weight.device)
        return(self.transpose(self.convolution(self.dirac)))
       



# enforce zero mean kernels for each output channel
class ZeroMean(nn.Module):
    def forward(self, X):
        Y = X - torch.mean(X, dim=(1,2,3)).unsqueeze(1).unsqueeze(2).unsqueeze(3)
        return(Y)
    
class HalfZeroMean(nn.Module):
# enforce zero mean kernels for the first half of the output channels
    def forward(self, X):
        half = X.shape[1]//2
        Y = X.clone()
        Y[:,:half] = X[:,:half] - torch.mean(X[:,:half], dim=(1,2,3)).unsqueeze(1).unsqueeze(2).unsqueeze(3)

        return(Y)
    

class UnmatchedMultiConv3d(nn.Module):
    def __init__(self, num_channels=[1, 64], size_kernels=[3], zero_mean=True, sn_size=256, i_bCP = False):
        '''

        '''

        super().__init__()
        # parameters and options
        self.size_kernels = size_kernels
        self.num_channels = num_channels
        self.sn_size = sn_size
        self.zero_mean = zero_mean

        
        # list of convolutionnal layers
        self.conv_layers = nn.ModuleList()
        self.transpose_conv_layers = nn.ModuleList()
        
        for j in range(len(num_channels) - 1):
            self.conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[j], out_channels=num_channels[j+1], kernel_size=size_kernels[j], padding=size_kernels[j]//2, stride=1, bias=False), 'kaiming'))
            self.transpose_conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[j], out_channels=num_channels[j+1], kernel_size=size_kernels[j], padding=size_kernels[j]//2, stride=1, bias=False), 'kaiming'))
            # # enforce zero mean filter for first conv
            # if zero_mean and j == 0:
            #     P.register_parametrization(self.conv_layers[-1], "weight", ZeroMean())
           


        # cache the estimation of the spectral norm
        if i_bCP:
            self.step = torch.tensor(1., requires_grad=True)
            self.eps  = torch.tensor(1., requires_grad=True)
        else :
            self.L = torch.tensor(1., requires_grad=True)
        # self.l_max = torch.tensor(1., requires_grad=True)
        # self.l_min = torch.tensor(1., requires_grad=True)
        # self.norm_diff = torch.tensor(1., requires_grad=True)
        # cache dirac impulse used to estimate the spectral norm
        self.padding_total = sum([kernel_size//2 for kernel_size in size_kernels])
        self.dirac = torch.zeros((1, 1) + (4 * self.padding_total + 1, 4 * self.padding_total + 1, 4 * self.padding_total + 1))
        self.dirac[0, 0, 2 * self.padding_total, 2 * self.padding_total, 2 * self.padding_total] = 1
        # print("padding total", self.padding_total)
        # print("dirac shape", self.dirac.shape)

    def forward(self, x):
        return(self.convolution(x))

    def convolution(self, x):
        # normalized convolution, so that the spectral norm of the convolutional kernel is 1
        # nb the spectral norm of the convolution has to be upated before
        # x = x / torch.sqrt(self.L)

        for conv in self.conv_layers:
            weight = conv.weight
            x = nn.functional.conv3d(x, weight, bias=None, dilation=conv.dilation, padding=conv.padding, groups=conv.groups, stride=conv.stride)


        return(x)
    
    def transpose_convolution(self, x):
        for conv in self.transpose_conv_layers:
            weight = conv.weight
            x = nn.functional.conv3d(x, weight, bias=None, dilation=conv.dilation, padding=conv.padding, groups=conv.groups, stride=conv.stride)

        return(x)

    def transpose(self, x):
        # normalized transpose convolution, so that the spectral norm of the convolutional kernel is 1
        # nb the spectral norm of the convolution has to be upated before
        # x = x / torch.sqrt(self.L)

        for conv in reversed(self.transpose_conv_layers):
            weight = conv.weight
            x = nn.functional.conv_transpose3d(x, weight, bias = None, padding=conv.padding, groups=conv.groups, dilation=conv.dilation, stride=conv.stride)

        return(x)
    
    def convolution_transpose(self, x):
        for conv in reversed(self.conv_layers):
            weight = conv.weight
            x = nn.functional.conv_transpose3d(x, weight, bias = None, padding=conv.padding, groups=conv.groups, dilation=conv.dilation, stride=conv.stride)

        return(x)
    
    def spectral_norm(self, mode="Fourier", n_steps=1000):
        """ Compute the spectral norm of the convolutional layer
                Args:
                    mode: "Fourier" or "power_method"
                        - "Fourier" computes the spectral norm by computing the DFT of the equivalent convolutional kernel. This is only an estimate (boundary effects are not taken into account) but it is differentiable and fast
                        - "power_method" computes the spectral norm by power iteration. This is more accurate and used before testing
                    n_steps: number of steps for the power method
        """

        if mode =="Fourier":
            # temporary set L to 1 to get the spectral norm of the unnormalized filter
            self.L = torch.tensor([1.], device=self.conv_layers[0].weight.device)
            # get the convolutional kernel corresponding to WtW
            kernel = 0.5*(self.get_kernel_unmatched() + self.get_kernel_transpose_unmatched())
            # pad the kernel and compute its DFT. The spectral norm of WtW is the maximum of the absolute value of the DFT
            padding = (self.sn_size - 1) // 2 - self.padding_total
            max_sp = torch.fft.fftn(torch.nn.functional.pad(kernel, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()
            # min_sp = torch.fft.fftn(torch.nn.functional.pad(kernel, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().min()
            # print("vp ", torch.topk(torch.fft.fftn(torch.nn.functional.pad(kernel, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().view(1,-1),5, largest=False))
            norm_diff = torch.fft.fftn(torch.nn.functional.pad( self.get_kernel_transpose_unmatched() -self.get_kernel_unmatched(), (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()
            
            # self.L = (max_sp.sqrt() + 0.5*(norm_diff/min_sp.sqrt()))**2
            self.L = (max_sp.sqrt() + 0.5*norm_diff)**2

            # print("L", self.L)
            # print("min_sp", min_sp, "max_sp", max_sp)
            # print("norm_diff", norm_diff)
            # L__Lt =   self.get_kernel_unmatched() -self.get_kernel_transpose_unmatched()
            # L_Lt =   self.get_kernel_unmatched() + self.get_kernel_transpose_unmatched()
            # print("shape", L__Lt.shape)	
            # p_inv = torch.linalg.pinv(L_Lt, hermitian = True)

            # spectrum_L_Lt = torch.fft.rfftn(torch.nn.functional.pad(L_Lt, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().sqrt()

            # B = torch.fft.irfftn(spectrum_L_Lt, dim = (-3, -2, -1))
            
            # # s, u = torch.linalg.eigh(L_Lt) # eigenvectors=True)
            # # cond = 1e3 * 1.1920929e-07 
        
            # # above_cutoff = (abs(s) > cond * torch.max(abs(s)))

            # # psigma_diag = torch.sqrt(s) #[above_cutoff])
            # # # u = u[:, above_cutoff]

            # # B = u @ torch.diag(psigma_diag) @ u.t()
            # print(L__Lt.shape, p_inv.shape, B.shape)

            # T = torch.matmul((torch.matmul(L__Lt, p_inv)), B)
            # max_sp = torch.fft.fftn(torch.nn.functional.pad(T, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()
            # print("new max_sp", max_sp)

            return(self.L)
        


        elif mode == "power_method":
            raise NotImplementedError
            # self.L = torch.tensor([1.], device=self.conv_layers[0].weight.device)
            # u = torch.empty((1, 1, self.sn_size, self.sn_size, self.sn_size), device= self.conv_layers[0].weight.device).normal_()
            # with torch.no_grad():
            #     for _ in range(n_steps):
            #         u = self.transpose(self.convolution(u))
            #         u = u / torch.linalg.norm(u)

                
            #     # The largest eigen value can now be estimated in a differentiable way
            #     sn = torch.linalg.norm(self.transpose(self.convolution(u)))
            #     self.L = sn
            #     return sn
    def step_CP(self, mode="Fourier", n_steps=1000):
        """ Compute the spectral norm of the convolutional layer
                Args:
                    mode: "Fourier" or "power_method"
                        - "Fourier" computes the spectral norm by computing the DFT of the equivalent convolutional kernel. This is only an estimate (boundary effects are not taken into account) but it is differentiable and fast
                        - "power_method" computes the spectral norm by power iteration. This is more accurate and used before testing
                    n_steps: number of steps for the power method
        """

        if mode =="Fourier":
            # temporary set L to 1 to get the spectral norm of the unnormalized filter
            # get the convolutional kernel corresponding to WtW

            self.dirac = self.dirac.to(self.conv_layers[0].weight.device)
            # print("in step_CP, dirac shape", self.dirac.shape, "sn_size", self.sn_size, "padding_total", self.padding_total)
    
            kernel1 = self.convolution_transpose(self.convolution(self.dirac))
            # pad the kernel and compute its DFT. The spectral norm of WtW is the maximum of the absolute value of the DFT
            padding = (self.sn_size - 1) // 2 - self.padding_total
            norm1 = torch.fft.fftn(torch.nn.functional.pad(kernel1, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()

            kernel2 = self.transpose(self.transpose_convolution(self.dirac))
            norm2 = torch.fft.fftn(torch.nn.functional.pad(kernel2, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()

            kernel_diff = self.transpose(self.convolution(self.dirac))+self.convolution_transpose(self.transpose_convolution(self.dirac)) - kernel1 - kernel2
            norm_diff = torch.fft.fftn(torch.nn.functional.pad(kernel_diff, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()

            self.eps = norm_diff.sqrt()/(4*0.99)
            nu1 = self.eps.clamp(min=1.0)+torch.maximum(norm1.sqrt(), norm2.sqrt())
            nu2 = (1.0+norm1+norm2+self.eps*self.eps).sqrt()
            nu = torch.minimum(nu1, nu2)

            self.step = 0.99/nu



            return(self.step, self.eps)
        else :
            raise NotImplementedError
        
    def step_CV(self, mode="Fourier", n_steps=1000):
        """ Compute the spectral norm of the convolutional layer
                Args:
                    mode: "Fourier" or "power_method"
                        - "Fourier" computes the spectral norm by computing the DFT of the equivalent convolutional kernel. This is only an estimate (boundary effects are not taken into account) but it is differentiable and fast
                        - "power_method" computes the spectral norm by power iteration. This is more accurate and used before testing
                    n_steps: number of steps for the power method
        """

        if mode =="Fourier":
            # temporary set L to 1 to get the spectral norm of the unnormalized filter
            # get the convolutional kernel corresponding to WtW

            self.dirac = self.dirac.to(self.conv_layers[0].weight.device)
    
            # pad the kernel and compute its DFT. The spectral norm of WtW is the maximum of the absolute value of the DFT
            padding = (self.sn_size - 1) // 2 - self.padding_total


            kernel_sum = 0.5*(self.transpose(self.convolution(self.dirac))+self.convolution_transpose(self.transpose_convolution(self.dirac)))
            norm_sum_max = torch.fft.fftn(torch.nn.functional.pad(kernel_sum, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()
            norm_sum_min = torch.fft.fftn(torch.nn.functional.pad(kernel_sum, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().min()

            kernel_diff = self.transpose(self.convolution(self.dirac))-self.convolution_transpose(self.transpose_convolution(self.dirac)) 
            norm_diff = torch.fft.fftn(torch.nn.functional.pad(kernel_diff, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()
            norm_diff = 0.5*norm_diff.sqrt()
            print("norm_diff", norm_diff, "norm_sum_max", norm_sum_max, "norm_sum_min", norm_sum_min)

            self.step = 1/(norm_sum_max.sqrt()+norm_diff/norm_sum_min.sqrt())



            return self.step
        else :
            raise NotImplementedError
        


    def step_FB(self, scale, mode="Fourier", n_steps=1000):
        """ Compute the spectral norm of the convolutional layer
                Args:
                    mode: "Fourier" or "power_method"
                        - "Fourier" computes the spectral norm by computing the DFT of the equivalent convolutional kernel. This is only an estimate (boundary effects are not taken into account) but it is differentiable and fast
                        - "power_method" computes the spectral norm by power iteration. This is more accurate and used before testing
                    n_steps: number of steps for the power method
        """

        if mode =="Fourier":
            # temporary set L to 1 to get the spectral norm of the unnormalized filter
            # get the convolutional kernel corresponding to WtW

            self.dirac = self.dirac.to(self.conv_layers[0].weight.device)
    
            # pad the kernel and compute its DFT. The spectral norm of WtW is the maximum of the absolute value of the DFT
            padding = (self.sn_size - 1) // 2 - self.padding_total


            kernel_sum = 0.5*scale*(self.transpose(self.convolution(self.dirac))+self.convolution_transpose(self.transpose_convolution(self.dirac))) + 1.0*self.dirac
            norm_sum_max = torch.fft.fftn(torch.nn.functional.pad(kernel_sum, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()
            norm_sum_min = torch.fft.fftn(torch.nn.functional.pad(kernel_sum, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().min()
            print("(prec) norm_sum_min", norm_sum_min)

            if norm_sum_min < 0 :
                kappa = - norm_sum_min + 1e-6
                kernel_sum = 0.5*scale*(self.transpose(self.convolution(self.dirac))+self.convolution_transpose(self.transpose_convolution(self.dirac))) + (kappa + 1.0) * self.dirac
                norm_sum_max = torch.fft.fftn(torch.nn.functional.pad(kernel_sum, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()
                norm_sum_min = torch.fft.fftn(torch.nn.functional.pad(kernel_sum, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().min()
                print("norm_sum_max", norm_sum_max, "norm_sum_min", norm_sum_min)
            else :
                kappa = 0


            kernel_diff = scale*(self.transpose(self.convolution(self.dirac))-self.convolution_transpose(self.transpose_convolution(self.dirac)))
            norm_diff = torch.fft.fftn(torch.nn.functional.pad(kernel_diff, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()
            norm_diff = 0.5*norm_diff.sqrt()
            print("norm_diff", norm_diff, "norm_sum_max", norm_sum_max, "norm_sum_min", norm_sum_min)
            print("pow", (norm_sum_max.sqrt()+norm_diff/norm_sum_min.sqrt())**2)
            self.step = 1/(norm_sum_max.sqrt()+norm_diff/norm_sum_min.sqrt())**2
            print("step", self.step)



            return self.step, kappa
        else :
            raise NotImplementedError
        
    def spectrum(self):
        kernel = self.get_kernel_unmatched()
        padding = (self.sn_size - 1) // 2 - self.padding_total
        return(torch.fft.fftn(torch.nn.functional.pad(kernel, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)))
    
    def get_filters(self):
        # we collapse the convolutions to get one kernel per channel
        # this done by computing the response of a dirac impulse
        self.dirac = self.dirac.to(self.conv_layers[0].weight.device)
        kernel = self.convolution(self.dirac)[:,:,self.padding_total:3*self.padding_total+1, self.padding_total:3*self.padding_total+1, self.padding_total:3*self.padding_total+1]
        return(kernel)


    def get_kernel_unmatched(self):
        self.dirac = self.dirac.to(self.conv_layers[0].weight.device)
        print("in get_kernel_unmatched", self.dirac.shape)
        return(self.transpose(self.convolution(self.dirac)))
    
    def get_kernel_transpose_unmatched(self):
        self.dirac = self.dirac.to(self.conv_layers[0].weight.device)
        print("in get_kernel_transpose_unmatched", self.dirac.shape)
        return(self.convolution_transpose(self.transpose_convolution(self.dirac)))
       


class MultiConv3dSpline(nn.Module):
    def __init__(self, num_channels=[1, 64], size_kernels=[3], zero_mean=True, sn_size=128):
        '''

        '''

        super().__init__()
        # parameters and options
        self.size_kernels = size_kernels
        self.num_channels = num_channels
        self.sn_size = sn_size
        self.zero_mean = zero_mean

        
        # list of convolutionnal layers
        self.conv_layers = nn.ModuleList()
        
        for j in range(len(num_channels) - 1):
            self.conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[j], out_channels=num_channels[j+1], kernel_size=size_kernels[j], padding=size_kernels[j]//2, stride=1, bias=False), 'kaiming'))
            # enforce zero mean filter for first conv
            if zero_mean and j == 0:
                P.register_parametrization(self.conv_layers[-1], "weight", ZeroMean())
           


        # cache the estimation of the spectral norm
        self.L = torch.tensor(1., requires_grad=True)
        # cache dirac impulse used to estimate the spectral norm
        self.padding_total = sum([kernel_size//2 for kernel_size in size_kernels])
        self.dirac = torch.zeros((1, 1) + (4 * self.padding_total + 1, 4 * self.padding_total + 1, 4 * self.padding_total + 1))
        self.dirac[0, 0, 2 * self.padding_total, 2 * self.padding_total, 2 * self.padding_total] = 1


    def forward(self, x):
        return(self.convolution(x))

    def convolution(self, x):
        # normalized convolution, so that the spectral norm of the convolutional kernel is 1
        # nb the spectral norm of the convolution has to be upated before
        x = x / torch.sqrt(self.L)

        for conv in self.conv_layers:
            weight = conv.weight
            x = nn.functional.conv3d(x, weight, bias=None, dilation=conv.dilation, padding=conv.padding, groups=conv.groups, stride=conv.stride)


        return(x)

    def transpose(self, x):
        # normalized transpose convolution, so that the spectral norm of the convolutional kernel is 1
        # nb the spectral norm of the convolution has to be upated before
        x = x / torch.sqrt(self.L)

        for conv in reversed(self.conv_layers):
            # print("x shape", x.shape)
            weight = conv.weight
            x = nn.functional.conv_transpose3d(x, weight, bias = None, padding=conv.padding, groups=conv.groups, dilation=conv.dilation, stride=conv.stride)

        return(x)
    
    def spectral_norm(self, mode="Fourier", n_steps=1000):
        """ Compute the spectral norm of the convolutional layer
                Args:
                    mode: "Fourier" or "power_method"
                        - "Fourier" computes the spectral norm by computing the DFT of the equivalent convolutional kernel. This is only an estimate (boundary effects are not taken into account) but it is differentiable and fast
                        - "power_method" computes the spectral norm by power iteration. This is more accurate and used before testing
                    n_steps: number of steps for the power method
        """

        if mode =="Fourier":
            # temporary set L to 1 to get the spectral norm of the unnormalized filter
            self.L = torch.tensor([1.], device=self.conv_layers[0].weight.device)
            # get the convolutional kernel corresponding to WtW
            kernel = self.get_kernel_WtW()
            # pad the kernel and compute its DFT. The spectral norm of WtW is the maximum of the absolute value of the DFT
            padding = (self.sn_size - 1) // 2 - self.padding_total
            self.L = torch.fft.fftn(torch.nn.functional.pad(kernel, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()
            return(self.L)
        
        elif mode == "power_method":
            self.L = torch.tensor([1.], device=self.conv_layers[0].weight.device)
            u = torch.empty((1, 1, self.sn_size, self.sn_size, self.sn_size), device= self.conv_layers[0].weight.device).normal_()
            with torch.no_grad():
                for _ in range(n_steps):
                    u = self.transpose(self.convolution(u))
                    u = u / torch.linalg.norm(u)

                
                # The largest eigen value can now be estimated in a differentiable way
                sn = torch.linalg.norm(self.transpose(self.convolution(u)))
                self.L = sn
                return sn


    def check_tranpose(self):
        """
            Check that the convolutional layer is indeed the transpose of the convolutional layer
        """
        device = self.conv_layers[0].weight.device

        for i in range(1):
            x1 = torch.empty((1, 1, 40, 40), device=device).normal_()
            x2 = torch.empty((1, self.num_channels[-1], 40, 40), device=device).normal_()

            ps_1 = (self(x1)*x2).sum()
            ps_2 = (self.transpose(x2)*x1).sum()
            print(f"ps_1: {ps_1.item()}")
            print(f"ps_2: {ps_2.item()}")
            print(f"ratio: {ps_1.item()/ps_2.item()}")

    def spectrum(self):
        kernel = self.get_kernel_WtW()
        padding = (self.sn_size - 1) // 2 - self.padding_total
        return(torch.fft.fftn(torch.nn.functional.pad(kernel, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)))
    
    def get_filters(self):
        # we collapse the convolutions to get one kernel per channel
        # this done by computing the response of a dirac impulse
        self.dirac = self.dirac.to(self.conv_layers[0].weight.device)
        kernel = self.convolution(self.dirac)[:,:,self.padding_total:3*self.padding_total+1, self.padding_total:3*self.padding_total+1, self.padding_total:3*self.padding_total+1]
        return(kernel)


    def get_kernel_WtW(self):
        self.dirac = self.dirac.to(self.conv_layers[0].weight.device)
        return(self.transpose(self.convolution(self.dirac)))
       



# class UnmatchedMultiConv3dFB(nn.Module):
#     def __init__(self, num_channels=[1, 64], size_kernels=[3], zero_mean=True, sn_size=256, i_bCP = False):
#         '''

#         '''

#         super().__init__()
#         # parameters and options
#         self.size_kernels = size_kernels
#         self.num_channels = num_channels
#         self.sn_size = sn_size
#         self.zero_mean = zero_mean

        
#         # list of convolutionnal layers
#         self.conv_layers = nn.ModuleList()
#         self.transpose_conv_layers = nn.ModuleList()
        
#         for j in range(len(num_channels) - 1):
#             self.conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[j], out_channels=num_channels[j+1], kernel_size=size_kernels[j], padding=size_kernels[j]//2, stride=1, bias=False), 'kaiming'))
#             self.transpose_conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[j], out_channels=num_channels[j+1], kernel_size=size_kernels[j], padding=size_kernels[j]//2, stride=1, bias=False), 'kaiming'))
#             # # enforce zero mean filter for first conv
#             # if zero_mean and j == 0:
#             #     P.register_parametrization(self.conv_layers[-1], "weight", ZeroMean())
           


#         # cache the estimation of the spectral norm
#         if i_bCP:
#             self.step = torch.tensor(1., requires_grad=True)
#             self.eps  = torch.tensor(1., requires_grad=True)
#         else :
#             self.L = torch.tensor(1., requires_grad=True)
#         # self.l_max = torch.tensor(1., requires_grad=True)
#         # self.l_min = torch.tensor(1., requires_grad=True)
#         # self.norm_diff = torch.tensor(1., requires_grad=True)
#         # cache dirac impulse used to estimate the spectral norm
#         self.padding_total = sum([kernel_size//2 for kernel_size in size_kernels])
#         self.dirac = torch.zeros((1, 1) + (4 * self.padding_total + 1, 4 * self.padding_total + 1, 4 * self.padding_total + 1))
#         self.dirac[0, 0, 2 * self.padding_total, 2 * self.padding_total, 2 * self.padding_total] = 1


#     def forward(self, x):
#         return(self.convolution(x))

#     def convolution(self, x):
#         # normalized convolution, so that the spectral norm of the convolutional kernel is 1
#         # nb the spectral norm of the convolution has to be upated before
#         # x = x / torch.sqrt(self.L)

#         for conv in self.conv_layers:
#             weight = conv.weight
#             x = nn.functional.conv3d(x, weight, bias=None, dilation=conv.dilation, padding=conv.padding, groups=conv.groups, stride=conv.stride)


#         return(x)
    
#     def transpose_convolution(self, x):
#         for conv, conv2 in zip(self.transpose_conv_layers, self.conv_layers):
#             weight = conv.weight
#             weight2 = conv2.weight
#             x = nn.functional.conv3d(x, 0.5*(weight+weight2), bias=None, dilation=conv.dilation, padding=conv.padding, groups=conv.groups, stride=conv.stride)

#         return(x)

#     def transpose(self, x):
#         # normalized transpose convolution, so that the spectral norm of the convolutional kernel is 1
#         # nb the spectral norm of the convolution has to be upated before
#         # x = x / torch.sqrt(self.L)

#         for conv, conv2 in zip(reversed(self.transpose_conv_layers), reversed(self.conv_layers)):
#             weight = conv.weight
#             weight2 = conv2.weight
#             x = nn.functional.conv_transpose3d(x, 0.5*(weight+weight2), bias = None, padding=conv.padding, groups=conv.groups, dilation=conv.dilation, stride=conv.stride)

#         return(x)
    
#     def convolution_transpose(self, x):
#         for conv in reversed(self.conv_layers):
#             weight = conv.weight
#             x = nn.functional.conv_transpose3d(x, weight, bias = None, padding=conv.padding, groups=conv.groups, dilation=conv.dilation, stride=conv.stride)

#         return(x)


#     def step_FB(self, scale, mode="Fourier", n_steps=1000):
#         """ Compute the spectral norm of the convolutional layer
#                 Args:
#                     mode: "Fourier" or "power_method"
#                         - "Fourier" computes the spectral norm by computing the DFT of the equivalent convolutional kernel. This is only an estimate (boundary effects are not taken into account) but it is differentiable and fast
#                         - "power_method" computes the spectral norm by power iteration. This is more accurate and used before testing
#                     n_steps: number of steps for the power method
#         """

#         if mode =="Fourier":
#             # temporary set L to 1 to get the spectral norm of the unnormalized filter
#             # get the convolutional kernel corresponding to WtW

#             self.dirac = self.dirac.to(self.conv_layers[0].weight.device)
    
#             # pad the kernel and compute its DFT. The spectral norm of WtW is the maximum of the absolute value of the DFT
#             padding = (self.sn_size - 1) // 2 - self.padding_total


#             kernel_sum = 0.5*scale*(self.transpose(self.convolution(self.dirac))+self.convolution_transpose(self.transpose_convolution(self.dirac))) + 1.0*self.dirac
#             norm_sum_max = torch.fft.fftn(torch.nn.functional.pad(kernel_sum, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()
#             norm_sum_min = torch.fft.fftn(torch.nn.functional.pad(kernel_sum, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().min()
#             # print("(prec) norm_sum_min", norm_sum_min)

#             if norm_sum_min <= 0 :
#                 kappa =  norm_sum_min.abs() + 1e-6
#                 kernel_sum = 0.5*scale*(self.transpose(self.convolution(self.dirac))+self.convolution_transpose(self.transpose_convolution(self.dirac))) + (kappa + 1.0) * self.dirac
#                 norm_sum_max = torch.fft.fftn(torch.nn.functional.pad(kernel_sum, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()
#                 norm_sum_min = torch.fft.fftn(torch.nn.functional.pad(kernel_sum, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().min()
#                 print("norm_sum_max", norm_sum_max, "norm_sum_min", norm_sum_min)
#             else :
#                 kappa = 0


#             kernel_diff = scale*(self.transpose(self.convolution(self.dirac))-self.convolution_transpose(self.transpose_convolution(self.dirac)))
#             norm_diff = torch.fft.fftn(torch.nn.functional.pad(kernel_diff, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()
#             norm_diff = 0.5*norm_diff.sqrt()
#             # print("norm_diff", norm_diff, "norm_sum_max", norm_sum_max, "norm_sum_min", norm_sum_min)
#             # print("pow", (norm_sum_max.sqrt()+norm_diff/norm_sum_min.sqrt())**2)
#             t1 = norm_sum_max.abs().sqrt()
#             t2 = norm_diff/(1e-10+norm_sum_min.abs().sqrt())
#             self.step = 1/(t1.abs()+t2.abs())**2
#             # print("step", self.step)



#             return self.step, kappa
#         else :
#             raise NotImplementedError
        





#     def step_FB_with_conv(self, scale, i_conv, i_scale_conv):
#         """ Compute the spectral norm of the convolutional layer
#                 Args:
#                     mode: "Fourier" or "power_method"
#                         - "Fourier" computes the spectral norm by computing the DFT of the equivalent convolutional kernel. This is only an estimate (boundary effects are not taken into account) but it is differentiable and fast
#                         - "power_method" computes the spectral norm by power iteration. This is more accurate and used before testing
#                     n_steps: number of steps for the power method
#         """

        
#             # temporary set L to 1 to get the spectral norm of the unnormalized filter
#             # get the convolutional kernel corresponding to WtW

#         self.dirac = self.dirac.to(self.conv_layers[0].weight.device)

#         # pad the kernel and compute its DFT. The spectral norm of WtW is the maximum of the absolute value of the DFT
#         padding = (self.sn_size - 1) // 2 - self.padding_total


#         kernel_sum = 0.5*scale*(self.transpose(self.convolution(self.dirac))+self.convolution_transpose(self.transpose_convolution(self.dirac))) + 1.0*self.dirac + i_scale_conv*(i_conv.transpose(i_conv(self.dirac)))
#         norm_sum_max = torch.fft.fftn(torch.nn.functional.pad(kernel_sum, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()
#         norm_sum_min = torch.fft.fftn(torch.nn.functional.pad(kernel_sum, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().min()
#         # print("(prec) norm_sum_min", norm_sum_min)

#         if norm_sum_min <= 0 :
#             kappa =  norm_sum_min.abs() + 1e-6
#             kernel_sum = 0.5*scale*(self.transpose(self.convolution(self.dirac))+self.convolution_transpose(self.transpose_convolution(self.dirac))) + (kappa + 1.0) * self.dirac + i_scale_conv*(i_conv.transpose(i_conv(self.dirac)))
#             norm_sum_max = torch.fft.fftn(torch.nn.functional.pad(kernel_sum, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()
#             norm_sum_min = torch.fft.fftn(torch.nn.functional.pad(kernel_sum, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().min()
#             print("norm_sum_max", norm_sum_max, "norm_sum_min", norm_sum_min)
#         else :
#             kappa = 0


#         kernel_diff = scale*(self.transpose(self.convolution(self.dirac))-self.convolution_transpose(self.transpose_convolution(self.dirac)))
#         norm_diff = torch.fft.fftn(torch.nn.functional.pad(kernel_diff, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()
#         norm_diff = 0.5*norm_diff.sqrt()
#         # print("norm_diff", norm_diff, "norm_sum_max", norm_sum_max, "norm_sum_min", norm_sum_min)
#         # print("pow", (norm_sum_max.sqrt()+norm_diff/norm_sum_min.sqrt())**2)
#         t1 = norm_sum_max.abs().sqrt()
#         t2 = norm_diff/(1e-10+norm_sum_min.abs().sqrt())
#         self.step = 1/(t1.abs()+t2.abs())**2
#         # print("step", self.step)



#         return self.step, kappa
    
        
#     def spectrum(self):
#         kernel = self.get_kernel_unmatched()
#         padding = (self.sn_size - 1) // 2 - self.padding_total
#         return(torch.fft.fftn(torch.nn.functional.pad(kernel, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)))
    
#     def get_filters(self):
#         # we collapse the convolutions to get one kernel per channel
#         # this done by computing the response of a dirac impulse
#         self.dirac = self.dirac.to(self.conv_layers[0].weight.device)
#         kernel = self.convolution(self.dirac)[:,:,self.padding_total:3*self.padding_total+1, self.padding_total:3*self.padding_total+1, self.padding_total:3*self.padding_total+1]
#         return(kernel)


#     def get_kernel_unmatched(self):
#         self.dirac = self.dirac.to(self.conv_layers[0].weight.device)
#         return(self.transpose(self.convolution(self.dirac)))
    
#     def get_kernel_transpose_unmatched(self):
#         self.dirac = self.dirac.to(self.conv_layers[0].weight.device)
#         return(self.convolution_transpose(self.transpose_convolution(self.dirac)))
       



class UnmatchedMultiScaleConv3d(nn.Module):
    def __init__(self, num_channels=[1, 64], size_kernels=[3], zero_mean=True, sn_size=256, i_bCP = False):

        super().__init__()
        # parameters and options
        self.size_kernels = size_kernels
        self.num_channels = num_channels
        self.sn_size = sn_size
        self.zero_mean = zero_mean

        # list of convolutionnal layers
        self.conv_layers = nn.ModuleList()
        self.transpose_conv_layers = nn.ModuleList()

        self.conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[0], out_channels=num_channels[1], kernel_size=size_kernels[0], padding=size_kernels[0]//2, dilation=1, bias=False), 'kaiming'))

        self.conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[1], out_channels=num_channels[1], kernel_size=size_kernels[0], padding=size_kernels[0]//2, dilation=1, bias=False), 'kaiming'))
        self.conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[1], out_channels=num_channels[1], kernel_size=size_kernels[0], padding=(size_kernels[0]//2)*2, dilation=2, bias=False), 'kaiming'))
        self.conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[1], out_channels=num_channels[1], kernel_size=size_kernels[0], padding=(size_kernels[0]//2)*4, dilation=4, bias=False), 'kaiming'))
        self.conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[1], out_channels=num_channels[1], kernel_size=size_kernels[0], padding=(size_kernels[0]//2)*8, dilation=8, bias=False), 'kaiming'))
        self.conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[1], out_channels=num_channels[1], kernel_size=size_kernels[0], padding=(size_kernels[0]//2)*16, dilation=16, bias=False), 'kaiming'))
        
        self.conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[1], out_channels=num_channels[1], kernel_size=size_kernels[0], padding=size_kernels[0]//2, dilation=1, bias=False), 'kaiming'))

        # Doing the same for the transpose convolution
        self.transpose_conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[0], out_channels=num_channels[1], kernel_size=size_kernels[0], padding=size_kernels[0]//2, dilation=1, bias=False), 'kaiming'))

        self.transpose_conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[1], out_channels=num_channels[1], kernel_size=size_kernels[1], padding=size_kernels[1]//2, dilation=1, bias=False), 'kaiming'))
        self.transpose_conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[1], out_channels=num_channels[1], kernel_size=size_kernels[1], padding=(size_kernels[1]//2)*2, dilation=2, bias=False), 'kaiming'))
        self.transpose_conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[1], out_channels=num_channels[1], kernel_size=size_kernels[1], padding=(size_kernels[1]//2)*4, dilation=4, bias=False), 'kaiming'))
        self.transpose_conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[1], out_channels=num_channels[1], kernel_size=size_kernels[1], padding=(size_kernels[1]//2)*8, dilation=8, bias=False), 'kaiming'))
        self.transpose_conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[1], out_channels=num_channels[1], kernel_size=size_kernels[1], padding=(size_kernels[1]//2)*16, dilation=16, bias=False), 'kaiming'))

        self.transpose_conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[1], out_channels=num_channels[1], kernel_size=size_kernels[1], padding=size_kernels[0]//2, dilation=1, bias=False), 'kaiming'))

        # cache the estimation of the spectral norm
        if i_bCP:
            self.step = torch.tensor(1., requires_grad=True)
            self.eps  = torch.tensor(1., requires_grad=True)
        else :
            self.L = torch.tensor(1., requires_grad=True)
        # self.l_max = torch.tensor(1., requires_grad=True)
        # self.l_min = torch.tensor(1., requires_grad=True)
        # self.norm_diff = torch.tensor(1., requires_grad=True)
        # cache dirac impulse used to estimate the spectral norm
        self.padding_total =  sum([size_kernels[0]//2,  16*(size_kernels[0]//2), size_kernels[0]//2 ])
        self.dirac = torch.zeros((1, 1) + (4 * self.padding_total + 1, 4 * self.padding_total + 1, 4 * self.padding_total + 1))
        self.dirac[0, 0, 2 * self.padding_total, 2 * self.padding_total, 2 * self.padding_total] = 1


    def forward(self, x):

        return(self.convolution(x))

    def convolution(self, x):
        # x = self.conv_layers[0](x)
        # x = nn.functional.conv3d(x, weight, bias=None, dilation=conv.dilation, padding=conv.padding, groups=conv.groups, stride=conv.stride)

        x = nn.functional.conv3d(x, self.conv_layers[0].weight, bias=None, dilation=self.conv_layers[0].dilation, padding=self.conv_layers[0].padding, groups=self.conv_layers[0].groups, stride=self.conv_layers[0].stride)

        x1 = nn.functional.conv3d(x, self.conv_layers[1].weight, bias=None, dilation=self.conv_layers[1].dilation, padding=self.conv_layers[1].padding, groups=self.conv_layers[1].groups, stride=self.conv_layers[1].stride) 
        x2 = nn.functional.conv3d(x, self.conv_layers[2].weight, bias=None, dilation=self.conv_layers[2].dilation, padding=self.conv_layers[2].padding, groups=self.conv_layers[2].groups, stride=self.conv_layers[2].stride) 
        x3 = nn.functional.conv3d(x, self.conv_layers[3].weight, bias=None, dilation=self.conv_layers[3].dilation, padding=self.conv_layers[3].padding, groups=self.conv_layers[3].groups, stride=self.conv_layers[3].stride)
        x4 = nn.functional.conv3d(x, self.conv_layers[4].weight, bias=None, dilation=self.conv_layers[4].dilation, padding=self.conv_layers[4].padding, groups=self.conv_layers[4].groups, stride=self.conv_layers[4].stride)
        x5 = nn.functional.conv3d(x, self.conv_layers[5].weight, bias=None, dilation=self.conv_layers[5].dilation, padding=self.conv_layers[5].padding, groups=self.conv_layers[5].groups, stride=self.conv_layers[5].stride)
        x = (x1+x2+x3+x4+x5)/5
        x = nn.functional.conv3d(x, self.conv_layers[6].weight, bias=None, dilation=self.conv_layers[6].dilation, padding=self.conv_layers[6].padding, groups=self.conv_layers[6].groups, stride=self.conv_layers[6].stride)

        return(x)
    
    def transpose_convolution(self, x):
        # xref = self.convolution(x)

        x = nn.functional.conv3d(x, self.transpose_conv_layers[0].weight, bias=None, dilation=self.transpose_conv_layers[0].dilation, padding=self.transpose_conv_layers[0].padding, groups=self.transpose_conv_layers[0].groups, stride=self.transpose_conv_layers[0].stride)

        x1 = nn.functional.conv3d(x, self.transpose_conv_layers[1].weight, bias=None, dilation=self.transpose_conv_layers[1].dilation, padding=self.transpose_conv_layers[1].padding, groups=self.transpose_conv_layers[1].groups, stride=self.transpose_conv_layers[1].stride) 
        x2 = nn.functional.conv3d(x, self.transpose_conv_layers[2].weight, bias=None, dilation=self.transpose_conv_layers[2].dilation, padding=self.transpose_conv_layers[2].padding, groups=self.transpose_conv_layers[2].groups, stride=self.transpose_conv_layers[2].stride) 
        x3 = nn.functional.conv3d(x, self.transpose_conv_layers[3].weight, bias=None, dilation=self.transpose_conv_layers[3].dilation, padding=self.transpose_conv_layers[3].padding, groups=self.transpose_conv_layers[3].groups, stride=self.transpose_conv_layers[3].stride)
        x4 = nn.functional.conv3d(x, self.transpose_conv_layers[4].weight, bias=None, dilation=self.transpose_conv_layers[4].dilation, padding=self.transpose_conv_layers[4].padding, groups=self.transpose_conv_layers[4].groups, stride=self.transpose_conv_layers[4].stride)
        x5 = nn.functional.conv3d(x, self.transpose_conv_layers[5].weight, bias=None, dilation=self.transpose_conv_layers[5].dilation, padding=self.transpose_conv_layers[5].padding, groups=self.transpose_conv_layers[5].groups, stride=self.transpose_conv_layers[5].stride)

        x = (x1+x2+x3+x4+x5)/5
        x = nn.functional.conv3d(x, self.transpose_conv_layers[6].weight, bias=None, dilation=self.transpose_conv_layers[6].dilation, padding=self.transpose_conv_layers[6].padding, groups=self.transpose_conv_layers[6].groups, stride=self.transpose_conv_layers[6].stride)
        
        return(x)

    def transpose(self, x):
        # xref = self.convolution_transpose(x)

        x = nn.functional.conv_transpose3d(x, self.transpose_conv_layers[6].weight, bias = None, padding=self.transpose_conv_layers[6].padding, groups=self.transpose_conv_layers[6].groups, dilation=self.transpose_conv_layers[6].dilation, stride=self.transpose_conv_layers[6].stride)
        x = x/5
        x5 = nn.functional.conv_transpose3d(x, self.transpose_conv_layers[5].weight, bias = None, padding=self.transpose_conv_layers[5].padding, groups=self.transpose_conv_layers[5].groups, dilation=self.transpose_conv_layers[5].dilation, stride=self.transpose_conv_layers[5].stride)
        x4 = nn.functional.conv_transpose3d(x, self.transpose_conv_layers[4].weight, bias = None, padding=self.transpose_conv_layers[4].padding, groups=self.transpose_conv_layers[4].groups, dilation=self.transpose_conv_layers[4].dilation, stride=self.transpose_conv_layers[4].stride)
        x3 = nn.functional.conv_transpose3d(x, self.transpose_conv_layers[3].weight, bias = None, padding=self.transpose_conv_layers[3].padding, groups=self.transpose_conv_layers[3].groups, dilation=self.transpose_conv_layers[3].dilation, stride=self.transpose_conv_layers[3].stride)
        x2 = nn.functional.conv_transpose3d(x, self.transpose_conv_layers[2].weight, bias = None, padding=self.transpose_conv_layers[2].padding, groups=self.transpose_conv_layers[2].groups, dilation=self.transpose_conv_layers[2].dilation, stride=self.transpose_conv_layers[2].stride)
        x1 = nn.functional.conv_transpose3d(x, self.transpose_conv_layers[1].weight, bias = None, padding=self.transpose_conv_layers[1].padding, groups=self.transpose_conv_layers[1].groups, dilation=self.transpose_conv_layers[1].dilation, stride=self.transpose_conv_layers[1].stride)

        x = x1+x2+x3+x4+x5
        x = nn.functional.conv_transpose3d(x, self.transpose_conv_layers[0].weight, bias = None, padding=self.transpose_conv_layers[0].padding, groups=self.transpose_conv_layers[0].groups, dilation=self.transpose_conv_layers[0].dilation, stride=self.transpose_conv_layers[0].stride)

       
        return(x)
    
    def convolution_transpose(self, x):


        x = nn.functional.conv_transpose3d(x, self.conv_layers[6].weight, bias = None, padding=self.conv_layers[6].padding, groups=self.conv_layers[6].groups, dilation=self.conv_layers[6].dilation, stride=self.conv_layers[6].stride)
        x = x/5
        x5 = nn.functional.conv_transpose3d(x, self.conv_layers[5].weight, bias = None, padding=self.conv_layers[5].padding, groups=self.conv_layers[5].groups, dilation=self.conv_layers[5].dilation, stride=self.conv_layers[5].stride)
        x4 = nn.functional.conv_transpose3d(x, self.conv_layers[4].weight, bias = None, padding=self.conv_layers[4].padding, groups=self.conv_layers[4].groups, dilation=self.conv_layers[4].dilation, stride=self.conv_layers[4].stride)
        x3 = nn.functional.conv_transpose3d(x, self.conv_layers[3].weight, bias = None, padding=self.conv_layers[3].padding, groups=self.conv_layers[3].groups, dilation=self.conv_layers[3].dilation, stride=self.conv_layers[3].stride)
        x2 = nn.functional.conv_transpose3d(x, self.conv_layers[2].weight, bias = None, padding=self.conv_layers[2].padding, groups=self.conv_layers[2].groups, dilation=self.conv_layers[2].dilation, stride=self.conv_layers[2].stride)
        x1 = nn.functional.conv_transpose3d(x, self.conv_layers[1].weight, bias = None, padding=self.conv_layers[1].padding, groups=self.conv_layers[1].groups, dilation=self.conv_layers[1].dilation, stride=self.conv_layers[1].stride)

        x = x1+x2+x3+x4+x5
        x = nn.functional.conv_transpose3d(x, self.conv_layers[0].weight, bias = None, padding=self.conv_layers[0].padding, groups=self.conv_layers[0].groups, dilation=self.conv_layers[0].dilation, stride=self.conv_layers[0].stride)
        
        return(x)
    
    
    def step_CP(self, mode="Fourier", n_steps=1000):
        """ Compute the spectral norm of the convolutional layer
                Args:
                    mode: "Fourier" or "power_method"
                        - "Fourier" computes the spectral norm by computing the DFT of the equivalent convolutional kernel. This is only an estimate (boundary effects are not taken into account) but it is differentiable and fast
                        - "power_method" computes the spectral norm by power iteration. This is more accurate and used before testing
                    n_steps: number of steps for the power method
        """

        if mode =="Fourier":
            # temporary set L to 1 to get the spectral norm of the unnormalized filter
            # get the convolutional kernel corresponding to WtW

            self.dirac = self.dirac.to(self.conv_layers[0].weight.device)
            # print("in step_CP, dirac shape", self.dirac.shape, "sn_size", self.sn_size, "padding_total", self.padding_total)

            kernel1 = self.convolution_transpose(self.convolution(self.dirac))
            # pad the kernel and compute its DFT. The spectral norm of WtW is the maximum of the absolute value of the DFT
            padding = (self.sn_size - 1) // 2 - self.padding_total


            norm1 = torch.fft.fftn(torch.nn.functional.pad(kernel1, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()

            kernel2 = self.transpose(self.transpose_convolution(self.dirac))
            norm2 = torch.fft.fftn(torch.nn.functional.pad(kernel2, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()

            kernel_diff = self.transpose(self.convolution(self.dirac))+self.convolution_transpose(self.transpose_convolution(self.dirac)) - kernel1 - kernel2
            if (kernel_diff.abs().max() ==0 and kernel_diff.abs().min() == 0):
                self.eps = 0.0
                nu = (1.0+norm1+norm2).sqrt()
                #print("kernel_diff", kernel_diff.shape, kernel_diff.max(), kernel_diff.min())
            else :
                # print("kernel_diff", kernel_diff.shape, kernel_diff.max(), kernel_diff.min())
                norm_diff = torch.fft.fftn(torch.nn.functional.pad(kernel_diff, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()

                self.eps = norm_diff.sqrt()/(4*0.99)
                nu1 = self.eps.clamp(min=1.0)+torch.maximum(norm1.sqrt(), norm2.sqrt())
                nu2 = (1.0+norm1+norm2+self.eps*self.eps).sqrt()
                nu = torch.minimum(nu1, nu2)

            self.step = 0.99/nu



            return(self.step, self.eps)
        else :
            raise NotImplementedError
        

    def get_kernel_unmatched(self):
        self.dirac = self.dirac.to(self.conv_layers[0].weight.device)
        return(self.transpose(self.convolution(self.dirac)))
    
    def get_kernel_transpose_unmatched(self):
        self.dirac = self.dirac.to(self.conv_layers[0].weight.device)
        return(self.convolution_transpose(self.transpose_convolution(self.dirac)))
       
#################################
    


class MultiConvScale3d(nn.Module):
    def __init__(self, num_channels=[1, 64], size_kernels=[3], zero_mean=True, sn_size=256):
        '''

        '''

        super().__init__()
        # parameters and options
        self.size_kernels = size_kernels
        self.num_channels = num_channels
        self.sn_size = sn_size
        self.zero_mean = zero_mean

        
        # list of convolutionnal layers
        self.conv_layers = nn.ModuleList()
        
        self.conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[0], out_channels=num_channels[1], kernel_size=size_kernels[0], padding=size_kernels[0]//2, dilation=1, bias=False), 'kaiming'))

        self.conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[1], out_channels=num_channels[1], kernel_size=size_kernels[0], padding=size_kernels[0]//2, dilation=1, bias=False), 'kaiming'))
        self.conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[1], out_channels=num_channels[1], kernel_size=size_kernels[0], padding=(size_kernels[0]//2)*2, dilation=2, bias=False), 'kaiming'))
        self.conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[1], out_channels=num_channels[1], kernel_size=size_kernels[0], padding=(size_kernels[0]//2)*4, dilation=4, bias=False), 'kaiming'))
        self.conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[1], out_channels=num_channels[1], kernel_size=size_kernels[0], padding=(size_kernels[0]//2)*8, dilation=8, bias=False), 'kaiming'))
        self.conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[1], out_channels=num_channels[1], kernel_size=size_kernels[0], padding=(size_kernels[0]//2)*16, dilation=16, bias=False), 'kaiming'))
        
        self.conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[1], out_channels=num_channels[1], kernel_size=size_kernels[0], padding=size_kernels[0]//2, dilation=1, bias=False), 'kaiming'))

        # cache the estimation of the spectral norm
        self.L = torch.tensor(1., requires_grad=True)
        # cache dirac impulse used to estimate the spectral norm
        self.padding_total = sum([kernel_size//2 for kernel_size in size_kernels])
        self.dirac = torch.zeros((1, 1) + (4 * self.padding_total + 1, 4 * self.padding_total + 1, 4 * self.padding_total + 1))
        self.dirac[0, 0, 2 * self.padding_total, 2 * self.padding_total, 2 * self.padding_total] = 1


    def forward(self, x):
        return(self.convolution(x))

    def convolution(self, x):
        x = nn.functional.conv3d(x, self.conv_layers[0].weight, bias=None, dilation=self.conv_layers[0].dilation, padding=self.conv_layers[0].padding, groups=self.conv_layers[0].groups, stride=self.conv_layers[0].stride)

        x1 = nn.functional.conv3d(x, self.conv_layers[1].weight, bias=None, dilation=self.conv_layers[1].dilation, padding=self.conv_layers[1].padding, groups=self.conv_layers[1].groups, stride=self.conv_layers[1].stride) 
        x2 = nn.functional.conv3d(x, self.conv_layers[2].weight, bias=None, dilation=self.conv_layers[2].dilation, padding=self.conv_layers[2].padding, groups=self.conv_layers[2].groups, stride=self.conv_layers[2].stride) 
        x3 = nn.functional.conv3d(x, self.conv_layers[3].weight, bias=None, dilation=self.conv_layers[3].dilation, padding=self.conv_layers[3].padding, groups=self.conv_layers[3].groups, stride=self.conv_layers[3].stride)
        x4 = nn.functional.conv3d(x, self.conv_layers[4].weight, bias=None, dilation=self.conv_layers[4].dilation, padding=self.conv_layers[4].padding, groups=self.conv_layers[4].groups, stride=self.conv_layers[4].stride)
        x5 = nn.functional.conv3d(x, self.conv_layers[5].weight, bias=None, dilation=self.conv_layers[5].dilation, padding=self.conv_layers[5].padding, groups=self.conv_layers[5].groups, stride=self.conv_layers[5].stride)

        x = (x1+x2+x3+x4+x5)/5
        x = nn.functional.conv3d(x, self.conv_layers[6].weight, bias=None, dilation=self.conv_layers[6].dilation, padding=self.conv_layers[6].padding, groups=self.conv_layers[6].groups, stride=self.conv_layers[6].stride)


   
        return(x)

    def transpose(self, x):
        x = nn.functional.conv_transpose3d(x, self.conv_layers[6].weight, bias = None, padding=self.conv_layers[6].padding, groups=self.conv_layers[6].groups, dilation=self.conv_layers[6].dilation, stride=self.conv_layers[6].stride)
        x=x/5
        x5 = nn.functional.conv_transpose3d(x, self.conv_layers[5].weight, bias = None, padding=self.conv_layers[5].padding, groups=self.conv_layers[5].groups, dilation=self.conv_layers[5].dilation, stride=self.conv_layers[5].stride)
        x4 = nn.functional.conv_transpose3d(x, self.conv_layers[4].weight, bias = None, padding=self.conv_layers[4].padding, groups=self.conv_layers[4].groups, dilation=self.conv_layers[4].dilation, stride=self.conv_layers[4].stride)
        x3 = nn.functional.conv_transpose3d(x, self.conv_layers[3].weight, bias = None, padding=self.conv_layers[3].padding, groups=self.conv_layers[3].groups, dilation=self.conv_layers[3].dilation, stride=self.conv_layers[3].stride)
        x2 = nn.functional.conv_transpose3d(x, self.conv_layers[2].weight, bias = None, padding=self.conv_layers[2].padding, groups=self.conv_layers[2].groups, dilation=self.conv_layers[2].dilation, stride=self.conv_layers[2].stride)
        x1 = nn.functional.conv_transpose3d(x, self.conv_layers[1].weight, bias = None, padding=self.conv_layers[1].padding, groups=self.conv_layers[1].groups, dilation=self.conv_layers[1].dilation, stride=self.conv_layers[1].stride)

        x = x1+x2+x3+x4+x5
        x = nn.functional.conv_transpose3d(x, self.conv_layers[0].weight, bias = None, padding=self.conv_layers[0].padding, groups=self.conv_layers[0].groups, dilation=self.conv_layers[0].dilation, stride=self.conv_layers[0].stride)

        return(x)
    
    def spectral_norm(self, mode="Fourier", n_steps=1000):
        """ Compute the spectral norm of the convolutional layer
                Args:
                    mode: "Fourier" or "power_method"
                        - "Fourier" computes the spectral norm by computing the DFT of the equivalent convolutional kernel. This is only an estimate (boundary effects are not taken into account) but it is differentiable and fast
                        - "power_method" computes the spectral norm by power iteration. This is more accurate and used before testing
                    n_steps: number of steps for the power method
        """

        if mode =="Fourier":
            # temporary set L to 1 to get the spectral norm of the unnormalized filter
            self.L = torch.tensor([1.], device=self.conv_layers[0].weight.device)
            # get the convolutional kernel corresponding to WtW
            kernel = self.get_kernel_WtW()
            # pad the kernel and compute its DFT. The spectral norm of WtW is the maximum of the absolute value of the DFT
            padding = (self.sn_size - 1) // 2 - self.padding_total
            self.L = torch.fft.fftn(torch.nn.functional.pad(kernel, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()
            return(self.L)
        
        elif mode == "power_method":
            self.L = torch.tensor([1.], device=self.conv_layers[0].weight.device)
            u = torch.empty((1, 1, self.sn_size, self.sn_size, self.sn_size), device= self.conv_layers[0].weight.device).normal_()
            with torch.no_grad():
                for _ in range(n_steps):
                    u = self.transpose(self.convolution(u))
                    u = u / torch.linalg.norm(u)

                
                # The largest eigen value can now be estimated in a differentiable way
                sn = torch.linalg.norm(self.transpose(self.convolution(u)))
                self.L = sn
                return sn



    def spectrum(self):
        kernel = self.get_kernel_WtW()
        padding = (self.sn_size - 1) // 2 - self.padding_total
        return(torch.fft.fftn(torch.nn.functional.pad(kernel, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)))
    
    def get_filters(self):
        # we collapse the convolutions to get one kernel per channel
        # this done by computing the response of a dirac impulse
        self.dirac = self.dirac.to(self.conv_layers[0].weight.device)
        kernel = self.convolution(self.dirac)[:,:,self.padding_total:3*self.padding_total+1, self.padding_total:3*self.padding_total+1, self.padding_total:3*self.padding_total+1]
        return(kernel)


    def get_kernel_WtW(self):
        self.dirac = self.dirac.to(self.conv_layers[0].weight.device)
        return(self.transpose(self.convolution(self.dirac)))
    
    def check_tranpose(self):
        """
            Check that the convolutional layer is indeed the transpose of the convolutional layer
        """
        device = self.conv_layers[0].weight.device
        sum_ratio = 0

        for i in range(100):
            x1 = torch.empty((1, 1, 104, 128, 128), device=device).normal_()
            x2 = torch.empty((1, self.num_channels[-1], 104, 128, 128), device=device).normal_()

            ps_1 = (self(x1)*x2).sum()
            ps_2 = (self.transpose(x2)*x1).sum()
            sum_ratio += ps_1.item()/ps_2.item()
          
        print(f"ratio: {sum_ratio/100}")
    



###########################
    

class MultiConv3d2(nn.Module):
    def __init__(self, num_channels=[1, 64], size_kernels=[3], zero_mean=True, sn_size=256):
        '''

        '''

        super().__init__()
        # parameters and options
        self.size_kernels = size_kernels
        self.num_channels = num_channels
        self.sn_size = sn_size
        self.zero_mean = zero_mean

        
        # list of convolutionnal layers
        self.conv_layers = nn.ModuleList()
        self.pad_layers = nn.ModuleList()
        
        for j in range(len(num_channels) - 1):# padding_mode='circular'
            self.conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[j], out_channels=num_channels[j+1], kernel_size=size_kernels[j], padding=size_kernels[j]//2, stride=1, bias=False), 'kaiming')) #, padding_mode='circular'
            self.pad_layers.append(nn.ZeroPad3d(size_kernels[j]//2))
            # # enforce zero mean filter for first conv
            # if zero_mean and j == 0:
            #     P.register_parametrization(self.conv_layers[-1], "weight", ZeroMean())
           


        # cache the estimation of the spectral norm
        self.L = torch.tensor(1., requires_grad=True)
        # cache dirac impulse used to estimate the spectral norm
        self.padding_total = sum([kernel_size//2 for kernel_size in size_kernels])
        self.dirac = torch.zeros((1, 1) + (4 * self.padding_total + 1, 4 * self.padding_total + 1, 4 * self.padding_total + 1))
        self.dirac[0, 0, 2 * self.padding_total, 2 * self.padding_total, 2 * self.padding_total] = 1


    def forward(self, x):
        return(self.convolution(x))

    def convolution(self, x):
        # normalized convolution, so that the spectral norm of the convolutional kernel is 1
        # nb the spectral norm of the convolution has to be upated before
        # x = x / torch.sqrt(self.L)

        for conv, pad in zip(self.conv_layers, self.pad_layers):
            # print("prepad", x.shape)
            x = pad(x)
            weight = conv.weight
            # print(x.shape)
            x = nn.functional.conv3d(x, weight, bias=None, dilation=conv.dilation, padding=0, groups=conv.groups, stride=conv.stride)

            # x = conv(x)
            # print("conv", x.shape)

        return(x)

    def transpose(self, x):
        # normalized transpose convolution, so that the spectral norm of the convolutional kernel is 1
        # nb the spectral norm of the convolution has to be upated before
        # x = x / torch.sqrt(self.L)

        for conv, pad in zip(reversed(self.conv_layers), reversed(self.pad_layers)):
            
            # tmp_conv = nn.ConvTranspose3d(in_channels=conv.weight[0], out_channels=conv.weight[1], kernel_size=conv.weight[-1], padding=conv.weight[-1]//2, stride=1, bias=False) #, padding_mode='circular')
            weight = conv.weight
            # print("prepad", x.shape)
            # x = tmp_conv(x) 
            x = nn.functional.conv_transpose3d(x, weight, bias = None, padding=0, groups=conv.groups, dilation=conv.dilation, stride=conv.stride)
            # print("transpose", x.shape, conv.padding)
            # crop x
            x = x[:,:,conv.padding[0]:-conv.padding[0], conv.padding[1]:-conv.padding[1], conv.padding[2]:-conv.padding[2]]
            # print("transpose cut", x.shape)

        return(x)

    
    def check_tranpose(self):
        """
            Check that the convolutional layer is indeed the transpose of the convolutional layer
        """
        device = self.conv_layers[0].weight.device
        sum_ratio = 0

        for i in range(100):
            x1 = torch.empty((1, 1, 104, 128, 128), device=device).normal_()
            x2 = torch.empty((1, self.num_channels[-1], 104, 128, 128), device=device).normal_()

            ps_1 = (self(x1)*x2).sum()
            ps_2 = (self.transpose(x2)*x1).sum()
            sum_ratio += ps_1.item()/ps_2.item()
          
        print(f"ratio: {sum_ratio/100}")

    
    def spectral_norm(self, mode="Fourier", n_steps=1000):
        """ Compute the spectral norm of the convolutional layer
                Args:
                    mode: "Fourier" or "power_method"
                        - "Fourier" computes the spectral norm by computing the DFT of the equivalent convolutional kernel. This is only an estimate (boundary effects are not taken into account) but it is differentiable and fast
                        - "power_method" computes the spectral norm by power iteration. This is more accurate and used before testing
                    n_steps: number of steps for the power method
        """

        if mode =="Fourier":
            # temporary set L to 1 to get the spectral norm of the unnormalized filter
            self.L = torch.tensor([1.], device=self.conv_layers[0].weight.device)
            # get the convolutional kernel corresponding to WtW
            kernel = self.get_kernel_WtW()
            # pad the kernel and compute its DFT. The spectral norm of WtW is the maximum of the absolute value of the DFT
            padding = (self.sn_size - 1) // 2 - self.padding_total
            sn = torch.fft.fftn(torch.nn.functional.pad(kernel, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()
            sn = torch.ceil(sn)
            self.L = sn
            return(self.L)
        
        elif mode == "power_method":
            self.L = torch.tensor([1.], device=self.conv_layers[0].weight.device)
            u = torch.empty((1, 1, self.sn_size, self.sn_size, self.sn_size), device= self.conv_layers[0].weight.device).normal_()
            with torch.no_grad():
                for _ in range(n_steps):
                    u = self.transpose(self.convolution(u))
                    u = u / torch.linalg.norm(u)

                
                # The largest eigen value can now be estimated in a differentiable way
                sn = torch.linalg.norm(self.transpose(self.convolution(u)))
                sn = torch.ceil(sn)
                self.L = sn
                return sn


    def shifted_spectral_norm(self, scale, shift, mode="Fourier", n_steps=1000):
        """ Compute the spectral norm of the convolutional layer
                Args:
                    mode: "Fourier" or "power_method"
                        - "Fourier" computes the spectral norm by computing the DFT of the equivalent convolutional kernel. This is only an estimate (boundary effects are not taken into account) but it is differentiable and fast
                        - "power_method" computes the spectral norm by power iteration. This is more accurate and used before testing
                    n_steps: number of steps for the power method
        """

        if mode =="Fourier":
            # temporary set L to 1 to get the spectral norm of the unnormalized filter
            self.L = torch.tensor([1.], device=self.conv_layers[0].weight.device)
            # get the convolutional kernel corresponding to WtW
            kernel = scale*self.get_kernel_WtW() + shift*self.dirac
            # pad the kernel and compute its DFT. The spectral norm of WtW is the maximum of the absolute value of the DFT
            padding = (self.sn_size - 1) // 2 - self.padding_total
            sn = torch.fft.fftn(torch.nn.functional.pad(kernel, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()
        
        elif mode == "power_method":
            self.L = torch.tensor([1.], device=self.conv_layers[0].weight.device)
            u = torch.empty((1, 1, self.sn_size, self.sn_size, self.sn_size), device= self.conv_layers[0].weight.device).normal_()
            with torch.no_grad():
                for _ in range(n_steps):
                    u = scale*self.transpose(self.convolution(u)) + shift*u
                    u = u / torch.linalg.norm(u)

                
                # The largest eigen value can now be estimated in a differentiable way
                sn = torch.linalg.norm(self.transpose(self.convolution(u)))
                # self.L = sn
        return torch.ceil(sn)


    # def check_tranpose(self):
    #     """
    #         Check that the convolutional layer is indeed the transpose of the convolutional layer
    #     """
    #     device = self.conv_layers[0].weight.device

    #     for i in range(1):
    #         x1 = torch.empty((1, 1, 40, 40), device=device).normal_()
    #         x2 = torch.empty((1, self.num_channels[-1], 40, 40), device=device).normal_()

    #         ps_1 = (self(x1)*x2).sum()
    #         ps_2 = (self.transpose(x2)*x1).sum()
    #         print(f"ps_1: {ps_1.item()}")
    #         print(f"ps_2: {ps_2.item()}")
    #         print(f"ratio: {ps_1.item()/ps_2.item()}")

    def spectrum(self):
        kernel = self.get_kernel_WtW()
        padding = (self.sn_size - 1) // 2 - self.padding_total
        return(torch.fft.fftn(torch.nn.functional.pad(kernel, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)))
    
    def get_filters(self):
        # we collapse the convolutions to get one kernel per channel
        # this done by computing the response of a dirac impulse
        self.dirac = self.dirac.to(self.conv_layers[0].weight.device)
        kernel = self.convolution(self.dirac)[:,:,self.padding_total:3*self.padding_total+1, self.padding_total:3*self.padding_total+1, self.padding_total:3*self.padding_total+1]
        return(kernel)


    def get_kernel_WtW(self):
        self.dirac = self.dirac.to(self.conv_layers[0].weight.device)
        return(self.transpose(self.convolution(self.dirac)))



    #################################

    
class UnmatchedMultiConv3dUnit(nn.Module):
    def __init__(self, num_channels=[1, 64], size_kernels=[3], zero_mean=True, sn_size=256, i_bCP = False):
        '''

        '''

        super().__init__()
        # parameters and options
        self.size_kernels = size_kernels
        self.num_channels = num_channels
        self.sn_size = sn_size
        self.zero_mean = zero_mean

        
        # list of convolutionnal layers
        self.conv_layers = nn.ModuleList()
        self.transpose_conv_layers = nn.ModuleList()
        
        for j in range(len(num_channels) - 1):
            self.conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[j], out_channels=num_channels[j+1], kernel_size=size_kernels[j], padding=size_kernels[j]//2, stride=1, bias=False), 'kaiming'))
            self.transpose_conv_layers.append(init_weights_conv(nn.Conv3d(in_channels=num_channels[j], out_channels=num_channels[j+1], kernel_size=size_kernels[j], padding=size_kernels[j]//2, stride=1, bias=False), 'kaiming'))
            # # enforce zero mean filter for first conv
            # if zero_mean and j == 0:
            #     P.register_parametrization(self.conv_layers[-1], "weight", ZeroMean())
           


        # cache the estimation of the spectral norm
        if i_bCP:
            self.step = torch.tensor(1., requires_grad=True)
            self.eps  = torch.tensor(1., requires_grad=True)
        else :
            self.L = torch.tensor(1., requires_grad=True)
        self.scal = torch.tensor(1., requires_grad=True)
        # self.l_max = torch.tensor(1., requires_grad=True)
        # self.l_min = torch.tensor(1., requires_grad=True)
        # self.norm_diff = torch.tensor(1., requires_grad=True)
        # cache dirac impulse used to estimate the spectral norm
        self.padding_total = sum([kernel_size//2 for kernel_size in size_kernels])
        self.dirac = torch.zeros((1, 1) + (4 * self.padding_total + 1, 4 * self.padding_total + 1, 4 * self.padding_total + 1))
        self.dirac[0, 0, 2 * self.padding_total, 2 * self.padding_total, 2 * self.padding_total] = 1
        # print("padding total", self.padding_total)
        # print("dirac shape", self.dirac.shape)

    def forward(self, x):
        return(self.convolution(x))

    def convolution(self, x):
        # normalized convolution, so that the spectral norm of the convolutional kernel is 1
        # nb the spectral norm of the convolution has to be upated before
        # x = x / torch.sqrt(self.L)

        for conv in self.conv_layers:
            weight = conv.weight
            x = nn.functional.conv3d(x, weight, bias=None, dilation=conv.dilation, padding=conv.padding, groups=conv.groups, stride=conv.stride)


        return(x)
    
    def transpose_convolution(self, x):
        for conv in self.transpose_conv_layers:
            weight = conv.weight
            x = nn.functional.conv3d(x, weight, bias=None, dilation=conv.dilation, padding=conv.padding, groups=conv.groups, stride=conv.stride)

        return(x/self.scal)

    def transpose(self, x):
        # normalized transpose convolution, so that the spectral norm of the convolutional kernel is 1
        # nb the spectral norm of the convolution has to be upated before
        # x = x / torch.sqrt(self.L)

        for conv in reversed(self.transpose_conv_layers):
            weight = conv.weight
            x = nn.functional.conv_transpose3d(x, weight, bias = None, padding=conv.padding, groups=conv.groups, dilation=conv.dilation, stride=conv.stride)

        return(x/self.scal)
    
    def convolution_transpose(self, x):
        for conv in reversed(self.conv_layers):
            weight = conv.weight
            x = nn.functional.conv_transpose3d(x, weight, bias = None, padding=conv.padding, groups=conv.groups, dilation=conv.dilation, stride=conv.stride)

        return(x)
    
    def spectral_norm(self, mode="Fourier", n_steps=1000):
        """ Compute the spectral norm of the convolutional layer
                Args:
                    mode: "Fourier" or "power_method"
                        - "Fourier" computes the spectral norm by computing the DFT of the equivalent convolutional kernel. This is only an estimate (boundary effects are not taken into account) but it is differentiable and fast
                        - "power_method" computes the spectral norm by power iteration. This is more accurate and used before testing
                    n_steps: number of steps for the power method
        """

        if mode =="Fourier":
            # temporary set L to 1 to get the spectral norm of the unnormalized filter
            self.L = torch.tensor([1.], device=self.conv_layers[0].weight.device)
            # get the convolutional kernel corresponding to WtW
            kernel = 0.5*(self.get_kernel_unmatched() + self.get_kernel_transpose_unmatched())
            # pad the kernel and compute its DFT. The spectral norm of WtW is the maximum of the absolute value of the DFT
            padding = (self.sn_size - 1) // 2 - self.padding_total
            max_sp = torch.fft.fftn(torch.nn.functional.pad(kernel, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()
            # min_sp = torch.fft.fftn(torch.nn.functional.pad(kernel, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().min()
            # print("vp ", torch.topk(torch.fft.fftn(torch.nn.functional.pad(kernel, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().view(1,-1),5, largest=False))
            norm_diff = torch.fft.fftn(torch.nn.functional.pad( self.get_kernel_transpose_unmatched() -self.get_kernel_unmatched(), (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()
            
            # self.L = (max_sp.sqrt() + 0.5*(norm_diff/min_sp.sqrt()))**2
            self.L = (max_sp.sqrt() + 0.5*norm_diff)**2



            return(self.L)
        


      
    def step_CP(self, mode="Fourier", n_steps=1000):
        """ Compute the spectral norm of the convolutional layer
                Args:
                    mode: "Fourier" or "power_method"
                        - "Fourier" computes the spectral norm by computing the DFT of the equivalent convolutional kernel. This is only an estimate (boundary effects are not taken into account) but it is differentiable and fast
                        - "power_method" computes the spectral norm by power iteration. This is more accurate and used before testing
                    n_steps: number of steps for the power method
        """

        if mode =="Fourier":
            # temporary set L to 1 to get the spectral norm of the unnormalized filter
            # get the convolutional kernel corresponding to WtW

            self.dirac = self.dirac.to(self.conv_layers[0].weight.device)
            self.scal = 1.0

            # DT D    
            kernel1 = self.convolution_transpose(self.convolution(self.dirac))
            # pad the kernel and compute its DFT. The spectral norm of WtW is the maximum of the absolute value of the DFT
            padding = (self.sn_size - 1) // 2 - self.padding_total
            norm1 = torch.fft.fftn(torch.nn.functional.pad(kernel1, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()

            # E ET
            kernel2 = self.transpose(self.transpose_convolution(self.dirac))

            # (D + E)T (E + D)
            kernel3 = self.transpose(self.convolution(self.dirac))+self.convolution_transpose(self.transpose_convolution(self.dirac)) + kernel1 + kernel2
            norm2 = torch.fft.fftn(torch.nn.functional.pad(kernel3, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()

            # (D + E) - D 
            norm_diff = torch.fft.fftn(torch.nn.functional.pad(kernel2, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()

            self.eps = norm_diff.sqrt()/(4*0.99)
            self.scal = self.eps.sqrt()

            # E ET
            kernel2 = self.transpose(self.transpose_convolution(self.dirac))

            # (D + E)T (E + D)
            kernel3 = self.transpose(self.convolution(self.dirac))+self.convolution_transpose(self.transpose_convolution(self.dirac)) + kernel1 + kernel2
            norm2 = torch.fft.fftn(torch.nn.functional.pad(kernel3, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()

            # (D + E) - D 
            norm_diff = torch.fft.fftn(torch.nn.functional.pad(kernel2, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)).abs().max()


            nu1 = 1.0+torch.maximum(norm1.sqrt(), norm2.sqrt())
            nu2 = (2.0+norm1+norm2).sqrt()
            nu = torch.minimum(nu1, nu2)

            self.step = 0.99/nu



            return(self.step, 1.0)
        else :
            raise NotImplementedError
        
    
    def spectrum(self):
        kernel = self.get_kernel_unmatched()
        padding = (self.sn_size - 1) // 2 - self.padding_total
        return(torch.fft.fftn(torch.nn.functional.pad(kernel, (padding, padding, padding, padding, padding, padding)), dim = (-3, -2, -1)))
    
    def get_filters(self):
        # we collapse the convolutions to get one kernel per channel
        # this done by computing the response of a dirac impulse
        self.dirac = self.dirac.to(self.conv_layers[0].weight.device)
        kernel = self.convolution(self.dirac)[:,:,self.padding_total:3*self.padding_total+1, self.padding_total:3*self.padding_total+1, self.padding_total:3*self.padding_total+1]
        return(kernel)


    def get_kernel_unmatched(self):
        self.dirac = self.dirac.to(self.conv_layers[0].weight.device)
        print("in get_kernel_unmatched", self.dirac.shape)
        return(self.transpose(self.convolution(self.dirac)))
    
    def get_kernel_transpose_unmatched(self):
        self.dirac = self.dirac.to(self.conv_layers[0].weight.device)
        print("in get_kernel_transpose_unmatched", self.dirac.shape)
        return(self.convolution_transpose(self.transpose_convolution(self.dirac)))
       
