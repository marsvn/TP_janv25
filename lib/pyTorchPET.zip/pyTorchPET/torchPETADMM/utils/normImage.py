"""
Created on March 2023

@author: florent.sureau
"""

import os
from PETLibs import cyReadCastorHisto
import numpy as np
import torch
#import PETLibs.ios.CASToRInterfile
from interfile import Interfile

from torchPETADMM.database import database_sino

def normalize_image(image, alpha=9*1e6):

    '''
    Normalizes a numpy image such that the result is equivalent to:
    .. math::
        g_1(v) = \frac{\alpha}{\sum_jv_j} v

    Arguments:
        - image: Image to normalize (numpy array).
        - alpha: normalization constant (float, default:9*1e6)

    Returns:
        - n_image: Normalized image (numpy array).
        - sum_i: image sum value (float)
    '''

    sum_i = np.sum(image)
    n_image = image / sum_i
    n_image = n_image * alpha

    return n_image, sum_i


def min_max_normalize_image(image):

    '''
    Normalizes a numpy image such that the result is equivalent to:
    .. math::
        g_1(v) = \frac{v - min(v)}{max(v) - min(v)}

    Arguments:
        - image: Image to normalize (numpy array).

    Returns:
        - n_image: Normalized image (numpy array).
        - min_i: image min value (float)
        - max_i: image max value (float)
        - sum_i: image sum value (float)
    '''

    max_i = np.max(image)
    min_i = np.min(image)
    sum_i = np.sum(image)
    n_image = (image - min_i) / (max_i - min_i)

    return n_image, min_i, max_i, sum_i

def denormalize_image(n_image, sum_i, alpha=9*1e6):

    r'''
    Denormalizes a numpy image such that the result is equivalent to:
    .. math::
        g_1^-1(v) = \frac{\sum_j v_j}{\alpha} v

    Arguments:
        - n_image: Image to denormalize (numpy array).
        - sum_i: List of original image sum value.
        - alpha: normalization constant (float, default:9*1e6)

    Returns:
        - image: Denormalized image (numpy array).
    '''

    image = n_image * sum_i
    image = image / alpha

    return image

def normalize_image_torch(image, alpha=9*1e6):

    '''
    Normalizes a pytorch image such that the result is equivalent to:
        g_1(v) = \frac{\alpha}{\sum_jv_j} v

    Arguments:
        - image: Image to normalize (pytorch Tensor).
        - alpha: normalization constant (float, default:9*1e6)

    Returns:
        - n_image: Normalized image (pytorch Tensor).
        - sum_i: image sum value (float)
    '''

    sum_i = torch.sum(image)
    n_image = image / sum_i
    n_image = n_image * alpha

    return n_image, sum_i

def denormalize_image_PROJ3D_AUTOGRAD_BIOGRAPH(n_image, n_iter, init_v, patient, realization, dose, lst_temoins,
                        sino_dir, castor_dir, device, projector, epsilon = 1e-6):

    '''
    Denormalizes an input image using the method proposed by Lim. et al.: maximum likelihood
    estimate of scaling factor using Newton's method. This requires to have access to the dose factor for
    correction sinograms, and therefore the patient id and realization id.
    This assumes that the normalization sinogram only includes 1/number_lors for each bin
    (i.e only span effect, efficiency=1)

    Arguments:
        - n_image: Normalized image (torch.Tensor).
        - n_iter: Number of iterations for ML estimate (int).
        - init_v: Initial value for scaling factor.
        - patient: Patient number (int).
        - realization: realization number (int).
        - dose: Realization dose factor (relative to the image's original dose).
        - lst_temoins: Patient names list (list of strings).
        - sino_dir: correction sinogram location (string).
        - castor_dir: castor file location (string).
        - device: Device used (whether "cpu" or "gpu").
        - epsilon: Epsilon to avoid singularity in algorithm (float, default: 1e-6).
    Returns:
        - image: Resulting denormalized image (torch.Tensor).
        - s: Scaling factor (float).
        - s_all: Evolution of the scaling factor per iteration (list of floats).
    '''

    patient = patient - 1

    deviceGPU = torch.device("cuda:0")
    deviceCPU = torch.device("cpu")

    att_sino,att_hdrname = database_sino.get_att(lst_temoins[patient], sino_dir)
    att_sino_tensor = torch.unsqueeze(torch.unsqueeze(torch.from_numpy(att_sino), 0), 4)
    att_sino_tensor = att_sino_tensor.to(device = device)
    scat_sino = database_sino.get_scat_norm(lst_temoins[patient], sino_dir)
    scat_sino_tensor = torch.unsqueeze(torch.unsqueeze(torch.from_numpy(scat_sino), 0), 4)
    scat_sino_tensor = scat_sino_tensor.to(device = device)
    rd_sino = database_sino.get_rd(lst_temoins[patient], sino_dir)
    rd_sino_tensor = torch.unsqueeze(torch.unsqueeze(torch.from_numpy(rd_sino), 0), 4)
    rd_sino_tensor = rd_sino_tensor.to(device = device)

    calib_hdrname=att_hdrname.replace('_at.s.hdr','_nm.calib.hdr')
    hdr_calib=Interfile.load(calib_hdrname)
    calib_factor=hdr_calib['calibration factor']['value']
    real_hdrname=att_hdrname.replace('_at.s.hdr','_fr0_pt_rep1.s.hdr')
    real_hdr=Interfile.load(real_hdrname)
    calfact_decay=database_sino.compute_decay_correction_factor(real_hdr['image duration']['value'],
                                                  half_life=real_hdr['isotope halflife']['value'],
                                                  branching_ratio=real_hdr['branching factor']['value'])
    calib_total=calib_factor*calfact_decay

    #Read realization sinogram
    fname_dir=castor_dir + "/{}/realization{}-{}".format(lst_temoins[patient], lst_temoins[patient], realization+1)
    hdr_path="realization{}-{}.cdh".format(lst_temoins[patient], realization+1)
    y=cyReadCastorHisto(os.path.join(fname_dir,hdr_path),fname_dir=fname_dir,ZeroFill=True,verbose=False,count=-1)
    y_tensor = torch.unsqueeze(torch.unsqueeze(torch.from_numpy(y), 0), 4)
    y_tensor = y_tensor.to(device = device)

    #Setup path for
    #lut_path="/share/Programs/castor/castor_git/config/scanner/PET_SIEMENS_BIOGRAPH6_TRUEPOINT_TRUEV.lut"
    #castor_lut=np.fromfile(lut_path,dtype="f4", count=- 1)
    #castor_lut=castor_lut.reshape(52,13*48,6)
    #lut,lut_ax=PETLibs.proj.BiographGetLUTs(castor_LUT=castor_lut,compareCastor=True)
    #LUT,LUT_ax = PETLibs.proj.preprocess_lut(lut,lut_ax,dim_vol=[109, 128, 128],vox_size=vox_size,
    #                                             compareCastor=True)
    #tlut = torch.tensor(LUT, dtype = torch.double, device = deviceGPU)
    #tlut_ax = torch.tensor(LUT_ax, dtype = torch.float, device = deviceCPU)
    #tproj_dims=torch.tensor(dim_sino, dtype = torch.float, device = deviceCPU)
    #tvox_size=torch.tensor(vox_size, dtype = torch.float, device = deviceCPU)
    #
    #toffset_list,tcoord_list,toffset2Plane=PETLibs.proj.pet_gpu_3D.planeCoordAxial(tlut_ax,False)
    #tcoordlist_cuda=tcoord_list.cuda()
    #
    #projector = PETLibs.proj.cuTorchProj.PROJ3D_AUTOGRAD(tlut, tcoordlist_cuda,toffset2Plane,toffset_list,tproj_dims,tvox_size,
    #                            outputscale=1.0, blockX=8,blockY=4,blockZ=128,blockGX=16,blockGY=16,blockGZ=560)

    n_image = n_image.to(deviceGPU)
    fw_n_image = projector(n_image)
    fw_n_image = fw_n_image.to(device = device)

    fw_gpu = torch.divide(fw_n_image,att_sino_tensor)
    fw_gpu = torch.where(fw_gpu >= 0, fw_gpu, torch.zeros_like(fw_gpu, dtype = torch.float32))
    fw_gpu/=calib_total

    s = torch.tensor([init_v],device=device,dtype=torch.float32)
    s_all = [s.cpu()]
    for i in range(n_iter):
        fw_n_image_full = (fw_gpu*s + dose*scat_sino_tensor) + dose*dose*rd_sino_tensor
        fraction = fw_gpu/torch.maximum(fw_n_image_full, epsilon*torch.ones_like(fw_n_image_full))
        #A verifier que fw_n_image_full=0=>fw_gpu=0
        #fraction = fw_gpu/fw_n_image_full
        a = torch.sum(fw_gpu - y_tensor*fraction)
        b = torch.sum(y_tensor*fraction*fraction)
        s = s - (a/b)
        s_all.append(s.cpu())

        #del fw_n_image_full, fraction, a, b

    image = n_image.to(deviceCPU) * s

    return image, s, s_all
