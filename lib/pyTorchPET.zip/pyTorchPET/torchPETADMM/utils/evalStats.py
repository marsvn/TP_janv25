"""
Created on March 2023

@author: florent.sureau
"""

import os
import numpy as np
import torch
import matplotlib.pyplot as plt
from tqdm.autonotebook import trange,tqdm
import PETLibs.ios
import PETLibs.utils


def ratio(model, dataset, device):

    '''
    Calculates the ratio of the norm of residue after and before using the NN

    Arguments:
        - model: Neural Network model (class derived from torch.nn.Module)
        - dataset: Dataset wrapping input and target data (torch.utils.data.TensorDataset).
        - device: Device used for prediction (string, possible values: "cpu", "gpu").
    Returns:
        - mean ratio overt Dataset (flat)
        - list of ratio for all elements in dataset
    '''

    torch.cuda.empty_cache()
    model_device= model.to(device)
    model_device.eval()
    test_loader = torch.utils.data.DataLoader(dataset, shuffle = False, batch_size = 1, num_workers=2, pin_memory=True)

    num_val_batches = len(dataset)
    orig_residue_norm = 0
    end_residue_norm = 0
    ratio = 0
    ratio_lst=[]
    with tqdm(total=num_val_batches, desc=f'Calculating Ratio', unit='Sample(s)') as pbar:
        for i, batch in enumerate(test_loader):
            inputs=batch[0]
            labels=batch[1]
            # if norm_sj:
            #     inputs, labels, sum_inputs, sum_labels, alpha = batch
            # elif norm_train:
            #     inputs, labels, patient, realization, dose, init = batch
            # else:
            #     inputs, labels = batch
            inputs = torch.unsqueeze(inputs, dim=1)
            inputs = inputs.to(device=device).float()

            with torch.no_grad():
                output = model_device(inputs)
                pred = output

            test = dataset[i][0]
            test = (test.unsqueeze(0)).to(device = device)
            orig = dataset[i][1]
            orig = (orig.unsqueeze(0)).to(device = device)

            ratio_lst.append(torch.norm(orig - pred)/torch.norm(orig - test))

            orig_residue_norm += torch.norm(orig - test)
            end_residue_norm += torch.norm(orig - pred)
            pbar.update(1)

    orig_residue_norm = orig_residue_norm / len(pred)
    end_residue_norm = end_residue_norm / len(pred)
    ratio = end_residue_norm/orig_residue_norm
    return ratio,ratio_lst

def show_metrics(train_mse, test_mse, train_loss, train_loss_batch,close=True):

    '''
    Displays plots of the Training and Testing Errors (Root Mean Squared Error), the Training Loss per epoch and per batch.

    Arguments:
        - train_mse: Training Error (Root Mean Squared Error) (np.array or list).
        - test_mse: Testing Error (Root Mean Squared Error) (np.array or list).
        - train_loss: Total training Loss (np.array or list).
        - train_loss_batch: Total batch training Loss (np.array or list).
    '''

    fig=plt.figure()
    plt.subplot(2,2,1)
    plt.plot(range(1,len(train_mse)+1),train_mse)
    plt.xlabel("Epochs")
    plt.ylabel("Training Error (MSE)")
    plt.subplot(2,2,2)
    plt.plot(range(1,len(test_mse)+1),test_mse)
    plt.xlabel("Epochs")
    plt.ylabel("Testing Error (MSE)")
    plt.subplot(2,2,3)
    plt.plot(range(1,len(train_loss)+1),train_loss)
    plt.xlabel("Epochs")
    plt.ylabel("Total Training Loss")
    plt.subplot(2,2,4)
    aaa = np.linspace(len(train_loss)/len(train_loss_batch), len(train_loss), num = len(train_loss_batch))
    plt.plot(aaa,train_loss_batch)
    plt.xlabel("Epochs")
    plt.ylabel("Batch Loss (MSE)")
    if close:
        plt.show()
        plt.close()
        return None
    else:
        return fig

def show_metric(metric, epochs = 1, start = 1, xlabel = 'Epochs', ylabel = 'Metric', bl = False,close=True):

    '''
    Displays plot of a metric potentially stored per batch.

    Arguments:
        - metric: array containing the metric value (np.array or list).
        - epochs: number of epochs (int, default: 1).
        - start: starting epoch ("1" or "0").
        - xlabel: label of x axis (string, default: 'Epochs').
        - ylabel: label of y axis (string, default: 'Metric').
        - bl: if batch loss, where each batch is displayed as a fraction of an epoch  (boolean, default: False).
    '''
    fig=plt.figure()
    if start == 0:
        plt.plot(range(len(metric)),metric)
    elif bl:
        aaa = np.linspace(epochs/len(metric),epochs,
                      num=len(metric))
        plt.plot(aaa,metric)
    else:
        plt.plot(range(1,len(metric)+1),metric)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    if close:
        plt.show()
        plt.close()
        return None
    else:
        return fig

def show_metric2(metric1, metric2, start = 1, xlabel = 'Epochs', ylabel = 'Metric', legend1 = None, legend2 = None,close=True):
    '''
    Displays plot of a 2 metrics potentially stored per batch.

    Arguments:
        - metric1: array containing the first metric value (np.array or list).
        - metric2: array containing the second metric value (np.array or list).
        - start: starting epoch ("1" or "0").
        - xlabel: label of x axis (string, default: 'Epochs').
        - ylabel: label of y axis (string, default: 'Metric').
        - legend1:legend for first metric (string, default:None).
        - legend1:legend for second metric (string, default:None).
    '''
    fig=plt.figure()
    if start == 0:
        plt.plot(range(len(metric1)),metric1)
        plt.plot(range(len(metric2)),metric2)
    else:
        plt.plot(range(1,len(metric1)+1),metric1)
        plt.plot(range(1,len(metric2)+1),metric2)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.legend([legend1, legend2])
    if close:
        plt.show()
        plt.close()
        return None
    else:
        return fig
