"""
Created on March 2023

@author: florent.sureau
"""

import os
import PETLibs.ios
import PETLibs.utils
from interfile import Interfile as Interfile
import fnmatch



def display(loader, batch_size = 1, vmax = None, vmin = None):

    '''
    Displays a chosen image in a given dataloader.

    Arguments:
        - loader: Dataloader containing the data (torch.utils.data.DataLoader)
        - batch_size: Dataloader batch size (int, default: 1).
        - vmax: Maximum displayed value (float,default: None).
        - vmin: Minimum displayed value (float,default: None).
    '''

    if batch_size == 1:
        i = 0
        b = int(input("Input sample number (1-{}): ".format(len(list(loader)[0][0])*len(loader)))) - 1
        s = 0
    else:
        i = int(input("Input sample number (1-{}): ".format(len(list(loader)[0][0])*len(loader)))) - 1
        b = i//len(list(loader)[0][0])
        s = i%len(list(loader)[0][0])

    test = list(loader)[b][0][s]
    target = list(loader)[b][1][s]
    _=PETLibs.utils.display3D(test,interpolation='none', vmax = vmax)
    _=PETLibs.utils.display3D(target,interpolation='none', vmax = vmax)

def show_images(database_name, new_dir, vmax = None, vmin = None, lst_subjects=None):

    '''
    Shows an image/multiple images from a given generated database.
    To be tested
    Arguments:
        - database_name: Generated database name (string)
        - new_dir: Generated database location (string)
        - vmax: Maximum displayed value (float, Default value: None).
        - vmin: Minimum displayed value (float, Default value: None).
    '''

    if lst_subjects is None:
        lst_subjects=['j00150','j00169','j00186','j00189','j00200','j00249','j00263','j00337',
                 'j00353','j00363','j00376','j00396','j00403','j00414']

    times = input("Input number of images to show: ")
    for i in range(int(times)):
        title=f"Input Subject: \n"
        for k in range(len(lst_subjects)):
            title+=f"{k} - {lst_subjects[k]}.\n"
        subject_index = input(title)
        subject = lst_subjects[int(subject_index)]
        real = input("Input number of realization: ")

        test_recons_dir = os.path.join(new_dir, f'{database_name}/{subject}')
        real = int(real)

        recondir=os.path.join(test_recons_dir,f'/reconstruction{subject}-{real+1}')
        datafiles = os.listdir(test_recons_dir)
        for file_name in datafiles:
            if fnmatch.fnmatch(file_name,'originaldose-target-{0}-{1}*.hdr'.format(subject,real+1)):
                imrec_hdr=Interfile.load(os.path.join(test_recons_dir,file_name))
                imrec_rep,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(imrec_hdr,test_recons_dir)
                _=PETLibs.utils.display3D(imrec_rep,interpolation='none', vmax = vmax, vmin = vmin,title="Original dose reconstructed and rescaled")
            if fnmatch.fnmatch(file_name,'phantom{0}-red-{1}*.hdr'.format(subject,real+1)):
                imrec_hdr=Interfile.load(os.path.join(test_recons_dir,file_name))
                imrec_rep,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(imrec_hdr,test_recons_dir)
                _=PETLibs.utils.display3D(imrec_rep,interpolation='none', vmax = vmax, vmin = vmin,title="Phantom rescaled")
            if fnmatch.fnmatch(file_name,'realization{0}-{1}*.hdr'.format(subject,real+1)):
                imrec_hdr=Interfile.load(os.path.join(test_recons_dir,file_name))
                imrec_rep,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(imrec_hdr,test_recons_dir)
                _=PETLibs.utils.display3D(imrec_rep,interpolation='none', vmax = vmax, vmin = vmin,title="Noisy data reconstructed")
            if fnmatch.fnmatch(file_name,'reconstruction{0}-{1}.hdr'.format(subject,real+1)):
                imrec_hdr=Interfile.load(os.path.join(test_recons_dir,file_name))
                imrec_rep,_,_,_,_=PETLibs.ios.getNPArrayFromCASToRInterfileHeader(imrec_hdr,test_recons_dir)
                _=PETLibs.utils.display3D(imrec_rep,interpolation='none', vmax = vmax, vmin = vmin,title="Noisy data reconstructed")
