"""
Created on March 2023

@author: florent.sureau
"""

import os
import numpy as np
import torch
from tqdm.autonotebook import trange,tqdm

class JacobianReg_l2(torch.nn.Module):
    '''
    Module used to compute the spectral radius of the Jacobian
    '''

    def __init__(self, max_iter=1, tol=1e-3, verbose=False, eval_mode=False):
        '''
        Initialization of the module

        Arguments:
            - max_iter: maximal number of iterations (int, default: 1)
            - tol: tolerance used to stop the iterations, norm of 2 consecutive spectral norm values (float, default: 1e-3)
            - test_loader: Dataloader containing the testing data (torch.utils.data.DataLoader)
            - verbose: if verbosity enqbled (boolean, default: False).
            - eval_mode: if evaluation mode, i.e. the power iteration is not built as a graph (boolean, default: False).
        '''
        self.max_iter = max_iter
        self.tol = tol
        self.verbose = verbose
        self.eval = eval_mode
        super(JacobianReg_l2, self).__init__()

    def forward(self, x, y):
        '''
        Perform evaluation of the spectral radius of the jacobian dy/dx(x)

        Arguments:
            - x: input where the Jacobian is computed (torch.Tensor).
            - y: output of the operator of which the spectral radius of the Jacobian is computed  (torch.Tensor).

        Returns:
            spectral_radius: last evaluation of spectral radius of Jacobian.
            lst_spectral_radius: list of values of spectral radius of Jacobian across iterations.
        '''
        u = torch.randn_like(x)
        u = u/torch.matmul(u.reshape(u.shape[0], 1, -1), u.reshape(u.shape[0], -1, 1)).view(u.shape[0], 1, 1, 1)

        z_old = torch.zeros(u.shape[0])
        z_all = torch.zeros([self.max_iter, u.shape[0]])
        with tqdm(total=self.max_iter, desc="Power Method",leave=False) as pbar_jac:
            for it in range(self.max_iter-1):
                w = torch.ones_like(y, requires_grad=True)  # Double backward trick. From https://gist.github.com/apaszke/c7257ac04cb8debb82221764f6d117ad
                v = torch.autograd.grad(torch.autograd.grad(y, x, w, create_graph=True), w, u, create_graph=False)[0]  # Ju
                w.detach_()
                v.detach_()
                v, = torch.autograd.grad(y, x, v, retain_graph=True, create_graph=False)  # vtJt
                #v = torch.autograd.grad(torch.autograd.grad(y, x, w, create_graph=True), w, u, create_graph=not self.eval)[0]  # Ju
                #v, = torch.autograd.grad(y, x, v, retain_graph=True, create_graph=not self.eval)  # vtJt

                z = torch.matmul(u.reshape(u.shape[0], 1, -1), v.reshape(v.shape[0], -1, 1)) / torch.matmul(u.reshape(u.shape[0], 1, -1), u.reshape(u.shape[0], -1, 1))
                z_all[it] = z.view(-1).sqrt()
                if it > 0:
                    rel_var = torch.norm(z-z_old)
                    if rel_var < self.tol:
                        break
                z_old = z.clone()
                #if self.verbose:
                #    pbar_jac.write(f"Power iteration at iteration: {it}, val: {z.sqrt()}")

                u = v/torch.matmul(v.reshape(v.shape[0], 1, -1), v.reshape(v.shape[0], -1, 1)).view(v.shape[0], 1, 1, 1)
                pbar_jac.update(1)
                #if self.eval:
                u.detach_()

            w = torch.ones_like(y, requires_grad=True)  # Double backward trick. From https://gist.github.com/apaszke/c7257ac04cb8debb82221764f6d117ad
            v = torch.autograd.grad(torch.autograd.grad(y, x, w, create_graph=True), w, u, create_graph=not self.eval)[0]  # Ju
            v, = torch.autograd.grad(y, x, v, retain_graph=True, create_graph=not self.eval)  # vtJt
            z = torch.matmul(u.reshape(u.shape[0], 1, -1), v.reshape(v.shape[0], -1, 1)) / torch.matmul(u.reshape(u.shape[0], 1, -1), u.reshape(u.shape[0], -1, 1))
            z_all[it] = z.view(-1).sqrt()
            for jt in range(it+1,self.max_iter):
                z_all[jt] = z_all[it]
            if self.verbose:
                pbar_jac.write(f"Power iteration at iteration: {self.max_iter-1}, val: {z.sqrt()}")
            pbar_jac.update(1)
            if self.eval:
                w.detach_()
                v.detach_()
        return z.view(-1).sqrt(), z_all

def compute_reg(out, 
                data_true, 
                model, 
                reg_fun, 
                device, 
                epsilon = 0, 
                eval_mode=False,
                diff=False,
                beta_sj=1.0, 
                precond=None,
                bResNE = False
                ):
    '''
    Perform evaluation of the spectral radius r of the jacobian of (2*model-Id) (tau*out+(1-tau)*target)
    and outputs the maximum of {r,1-epsilon}

    Arguments:
        - out: input where the Jacobian is computed (torch.Tensor).
        - data_true: reference image (torch.Tensor).
        - model: Neural Network model (class derived from torch.nn.Module)
        - reg_fun: module used to compute the Jacobian with power iteration (class derived from torch.nn.Module, e.g. JacobianReg_l2(max_iter=10))
        - device: Device used for training (Possible values: "cpu", "gpu").
        - epsilon: margin used for enforcing the spectral radius <1  (float, default: 0, should be much less than 1).
        - eval_mode: if evaluation mode, i.e. the power iteration is not built as a graph (boolean, default: False).
        - diff: if differentiable penalty (boolean, default: False).
        - beta_sj: if differentiable penalty mode, power in penalty is 1+beta_sj (float, default: 1.0).

    Returns:
        spectral_radius: max spectral radius
        lst_spectral_radius: list of values of all spectral radius of Jacobian across iterations.
    '''
    out_detached = out.detach().type(torch.Tensor)
    true_detached = data_true.detach().type(torch.Tensor)
    out_detached = out_detached.to(device)
    true_detached = true_detached.to(device)

    tau = torch.rand(true_detached.shape[0], 1, 1, 1).type(torch.Tensor)
    tau = tau.to(device)

    out_detached = tau*out_detached+(1-tau)*true_detached
    out_detached.requires_grad_()
    model_run=model #.to(device)

    if precond is not None:

        out_reg = model_run(precond*out_detached)

    else :

        out_reg = model_run(out_detached)

    if precond is not None:
        out_reg = out_reg/precond

    if bResNE:
        out_net_reg = out_detached - out_reg
    else :
        out_net_reg = 2.*out_reg-out_detached
    reg_loss, reg_loss_all = reg_fun(out_detached, out_net_reg)
    if eval_mode:
        return reg_loss.max(), reg_loss_all
    else:
        if diff:
            barrier=torch.maximum(reg_loss-torch.ones_like(reg_loss)+epsilon,torch.zeros_like(reg_loss))
            reg_loss_max=torch.pow(torch.linalg.norm(barrier,2),1+beta_sj)
            print(f"reg_loss={reg_loss},barrier={barrier},reg_loss_max={reg_loss_max}")
        else:
            reg_loss_max = torch.max(torch.pow(reg_loss,2.0), torch.ones_like(reg_loss)-epsilon)
        #print(epsilon,torch.ones_like(reg_loss)-epsilon,reg_loss_max)
        return reg_loss_max, reg_loss_all #return reg_loss_max.max(), reg_loss.max(), reg_loss_all

def compute_reg_with_norm_denorm(out, data_true, model, reg_fun, device, sum_inputs,
    sum_labels, alpha, epsilon = 0, eval_mode=False,diff=False,beta_sj=1.0):
    '''
    Perform evaluation of the spectral radius r of the jacobian of (2*model-Id) (tau*out+(1-tau)*target)
    and outputs the maximum of {r,1-epsilon}. Input images are first denormalized and Jacobian
    includes normalization and denormalization.

    Arguments:
        - out: input where the Jacobian is computed (torch.Tensor).
        - data_true: noise-free image (torch.Tensor).
        - model: Neural Network model (class derived from torch.nn.Module)
        - reg_fun: module used to compute the Jacobian with power iteration (class derived from torch.nn.Module, e.g. JacobianReg_l2(max_iter=10))
        - device: Device used for training (Possible values: "cpu", "gpu").
        - sum_inputs: sum of inputs prior to normalization (float).
        - sum_labels: sum of labels prior to normalization (float).
        - alpha: normalization constant (float).
        - epsilon: margin used for enforcing the spectral radius <1  (float, default: 0, should be much less than 1).
        - eval_mode: if evaluation mode, i.e. the power iteration is not built as a graph (boolean, default: False).
        - diff: if differentiable penalty (boolean, default: False).
        - beta_sj: if differentiable penalty mode, power in penalty is 1+beta_sj (float, default: 1.0).

    Returns:
        spectral_radius: max spectral radius
        lst_spectral_radius: list of values of all spectral radius of Jacobian across iterations.
    '''
    out_detached = out.detach().type(torch.Tensor).to(device) * sum_inputs / alpha #image avant normalisation
    out_detached.requires_grad_()
    true_detached = data_true.detach().type(torch.Tensor).to(device) * sum_labels / alpha  #target avant normalisation
    true_detached.requires_grad_()

    out_detached = out_detached.to(device)
    true_detached = true_detached.to(device)

    tau = torch.rand(true_detached.shape[0], 1, 1, 1).type(torch.Tensor)
    tau = tau.to(device)

    out_detached = tau*out_detached+(1-tau)*true_detached
    out_detached.requires_grad_()
    sum_comb = tau * sum_inputs + (1-tau) * sum_labels
    out_detached_norm = out_detached * alpha / sum_comb #normalisation

    model_run=model.to(device)

    out_reg = model_run(out_detached_norm)
    out_reg = torch.div(out_reg*sum_comb, alpha)#denormalisation

    out_net_reg = 2.*out_reg-out_detached
    reg_loss, reg_loss_all = reg_fun(out_detached, out_net_reg)
    reg_loss_max = torch.max(reg_loss, torch.ones_like(reg_loss)-epsilon)
    if eval_mode:
        return reg_loss.max(), reg_loss_all
    else:
        if diff:
            barrier=torch.maximum(reg_loss-torch.ones_like(reg_loss)+epsilon,torch.zeros_like(reg_loss))
            reg_loss_max=torch.pow(torch.linalg.norm(barrier,2),1+beta_sj)
        else:
            reg_loss_max = torch.max(torch.pow(reg_loss,2.0), torch.ones_like(reg_loss)-epsilon)
        return reg_loss_max, reg_loss_all #return reg_loss_max.max(), reg_loss.max(), reg_loss_all

def compute_reg_norm_mldenorm(out, data_true, model, reg_fun, device, patient, dose,
    lst_subjects,sino_dir,castor_dir, epsilon = 0,eval_mode=False,
     n_iter = 20, init_v = 0.1, alpha = 9*1e6,diff=False,beta_sj=1.0):

    '''
    Perform evaluation of the spectral radius r of the jacobian of (2*model-Id) (tau*out+(1-tau)*target)
    and outputs the maximum of {r,1-epsilon}. Input images are first denormalized and Jacobian
    includes normalization and denormalization using maximum likelihood estimate.

    Arguments:
        - out: input where the Jacobian is computed (torch.Tensor).
        - data_true: noise-free image (torch.Tensor).
        - model: Neural Network model (class derived from torch.nn.Module)
        - reg_fun: module used to compute the Jacobian with power iteration (class derived from torch.nn.Module, e.g. JacobianReg_l2(max_iter=10))
        - device: Device used for training (Possible values: "cpu", "gpu").
        - patient: index of patient considered in list (int).
        - dose: dose factor (float).
        - lst_subjects: list of subjects (list of strings).
        - sino_dir: rootpath where sinograms are saved (string).
        - sino_dir: rootpath where sinograms are saved (string).
        - n_iter: if evaluation mode, i.e. the power iteration is not built as a graph (boolean, default: False).
        - epsilon: margin used for enforcing the spectral radius <1  (float, default: 0, should be much less than 1).
        - eval_mode: if evaluation mode, i.e. the power iteration is not built as a graph (boolean, default: False).
        - diff: if differentiable penalty (boolean, default: False).
        - beta_sj: if differentiable penalty mode, power in penalty is 1+beta_sj (float, default: 1.0).

    Returns:
        spectral_radius: max spectral radius
        lst_spectral_radius: list of values of all spectral radius of Jacobian across iterations.
    '''
    out_detached = out.detach().type(torch.Tensor)
    true_detached = data_true.detach().type(torch.Tensor)
    out_detached = out_detached.to(device)
    true_detached = true_detached.to(device)

    tau = torch.rand(true_detached.shape[0], 1, 1, 1).type(torch.Tensor)
    tau = tau.to(device)

    out_detached = tau*out_detached+(1-tau)*true_detached
    out_detached.requires_grad_()
    print("out_detached: {}".format(out_detached.shape))

    n_inputs, _ = normalize_image_torch(out_detached, alpha)

    model_run=model.to(device)

    n_outputs = model(n_inputs)
    n_outputs2 = torch.transpose(torch.transpose(torch.transpose(n_outputs, 1, 2), 2, 3), 3, 4)
    outputs, _, _ = denormalize_image_PROJ3D_AUTOGRAD(n_outputs2, n_iter, init_v, int(patient.item()), int(dose.item()), lst_subjects, sino_dir,
                                                      device = device)
    #print("outputs: {}".format(outputs.shape))
    out_reg = torch.transpose(torch.transpose(torch.transpose(outputs, 3, 4), 2, 3), 1, 2)
    out_reg = out_reg.to(device = device)
    #out_detached = torch.transpose(torch.transpose(torch.transpose(out_detached, 3, 4), 2, 3), 1, 2)

    #print("out_reg: {}".format(out_reg.shape))
    #print("out_detached: {}".format(out_detached.shape))

    out_net_reg = 2.*out_reg-out_detached
    reg_loss, reg_loss_all = reg_fun(out_detached, out_net_reg)
    if eval_mode:
        return reg_loss.max(), reg_loss_all
    else:
        #print(epsilon)
        #print(torch.ones_like(reg_loss)-epsilon)
        if diff:
            barrier=torch.maximum(reg_loss-torch.ones_like(reg_loss)+epsilon,torch.zeros_like(reg_loss))
            reg_loss_max=torch.pow(torch.linalg.norm(barrier,2),1+beta_sj)
        else:
            reg_loss_max = torch.max(torch.pow(reg_loss,2.0), torch.ones_like(reg_loss)-epsilon)
        #print(reg_loss_max)
        return reg_loss_max.max(), reg_loss.max(), reg_loss_all
