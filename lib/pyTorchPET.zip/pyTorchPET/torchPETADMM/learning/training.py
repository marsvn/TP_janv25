"""
Created on March 2023

@author: florent.sureau
"""

import os
import numpy as np
import torch
import matplotlib.pyplot as plt
import copy,pickle
from . import jacobian
from PETLibs.utils import display3D
import torchPETADMM.utils.normImage as normImage
import torchPETADMM.utils.evalStats as evalStats

from tqdm.autonotebook import trange,tqdm
from torch.utils.tensorboard import SummaryWriter
from torch.utils.tensorboard.summary import hparams as hparams_tb

def copy_grad_and_reset(model,lst_grad, accumulate=True):
    params_model=[(name,p) for name,p in model.named_parameters() ]
    for p in params_model:
        if p[1].requires_grad:
            if(p[1].grad is None):#No gradient flown
                lst_grad[p[0]]=None
            else:#Gradient in p[0]
                if lst_grad[p[0]] is None:#Just copy
                    lst_grad[p[0]]=(p[1].grad.detach()).clone()#Contains gradient
                else:#Check if accumulation or not
                    if p[1].grad is not None:
                        if accumulate:
                            lst_grad[p[0]]+=(p[1].grad.detach()).clone()#Contains accumulated gradient
                        else:
                            lst_grad[p[0]]=(p[1].grad.detach()).clone()#Contains gradient
            p[1].grad=None
        else:
            lst_grad[p[0]]=None
    return lst_grad


def save_scalar_hparams_object(object):
    hparams_dict={}
    if hasattr(object,"__dict__"):
        hparams2=copy.deepcopy(object.__dict__)
        lst_delete=[]
        dict_add={}
        for key in hparams2.keys():
            if torch.is_tensor(hparams2[key]):
                lst_delete+=[key]
            elif isinstance(hparams2[key],list):
                lst_delete+=[key]
                print(f"list {key}")
                for k in range(len(hparams2[key])):
                    new_k=f"{key}_{str(k)}"
                    dict_add[new_k]=hparams2[key][k]
            else:
                if not isinstance(hparams2[key],int) and \
                    not isinstance(hparams2[key],float) and \
                    not isinstance(hparams2[key],str) and \
                    not isinstance(hparams2[key],bool):
                    lst_delete+=[key]
        for key in lst_delete:
            del hparams2[key]
        hparams_dict.update(hparams2)
        hparams_dict.update(dict_add)
        return hparams_dict

#-------------------------------------------------------------------------------
# Class for tensorDatasets with dose redution
#-------------------------------------------------------------------------------
class learningParams():
    '''
    Parameters used for generated tensor datasets with dose reduction.
    '''
    def __init__(self,init_model=None, paramsTensorDataSet=None, epochs=0, learning_rate=0, patience = 0,
        jacobian_reg = False, sj_lambda = 1, sj_iter = 1, eval_jacobian = False,
        sj_eps=0.05, name_save=None,save_dir='./',noisy_jac=False,init_model_name='',
        diff_sj=False,beta_sj=1.0,accumulate_grad=None):
        '''
        Initialization of the parameters used for Database Generation

        Arguments:
            - init_model: torch NN used for initialization (derived class from torch.nn.Module).
            - paramsTensorDataSet: parameters for tensor dataset (tensorDataSetDoserec).
            - epochs: Number of training epochs (int)
            - train_batch_size: Batch size for training (int).
            - test_batch_size: Batch size for testing (int).
            - learning_rate: Learning rate for training (float).
            - patience: Training patience after which the learning rate is decreased if there is no loss improvement (int, default: 0).
            - jacobian_reg: Uses MSE + Jacobian Regularization as loss instead of only MSE (boolean, default: False).
            - sj_lambda: Regularization hyperparameter (float, default: 1).
            - sj_iter: Number of max iterations in Power Iterative Method  (int, default: 1).
            - eval_jacobian: Evaluates the square Jacobian spectral norm every epoch (boolean, default: False).
            - sj_eps: Epsilon in penalty for spectral norm of jacobian (penalizes above 1-epsilon) (float, default: 0.05).
            - name_save: filename of intermediate networks (string, default: None).
            - save_dir: directory where to save intermediate networks and results (string, default: "./").
            - noisy_jac: whether to compute jacobian on random realization around noisy data point (boolean, default: False, ie around denoised).
            - init_model_name: filename of init network (string, default: '').
            - diff_sj: if differentiable penalty for Jacobian (boolean, default: False).
            - beta_sj: if differentiable penalty mode, power in penalty for Jacobian is 1+alpha (float, default: 1.0, ie exponent is 2).
            - accumulate_grad: number of batches to accumulate the grad (int, Default value: None)
        '''
        self._init_model=init_model
        self._init_model_name=init_model_name
        self._paramsTensorDataSet=paramsTensorDataSet
        self._epochs=epochs
        self._learning_rate=learning_rate
        self._patience=patience
        self._jacobian_reg=jacobian_reg
        self._sj_lambda=sj_lambda
        self._sj_iter=sj_iter
        self._eval_jacobian=eval_jacobian
        self._sj_eps=sj_eps
        self._name_save=name_save
        self._save_dir=save_dir
        self._noisy_jac=noisy_jac
        self._diff_sj=diff_sj
        self._beta_sj=beta_sj
        self._accumulate_grad=accumulate_grad

    @property
    def init_model(self):
        return self._init_model
    @property
    def init_model_name(self):
        return self._init_model_name
    @property
    def paramsTensorDataSet(self):
        return self._paramsTensorDataSet
    @property
    def epochs(self):
        return self._epochs
    @property
    def learning_rate(self):
        return self._learning_rate
    @property
    def patience(self):
        return self._patience
    @property
    def jacobian_reg(self):
        return self._jacobian_reg
    @property
    def sj_lambda(self):
        return self._sj_lambda
    @property
    def sj_iter(self):
        return self._sj_iter
    @property
    def eval_jacobian(self):
        return self._eval_jacobian
    @property
    def sj_eps(self):
        return self._sj_eps
    @property
    def name_save(self):
        return self._name_save
    @property
    def save_dir(self):
        return self._save_dir
    @property
    def noisy_jac(self):
        return self._noisy_jac
    @property
    def train_batch_size(self):
        return self.paramsTensorDataSet._train_batch_size
    @property
    def test_batch_size(self):
        return self.paramsTensorDataSet._test_batch_size
    @property
    def norm_sj(self):
        return self.paramsTensorDataSet._norm_sj
    @property
    def normalize(self):
        return self.paramsTensorDataSet._normalize
    @property
    def norm_train(self):
        return self.paramsTensorDataSet._norm_train
    @property
    def norm_denoise(self):
        return self.paramsTensorDataSet._norm_denoise
    @property
    def im_dim_truncate(self):
        dim=self.paramsTensorDataSet.doserecParams.CASToRParams.im_dim
        if self.truncate < dim[0]:
            dim[0]=self.truncate
        return dim
    @property
    def truncate(self):
        return self.paramsTensorDataSet._truncate
    @property
    def alpha(self):
        return self.paramsTensorDataSet._alpha
    @property
    def beta_sj(self):
        return self._beta_sj
    @property
    def diff_sj(self):
        return self._diff_sj
    @property
    def accumulate_grad(self):
        return self._accumulate_grad


    @init_model.setter
    def init_model(self,_init_model):
        self._init_model=_init_model
    @init_model_name.setter
    def init_model_name(self,_init_model_name):
        self._init_model_name=_init_model_name
    @paramsTensorDataSet.setter
    def paramsTensorDataSet(self,_paramsTensorDataSet):
        self._paramsTensorDataSet=_paramsTensorDataSet
    @epochs.setter
    def epochs(self,_epochs):
        self._epochs=_epochs
    @learning_rate.setter
    def learning_rate(self,_learning_rate):
        self._learning_rate=_learning_rate
    @patience.setter
    def patience(self,_patience):
        self._patience=_patience
    @jacobian_reg.setter
    def jacobian_reg(self,_jacobian_reg):
        self._jacobian_reg=_jacobian_reg
    @sj_lambda.setter
    def sj_lambda(self,_sj_lambda):
        self._sj_lambda=_sj_lambda
    @sj_iter.setter
    def sj_iter(self,_sj_iter):
        self._sj_iter=_sj_iter
    @eval_jacobian.setter
    def eval_jacobian(self,_eval_jacobian):
        self._eval_jacobian=_eval_jacobian
    @sj_eps.setter
    def sj_eps(self,_sj_eps):
        self._sj_eps=_sj_eps
    @name_save.setter
    def name_save(self,_name_save):
        self._name_save=_name_save
    @save_dir.setter
    def save_dir(self,_save_dir):
        self._save_dir=_save_dir
    @noisy_jac.setter
    def noisy_jac(self,_noisy_jac):
        self._noisy_jac=_noisy_jac
    @beta_sj.setter
    def beta_sj(self,_beta_sj):
        self._beta_sj=_beta_sj
    @diff_sj.setter
    def diff_sj(self,_diff_sj):
        self._diff_sj=_diff_sj
    @accumulate_grad.setter
    def accumulate_grad(self,_accumulate_grad):
        self._accumulate_grad=_accumulate_grad

    def save(self,params_fpath):
        '''
        Save the current class parameters using pickle.

        Arguments:
            - params_fpath: filepath to save the parameters (string).
        '''
        with open(params_fpath,"wb") as handle:
            pickle.dump(self.__dict__,handle,protocol=pickle.HIGHEST_PROTOCOL)

    def load(self,params_fpath):
        '''
        Load and update instance using pickle.

        Arguments:
            - params_fpath: filepath where the parameters are saved (string).
        '''
        with open(params_fpath,"rb") as handle:
            tmp=pickle.load(handle)
        self.__dict__.update(tmp)


def estimate_sj(model, dataloader, device, paramsTraining, data = '0', show = False,
                verbose=False,device_to="cuda"):

    '''
    Estimates the model's Jacobian spectral norm on the test set, in eval mode.

    Arguments:
        - model: Neural Network model (class derived from torch.nn.Module)
        - dataloader: Dataloader containing the data (torch.utils.data.DataLoader)
        - device: Device used for estimation (Possible values: "cpu", "gpu").
        - paramsTraining: parameters for training (learningParams).
        - data: naming of tqdm bar (string, default: '0').
        - show: whether to show estimates of spectral radius for all iterations and all images  (boolean, default: False).
        - verbose: verbosity (boolean, default: False)
        - device_to: device used to compute spectral norm of jacobian (string, among "cpu","cuda").

    Returns:
        - sj_norm: Final estimate of the the model's square Jacobian spectral norm.
        - sj_norm_all: The model's square Jacobian spectral norm over the iterations.
    '''
    if not isinstance(paramsTraining,learningParams):
        raise TypeError("paramsTraining type is not learningParams ")

    sj_iter=paramsTraining.sj_iter
    norm_sj=paramsTraining.norm_sj
    norm_train=paramsTraining.norm_train
    noisy_jac=paramsTraining.noisy_jac

    torch.cuda.empty_cache()
    model.eval()
    model_to=copy.deepcopy(model).to(device_to)

    reg_fun = jacobian.JacobianReg_l2(max_iter=sj_iter, eval_mode=True,verbose=verbose)

    num_val_batches = len(dataloader)
    sj_norm = 0
    sj_norm_all = np.zeros(sj_iter)

    if data == 'Training Data':
        expression = f'Jacobian Spectral Norm Estimation (Training Data)'
    elif data == 'Testing Data':
        expression = f'Jacobian Spectral Norm Estimation (Testing Data)'
    else:
        expression = f'Jacobian Spectral Norm Estimation'
    with tqdm(total=num_val_batches, desc=expression, unit='Sample(s)') as pbar:
        for batch in dataloader:
            if norm_sj:
                inputs, labels, sum_inputs, sum_labels, alpha = batch
            elif norm_train:
                inputs, labels, patient, realization, dose, init = batch
            else:
                inputs, labels = batch

            inputs = torch.unsqueeze(inputs, dim=1)
            inputs=inputs.to(device=device_to).float()
            labels=labels.to(device=device_to).float()

            with torch.no_grad():
                if norm_train:
                    lst_subjects=paramsTraining.paramsTensorDataSet.doserecParams.lst_subjects_reduced
                    dbase_dir = paramsTraining.paramsTensorDataSet.doserecParams.dbase_dir #"/share/Programs/MRI_processing/freesurfer/subjects/"
                    dbase_dir2 = paramsTraining.paramsTensorDataSet.doserecParams.gen_dir #"/data/dsk1/latreche/database_test"
                    n_iter = paramsTraining.paramsTensorDataSet.n_iter_ML #20
                    alpha = paramsTraining.alpha

                    n_inputs, _ = normImage.normalize_image_torch(inputs, alpha)
                    n_outputs = model(n_inputs)
                    n_outputs2 = torch.transpose(torch.transpose(torch.transpose(n_outputs, 1, 2), 2, 3), 3, 4)
                    pred, _, _ = normImage.denormalize_image_PROJ3D_AUTOGRAD(n_outputs2, n_iter, int(init.item()),
                                    int(patient.item()), int(realization.item()), int(dose.item()), lst_subjects,
                                                            dbase_dir, dbase_dir2, test_dir, device = device)
                    pred = torch.transpose(torch.transpose(torch.transpose(pred, 3, 4), 2, 3), 1, 2)
                    pred = pred.to(device = device_to)
                    labels = torch.unsqueeze(labels, dim=1)
                else:
                    if noisy_jac:
                        pred=inputs
                    else:
                        pred = model_to(inputs)
                    labels = torch.unsqueeze(labels, dim=1)

            if norm_train:
                reg_loss, reg_loss_all = jacobian.compute_reg_norm_mldenorm(pred, labels, model_to,
                                     reg_fun, device_to, patient, dose, alpha, eval_mode = True)
            else:
                reg_loss, reg_loss_all = jacobian.compute_reg(pred, labels, model_to,
                                    reg_fun, device = device_to, eval_mode = True)


            reg_loss = reg_loss.detach().cpu().numpy()
            sj_norm = max(sj_norm, reg_loss)
            reg_loss_all = reg_loss_all.detach().cpu().numpy()
            for i in range(sj_iter):
                sj_norm_all[i] = max(sj_norm_all[i], reg_loss_all[i])
            if show:
                plt.plot(range(1, sj_iter+1), reg_loss_all)

            pbar.update(1)
            del inputs, labels, pred, reg_loss, reg_loss_all
    print(f"sj_norm_max={sj_norm}")

    if show:
        plt.axhline(y = sj_norm)
        '''
        legend = []
        for i in range(num_val_batches):
            legend.append('Sample {}'.format(i+1))
        legend.append('Maximum Value over all Iterations')
        plt.legend(legend)
        '''
    model.train()
    return sj_norm, sj_norm_all


def evaluate(model, dataloader, paramsTraining, device):

    '''
    Evaluates the model's RMSE on the test set.

    Arguments:
        - model: Neural Network model (class derived from torch.nn.Module)
        - dataloader: Dataloader containing the data (torch.utils.data.DataLoader)
        - paramsTraining: parameters for training (learningParams).
        - device: Device used for evaluation (string, possible values: "cpu", "gpu")

    Returns:
        - mse: Testing Error (Mean Squared Error over batches and pixels).
    '''
    if not isinstance(paramsTraining,learningParams):
        raise TypeError("paramsTraining type is not learningParams ")

    torch.cuda.empty_cache()
    model.eval()

    criterion = torch.nn.MSELoss()
    norm_sj=paramsTraining.norm_sj
    norm_train=paramsTraining.norm_train
    num_val_batches = len(dataloader)

    mse = 0

    with tqdm(total=num_val_batches, desc='Validation', unit='Sample(s)',leave=False) as pbar_eval:
        for batch in dataloader:
            if norm_sj:
                inputs, labels, sum_inputs, sum_labels, alpha = batch
            elif norm_train:
                inputs, labels, patient, realization, dose, init = batch
            else:
                inputs, labels = batch
            inputs = torch.unsqueeze(inputs, dim=1)
            inputs=inputs.to(device=device).float()
            labels=labels.to(device=device).float()

            with torch.no_grad():
                if norm_train:
                    lst_subjects=paramsTraining.paramsTensorDataSet.doserecParams.lst_subjects_reduced
                    dbase_dir = paramsTraining.paramsTensorDataSet.doserecParams.dbase_dir #"/share/Programs/MRI_processing/freesurfer/subjects/"
                    dbase_dir2 = paramsTraining.paramsTensorDataSet.doserecParams.gen_dir #"/data/dsk1/latreche/database_test"
                    n_iter = paramsTraining.paramsTensorDataSet.n_iter_ML #20
                    alpha = paramsTraining.alpha

                    n_inputs, _ = normImage.normalize_image_torch(inputs, alpha)
                    n_outputs = model(n_inputs)
                    n_outputs2 = torch.transpose(torch.transpose(torch.transpose(n_outputs, 1, 2), 2, 3), 3, 4)
                    pred, _, _ = normImage.denormalize_image_PROJ3D_AUTOGRAD(n_outputs2, n_iter, int(init.item()),
                                            int(patient.item()), int(realization.item()), int(dose.item()),
                                            lst_subjects, dbase_dir, dbase_dir2, device = device)
                    pred = torch.transpose(torch.transpose(torch.transpose(pred, 3, 4), 2, 3), 1, 2)
                    pred = pred.to(device = device)
                    labels = torch.unsqueeze(labels, dim=1)
                    loss = criterion(pred, labels)
                    mse += loss.item()
                else:
                    pred = model(inputs)
                    labels = torch.unsqueeze(labels, dim=1)
                    loss = criterion(pred, labels)
                    mse += loss.item()

            pbar_eval.update(dataloader.batch_size)

    model.train()

    if num_val_batches != 0:
        return mse / num_val_batches
    else:
        return mse

def predict(model, im_tensor, device):

    '''
    Predicts the model's output of the given image

    Arguments:
        - model: Neural Network model (class derived from torch.nn.Module)
        - im_tensor: Image given for prediction (torch.Tensor with correct dimension for model input).
        - device: Device used for prediction (string, possible values: "cpu", "gpu").

    Returns:
        - pred: Predicted image (torch.Tensor).
    '''
    im_tensor = im_tensor.to(device=device, dtype=torch.float32)
    model.eval()
    with torch.no_grad():
        output = model(im_tensor)

    return output

def predict_np(model, image, device):

    '''
    Predicts the model's output of the given image

    Arguments:
        - model: Neural Network model (class derived from torch.nn.Module)
        - image: Image given for prediction (3D numpy array).
        - device: Device used for prediction (string, possible values: "cpu", "gpu").

    Returns:
        - pred: Predicted image (np.array).
    '''
    inputt = torch.tensor(image,device=device,dtype=torch.float32)
    inputt = inputt.unsqueeze(0)
    inputt = inputt.unsqueeze(0)
    output=predict(model, inputt, device).detach().cpu().numpy()

    return np.squeeze(output)

def predict_all(model, dataset, paramsTraining, device, verbose = True):

    '''
    Predicts all the images of the given dataset.

    Arguments:
        - model: Neural Network model (class derived from torch.nn.Module)
        - dataset: Dataset wrapping input and target data (torch.utils.data.TensorDataset).
        - paramsTraining: parameters for training (learningParams).
        - device: Device used for prediction (string, possible values: "cpu", "gpu").
        - verbose: Shows the prediction's advancement (boolean, default: True).
    Returns:
        - pred: Predicted dataset (numpy array).
    '''
    if not isinstance(paramsTraining,learningParams):
        raise TypeError("paramsTraining type is not learningParams ")

    model.eval()

    loader_args = dict(batch_size=1, num_workers=2, pin_memory=True)
    dataloader = torch.utils.data.DataLoader(dataset, shuffle=False, **loader_args)
    num_val_batches = len(dataloader)
    im_dim=paramsTraining.im_dim_truncate
    pred = torch.zeros(num_val_batches,im_dim[0] ,im_dim[1], im_dim[2])

    with tqdm(total=num_val_batches, desc=f'Prediction', unit='Sample(s)', disable = not verbose) as pbar:
        for i, batch in enumerate(dataloader):

            inputs, labels = batch
            inputs = torch.unsqueeze(inputs, dim=1)
            inputs=inputs.to(device=device).float()

            with torch.no_grad():
                output = model(inputs)
                pred[i] = output

            pbar.update(1)

    return pred

def train(device, 
          model,
          paramsTraining, 
          train_loader, 
          test_loader, 
          dataset,
          show = True, 
          show_sj = True,
          twriter=False,
          tlog_dir=None,
          model_name=None,
          compute_grad_norms=False
          ):
    '''
    Trains the given model on the training data either on the MSE or the MSE + Jacobian Regularization.
    Evaluates on the testing data, estimates the testing RMSE and the square Jacobian Spectral Norm.

    Arguments:
        - device: Device used for training (Possible values: "cpu", "gpu").
        - model: Neural Network model (class derived from torch.nn.Module)
        - paramsTraining: parameters for training (learningParams).
        - train_loader: Dataloader containing the training data (torch.utils.data.DataLoader)
        - test_loader: Dataloader containing the testing data (torch.utils.data.DataLoader)
        - dataset: Dataset wrapping input and target data (torch.utils.data.TensorDataset).
        - show: Plots training and evaluation metrics on every epoch (boolean, default: True).
        - show_sj: Plots square jacobian spectral norm evolution on every epoch (boolean, default: True).
        - twriter: tensorboard writer on (boolean, Default value: False)
        - tlog_dir: tensorboard writer save directory (Default value: None)
        - model_name: name of model for tensorboard writer (string, Default value: None)
        - device: Device used for training (Possible values: "cpu", "gpu").
        - compute_grad_norms: compute norm of both cost function term (boolean, Default value: False)
    Returns:
        - dictionary of learning metrics:
            - train_mse: Training Error (Mean Squared Error) (list of floats).
            - test_mse: Testing Error (Mean Squared Error) (list of floats).
            - train_loss: Total training Loss (list of floats).
            - train_loss_batch: Total batch training Loss (list of floats).
            - train_loss_mse: Training Mean Squared Error Loss (list of floats).
            - train_loss_reg: Training Jacobian Regularization Loss (list of floats).
            - spectral_jacobian_train: Training square Jacobian spectral norm (list of floats).
            - spectral_jacobian_test: Testing square Jacobian spectral norm (list of floats).
    '''

    train_batch_size=paramsTraining.train_batch_size
    test_batch_size=paramsTraining.test_batch_size
    noisy_jac=paramsTraining.noisy_jac
    if paramsTraining.accumulate_grad is None or paramsTraining.accumulate_grad<1:
        nBatchesAcc=1
        accumulate_grad=0
    else:
        nBatchesAcc=paramsTraining.accumulate_grad
        accumulate_grad=nBatchesAcc

    torch.cuda.empty_cache()
    n_batch_train = len(train_loader)
    n_train = n_batch_train*train_batch_size
    n_batch_test = len(test_loader)
    n_test = n_batch_test*test_batch_size
    diff_sj=paramsTraining.test_batch_size
    test_batch_size=paramsTraining.test_batch_size

    criterion = torch.nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), paramsTraining.learning_rate)
    if paramsTraining.patience != 0:
        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, 'min',
                        patience = paramsTraining.patience, verbose = True)
    optimizer.zero_grad()

    if paramsTraining.jacobian_reg:#call to jacobian regularization
        reg_fun = jacobian.JacobianReg_l2(max_iter=paramsTraining.sj_iter, verbose=True)

    diff_sj=paramsTraining.diff_sj
    beta_sj=paramsTraining.beta_sj

    if twriter is True:
        writer=SummaryWriter(log_dir=os.path.join(tlog_dir,model_name))
        hparams_dict={}
        hparams_dict["n_batch_train"]=n_batch_train
        hparams_dict["n_batch_test"]=n_batch_test
        hparams_dict["n_train"]=n_train
        hparams_dict["n_test"]=n_test
        hparams_dict["model"]=model_name
        hparams_dict["diff_sj"]=diff_sj
        hparams2=save_scalar_hparams_object(paramsTraining)
        print(f"hparams2={hparams2}")
        hparams_dict.update(hparams2)
        print(f"hparams_dict={hparams_dict}")
    train_loss = []
    train_loss_mse = []
    train_loss_reg = []
    train_loss_batch = []
    test_mse = []
    spectral_jacobian_train = []
    spectral_jacobian_test = []

    if paramsTraining.name_save is not None:
        if paramsTraining.jacobian_reg is True:
            torch.save(model, os.path.join(paramsTraining.save_dir, paramsTraining.name_save.replace(".pth",
                            f"_sjlam{paramsTraining.sj_lambda}_sjiter{paramsTraining.sj_iter}_init.pth")))
        else:
            torch.save(model, os.path.join(paramsTraining.save_dir, paramsTraining.name_save.replace(".pth",
                            f"_init.pth")))

    if paramsTraining.eval_jacobian:
        j1, j1_all = estimate_sj(model, train_loader, device, paramsTraining,
                                    show = False, data = 'Training Data',device_to=device)
        spectral_jacobian_train.append(j1)
        print(f"Eval train Model.is_cuda={next(model.parameters()).is_cuda}")
        if show_sj or twriter is True:
            fig=plt.figure()
            plt.plot(range(1, paramsTraining.sj_iter+1), j1_all)
            plt.xlabel('Iterations')
            plt.ylabel('Jacobian Spectral Norm (Training Data)')
            if twriter is True:
                writer.add_figure("Max Jacobian Training set",fig,global_step=0,close=True)
            else:
                plt.show()
                plt.close()

    if paramsTraining.jacobian_reg:
        j2, j2_all = estimate_sj(model, test_loader, device, paramsTraining,
            show = False, data = 'Testing Data',device_to=device)
        spectral_jacobian_test.append(j2)
        print(f"Eval test Model.is_cuda={next(model.parameters()).is_cuda}")

        if show_sj or twriter is True:
            fig=plt.figure()
            plt.plot(range(1, paramsTraining.sj_iter+1), j2_all)
            plt.xlabel('Iterations')
            plt.ylabel('Jacobian Spectral Norm (Testing Data)')
            if twriter is True:
                writer.add_figure("Max Jacobian Test set",fig,global_step=0,close=True)
            else:
                plt.show()
                plt.close()

    params_model=[(name,p) for name,p in model.named_parameters() ]
    if accumulate_grad>0:
        lst_mse_grad={}
        lst_jac_grad={}
        for p in params_model:
            lst_mse_grad[p[0]]=None
            lst_jac_grad[p[0]]=None
    params_diff=[(name,p) for name,p in model.named_parameters() if p.requires_grad]
    print([name for name,p in params_diff])

    with tqdm(total=paramsTraining.epochs, desc='Training') as pbar_epoch:
        for epoch in range(1,paramsTraining.epochs+1):
            model.train()
            epoch_loss = 0 #mean total loss for each epoch
            epoch_reg_loss_max = 0#max spectral radius over one epoch
            epoch_loss_reg = 0  #mean Jac loss for each epoch
            jac_batch_max=0 #max spectral radius for batch
            epoch_train_mse = 0 #mean MSE loss for each epoch
            epoch_batch_mse=0 #MSE loss for each batch

            test_eval=0
            curBatchAcc=0
            reg_loss_val_max=0
            with tqdm(total=n_train, desc='Batch Training',leave=False) as pbar_batch:
                for i, batch in enumerate(train_loader):

                    ###########################################################
                    # GET DATA
                    ###########################################################
                    if paramsTraining.norm_sj:
                        inputs, labels, sum_inputs, sum_labels, alpha = batch
                    elif paramsTraining.norm_train:
                        inputs, labels, patient, realization, dose, init = batch
                        #inputs, labels non normalisés avec variation de dose
                        #dose=rapport avec l'image de départ
                        #dose utile pour le fwd model -sinogrammes de correction
                    else:
                        inputs, labels = batch
                        sum_inputs = torch.zeros(1)
                        sum_labels = torch.zeros(1)
                        alpha = torch.zeros(1)


                    ###########################################################
                    # PREPROCESS DATA + MODEL
                    ###########################################################

                    inputs = torch.unsqueeze(inputs, dim=1)
                    labels = torch.unsqueeze(labels, dim=1)

                    inputs = inputs.to(device = device)
                    labels = labels.to(device = device)
                    if paramsTraining.norm_sj:#normalisation dans dataloader
                        sum_inputs = sum_inputs.to(device = device)
                        sum_labels = sum_labels.to(device = device)
                        alpha = alpha.to(device = device)
                    elif paramsTraining.norm_train:#pas de normalisation, acces dose
                        patient = patient.to(device = device)
                        realization = patient.to(device = device)
                        dose = dose.to(device = device)
                        init = init.to(device = device)

                    if paramsTraining.norm_train:
                        lst_subjects=paramsTraining.paramsTensorDataSet.doserecParams.lst_subjects_reduced
                        dbase_dir = paramsTraining.paramsTensorDataSet.doserecParams.dbase_dir #"/share/Programs/MRI_processing/freesurfer/subjects/"
                        dbase_dir2 = paramsTraining.paramsTensorDataSet.doserecParams.gen_dir #"/data/dsk1/latreche/database_test"
                        n_iter = paramsTraining.paramsTensorDataSet.n_iter_ML #20
                        alpha = paramsTraining.alpha

                        n_inputs, _ = normImage.normalize_image_torch(inputs, alpha)
                        n_outputs = model(n_inputs) #nbatch=1, nfeatures=1,nz,ny,nx
                        #print(n_outputs.shape)
                        n_outputs2 = torch.transpose(torch.transpose(torch.transpose(n_outputs, 1, 2), 2, 3), 3, 4)
                        #nbatch=1 nz ny nx nfeatures=1
                        #print(n_outputs2.shape)
                        outputs, _, _ = normImage.denormalize_image_PROJ3D_AUTOGRAD(n_outputs2, n_iter, int(init.item()),
                                    int(patient.item()), int(realization.item()),int(dose.item()), lst_subjects,
                                    dbase_dir, dbase_dir2, test_dir, device = device)
                        outputs = torch.transpose(torch.transpose(torch.transpose(outputs, 3, 4), 2, 3), 1, 2)
                        outputs = outputs.to(device = device)
                    else:
                        outputs = model(inputs)
                    if twriter==True and epoch==1 and i==0:
                        writer.add_graph(model,inputs)

                    ###########################################################
                    # HANDLE MSE
                    ###########################################################
                    loss = criterion(outputs, labels)
                    curBatchAcc+=1
                    #START WITH MSE
                    loss_batch_mse=loss #For current sample in batch
                    epoch_batch_mse += loss.item()#For all epoch
                    train_loss_batch.append(loss.item())#For current sample
                    if accumulate_grad>0:
                        loss_batch_mse.backward()#No need to retain graph as the second loss will not use output
                        #Store Grad and reset
                        lst_mse_grad=copy_grad_and_reset(model,lst_mse_grad,accumulate=True)

                    if twriter is True:
                        writer.add_scalar("Loss/Batch_Train_MSE",loss.item(),global_step=(epoch-1)*n_batch_train+i)

                    ###########################################################
                    # HANDLE JACOBIAN REGULARIZATION
                    ###########################################################

                    if paramsTraining.jacobian_reg:
                        torch.cuda.empty_cache()
                        if noisy_jac:
                            input_jac=inputs
                        else:
                            input_jac=outputs
                        if paramsTraining.norm_sj:
                            reg_loss_max, reg_loss_all = jacobian.compute_reg_with_norm_denorm(input_jac, labels, model, reg_fun,
                                                                device, sum_inputs, sum_labels, alpha,epsilon=paramsTraining.sj_eps,
                                                                diff=diff_sj,beta_sj=beta_sj)
                            #1) denormalisation des données/targets normalisées (g1^-1)
                            #2) dans calcul jacobien: combinaison convexe, normalisation (g1), modele, denormalisation (g1^-1) (pas teste)
                            if show_sj or twriter is True:#Evolution pour chaque sample du rayon spectral au cours des itérations
                                fig=plt.figure()
                                plt.plot(range(1, paramsTraining.sj_iter+1), reg_loss_all.detach().cpu().numpy())
                                plt.xlabel('Iterations')
                                plt.ylabel('Jacobian Spectral Norm (Training Data Sample {})'.format(i+1))
                                if twriter is True:
                                    if i==0:
                                        writer.add_figure("Jacobian Training batch 0",fig,global_step=epoch-1,close=True)
                                    else:
                                        plt.close()
                                else:
                                    plt.show()
                                    plt.close()

                        elif paramsTraining.norm_train:
                            reg_loss_max, reg_loss_all = jacobian.compute_reg_norm_mldenorm(input_jac, labels, model, reg_fun,
                                                                device, patient, dose, alpha,epsilon=paramsTraining.sj_eps,
                                                                diff=diff_sj,beta_sj=beta_sj)
                            #dans calcul jacobien: combinaison convexe, normalisation g1, modele, denormalisation g2 (pas teste)
                            if show_sj or twriter is True:#Evolution pour chaque sample du rayon spectral au cours des itérations
                                fig=plt.figure()
                                plt.plot(range(1, paramsTraining.sj_iter+1), reg_loss_all.detach().cpu().numpy())
                                plt.xlabel('Iterations')
                                plt.ylabel('Jacobian Spectral Norm (Training Data Sample {})'.format(i+1))
                                if twriter is True:
                                    if i==0:
                                        writer.add_figure("Jacobian Training batch 0",fig,global_step=epoch-1,close=True)
                                    else:
                                        plt.close()
                                else:
                                    plt.show()
                                    plt.close()

                        else:
                            reg_loss_max, reg_loss_all = jacobian.compute_reg(input_jac, labels, model, reg_fun,
                                                                               device,epsilon=paramsTraining.sj_eps,
                                                                               diff=diff_sj,beta_sj=beta_sj)
                            #dans calcul jacobien: combinaison convexe (données normalisées avec g1), modele
                            #combinaison convexe, estimation jacobian
                            if show_sj or twriter is True:#Evolution pour chaque sample du rayon spectral au cours des itérations
                                fig=plt.figure()
                                plt.plot(range(1, paramsTraining.sj_iter+1), reg_loss_all.detach().cpu().numpy())
                                plt.xlabel('Iterations')
                                plt.ylabel('Jacobian Spectral Norm (Training Data Sample {})'.format(i+1))
                                if twriter is True:
                                    if i==0:
                                        writer.add_figure("Jacobian Training batch 0",fig,global_step=epoch-1,close=True)
                                    else:
                                        plt.close()
                                else:
                                    plt.show()
                                    plt.close()
                        torch.cuda.empty_cache()
                        jac_loss_val=reg_loss_max.detach().cpu().numpy()
                        reg_loss_val=paramsTraining.sj_lambda*reg_loss_max
                        if twriter is True:
                            writer.add_scalar("Loss/Batch_Train_S2RadiusJacobian",jac_loss_val,global_step=(epoch-1)*n_batch_train+i+1-curBatchAcc)
                            writer.add_scalar("Loss/Batch_Train_S2RadiusJacobian",jac_loss_val,global_step=(epoch-1)*n_batch_train+i)

                        #print(f"Compute grad of batch {i} ({jac_loss_val}>?{jac_batch_max})")
                        if accumulate_grad>0:
                            if jac_loss_val>jac_batch_max:#Recompute the grad of reg
                                print(f"Compute grad of batch {i} ({jac_loss_val}>{jac_batch_max})")
                                reg_loss_val.backward(retain_graph=False)
                                lst_jac_grad=copy_grad_and_reset(model,lst_jac_grad,accumulate=False)
                                jac_batch_max=jac_loss_val.item()
                                epoch_reg_loss_max = max(epoch_reg_loss_max, jac_batch_max)
                        else:
                            epoch_reg_loss_max = max(epoch_reg_loss_max, jac_loss_val.item())
                    else:
                        reg_loss_val=torch.tensor(0.0)

                    ###########################################################
                    # UPDATE BATCH STATS
                    ###########################################################

                    if (curBatchAcc)%nBatchesAcc == 0 or i+1== len(train_loader):
                        if accumulate_grad>0:
                            lst_grad_mse_norm=[]
                            lst_grad_jac_norm=[]
                            lst_grad_total_norm=[]
                            #Add gradients with proper rescaling and compute their norm2
                            for p in params_model:
                                if lst_mse_grad[p[0]] is not None:
                                    #print(f"lst_mse_grad: {p[0]}")
                                    p[1].grad=lst_mse_grad[p[0]].clone()/(curBatchAcc)
                                    #Take norm2
                                    val_grad_mse=lst_mse_grad[p[0]].clone()/(curBatchAcc)
                                    lst_grad_mse_norm.append(val_grad_mse.norm(2).item())
                                elif p[1].requires_grad:
                                    lst_grad_mse_norm.append(0.);
                            if paramsTraining.jacobian_reg:
                                for p in params_model:
                                    if lst_jac_grad[p[0]] is not None:
                                        #print(f"lst_jac_grad: {p[0]}")
                                        if p[1].grad is None:
                                            #print("p[1].grad is None for JAC !")
                                            p[1].grad=lst_jac_grad[p[0]].clone()
                                        else:
                                            p[1].grad+=lst_jac_grad[p[0]].clone()
                                        lst_grad_jac_norm.append(lst_jac_grad[p[0]].norm(2).item())
                                    elif p[1].requires_grad:
                                        lst_grad_jac_norm.append(0.)
                                    #compute total norm
                                    if p[1].requires_grad:
                                        if p[1].grad is None:
                                            lst_grad_total_norm.append(0.)
                                        else:
                                            val_total_grad=(p[1].grad.detach()).clone()#Contains gradient for element associate to max spectral radius
                                            lst_grad_total_norm.append(val_total_grad.norm(2).item())
                            if compute_grad_norms and twriter is True:
                                writer.add_scalars("GradLoss",{"MSE ell_1,2":np.sum(lst_grad_mse_norm),
                                    "JAC ell_1,2":np.sum(lst_grad_jac_norm)},global_step=(epoch-1)*n_batch_train+i)
                                if i==0:
                                    fig=plt.figure(figsize=[12,8])
                                    str_label=[p[0] for p in params_diff]
                                    _=plt.plot(range(0, len(params_diff)), lst_grad_mse_norm,label="Grad of MSE")
                                    _=plt.plot(range(0, len(params_diff)), lst_grad_jac_norm,label="Grad of Jacobian Regularization")
                                    _=plt.plot(range(0, len(params_diff)), lst_grad_total_norm,label="Total Grad")
                                    ax=plt.gca()
                                    ax.set_xticks(range(0, len(params_diff)))
                                    ax.set_xticklabels(str_label,rotation=90)
                                    plt.xlabel('Parameters')
                                    plt.ylabel('gradient norm value(Training Data Sample {})'.format(i+1))
                                    plt.legend()
                                    writer.add_figure("Grad Norm Training batch 0",fig,global_step=epoch-1,close=True)

                        else:
                            total_loss=loss_batch_mse+reg_loss_val
                            total_loss.backward()
                            lst_grad_total_norm=[]
                            for p in params_model:
                                if p[1].requires_grad:
                                    if p[1].grad is None:
                                        lst_grad_total_norm.append(0)
                                    else:
                                        val_grad_total=p[1].grad.detach().clone()
                                        lst_grad_total_norm.append(val_grad_total.norm(2).item())
                            if compute_grad_norms and twriter is True:
                                if i==0:
                                    fig=plt.figure(figsize=[12,8])
                                    str_label=[p[0] for p in params_diff]
                                    _=plt.plot(range(0, len(params_diff)), lst_grad_total_norm,label="Total Grad")
                                    ax=plt.gca()
                                    ax.set_xticks(range(0, len(params_diff)))
                                    ax.set_xticklabels(str_label,rotation=90)
                                    plt.xlabel('Parameters')
                                    plt.ylabel('gradient norm value(Training Data Sample {})'.format(i+1))
                                    plt.legend()
                                    writer.add_figure("Grad Norm Training batch 0",fig,global_step=epoch-1,close=True)


                        ###########################################################
                        # DESCENT+UPDATE BATCH STATS
                        ###########################################################
                        #Perform optimizer step
                        optimizer.step()
                        optimizer.zero_grad()
                        if accumulate_grad>0:
                            for p in params_model:
                                lst_mse_grad[p[0]]=None
                                lst_jac_grad[p[0]]=None
                        #Save accumulated batch loss
                        train_loss_batch.append(loss_batch_mse.item()/(curBatchAcc)+reg_loss_val.item())
                        epoch_train_mse+=epoch_batch_mse
                        epoch_loss_reg+= reg_loss_val.item()*(curBatchAcc)
                        curBatchAcc=0
                        jac_batch_max=0
                        epoch_batch_mse=0

                    del inputs, outputs, labels
                    pbar_batch.update(train_batch_size)

            ###########################################################
            # SAVE GLOBAL STATS
            ###########################################################
            train_loss_mse.append(epoch_train_mse/n_batch_train)
            train_loss_reg.append(epoch_loss_reg/n_batch_train)
            train_loss.append((epoch_train_mse+epoch_loss_reg)/n_batch_train)
            if twriter is True:
                writer.add_scalar("Loss/Train_Total_loss",train_loss[-1],global_step=(epoch-1))
                writer.add_scalar("Loss/Train_MSE",train_loss_mse[-1],global_step=(epoch-1))
                writer.add_scalar("Loss/Train_Jac",train_loss_reg[-1],global_step=(epoch-1))
            print("Prediction")
            test_eval = evaluate(model, test_loader, paramsTraining,device = device)
            print(f"Prediction test Model.is_cuda={next(model.parameters()).is_cuda}")

            if twriter is True:
                print("Batch 0 test set")
                denoised=predict_np(model,test_loader.dataset[0][0].detach().cpu().numpy(),device)
                vmax=test_loader.dataset[0][1].max()*0.75
                if epoch==1:
                    fig=display3D(test_loader.dataset[0][0].detach().cpu().numpy(),
                                  interpolation='none',vmax=vmax,title="Input of Network")
                    writer.add_figure("Test El 0-input network",fig,global_step=0,close=True)
                    fig=display3D(test_loader.dataset[0][1].detach().cpu().numpy(),
                                  interpolation='none',vmax=vmax,title="Target")
                    writer.add_figure("Test El 0-target",fig,global_step=0,close=True)
                fig=display3D(denoised,interpolation='none',vmax=vmax,
                                      title="Output of Network")
                writer.add_figure("Test El 0-output network",fig,global_step=epoch-1,close=True)

            if paramsTraining.name_save is not None:
                if paramsTraining.jacobian_reg is True:
                    save_model_fname= os.path.join(paramsTraining.save_dir, paramsTraining.name_save.replace(".pth",
                                    f"_sjlam{paramsTraining.sj_lambda}_sjiter{paramsTraining.sj_iter}_ep{epoch}.pth"))
                else:
                    save_model_fname=os.path.join(paramsTraining.save_dir, paramsTraining.name_save.replace(".pth",
                                    f"_ep{epoch}.pth"))
                print(f"Save model {save_model_fname}")
                torch.save(model,save_model_fname)

            print(f"Epoch {epoch}: Train MSE: {epoch_train_mse/n_batch_train},"+\
                    f" Test MSE: {test_eval}, Train total Loss: {epoch_loss/n_batch_train}")
            pbar_epoch.update(1)

            if paramsTraining.patience != 0:
                scheduler.step(test_eval)
            test_mse.append(test_eval)
            if twriter is True:
                writer.add_scalar("Loss/Test_MSE",test_eval,global_step=epoch-1)
            if paramsTraining.jacobian_reg:
                spectral_jacobian_train.append(epoch_reg_loss_max)

            if paramsTraining.eval_jacobian:
                j1, j1_all = estimate_sj(model, train_loader, device, paramsTraining,
                                                    show = False, data = 'Training Data',device_to=device)
                if twriter is True:
                    writer.add_scalar("Jacobian/Train",j1,global_step=epoch-1)
                if show_sj or twriter is True:#Evolution pour chaque sample du rayon spectral au cours des itérations
                    fig=plt.figure()
                    plt.plot(range(1, paramsTraining.sj_iter+1), j1_all)
                    plt.xlabel('Epochs')
                    plt.ylabel('Jacobian Spectral Norm (Training Data)')
                    if twriter is True:
                        writer.add_figure("Max Jacobian Training set",fig,global_step=epoch-1,close=True)
                    else:
                        plt.show()
                        plt.close()
            if paramsTraining.jacobian_reg:
                j2, j2_all = estimate_sj(model, test_loader, device, paramsTraining,
                    show = False, data = 'Testing Data',device_to=device)
                spectral_jacobian_test.append(j2)
                if twriter is True:
                    writer.add_scalar("Jacobian/Test",j2,global_step=epoch-1)

                if show_sj or twriter is True:#Evolution pour chaque sample du rayon spectral au cours des itérations
                    fig=plt.figure()
                    plt.plot(range(1, paramsTraining.sj_iter+1), j2_all)
                    plt.xlabel('Epochs')
                    plt.ylabel('Jacobian Spectral Norm (Testing Data)')
                    if show_sj or twriter is True:#Evolution pour chaque sample du rayon spectral au cours des itérations
                        if twriter is True:
                            writer.add_figure("Max Jacobian Test set",fig,global_step=epoch-1,close=True)
                        else:
                            plt.show()
                            plt.close()

            if show:
                fig=evalStats.show_metrics(train_loss_mse, test_mse, train_loss, train_loss_batch,close=False)
                if twriter is True:
                    writer.add_figure("Metrics",fig,global_step=0,close=True)
                else:
                    plt.show()
                    plt.close(fig)

                if paramsTraining.jacobian_reg:
                    fig=evalStats.show_metric2(train_loss_mse, train_loss_reg, xlabel = 'Epochs',
                        ylabel = 'Loss', legend1 = 'MSE', legend2 = 'Square Jacobian Spectral Norm',close=False)
                    if twriter is True:
                        writer.add_figure("Losses",fig,global_step=0,close=True)
                    else:
                        plt.show()
                        plt.close(fig)
                    print(spectral_jacobian_train)
                    fig=evalStats.show_metric(spectral_jacobian_train, start = 0, xlabel = 'Epochs',
                        ylabel = 'Jacobian Spectral Norm (Training Data)',close=False)
                    if twriter is True:
                        writer.add_figure("Jacobian Spectral Train",fig,global_step=0,close=True)
                    else:
                        plt.show()
                        plt.close(fig)
                    print(spectral_jacobian_test)
                    fig=evalStats.show_metric(spectral_jacobian_test, start = 0, xlabel = 'Epochs',
                        ylabel = 'Jacobian Spectral Norm (Testing Data)',close=False)
                    if twriter is True:
                        writer.add_figure("Jacobian Spectral Test",fig,global_step=0,close=True)
                    else:
                        plt.show()
                        plt.close(fig)

            dico_results={}
            dico_results["train_mse"]=train_loss_mse
            dico_results["test_mse"]=test_mse
            dico_results["train_loss"]= train_loss
            dico_results["train_loss_batch"]=train_loss_batch
            dico_results["train_loss_mse"]=train_loss_mse
            dico_results["train_loss_reg"]=train_loss_reg
            dico_results["spectral_jacobian_train"]=spectral_jacobian_train
            dico_results["spectral_jacobian_test"]=spectral_jacobian_test

            if paramsTraining.name_save is not None:
                if paramsTraining.jacobian_reg is True:
                    test_name_save=f"{paramsTraining.name_save.replace('.pth','')}_lamb{paramsTraining.sj_lambda}_iter{paramsTraining.sj_iter}_ep{epoch}.pickle"
                else:
                    test_name_save=f"{paramsTraining.name_save.replace('.pth','')}_ep{epoch}.pickle"
                    print(os.path.join(paramsTraining.save_dir,test_name_save))
                with open(os.path.join(paramsTraining.save_dir,test_name_save),"wb") as handle:
                    pickle.dump(dico_results,handle,protocol=pickle.HIGHEST_PROTOCOL)

    if twriter is True:
        if evaluate:
            metric_dict={}
            metric_dict["Loss/Train_MSE"]=train_loss_mse[-1]
            metric_dict["Loss/Test_MSE"]=test_mse[-1]
            metric_dict["Loss/Train_Total_loss"]=train_loss[-1]
            if paramsTraining.jacobian_reg:
                metric_dict["Loss/Train_Jac"]=spectral_jacobian_train[-1]
            if paramsTraining.eval_jacobian:
                metric_dict["Jacobian/Train"]=j1
                metric_dict["Jacobian/Test"]=j2
            print(f"hparams_dict={hparams_dict}")
            print(f"metric_dict={metric_dict}")
            exp,ssi,_=hparams_tb(hparam_dict=hparams_dict,metric_dict=metric_dict)
            writer.file_writer.add_summary(exp)
            writer.file_writer.add_summary(ssi)
            writer.close()
    return dico_results
