# pyTorchPET

Installation is performed by running:
```shell
python setup.py clean 
python setup.py build_ext --inplace
python setup.py install 
```
or inside directory:
```shell
pip install .
```
or executing [launch_build_python.cmd](launch_build_python.cmd)
